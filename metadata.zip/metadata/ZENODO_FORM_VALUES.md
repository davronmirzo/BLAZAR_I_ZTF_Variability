# Zenodo form values

## Title
BLAZAR_I: code, tables, and figures for Population-Scale Optical Variability of Fermi Blazars in ZTF

## Creators
1. Davron Mirzaqulov
2. Sobir Turaev
3. Shuhrat Ehgamberdiev

## Resource type
Dataset

## Version
1.0.0

## Publication date
2026-09-19

## Access
Open access

## Description
This reproducibility package supports the article **Population-Scale Optical Variability of Fermi Blazars in ZTF: Stochastic Timescales, Diagnostic Calibration, and Sampling Effects**.
It contains the principal Python analysis scripts, machine-readable final tables,
vector figure products, and provenance documentation. The manuscript and manuscript
source are intentionally excluded. Raw Fermi-LAT, ZTF, and Pan-STARRS survey products
are not redistributed; users should obtain them from their original public providers.

## Keywords
blazars; FSRQ; BL Lac; Fermi-LAT; ZTF; optical variability; damped random walk;
DRW timescale; rms-flux relation; colour-magnitude relation; time-domain astronomy;
reproducibility

## Licenses
- MIT — code
- CC BY 4.0 — tables, figures, documentation

## Related identifier
After the journal DOI is assigned:
- relation: **Is supplement to**
- identifier: **journal article DOI**

## Important
Do not upload the manuscript PDF, LaTeX source, bibliography, cover letter, or journal
submission files to this record.
