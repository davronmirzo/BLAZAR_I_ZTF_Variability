# Zenodo publication checklist

Before publishing the Zenodo record:

- [ ] Confirm author spelling and order.
- [ ] Add ORCID identifiers, if available.
- [ ] Add institutional affiliations, if desired.
- [ ] Verify all ZIP contents.
- [ ] Confirm that no manuscript or journal-submission file is present.
- [ ] Confirm mixed licensing: MIT for code; CC BY 4.0 for tables/figures/docs.
- [ ] Reserve the Zenodo DOI if it is needed in the journal manuscript before publication.
- [ ] Insert the reserved DOI into `CITATION.cff` and the article Data/Code Availability statement.
- [ ] Add the journal article DOI as `Is supplement to` once that DOI exists.
- [ ] Publish Zenodo version 1.0.0 only after the final audit.
