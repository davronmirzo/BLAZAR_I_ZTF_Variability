# Environment notes

Python 3.12 is recommended for reconstruction of the analysis environment.

The original project used a Windows virtual environment. Exact third-party package
versions were not frozen into the final article package, so this archive does not
pretend to provide an exact historical lock file.

For a new rerun:

```bash
python -m venv .venv
pip install -r environment/requirements.txt
pip freeze > environment/pip-freeze-local.txt
```

Retain the generated `pip-freeze-local.txt` with any new rerun products.
