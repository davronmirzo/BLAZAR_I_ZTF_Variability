# ============================================================
# BLAZAR_I — STAGE 06B1
# COLOUR-BREAK ROBUSTNESS:
#   TIGHTER SIMULTANEITY + ERROR-AWARE LIKELIHOOD
#
# Inputs:
#   outputs/tables/stage03c_colour_pairs_master.parquet
#   outputs/tables/stage03c_colour_break_master.csv
#   outputs/tables/stage04_population_master.csv
#
# Timing cuts:
#   T6H : |dt(g-r)| <= 6 h   (primary pairing envelope)
#   T2H : |dt(g-r)| <= 2 h
#   T1H : |dt(g-r)| <= 1 h
#
# Error-aware model:
#   y = g-r, x = r
#
# Because r enters BOTH x and y, x/y measurement errors are
# correlated.  Assuming independent g and r magnitude errors,
# for a local colour-magnitude slope b,
#
#   Var[y_obs - f(x_obs)]
#       ~= sigma_g^2 + (1+b)^2 sigma_r^2 + sigma_int^2
#
# This is used directly in the Gaussian likelihood.
#
# Single line parameters:
#   c, b, sigma_int                      k=3
#
# Continuous broken line parameters:
#   c_at_break, b_left, delta_b, x_break, sigma_int   k=5
#
# BIC = 2*NLL + k*ln(N)
#
# Gates:
#   N >= 30 pairs
#   >=10 points on each side of fitted break
#
# Error-aware strong break:
#   DeltaBIC(single-broken) >= 10
#
# Error-aware robust central break:
#   DeltaBIC >= 20
#   0.15 <= break_fraction <= 0.85
#
# This is a ROBUSTNESS analysis.  It does not replace the frozen
# empirical STAGE 03C primary model.
#
# Resumable:
#   outputs/models/stage06b1_colour/
#       BZI_xxxxx_06B1.csv
#       BZI_xxxxx.done
#
# Global outputs when all sources complete:
#   outputs/tables/stage06b1_colour_erroraware_master.csv
#   outputs/tables/stage06b1_colour_erroraware_source.csv
#   outputs/tables/stage06b1_colour_timing_comparison.csv
#   outputs/audit/stage06b1_summary.txt
# ============================================================

from pathlib import Path
import argparse
import math
import warnings

import numpy as np
import pandas as pd

from scipy.optimize import minimize
from scipy.stats import fisher_exact

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

PAIR_FILE = (
    ROOT / "outputs" / "tables"
    / "stage03c_colour_pairs_master.parquet"
)

PRIMARY_FILE = (
    ROOT / "outputs" / "tables"
    / "stage03c_colour_break_master.csv"
)

POP_FILE = (
    ROOT / "outputs" / "tables"
    / "stage04_population_master.csv"
)

MODEL_DIR = (
    ROOT / "outputs" / "models"
    / "stage06b1_colour"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_MASTER = TABLE_DIR / "stage06b1_colour_erroraware_master.csv"
OUT_SOURCE = TABLE_DIR / "stage06b1_colour_erroraware_source.csv"
OUT_COMPARE = TABLE_DIR / "stage06b1_colour_timing_comparison.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06b1_summary.txt"

MODEL_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# CONFIG
# ============================================================

TIMING_CUTS_HOURS = {
    "T6H": 6.0,
    "T2H": 2.0,
    "T1H": 1.0,
}

MIN_N = 30
MIN_SIDE = 10

STRONG_DBIC = 10.0
ROBUST_DBIC = 20.0
CENTRAL_MIN = 0.15
CENTRAL_MAX = 0.85

SLOPE_BOUND = 10.0
DELTA_SLOPE_BOUND = 20.0

SIGMA_INT_MIN = 1.0e-4
SIGMA_INT_MAX = 2.0

BREAK_START_QUANTILES = [
    0.20,
    0.35,
    0.50,
    0.65,
    0.80,
]


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def finite_array(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    ).to_numpy(dtype=float)


def robust_scale(y):
    y = np.asarray(y, dtype=float)

    med = np.median(y)
    mad = np.median(
        np.abs(y - med)
    )

    if np.isfinite(mad) and mad > 0:
        return 1.4826 * mad

    sd = np.std(y, ddof=1)

    if np.isfinite(sd) and sd > 0:
        return sd

    return 0.05


def single_nll(
    pars,
    x,
    y,
    sg,
    sr,
    x0,
):
    c, b, log_sint = pars

    sint = math.exp(log_sint)

    mu = (
        c
        +
        b * (x - x0)
    )

    var = (
        sg ** 2
        +
        (1.0 + b) ** 2 * sr ** 2
        +
        sint ** 2
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= 0)
    ):
        return 1.0e100

    resid = y - mu

    return 0.5 * float(
        np.sum(
            np.log(2.0 * np.pi * var)
            +
            resid ** 2 / var
        )
    )


def broken_nll(
    pars,
    x,
    y,
    sg,
    sr,
):
    c, b_left, db, xb, log_sint = pars

    left = x <= xb
    right = ~left

    if (
        int(left.sum()) < MIN_SIDE
        or
        int(right.sum()) < MIN_SIDE
    ):
        return 1.0e100

    b_right = b_left + db

    sint = math.exp(log_sint)

    dx = x - xb

    mu = (
        c
        +
        b_left * dx
        +
        db * np.maximum(
            dx,
            0.0
        )
    )

    local_b = np.where(
        left,
        b_left,
        b_right
    )

    var = (
        sg ** 2
        +
        (1.0 + local_b) ** 2 * sr ** 2
        +
        sint ** 2
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= 0)
    ):
        return 1.0e100

    resid = y - mu

    return 0.5 * float(
        np.sum(
            np.log(2.0 * np.pi * var)
            +
            resid ** 2 / var
        )
    )


def initial_ols(x, y):
    x0 = float(np.median(x))

    A = np.column_stack(
        [
            np.ones(len(x)),
            x - x0,
        ]
    )

    beta, *_ = np.linalg.lstsq(
        A,
        y,
        rcond=None
    )

    c = float(beta[0])
    b = float(
        np.clip(
            beta[1],
            -SLOPE_BOUND,
            SLOPE_BOUND
        )
    )

    return x0, c, b


def fit_single(
    x,
    y,
    sg,
    sr,
):
    x0, c0, b0 = initial_ols(
        x,
        y
    )

    s0 = max(
        SIGMA_INT_MIN * 10.0,
        min(
            robust_scale(y) * 0.5,
            0.5
        )
    )

    starts = [
        [c0, b0, math.log(s0)],
        [float(np.median(y)), 0.0, math.log(s0)],
        [c0, b0, math.log(0.02)],
        [c0, b0, math.log(0.10)],
    ]

    c_pad = max(
        1.0,
        4.0 * robust_scale(y)
    )

    c_lo = float(
        np.median(y) - c_pad
    )

    c_hi = float(
        np.median(y) + c_pad
    )

    bounds = [
        (c_lo, c_hi),
        (-SLOPE_BOUND, SLOPE_BOUND),
        (
            math.log(SIGMA_INT_MIN),
            math.log(SIGMA_INT_MAX),
        ),
    ]

    best = None

    for start in starts:
        res = minimize(
            single_nll,
            x0=np.asarray(start, dtype=float),
            args=(x, y, sg, sr, x0),
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 500,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(res.fun):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    c, b, log_sint = best.x

    return {
        "success": bool(best.success),
        "nll": float(best.fun),
        "c": float(c),
        "slope": float(b),
        "sigma_int": float(
            math.exp(log_sint)
        ),
        "x0": float(x0),
        "message": str(best.message),
    }


def fit_broken(
    x,
    y,
    sg,
    sr,
    single_fit,
):
    xs = np.sort(x)

    if len(xs) < MIN_N:
        return None

    # Bounds that can support >=MIN_SIDE on both sides.
    x_lo = float(
        xs[MIN_SIDE - 1]
    )

    x_hi = float(
        xs[-MIN_SIDE]
    )

    if not (
        np.isfinite(x_lo)
        and
        np.isfinite(x_hi)
        and
        x_hi > x_lo
    ):
        return None

    x0_single = single_fit["x0"]
    c_single = single_fit["c"]
    b_single = single_fit["slope"]
    sint_single = single_fit["sigma_int"]

    starts = []

    for q in BREAK_START_QUANTILES:
        xb0 = float(
            np.quantile(
                x,
                q
            )
        )

        xb0 = float(
            np.clip(
                xb0,
                x_lo,
                x_hi
            )
        )

        c_at_xb = (
            c_single
            +
            b_single
            * (xb0 - x0_single)
        )

        starts.append(
            [
                c_at_xb,
                b_single,
                0.0,
                xb0,
                math.log(
                    max(
                        sint_single,
                        SIGMA_INT_MIN
                    )
                ),
            ]
        )

    # Add simple left/right OLS starts.
    for q in [0.35, 0.50, 0.65]:
        xb0 = float(
            np.clip(
                np.quantile(x, q),
                x_lo,
                x_hi
            )
        )

        left = x <= xb0
        right = x > xb0

        if (
            left.sum() < MIN_SIDE
            or
            right.sum() < MIN_SIDE
        ):
            continue

        def slope_only(xx, yy):
            if len(xx) < 2:
                return 0.0

            xx0 = xx - np.mean(xx)
            den = float(
                np.sum(xx0 ** 2)
            )

            if den <= 0:
                return 0.0

            return float(
                np.sum(
                    xx0
                    *
                    (yy - np.mean(yy))
                )
                /
                den
            )

        bl = np.clip(
            slope_only(
                x[left],
                y[left]
            ),
            -SLOPE_BOUND,
            SLOPE_BOUND
        )

        br = np.clip(
            slope_only(
                x[right],
                y[right]
            ),
            -SLOPE_BOUND,
            SLOPE_BOUND
        )

        db0 = float(
            np.clip(
                br - bl,
                -DELTA_SLOPE_BOUND,
                DELTA_SLOPE_BOUND
            )
        )

        c0 = float(
            np.median(
                y[
                    np.argsort(
                        np.abs(
                            x - xb0
                        )
                    )[:max(
                        5,
                        min(
                            20,
                            len(x)
                        )
                    )]
                ]
            )
        )

        starts.append(
            [
                c0,
                float(bl),
                db0,
                xb0,
                math.log(
                    max(
                        sint_single,
                        SIGMA_INT_MIN
                    )
                ),
            ]
        )

    c_pad = max(
        1.0,
        4.0 * robust_scale(y)
    )

    c_med = float(
        np.median(y)
    )

    bounds = [
        (
            c_med - c_pad,
            c_med + c_pad
        ),
        (
            -SLOPE_BOUND,
            SLOPE_BOUND
        ),
        (
            -DELTA_SLOPE_BOUND,
            DELTA_SLOPE_BOUND
        ),
        (
            x_lo,
            x_hi
        ),
        (
            math.log(SIGMA_INT_MIN),
            math.log(SIGMA_INT_MAX)
        ),
    ]

    best = None

    for start in starts:

        res = minimize(
            broken_nll,
            x0=np.asarray(
                start,
                dtype=float
            ),
            args=(x, y, sg, sr),
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 700,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(res.fun):
            continue

        c, b_left, db, xb, log_sint = res.x

        n_left = int(
            (x <= xb).sum()
        )

        n_right = int(
            (x > xb).sum()
        )

        if (
            n_left < MIN_SIDE
            or
            n_right < MIN_SIDE
        ):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    c, b_left, db, xb, log_sint = best.x

    return {
        "success": bool(best.success),
        "nll": float(best.fun),
        "c_break": float(c),
        "slope_left": float(b_left),
        "slope_right": float(
            b_left + db
        ),
        "delta_slope": float(db),
        "break_r_mag": float(xb),
        "sigma_int": float(
            math.exp(log_sint)
        ),
        "message": str(best.message),
    }


def analyze_cut(
    source_pairs,
    blazar_id,
    blazar_class,
    cut_name,
    cut_hours,
):
    xdf = source_pairs.loc[
        source_pairs[
            "dt_gr_hours"
        ].abs()
        <=
        cut_hours
    ].copy()

    row = {
        "blazar_id": blazar_id,
        "blazar_class": blazar_class,
        "timing_cut": cut_name,
        "timing_cut_hours": cut_hours,
        "N_pairs": int(len(xdf)),
        "fit_status": "NOT_RUN",
    }

    if len(xdf) < MIN_N:
        row["fit_status"] = (
            f"TOO_FEW_PAIRS_LT_{MIN_N}"
        )
        return row

    x = finite_array(
        xdf["r_mag"]
    )

    y = finite_array(
        xdf["g_minus_r"]
    )

    sg = finite_array(
        xdf["g_magerr"]
    )

    sr = finite_array(
        xdf["r_magerr"]
    )

    good = (
        np.isfinite(x)
        &
        np.isfinite(y)
        &
        np.isfinite(sg)
        &
        np.isfinite(sr)
        &
        (sg > 0)
        &
        (sr > 0)
    )

    x = x[good]
    y = y[good]
    sg = sg[good]
    sr = sr[good]

    row["N_pairs_finite"] = int(
        len(x)
    )

    if len(x) < MIN_N:
        row["fit_status"] = (
            f"TOO_FEW_FINITE_PAIRS_LT_{MIN_N}"
        )
        return row

    rmin = float(
        np.min(x)
    )

    rmax = float(
        np.max(x)
    )

    rrange = (
        rmax - rmin
    )

    row["r_mag_min"] = rmin
    row["r_mag_max"] = rmax
    row["r_mag_range"] = rrange

    if not (
        np.isfinite(rrange)
        and
        rrange > 0
    ):
        row["fit_status"] = (
            "DEGENERATE_R_RANGE"
        )
        return row

    single = fit_single(
        x,
        y,
        sg,
        sr
    )

    if single is None:
        row["fit_status"] = (
            "SINGLE_FIT_FAILED"
        )
        return row

    broken = fit_broken(
        x,
        y,
        sg,
        sr,
        single
    )

    if broken is None:
        row["fit_status"] = (
            "BROKEN_FIT_FAILED"
        )
        return row

    n = len(x)

    bic_single = (
        2.0 * single["nll"]
        +
        3.0 * math.log(n)
    )

    bic_broken = (
        2.0 * broken["nll"]
        +
        5.0 * math.log(n)
    )

    delta_bic = (
        bic_single
        -
        bic_broken
    )

    break_frac = (
        (
            broken["break_r_mag"]
            -
            rmin
        )
        /
        rrange
    )

    strong = (
        single["success"]
        and
        broken["success"]
        and
        delta_bic >= STRONG_DBIC
    )

    robust = (
        strong
        and
        delta_bic >= ROBUST_DBIC
        and
        CENTRAL_MIN
        <=
        break_frac
        <=
        CENTRAL_MAX
    )

    row.update({
        "single_optimizer_success": bool(
            single["success"]
        ),
        "broken_optimizer_success": bool(
            broken["success"]
        ),
        "single_nll": single["nll"],
        "broken_nll": broken["nll"],
        "single_bic": bic_single,
        "broken_bic": bic_broken,
        "delta_bic_single_minus_broken": delta_bic,
        "single_slope": single["slope"],
        "single_sigma_int_mag": single["sigma_int"],
        "break_r_mag": broken["break_r_mag"],
        "break_fraction": break_frac,
        "break_slope_left": broken["slope_left"],
        "break_slope_right": broken["slope_right"],
        "break_delta_slope": broken["delta_slope"],
        "broken_sigma_int_mag": broken["sigma_int"],
        "strong_break_bic10_ea": bool(strong),
        "robust_central_break_bic20_ea": bool(robust),
        "fit_status": "OK",
    })

    return row


def fisher_class_effect(df, flag_col):
    flag = as_bool(
        df[flag_col]
    )

    fsrq = (
        df["blazar_class"]
        .astype(str)
        .eq("FSRQ")
    )

    a = int(
        (fsrq & flag).sum()
    )

    b = int(
        (fsrq & ~flag).sum()
    )

    c = int(
        (~fsrq & flag).sum()
    )

    d = int(
        (~fsrq & ~flag).sum()
    )

    table = np.array(
        [
            [a, b],
            [c, d],
        ],
        dtype=int
    )

    orr, p = fisher_exact(
        table,
        alternative="two-sided"
    )

    return {
        "FSRQ_positive": a,
        "FSRQ_total": a + b,
        "BLL_positive": c,
        "BLL_total": c + d,
        "odds_ratio_FSRQ_vs_BLL": float(orr),
        "fisher_p": float(p),
    }


def classification_compare(
    a,
    b,
):
    a = np.asarray(
        a,
        dtype=bool
    )

    b = np.asarray(
        b,
        dtype=bool
    )

    agreement = float(
        np.mean(
            a == b
        )
    )

    inter = int(
        np.sum(
            a & b
        )
    )

    union = int(
        np.sum(
            a | b
        )
    )

    jaccard = (
        inter / union
        if union > 0
        else np.nan
    )

    return agreement, jaccard


# ============================================================
# MAIN
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="Process only first N not-yet-complete sources.",
)

args = parser.parse_args()

for path in [
    PAIR_FILE,
    PRIMARY_FILE,
    POP_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

pairs = pd.read_parquet(
    PAIR_FILE
)

primary = pd.read_csv(
    PRIMARY_FILE
)

pop = pd.read_csv(
    POP_FILE
)

for df in [
    pairs,
    primary,
    pop,
]:
    df["blazar_id"] = (
        df["blazar_id"]
        .astype(str)
    )

source_ids = (
    primary["blazar_id"]
    .drop_duplicates()
    .tolist()
)

if len(source_ids) != 1061:
    raise RuntimeError(
        f"Expected 1061 sources; got {len(source_ids)}"
    )

class_lookup = (
    pop[
        [
            "blazar_id",
            "blazar_class",
        ]
    ]
    .drop_duplicates("blazar_id")
    .set_index("blazar_id")[
        "blazar_class"
    ]
    .to_dict()
)

grouped = {
    bid: g.copy()
    for bid, g in pairs.groupby(
        "blazar_id",
        sort=False
    )
}

completed = set(
    p.stem
    for p in MODEL_DIR.glob(
        "*.done"
    )
)

todo = [
    bid
    for bid in source_ids
    if bid not in completed
]

if args.limit is not None:
    todo = todo[
        :args.limit
    ]

print("=" * 78)
print("BLAZAR_I — STAGE 06B1")
print("TIGHTER SIMULTANEITY + ERROR-AWARE COLOUR-BREAK LIKELIHOOD")
print("=" * 78)
print(f"Total sources     = {len(source_ids)}")
print(f"Already complete  = {len(completed)}")
print(f"This run           = {len(todo)}")
print()

for i, bid in enumerate(
    todo,
    start=1
):
    if bid not in grouped:
        raise RuntimeError(
            f"No colour pairs found for {bid}"
        )

    g = grouped[bid]

    cls = class_lookup.get(
        bid,
        np.nan
    )

    rows = []

    for cut_name, cut_hours in TIMING_CUTS_HOURS.items():

        rows.append(
            analyze_cut(
                source_pairs=g,
                blazar_id=bid,
                blazar_class=cls,
                cut_name=cut_name,
                cut_hours=cut_hours,
            )
        )

    out = pd.DataFrame(
        rows
    )

    out_path = (
        MODEL_DIR
        /
        f"{bid}_06B1.csv"
    )

    out.to_csv(
        out_path,
        index=False
    )

    done_path = (
        MODEL_DIR
        /
        f"{bid}.done"
    )

    done_path.write_text(
        "OK\n",
        encoding="utf-8"
    )

    if (
        i <= 5
        or
        i % 100 == 0
        or
        i == len(todo)
    ):
        status_bits = []

        for _, rr in out.iterrows():
            status_bits.append(
                f"{rr['timing_cut']}:N={int(rr['N_pairs'])},"
                f"robust={bool(rr.get('robust_central_break_bic20_ea', False))},"
                f"status={rr['fit_status']}"
            )

        print(
            f"{i}/{len(todo)} {bid} | "
            +
            " | ".join(status_bits)
        )


# ============================================================
# STATUS / GLOBAL ASSEMBLY
# ============================================================

done_files = list(
    MODEL_DIR.glob(
        "*.done"
    )
)

n_done = len(
    done_files
)

remaining = (
    len(source_ids)
    -
    n_done
)

print()
print("=" * 78)
print("STAGE 06B1 CURRENT STATUS")
print("=" * 78)
print(
    f"Completed sources = {n_done} / {len(source_ids)}"
)
print(
    f"Remaining         = {remaining}"
)

if remaining > 0:
    print()
    print(
        "Partial run complete. "
        "Re-run the same command to resume."
    )
    raise SystemExit(0)


# ============================================================
# GLOBAL TABLES
# ============================================================

csv_files = sorted(
    MODEL_DIR.glob(
        "BZI_*_06B1.csv"
    )
)

master = pd.concat(
    [
        pd.read_csv(f)
        for f in csv_files
    ],
    ignore_index=True
)

if len(master) != (
    len(source_ids)
    *
    len(TIMING_CUTS_HOURS)
):
    raise RuntimeError(
        "Unexpected global row count: "
        f"{len(master)}"
    )

for c in [
    "single_optimizer_success",
    "broken_optimizer_success",
    "strong_break_bic10_ea",
    "robust_central_break_bic20_ea",
]:
    if c in master.columns:
        master[c] = as_bool(
            master[c]
        )

master.to_csv(
    OUT_MASTER,
    index=False
)


# ============================================================
# SOURCE-LEVEL WIDE TABLE
# ============================================================

keep = [
    "blazar_id",
    "blazar_class",
    "timing_cut",
    "N_pairs",
    "fit_status",
    "delta_bic_single_minus_broken",
    "break_r_mag",
    "break_fraction",
    "strong_break_bic10_ea",
    "robust_central_break_bic20_ea",
]

wide = master[
    keep
].pivot(
    index=[
        "blazar_id",
        "blazar_class",
    ],
    columns="timing_cut"
)

wide.columns = [
    f"{metric}_{cut}"
    for metric, cut in wide.columns
]

wide = wide.reset_index()

primary2 = primary[
    [
        "blazar_id",
        "break_r_mag",
        "delta_bic_single_minus_broken",
        "r_mag_min",
        "r_mag_max",
    ]
].copy()

primary2["primary_break_fraction"] = (
    (
        primary2["break_r_mag"]
        -
        primary2["r_mag_min"]
    )
    /
    (
        primary2["r_mag_max"]
        -
        primary2["r_mag_min"]
    )
)

primary2["primary_robust_central_break"] = (
    (
        primary2[
            "delta_bic_single_minus_broken"
        ]
        >=
        ROBUST_DBIC
    )
    &
    primary2[
        "primary_break_fraction"
    ].between(
        CENTRAL_MIN,
        CENTRAL_MAX,
        inclusive="both"
    )
)

primary2 = primary2.rename(
    columns={
        "break_r_mag": "primary_break_r_mag",
        "delta_bic_single_minus_broken": "primary_delta_bic",
    }
)

source = wide.merge(
    primary2[
        [
            "blazar_id",
            "primary_break_r_mag",
            "primary_delta_bic",
            "primary_break_fraction",
            "primary_robust_central_break",
        ]
    ],
    on="blazar_id",
    how="left",
    validate="one_to_one"
)

source.to_csv(
    OUT_SOURCE,
    index=False
)


# ============================================================
# COMPARISONS
# ============================================================

compare_rows = []

# 6h error-aware vs frozen primary.
mask6 = (
    master["timing_cut"].eq("T6H")
    &
    master["fit_status"].eq("OK")
)

ea6 = (
    master.loc[
        mask6,
        [
            "blazar_id",
            "robust_central_break_bic20_ea",
            "break_r_mag",
        ]
    ]
    .set_index("blazar_id")
)

pcomp = (
    primary2
    .set_index("blazar_id")
    .loc[
        ea6.index
    ]
)

a = ea6[
    "robust_central_break_bic20_ea"
].astype(bool)

b = pcomp[
    "primary_robust_central_break"
].astype(bool)

agreement, jaccard = classification_compare(
    a,
    b
)

both = (
    a & b
)

if both.sum() > 0:
    break_diff = np.abs(
        ea6.loc[
            both,
            "break_r_mag"
        ].to_numpy(dtype=float)
        -
        pcomp.loc[
            both,
            "primary_break_r_mag"
        ].to_numpy(dtype=float)
    )

    med_break_diff = float(
        np.median(
            break_diff
        )
    )
else:
    med_break_diff = np.nan

compare_rows.append({
    "comparison": "EA_T6H_vs_PRIMARY03C",
    "N_common_eligible": int(len(a)),
    "agreement": agreement,
    "jaccard": jaccard,
    "both_robust_N": int(both.sum()),
    "median_abs_break_diff_mag": med_break_diff,
})

# Timing stability within the same error-aware model.
base6 = (
    master.loc[
        master["timing_cut"].eq("T6H")
        &
        master["fit_status"].eq("OK")
    ]
    .set_index("blazar_id")
)

for cut in [
    "T2H",
    "T1H",
]:
    tight = (
        master.loc[
            master["timing_cut"].eq(cut)
            &
            master["fit_status"].eq("OK")
        ]
        .set_index("blazar_id")
    )

    common_ids = (
        base6.index
        .intersection(
            tight.index
        )
    )

    a = base6.loc[
        common_ids,
        "robust_central_break_bic20_ea"
    ].astype(bool)

    b = tight.loc[
        common_ids,
        "robust_central_break_bic20_ea"
    ].astype(bool)

    agreement, jaccard = classification_compare(
        a,
        b
    )

    both = (
        a & b
    )

    if both.sum() > 0:
        diff = np.abs(
            base6.loc[
                common_ids,
                "break_r_mag"
            ][both].to_numpy(dtype=float)
            -
            tight.loc[
                common_ids,
                "break_r_mag"
            ][both].to_numpy(dtype=float)
        )

        rrange = (
            base6.loc[
                common_ids,
                "r_mag_range"
            ][both].to_numpy(dtype=float)
        )

        norm = (
            diff
            /
            rrange
        )

        med_diff = float(
            np.median(diff)
        )

        med_norm = float(
            np.median(norm)
        )
    else:
        med_diff = np.nan
        med_norm = np.nan

    compare_rows.append({
        "comparison": f"EA_T6H_vs_{cut}",
        "N_common_eligible": int(
            len(common_ids)
        ),
        "agreement": agreement,
        "jaccard": jaccard,
        "both_robust_N": int(
            both.sum()
        ),
        "median_abs_break_diff_mag": med_diff,
        "median_abs_break_diff_over_range": med_norm,
    })

compare = pd.DataFrame(
    compare_rows
)

compare.to_csv(
    OUT_COMPARE,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06B1 FINAL SUMMARY",
    "=" * 72,
    "",
    "ERROR-AWARE COLOUR-BREAK RESULTS:",
]

for cut in [
    "T6H",
    "T2H",
    "T1H",
]:
    x = master.loc[
        master["timing_cut"].eq(cut)
    ]

    ok = x.loc[
        x["fit_status"].eq("OK")
    ]

    strong_n = int(
        ok[
            "strong_break_bic10_ea"
        ].sum()
    )

    robust_n = int(
        ok[
            "robust_central_break_bic20_ea"
        ].sum()
    )

    class_stats = fisher_class_effect(
        ok,
        "robust_central_break_bic20_ea"
    )

    lines += [
        "",
        f"{cut}:",
        f"  fit OK = {len(ok)} / {len(x)}",
        f"  strong EA break (DeltaBIC>=10) = {strong_n}",
        f"  robust central EA break = {robust_n}",
        (
            "  FSRQ robust fraction = "
            f"{class_stats['FSRQ_positive']}/"
            f"{class_stats['FSRQ_total']}"
        ),
        (
            "  BLL robust fraction  = "
            f"{class_stats['BLL_positive']}/"
            f"{class_stats['BLL_total']}"
        ),
        (
            "  raw class OR(FSRQ/BLL) = "
            f"{class_stats['odds_ratio_FSRQ_vs_BLL']:.3f}, "
            f"p={class_stats['fisher_p']:.3g}"
        ),
    ]

lines += [
    "",
    "CLASSIFICATION / BREAK STABILITY:",
]

for _, rr in compare.iterrows():
    line = (
        f"  {rr['comparison']}: "
        f"N={int(rr['N_common_eligible'])}, "
        f"agreement={rr['agreement']:.3f}, "
        f"Jaccard={rr['jaccard']:.3f}, "
        f"both_robust={int(rr['both_robust_N'])}, "
        f"median |Delta break|={rr['median_abs_break_diff_mag']:.3f} mag"
    )

    if (
        "median_abs_break_diff_over_range"
        in rr.index
        and
        pd.notna(
            rr[
                "median_abs_break_diff_over_range"
            ]
        )
    ):
        line += (
            ", median normalized="
            f"{rr['median_abs_break_diff_over_range']:.3f}"
        )

    lines.append(
        line
    )

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("GLOBAL FILES SAVED")
print("=" * 78)
print(OUT_MASTER)
print(OUT_SOURCE)
print(OUT_COMPARE)
print(OUT_SUMMARY)
print()
print("STAGE 06B1 COMPLETE")
