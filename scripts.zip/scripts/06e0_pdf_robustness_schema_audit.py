# ============================================================
# BLAZAR_I — STAGE 06E0
# FLUX-PDF / MIXTURE ROBUSTNESS INPUT AUDIT
#
# Purpose:
#   Inventory the exact frozen STAGE 03A products and columns before
#   building the final flux-PDF robustness tests.
#
# Why:
#   rms-flux, colour-break, DRW, and selection-function diagnostics
#   now have dedicated robustness analyses. The flux-PDF / mixture
#   diagnostic still needs an explicit sampling-dependence check.
#
# Read-only.
# ============================================================

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

OUT = AUDIT_DIR / "stage06e0_pdf_schema_audit.txt"

patterns = [
    "stage03a*.csv",
    "stage03a*.parquet",
    "stage04_population_master.csv",
]

files = []

for pat in patterns:
    files.extend(
        sorted(
            TABLE_DIR.glob(pat)
        )
    )

files = list(
    dict.fromkeys(files)
)

keywords = [
    "blazar_id",
    "class",
    "filter",
    "n_",
    "fvar",
    "gauss",
    "lognormal",
    "double",
    "gmm",
    "bic",
    "aic",
    "weight",
    "separation",
    "preferred",
    "robust",
    "flux",
]

lines = [
    "BLAZAR_I - STAGE 06E0 FLUX-PDF ROBUSTNESS INPUT AUDIT",
    "=" * 78,
]

if not files:
    lines.append(
        "NO MATCHING STAGE03A / STAGE04 FILES FOUND"
    )

for path in files:
    try:
        if path.suffix.lower() == ".csv":
            df = pd.read_csv(path)
        else:
            df = pd.read_parquet(path)

        lines += [
            "",
            "-" * 78,
            f"FILE: {path.relative_to(ROOT)}",
            f"  rows={len(df)} columns={len(df.columns)}",
            "  RELEVANT COLUMNS:",
        ]

        relevant = [
            c
            for c in df.columns
            if any(
                k in c.lower()
                for k in keywords
            )
        ]

        for c in relevant:
            s = df[c]

            line = (
                f"    {c}: dtype={s.dtype}, "
                f"nonnull={int(s.notna().sum())}, "
                f"unique={int(s.nunique(dropna=True))}"
            )

            if s.nunique(dropna=True) <= 12:
                try:
                    counts = (
                        s.value_counts(
                            dropna=False
                        )
                        .head(20)
                        .to_dict()
                    )

                    line += (
                        f", counts={counts}"
                    )
                except Exception:
                    pass

            lines.append(line)

    except Exception as exc:
        lines += [
            "",
            f"FILE: {path.relative_to(ROOT)}",
            (
                "  READ FAILED: "
                f"{type(exc).__name__}: {exc}"
            ),
        ]

# Nightly schema confirmation from one analysis source.
sample_files = sorted(
    NIGHTLY_DIR.glob(
        "BZI_*_NIGHTLY.parquet"
    )
)

if sample_files:
    p = sample_files[0]
    df = pd.read_parquet(p)

    lines += [
        "",
        "-" * 78,
        "NIGHTLY INPUT SCHEMA EXAMPLE:",
        f"FILE: {p.relative_to(ROOT)}",
        f"  rows={len(df)} columns={len(df.columns)}",
    ]

    for c in df.columns:
        s = df[c]

        lines.append(
            f"    {c}: dtype={s.dtype}, "
            f"nonnull={int(s.notna().sum())}"
        )

text = "\n".join(
    lines
)

OUT.write_text(
    text,
    encoding="utf-8"
)

print(text)
print()
print("AUDIT SAVED:")
print(OUT)
print()
print("STAGE 06E0 COMPLETE")
