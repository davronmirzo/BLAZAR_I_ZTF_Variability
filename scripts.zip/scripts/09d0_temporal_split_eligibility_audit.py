# ============================================================
# BLAZAR_I — STAGE 09D0
# TEMPORAL EARLY/LATE VALIDATION ELIGIBILITY AUDIT
#
# Purpose:
#   Before refitting any endpoint on temporal halves, quantify how much
#   information remains in EARLY and LATE contiguous time blocks.
#
# Split definition:
#   For each blazar, define one common temporal midpoint using the union
#   of all valid g/r nightly observations:
#
#       t_split = 0.5 * (min(hmjd) + max(hmjd))
#
#   EARLY: hmjd <= t_split
#   LATE : hmjd >  t_split
#
#   The SAME split is applied to g and r so cross-band diagnostics refer
#   to the same temporal epochs.
#
# Exact eligibility audits:
#
#   RMS-FLUX primary:
#       >=160 nightly points/filter/half
#       (= 8 complete x 20-point segments)
#
#   COLOUR primary broken-line:
#       >=30 paired g-r nights/half
#       same night_id and |dt| <= 0.25 d
#
#   FLAGSHIP temporal validation:
#       rms-flux eligible in BOTH g and r in BOTH halves
#       AND colour-break eligible in BOTH halves
#
# DRW:
#   Stage03D had no frozen hard N eligibility threshold, so this audit
#   reports several descriptive half-sample N thresholds (>=30, >=50,
#   >=80, >=100) rather than silently inventing a new scientific gate.
#   Stage09D1 will choose the least arbitrary numerically safe refit rule
#   after this audit.
#
# Outputs:
#   outputs/tables/stage09d0_temporal_split_counts.csv
#   outputs/tables/stage09d0_temporal_source_eligibility.csv
#   outputs/tables/stage09d0_temporal_eligibility_by_class.csv
#   outputs/audit/stage09d0_summary.txt
#
# No endpoint is refit here.
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"
TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

SAMPLE_FILE = TABLE_DIR / "stage02b3_GOLD_PLUS_SILVER.csv"
CONF_FILE = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"

OUT_COUNTS = TABLE_DIR / "stage09d0_temporal_split_counts.csv"
OUT_SOURCE = TABLE_DIR / "stage09d0_temporal_source_eligibility.csv"
OUT_CLASS = TABLE_DIR / "stage09d0_temporal_eligibility_by_class.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09d0_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

PAIR_TOL_DAYS = 0.25
RMF_MIN_N_HALF = 160
COLOUR_MIN_PAIRS_HALF = 30


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def valid_nightly(d):
    out = d.copy()

    required = [
        "filter_name",
        "night_id",
        "hmjd",
        "mag",
        "magerr",
        "flux_jy",
        "fluxerr_jy",
    ]

    missing = [
        c for c in required
        if c not in out.columns
    ]

    if missing:
        raise RuntimeError(
            "Nightly file missing columns: "
            + repr(missing)
        )

    for c in [
        "night_id",
        "hmjd",
        "mag",
        "magerr",
        "flux_jy",
        "fluxerr_jy",
    ]:
        out[c] = numeric(out[c])

    out["filter_name"] = (
        out["filter_name"]
        .astype(str)
        .str.lower()
        .str.strip()
    )

    out = out.loc[
        out["filter_name"].isin(["g", "r"])
        &
        np.isfinite(out["hmjd"])
        &
        np.isfinite(out["mag"])
        &
        np.isfinite(out["magerr"])
        &
        np.isfinite(out["flux_jy"])
        &
        np.isfinite(out["fluxerr_jy"])
        &
        (out["magerr"] > 0)
        &
        (out["flux_jy"] > 0)
        &
        (out["fluxerr_jy"] >= 0)
    ].copy()

    return out


def colour_pairs(d):
    g = (
        d.loc[
            d["filter_name"].eq("g"),
            [
                "night_id",
                "hmjd",
                "mag",
                "magerr",
            ],
        ]
        .rename(
            columns={
                "hmjd": "hmjd_g",
                "mag": "g_mag",
                "magerr": "g_magerr",
            }
        )
        .copy()
    )

    r = (
        d.loc[
            d["filter_name"].eq("r"),
            [
                "night_id",
                "hmjd",
                "mag",
                "magerr",
            ],
        ]
        .rename(
            columns={
                "hmjd": "hmjd_r",
                "mag": "r_mag",
                "magerr": "r_magerr",
            }
        )
        .copy()
    )

    if len(g) == 0 or len(r) == 0:
        return pd.DataFrame()

    p = g.merge(
        r,
        on="night_id",
        how="inner",
        validate="one_to_one",
    )

    p["dt_days"] = np.abs(
        p["hmjd_g"]
        -
        p["hmjd_r"]
    )

    p = p.loc[
        np.isfinite(p["dt_days"])
        &
        (p["dt_days"] <= PAIR_TOL_DAYS)
    ].copy()

    if len(p):
        p["hmjd_pair"] = 0.5 * (
            p["hmjd_g"]
            +
            p["hmjd_r"]
        )

    return p


for path in [SAMPLE_FILE, CONF_FILE]:
    if not path.exists():
        raise FileNotFoundError(path)

if not NIGHTLY_DIR.exists():
    raise FileNotFoundError(NIGHTLY_DIR)

sample = pd.read_csv(
    SAMPLE_FILE,
    low_memory=False,
)

sample["blazar_id"] = (
    sample["blazar_id"]
    .astype(str)
)

source_ids = (
    sample["blazar_id"]
    .drop_duplicates()
    .tolist()
)

if len(source_ids) != 1061:
    raise RuntimeError(
        f"Expected 1061 analysis sources; got {len(source_ids)}"
    )

conf = pd.read_csv(
    CONF_FILE,
    low_memory=False,
)

conf["blazar_id"] = (
    conf["blazar_id"]
    .astype(str)
)

meta_cols = [
    c
    for c in [
        "blazar_id",
        "blazar_class",
        "redshift",
        "sed_class",
        "ps1_host_proxy_ri",
    ]
    if c in conf.columns
]

meta = (
    conf[
        meta_cols
    ]
    .drop_duplicates(
        "blazar_id"
    )
)

count_rows = []

print("=" * 80)
print("BLAZAR_I — STAGE 09D0 TEMPORAL ELIGIBILITY AUDIT")
print("=" * 80)
print("Sources =", len(source_ids))
print("Split = common source-level mid-baseline")
print()

for i, bid in enumerate(
    source_ids,
    start=1,
):
    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(path)

    d = pd.read_parquet(path)
    d = valid_nightly(d)

    if len(d) == 0:
        raise RuntimeError(
            f"{bid}: no valid g/r nightly rows."
        )

    tmin = float(
        d["hmjd"].min()
    )

    tmax = float(
        d["hmjd"].max()
    )

    tsplit = 0.5 * (
        tmin
        +
        tmax
    )

    p = colour_pairs(d)

    for half in [
        "EARLY",
        "LATE",
    ]:
        if half == "EARLY":
            dh = d.loc[
                d["hmjd"]
                <=
                tsplit
            ].copy()

            if len(p):
                ph = p.loc[
                    p["hmjd_pair"]
                    <=
                    tsplit
                ].copy()
            else:
                ph = p

        else:
            dh = d.loc[
                d["hmjd"]
                >
                tsplit
            ].copy()

            if len(p):
                ph = p.loc[
                    p["hmjd_pair"]
                    >
                    tsplit
                ].copy()
            else:
                ph = p

        ng = int(
            dh["filter_name"]
            .eq("g")
            .sum()
        )

        nr = int(
            dh["filter_name"]
            .eq("r")
            .sum()
        )

        ncol = int(
            len(ph)
        )

        tg = dh.loc[
            dh["filter_name"].eq("g"),
            "hmjd",
        ]

        tr = dh.loc[
            dh["filter_name"].eq("r"),
            "hmjd",
        ]

        count_rows.append({
            "blazar_id": bid,
            "half": half,
            "t_source_min": tmin,
            "t_source_max": tmax,
            "t_split": tsplit,
            "source_baseline_days": (
                tmax - tmin
            ),
            "N_g": ng,
            "N_r": nr,
            "N_colour_pairs": ncol,
            "baseline_g_days": (
                float(tg.max() - tg.min())
                if len(tg) >= 2
                else np.nan
            ),
            "baseline_r_days": (
                float(tr.max() - tr.min())
                if len(tr) >= 2
                else np.nan
            ),
            "rmf_eligible_g": bool(
                ng >= RMF_MIN_N_HALF
            ),
            "rmf_eligible_r": bool(
                nr >= RMF_MIN_N_HALF
            ),
            "rmf_eligible_both": bool(
                ng >= RMF_MIN_N_HALF
                and
                nr >= RMF_MIN_N_HALF
            ),
            "colour_eligible": bool(
                ncol >= COLOUR_MIN_PAIRS_HALF
            ),
            "drw_N30_both": bool(
                ng >= 30 and nr >= 30
            ),
            "drw_N50_both": bool(
                ng >= 50 and nr >= 50
            ),
            "drw_N80_both": bool(
                ng >= 80 and nr >= 80
            ),
            "drw_N100_both": bool(
                ng >= 100 and nr >= 100
            ),
        })

    if (
        i % 100 == 0
        or
        i == len(source_ids)
    ):
        print(
            f"Processed {i}/{len(source_ids)}"
        )

counts = pd.DataFrame(
    count_rows
)

counts = counts.merge(
    meta,
    on="blazar_id",
    how="left",
    validate="many_to_one",
)

counts.to_csv(
    OUT_COUNTS,
    index=False,
)


# ============================================================
# SOURCE-LEVEL EARLY + LATE ELIGIBILITY
# ============================================================

early = (
    counts.loc[
        counts["half"].eq("EARLY")
    ]
    .set_index("blazar_id")
)

late = (
    counts.loc[
        counts["half"].eq("LATE")
    ]
    .set_index("blazar_id")
)

if set(early.index) != set(late.index):
    raise RuntimeError(
        "EARLY/LATE source IDs do not match."
    )

rows = []

for bid in source_ids:
    e = early.loc[bid]
    l = late.loc[bid]

    cls = (
        e.get(
            "blazar_class",
            np.nan,
        )
    )

    z = (
        e.get(
            "redshift",
            np.nan,
        )
    )

    sed = (
        e.get(
            "sed_class",
            np.nan,
        )
    )

    rmf_both_halves = bool(
        e["rmf_eligible_both"]
        and
        l["rmf_eligible_both"]
    )

    colour_both_halves = bool(
        e["colour_eligible"]
        and
        l["colour_eligible"]
    )

    rows.append({
        "blazar_id": bid,
        "blazar_class": cls,
        "redshift": z,
        "sed_class": sed,

        "N_g_early": int(e["N_g"]),
        "N_g_late": int(l["N_g"]),
        "N_r_early": int(e["N_r"]),
        "N_r_late": int(l["N_r"]),
        "N_colour_early": int(e["N_colour_pairs"]),
        "N_colour_late": int(l["N_colour_pairs"]),

        "rmf_eligible_both_early": bool(
            e["rmf_eligible_both"]
        ),
        "rmf_eligible_both_late": bool(
            l["rmf_eligible_both"]
        ),
        "rmf_eligible_both_halves": rmf_both_halves,

        "colour_eligible_early": bool(
            e["colour_eligible"]
        ),
        "colour_eligible_late": bool(
            l["colour_eligible"]
        ),
        "colour_eligible_both_halves": colour_both_halves,

        "flagship_temporal_eligible": bool(
            rmf_both_halves
            and
            colour_both_halves
        ),

        "drw_N30_both_halves": bool(
            e["drw_N30_both"]
            and
            l["drw_N30_both"]
        ),
        "drw_N50_both_halves": bool(
            e["drw_N50_both"]
            and
            l["drw_N50_both"]
        ),
        "drw_N80_both_halves": bool(
            e["drw_N80_both"]
            and
            l["drw_N80_both"]
        ),
        "drw_N100_both_halves": bool(
            e["drw_N100_both"]
            and
            l["drw_N100_both"]
        ),

        "drw_rest_N50_both_halves": bool(
            e["drw_N50_both"]
            and
            l["drw_N50_both"]
            and
            np.isfinite(
                pd.to_numeric(
                    pd.Series([z]),
                    errors="coerce",
                ).iloc[0]
            )
        ),
    })

source = pd.DataFrame(
    rows
)

source.to_csv(
    OUT_SOURCE,
    index=False,
)


# ============================================================
# CLASS SUMMARY
# ============================================================

class_rows = []

metrics = [
    "rmf_eligible_both_halves",
    "colour_eligible_both_halves",
    "flagship_temporal_eligible",
    "drw_N30_both_halves",
    "drw_N50_both_halves",
    "drw_N80_both_halves",
    "drw_N100_both_halves",
    "drw_rest_N50_both_halves",
]

for cls in [
    "ALL",
    "BLL",
    "FSRQ",
]:
    if cls == "ALL":
        x = source.copy()
    else:
        x = source.loc[
            source["blazar_class"]
            .astype(str)
            .eq(cls)
        ].copy()

    for m in metrics:
        n = int(
            x[m]
            .astype(bool)
            .sum()
        )

        class_rows.append({
            "class": cls,
            "metric": m,
            "N_total": len(x),
            "N_eligible": n,
            "fraction": (
                n / len(x)
                if len(x)
                else np.nan
            ),
        })

class_summary = pd.DataFrame(
    class_rows
)

class_summary.to_csv(
    OUT_CLASS,
    index=False,
)


# ============================================================
# DISTRIBUTION SUMMARY
# ============================================================

def medq(s):
    x = numeric(s).dropna()
    if len(x) == 0:
        return (
            np.nan,
            np.nan,
            np.nan,
        )
    return (
        float(x.quantile(0.10)),
        float(x.median()),
        float(x.quantile(0.90)),
    )


def fmt_dist(label, s):
    p10, p50, p90 = medq(s)
    return (
        f"  {label:28s}: "
        f"p10={p10:.1f}, med={p50:.1f}, p90={p90:.1f}"
    )


flag = source["flagship_temporal_eligible"].astype(bool)

n_flag = int(flag.sum())
n_flag_bll = int(
    (
        flag
        &
        source["blazar_class"]
        .astype(str)
        .eq("BLL")
    ).sum()
)
n_flag_fsrq = int(
    (
        flag
        &
        source["blazar_class"]
        .astype(str)
        .eq("FSRQ")
    ).sum()
)

summary_lines = [
    "BLAZAR_I - STAGE 09D0 FINAL SUMMARY",
    "=" * 80,
    "",
    "Temporal early/late eligibility audit",
    "",
    "Split definition:",
    "  one common source-level mid-baseline split applied to both g and r",
    "",
    "EARLY nightly-count distributions:",
    fmt_dist(
        "N_g early",
        source["N_g_early"],
    ),
    fmt_dist(
        "N_r early",
        source["N_r_early"],
    ),
    fmt_dist(
        "N_colour early",
        source["N_colour_early"],
    ),
    "",
    "LATE nightly-count distributions:",
    fmt_dist(
        "N_g late",
        source["N_g_late"],
    ),
    fmt_dist(
        "N_r late",
        source["N_r_late"],
    ),
    fmt_dist(
        "N_colour late",
        source["N_colour_late"],
    ),
    "",
    "BOTH-HALF exact eligibility:",
    f"  rms-flux BOTH filters >=160 each half : {int(source['rmf_eligible_both_halves'].sum())}/1061",
    f"  colour >=30 pairs each half           : {int(source['colour_eligible_both_halves'].sum())}/1061",
    f"  FLAGSHIP common eligibility           : {n_flag}/1061",
    f"    BLL                                  : {n_flag_bll}",
    f"    FSRQ                                 : {n_flag_fsrq}",
    "",
    "DRW descriptive BOTH-filter half-sample support:",
    f"  >=30 nights/filter/half               : {int(source['drw_N30_both_halves'].sum())}/1061",
    f"  >=50 nights/filter/half               : {int(source['drw_N50_both_halves'].sum())}/1061",
    f"  >=80 nights/filter/half               : {int(source['drw_N80_both_halves'].sum())}/1061",
    f"  >=100 nights/filter/half              : {int(source['drw_N100_both_halves'].sum())}/1061",
    f"  >=50 + known redshift                 : {int(source['drw_rest_N50_both_halves'].sum())}/1061",
    "",
    "Interpretation locks:",
    "  - This is an eligibility/power audit only; no endpoint has been refit.",
    "  - EARLY and LATE are temporal validation blocks, not independent source samples.",
    "  - The exact frozen rms-flux and colour eligibility thresholds are preserved.",
    "  - No new DRW hard-N gate is frozen at this stage.",
    "",
    "Files saved:",
    f"  {OUT_COUNTS}",
    f"  {OUT_SOURCE}",
    f"  {OUT_CLASS}",
    "",
    "Next:",
    "  Use this audit to decide whether Stage09D1 should perform full",
    "  early/late rms-flux + colour + DRW refits on the common-support set.",
    "",
    "STAGE 09D0 COMPLETE",
]

summary = "\n".join(
    summary_lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
