# ============================================================
# BLAZAR_I — STAGE 06D3
# REFINED TWO-STAGE PROPENSITY MODEL + BALANCE DIAGNOSTICS
#
# Purpose:
#   Improve the two-stage selection model after STAGE 06D2B showed
#   that raw IPW reduced, but did not eliminate, parent-vs-analysis
#   sky imbalance (worst SMD was Dec).
#
# Selection flow:
#   1901 clean Fermi parent
#       -> ZTF_ANY
#       -> GOLD+SILVER analysis sample
#
# Refined propensity specification:
#   parent-level variables only
#
#   Class / source properties:
#       FSRQ
#       SED_HSP, SED_ISP, SED_UNKNOWN  [LSP reference]
#       redshift_known
#       logEnergyFlux_DR4
#       log1pVarIndex_DR4
#       quadratic terms for the two gamma-ray predictors
#
#   Flexible sky footprint:
#       RA Fourier harmonics k=1..4
#       Dec Legendre basis P1..P5
#       P1(Dec) x RA harmonics k=1..2
#
# No downstream ZTF quality variables are used.
#
# Outputs:
#   refined selection probabilities
#   raw + trimmed stabilized IPW
#   detailed covariate-balance table
#   compact balance summary
#
# IMPORTANT:
#   This stage only refines the propensity / weights.
#   Endpoint inference will be repeated after balance is inspected.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

FLOW_FILE = TABLE_DIR / "stage06d1_selection_flow_master.csv"
OLD_BALANCE_FILE = TABLE_DIR / "stage06d2_selection_balance.csv"

OUT_FLOW = TABLE_DIR / "stage06d3_refined_selection_flow.csv"
OUT_MODELS = TABLE_DIR / "stage06d3_refined_propensity_models.csv"
OUT_WEIGHTS = TABLE_DIR / "stage06d3_refined_selection_weights.csv"
OUT_BALANCE = TABLE_DIR / "stage06d3_refined_selection_balance.csv"
OUT_BALANCE_SUMMARY = TABLE_DIR / "stage06d3_refined_balance_summary.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06d3_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def kish_ess(w):
    w = np.asarray(w, dtype=float)

    mask = (
        np.isfinite(w)
        &
        (w > 0)
    )

    w = w[mask]

    if len(w) == 0:
        return np.nan

    return float(
        (w.sum() ** 2)
        /
        np.sum(w ** 2)
    )


def weighted_mean(x, w):
    x = np.asarray(x, dtype=float)
    w = np.asarray(w, dtype=float)

    mask = (
        np.isfinite(x)
        &
        np.isfinite(w)
        &
        (w > 0)
    )

    if mask.sum() == 0:
        return np.nan

    return float(
        np.average(
            x[mask],
            weights=w[mask]
        )
    )


def weighted_cdf_ks(
    parent_x,
    selected_x,
    selected_w,
):
    p = np.asarray(
        parent_x,
        dtype=float
    )

    s = np.asarray(
        selected_x,
        dtype=float
    )

    w = np.asarray(
        selected_w,
        dtype=float
    )

    p = p[
        np.isfinite(p)
    ]

    mask = (
        np.isfinite(s)
        &
        np.isfinite(w)
        &
        (w > 0)
    )

    s = s[mask]
    w = w[mask]

    if (
        len(p) == 0
        or
        len(s) == 0
    ):
        return np.nan

    grid = np.unique(
        np.concatenate(
            [p, s]
        )
    )

    p_sorted = np.sort(p)

    s_order = np.argsort(s)
    s_sorted = s[s_order]
    w_sorted = w[s_order]
    cw = np.cumsum(w_sorted)
    total_w = cw[-1]

    p_cdf = np.searchsorted(
        p_sorted,
        grid,
        side="right"
    ) / len(p_sorted)

    idx = np.searchsorted(
        s_sorted,
        grid,
        side="right"
    ) - 1

    s_cdf = np.zeros(
        len(grid),
        dtype=float
    )

    good = idx >= 0

    s_cdf[good] = (
        cw[idx[good]]
        /
        total_w
    )

    return float(
        np.max(
            np.abs(
                p_cdf
                -
                s_cdf
            )
        )
    )


def bh_qvalues(pvalues):
    p = np.asarray(
        pvalues,
        dtype=float
    )

    q = np.full(
        len(p),
        np.nan,
        dtype=float
    )

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw = (
        ranked
        *
        m
        /
        np.arange(
            1,
            m + 1
        )
    )

    adj = np.minimum.accumulate(
        raw[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0
    )

    qv = np.empty(
        m,
        dtype=float
    )

    qv[order] = adj
    q[valid] = qv

    return q


# ============================================================
# LOAD
# ============================================================

if not FLOW_FILE.exists():
    raise FileNotFoundError(
        FLOW_FILE
    )

flow = pd.read_csv(
    FLOW_FILE
)

flow[
    "blazar_id"
] = flow[
    "blazar_id"
].astype(str)

flow[
    "ZTF_ANY"
] = as_bool_series(
    flow[
        "ZTF_ANY"
    ]
)

flow[
    "ANALYSIS_SELECTED"
] = as_bool_series(
    flow[
        "ANALYSIS_SELECTED"
    ]
)

if len(flow) != 1901:
    raise RuntimeError(
        f"Expected N=1901; got {len(flow)}"
    )

if int(
    flow[
        "ZTF_ANY"
    ].sum()
) != 1456:
    raise RuntimeError(
        "Expected ZTF_ANY count 1456."
    )

if int(
    flow[
        "ANALYSIS_SELECTED"
    ].sum()
) != 1061:
    raise RuntimeError(
        "Expected final analysis count 1061."
    )


# ============================================================
# RECONSTRUCT / VALIDATE BASE PREDICTORS
# ============================================================

flow[
    "FSRQ"
] = (
    flow[
        "blazar_class"
    ]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

flow[
    "redshift_known"
] = (
    numeric(
        flow[
            "redshift_clean"
        ]
    )
    .notna()
    .astype(int)
)

sed = (
    flow[
        "SED_class_clean"
    ]
    .fillna("UNKNOWN")
    .astype(str)
    .str.strip()
    .str.upper()
)

flow[
    "SED_HSP"
] = sed.eq(
    "HSP"
).astype(int)

flow[
    "SED_ISP"
] = sed.eq(
    "ISP"
).astype(int)

flow[
    "SED_UNKNOWN"
] = sed.eq(
    "UNKNOWN"
).astype(int)

energy = numeric(
    flow[
        "Energy_Flux100_DR4"
    ]
)

varidx = numeric(
    flow[
        "Variability_Index_DR4"
    ]
)

if (
    energy.isna().any()
    or
    (energy <= 0).any()
):
    raise RuntimeError(
        "Energy_Flux100_DR4 must be finite and >0."
    )

if (
    varidx.isna().any()
    or
    (varidx < 0).any()
):
    raise RuntimeError(
        "Variability_Index_DR4 must be finite and >=0."
    )

flow[
    "logEnergyFlux_DR4"
] = np.log10(
    energy
)

flow[
    "log1pVarIndex_DR4"
] = np.log1p(
    varidx
)


# ============================================================
# FLEXIBLE SKY / GAMMA BASIS
# ============================================================

ra_deg = numeric(
    flow[
        "ra_opt"
    ]
)

dec_deg = numeric(
    flow[
        "dec_opt"
    ]
)

if (
    ra_deg.isna().any()
    or
    dec_deg.isna().any()
):
    raise RuntimeError(
        "RA/Dec must be finite for all parent sources."
    )

ra_rad = np.deg2rad(
    ra_deg.to_numpy(
        dtype=float
    )
)

for k in range(
    1,
    5
):
    flow[
        f"RA_sin{k}"
    ] = np.sin(
        k * ra_rad
    )

    flow[
        f"RA_cos{k}"
    ] = np.cos(
        k * ra_rad
    )

# Scale parent declination to [-1, +1], then use Legendre basis.
dec_min = float(
    dec_deg.min()
)

dec_max = float(
    dec_deg.max()
)

if not (
    np.isfinite(dec_min)
    and
    np.isfinite(dec_max)
    and
    dec_max > dec_min
):
    raise RuntimeError(
        "Invalid declination range."
    )

dec_scaled = (
    2.0
    *
    (
        dec_deg.to_numpy(
            dtype=float
        )
        -
        dec_min
    )
    /
    (
        dec_max
        -
        dec_min
    )
    -
    1.0
)

leg = np.polynomial.legendre.legvander(
    dec_scaled,
    5
)

# leg[:,0] is constant and is not used.
for degree in range(
    1,
    6
):
    flow[
        f"DEC_P{degree}"
    ] = leg[
        :,
        degree
    ]

# Low-order RA x Dec interactions.
for k in [
    1,
    2
]:
    flow[
        f"DEC_P1_x_RA_sin{k}"
    ] = (
        flow[
            "DEC_P1"
        ]
        *
        flow[
            f"RA_sin{k}"
        ]
    )

    flow[
        f"DEC_P1_x_RA_cos{k}"
    ] = (
        flow[
            "DEC_P1"
        ]
        *
        flow[
            f"RA_cos{k}"
        ]
    )

# Standardize the two gamma predictors on the full parent,
# then include quadratic terms.
for c in [
    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",
]:
    mu = float(
        flow[c].mean()
    )

    sd = float(
        flow[c].std(
            ddof=1
        )
    )

    if not (
        np.isfinite(sd)
        and
        sd > 0
    ):
        raise RuntimeError(
            f"Invalid SD for {c}"
        )

    zc = (
        c
        +
        "_Z"
    )

    flow[
        zc
    ] = (
        flow[c]
        -
        mu
    ) / sd

    flow[
        zc
        +
        "2"
    ] = (
        flow[zc]
        ** 2
    )


# ============================================================
# DESIGN
# ============================================================

PREDICTORS = [
    "FSRQ",
    "SED_HSP",
    "SED_ISP",
    "SED_UNKNOWN",
    "redshift_known",

    "logEnergyFlux_DR4_Z",
    "logEnergyFlux_DR4_Z2",
    "log1pVarIndex_DR4_Z",
    "log1pVarIndex_DR4_Z2",

    "RA_sin1",
    "RA_cos1",
    "RA_sin2",
    "RA_cos2",
    "RA_sin3",
    "RA_cos3",
    "RA_sin4",
    "RA_cos4",

    "DEC_P1",
    "DEC_P2",
    "DEC_P3",
    "DEC_P4",
    "DEC_P5",

    "DEC_P1_x_RA_sin1",
    "DEC_P1_x_RA_cos1",
    "DEC_P1_x_RA_sin2",
    "DEC_P1_x_RA_cos2",
]


def fit_stage(
    train_df,
    apply_df,
    outcome,
    stage_name,
):
    train = train_df[
        [
            outcome,
            *PREDICTORS,
        ]
    ].copy()

    apply = apply_df[
        PREDICTORS
    ].copy()

    for c in [
        outcome,
        *PREDICTORS,
    ]:
        train[c] = numeric(
            train[c]
        )

    for c in PREDICTORS:
        apply[c] = numeric(
            apply[c]
        )

    train = train.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    if apply.replace(
        [np.inf, -np.inf],
        np.nan
    ).isna().any().any():
        raise RuntimeError(
            f"{stage_name}: missing predictor values."
        )

    y = train[
        outcome
    ].astype(float)

    X = sm.add_constant(
        train[
            PREDICTORS
        ].astype(float),
        has_constant="add"
    )

    fit = sm.GLM(
        y,
        X,
        family=sm.families.Binomial()
    ).fit(
        cov_type="HC3",
        maxiter=200,
    )

    X_apply = sm.add_constant(
        apply[
            PREDICTORS
        ].astype(float),
        has_constant="add"
    )

    pred = np.asarray(
        fit.predict(
            X_apply
        ),
        dtype=float
    )

    ci = fit.conf_int()

    rows = []

    for term in fit.params.index:
        beta = float(
            fit.params[
                term
            ]
        )

        lo = float(
            ci.loc[
                term,
                0
            ]
        )

        hi = float(
            ci.loc[
                term,
                1
            ]
        )

        rows.append({
            "stage": stage_name,
            "N_model": int(
                len(train)
            ),
            "N_positive": int(
                y.sum()
            ),
            "term": term,
            "beta": beta,
            "OR": (
                math.exp(beta)
                if term != "const"
                else np.nan
            ),
            "OR_ci95_low": (
                math.exp(lo)
                if term != "const"
                else np.nan
            ),
            "OR_ci95_high": (
                math.exp(hi)
                if term != "const"
                else np.nan
            ),
            "p_value": float(
                fit.pvalues[
                    term
                ]
            ),
            "AIC": float(
                fit.aic
            ),
            "deviance": float(
                fit.deviance
            ),
        })

    return (
        pred,
        rows,
    )


# ============================================================
# FIT TWO-STAGE REFINED PROPENSITY
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 06D3")
print("REFINED TWO-STAGE PROPENSITY + BALANCE")
print("=" * 78)

model_rows = []

p1, rows1 = fit_stage(
    train_df=flow,
    apply_df=flow,
    outcome="ZTF_ANY",
    stage_name="STAGE1_PARENT_TO_ZTF_ANY",
)

model_rows.extend(
    rows1
)

flow[
    "p_stage1_refined"
] = p1

ztf = flow.loc[
    flow[
        "ZTF_ANY"
    ]
].copy()

p2, rows2 = fit_stage(
    train_df=ztf,
    apply_df=ztf,
    outcome="ANALYSIS_SELECTED",
    stage_name="STAGE2_ZTF_ANY_TO_ANALYSIS",
)

model_rows.extend(
    rows2
)

p2_map = dict(
    zip(
        ztf[
            "blazar_id"
        ],
        p2,
    )
)

flow[
    "p_stage2_refined"
] = (
    flow[
        "blazar_id"
    ]
    .map(
        p2_map
    )
)

flow[
    "p_final_refined"
] = (
    flow[
        "p_stage1_refined"
    ]
    *
    flow[
        "p_stage2_refined"
    ]
)

models = pd.DataFrame(
    model_rows
)

models[
    "q_BH_within_stage"
] = np.nan

for stage, idx in models.groupby(
    "stage"
).groups.items():
    idx = list(idx)

    nonconst = [
        i
        for i in idx
        if models.loc[
            i,
            "term"
        ]
        !=
        "const"
    ]

    models.loc[
        nonconst,
        "q_BH_within_stage"
    ] = bh_qvalues(
        models.loc[
            nonconst,
            "p_value"
        ].to_numpy(
            dtype=float
        )
    )

models.to_csv(
    OUT_MODELS,
    index=False
)


# ============================================================
# REFINED STABILIZED WEIGHTS
# ============================================================

selected = flow.loc[
    flow[
        "ANALYSIS_SELECTED"
    ]
].copy()

pf = numeric(
    selected[
        "p_final_refined"
    ]
)

if (
    pf.isna().any()
    or
    (pf <= 0).any()
    or
    (pf >= 1).any()
):
    bad = int(
        (
            pf.isna()
            |
            (pf <= 0)
            |
            (pf >= 1)
        ).sum()
    )

    raise RuntimeError(
        f"Invalid refined final probabilities: {bad}"
    )

marginal_final = (
    1061.0
    /
    1901.0
)

selected[
    "SW_REFINED_RAW"
] = (
    marginal_final
    /
    pf
)

q01 = float(
    selected[
        "SW_REFINED_RAW"
    ].quantile(
        0.01
    )
)

q99 = float(
    selected[
        "SW_REFINED_RAW"
    ].quantile(
        0.99
    )
)

q025 = float(
    selected[
        "SW_REFINED_RAW"
    ].quantile(
        0.025
    )
)

q975 = float(
    selected[
        "SW_REFINED_RAW"
    ].quantile(
        0.975
    )
)

selected[
    "SW_REFINED_TRIM_1_99"
] = (
    selected[
        "SW_REFINED_RAW"
    ]
    .clip(
        lower=q01,
        upper=q99
    )
)

selected[
    "SW_REFINED_TRIM_2P5_97P5"
] = (
    selected[
        "SW_REFINED_RAW"
    ]
    .clip(
        lower=q025,
        upper=q975
    )
)

weights = selected[
    [
        "blazar_id",
        "p_stage1_refined",
        "p_stage2_refined",
        "p_final_refined",
        "SW_REFINED_RAW",
        "SW_REFINED_TRIM_1_99",
        "SW_REFINED_TRIM_2P5_97P5",
    ]
].copy()

weights.to_csv(
    OUT_WEIGHTS,
    index=False
)


# ============================================================
# BALANCE DIAGNOSTICS
# ============================================================

# Balance is checked on source properties plus a richer set of
# sky moments than was used in STAGE 06D2B.
BALANCE_VARS = [
    "FSRQ",
    "SED_HSP",
    "SED_ISP",
    "SED_UNKNOWN",
    "redshift_known",

    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",

    "RA_sin1",
    "RA_cos1",
    "RA_sin2",
    "RA_cos2",
    "RA_sin3",
    "RA_cos3",
    "RA_sin4",
    "RA_cos4",

    "DEC_P1",
    "DEC_P2",
    "DEC_P3",
    "DEC_P4",
    "DEC_P5",
]

WEIGHT_SCHEMES = [
    (
        "UNWEIGHTED",
        None
    ),
    (
        "REFINED_RAW",
        "SW_REFINED_RAW"
    ),
    (
        "REFINED_TRIM_1_99",
        "SW_REFINED_TRIM_1_99"
    ),
    (
        "REFINED_TRIM_2P5_97P5",
        "SW_REFINED_TRIM_2P5_97P5"
    ),
]

balance_rows = []

for var in BALANCE_VARS:
    px = numeric(
        flow[
            var
        ]
    )

    sx = numeric(
        selected[
            var
        ]
    )

    parent_mean = float(
        px.mean()
    )

    parent_sd = float(
        px.std(
            ddof=1
        )
    )

    if not (
        np.isfinite(
            parent_sd
        )
        and
        parent_sd > 0
    ):
        parent_sd = 1.0

    for label, wcol in WEIGHT_SCHEMES:
        if wcol is None:
            w = np.ones(
                len(selected),
                dtype=float
            )
        else:
            w = numeric(
                selected[
                    wcol
                ]
            ).to_numpy(
                dtype=float
            )

        sample_mean = weighted_mean(
            sx,
            w
        )

        balance_rows.append({
            "variable": var,
            "weight_scheme": label,
            "parent_mean": parent_mean,
            "selected_mean": sample_mean,
            "difference": (
                sample_mean
                -
                parent_mean
            ),
            "standardized_difference": (
                (
                    sample_mean
                    -
                    parent_mean
                )
                /
                parent_sd
            ),
        })

balance = pd.DataFrame(
    balance_rows
)

balance[
    "abs_standardized_difference"
] = np.abs(
    numeric(
        balance[
            "standardized_difference"
        ]
    )
)

balance.to_csv(
    OUT_BALANCE,
    index=False
)


# ============================================================
# BALANCE SUMMARY + DECLINATION KS
# ============================================================

summary_rows = []

for label, wcol in WEIGHT_SCHEMES:
    x = balance.loc[
        balance[
            "weight_scheme"
        ].eq(label)
    ].copy()

    worst = x.sort_values(
        "abs_standardized_difference",
        ascending=False
    ).iloc[0]

    if wcol is None:
        w = np.ones(
            len(selected),
            dtype=float
        )
    else:
        w = numeric(
            selected[
                wcol
            ]
        ).to_numpy(
            dtype=float
        )

    ks_dec = weighted_cdf_ks(
        parent_x=numeric(
            flow[
                "dec_opt"
            ]
        ),
        selected_x=numeric(
            selected[
                "dec_opt"
            ]
        ),
        selected_w=w,
    )

    summary_rows.append({
        "weight_scheme": label,
        "max_abs_smd": float(
            x[
                "abs_standardized_difference"
            ].max()
        ),
        "mean_abs_smd": float(
            x[
                "abs_standardized_difference"
            ].mean()
        ),
        "median_abs_smd": float(
            x[
                "abs_standardized_difference"
            ].median()
        ),
        "worst_variable": worst[
            "variable"
        ],
        "worst_abs_smd": float(
            worst[
                "abs_standardized_difference"
            ]
        ),
        "dec_weighted_KS": ks_dec,
        "weight_ESS": kish_ess(
            w
        ),
    })

balance_summary = pd.DataFrame(
    summary_rows
)

balance_summary.to_csv(
    OUT_BALANCE_SUMMARY,
    index=False
)


# ============================================================
# SAVE FULL FLOW WITH REFINED PROPENSITIES
# ============================================================

flow.to_csv(
    OUT_FLOW,
    index=False
)


# ============================================================
# SUMMARY TEXT
# ============================================================

p1_selected = numeric(
    selected[
        "p_stage1_refined"
    ]
)

p2_selected = numeric(
    selected[
        "p_stage2_refined"
    ]
)

pf_selected = numeric(
    selected[
        "p_final_refined"
    ]
)

wraw = numeric(
    selected[
        "SW_REFINED_RAW"
    ]
)

lines = [
    "BLAZAR_I - STAGE 06D3 FINAL SUMMARY",
    "=" * 78,
    "",
    "REFINED SELECTION PROBABILITY / WEIGHT DIAGNOSTICS:",
    (
        "  p_stage1_refined: "
        f"min={p1_selected.min():.4f}, "
        f"p01={p1_selected.quantile(0.01):.4f}, "
        f"median={p1_selected.median():.4f}"
    ),
    (
        "  p_stage2_refined: "
        f"min={p2_selected.min():.4f}, "
        f"p01={p2_selected.quantile(0.01):.4f}, "
        f"median={p2_selected.median():.4f}"
    ),
    (
        "  p_final_refined:  "
        f"min={pf_selected.min():.4f}, "
        f"p01={pf_selected.quantile(0.01):.4f}, "
        f"median={pf_selected.median():.4f}"
    ),
    (
        "  SW_REFINED_RAW:   "
        f"median={wraw.median():.3f}, "
        f"p95={wraw.quantile(0.95):.3f}, "
        f"p99={wraw.quantile(0.99):.3f}, "
        f"max={wraw.max():.3f}"
    ),
    "",
    "REFINED BALANCE:",
]

for _, rr in balance_summary.iterrows():
    lines.append(
        f"  {rr['weight_scheme']}: "
        f"max|SMD|={rr['max_abs_smd']:.3f}, "
        f"mean|SMD|={rr['mean_abs_smd']:.3f}, "
        f"median|SMD|={rr['median_abs_smd']:.3f}, "
        f"worst={rr['worst_variable']} "
        f"({rr['worst_abs_smd']:.3f}), "
        f"Dec_KS={rr['dec_weighted_KS']:.3f}, "
        f"ESS={rr['weight_ESS']:.1f}"
    )

if OLD_BALANCE_FILE.exists():
    old = pd.read_csv(
        OLD_BALANCE_FILE
    )

    old[
        "abs_standardized_difference"
    ] = np.abs(
        numeric(
            old[
                "standardized_difference"
            ]
        )
    )

    old_ipw = old.loc[
        old[
            "weight_scheme"
        ].eq(
            "IPW_RAW"
        )
    ]

    if len(old_ipw) > 0:
        lines += [
            "",
            (
                "Previous STAGE 06D2 raw-IPW "
                f"max|SMD|={old_ipw['abs_standardized_difference'].max():.3f}"
            ),
        ]

lines += [
    "",
    "NOTE:",
    (
        "  STAGE 06D3 refines only the selection propensity / weights. "
        "Endpoint models should be rerun only after these balance "
        "diagnostics are inspected."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_FLOW)
print(OUT_MODELS)
print(OUT_WEIGHTS)
print(OUT_BALANCE)
print(OUT_BALANCE_SUMMARY)
print(OUT_SUMMARY)
print()
print("STAGE 06D3 COMPLETE")
