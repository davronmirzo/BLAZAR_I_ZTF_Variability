# ============================================================
# BLAZAR_I — STAGE 06C0B
# NIGHTLY LIGHT-CURVE SCHEMA + DRW INPUT CONSISTENCY AUDIT
#
# Purpose:
#   Confirm the exact nightly parquet columns and verify that
#   N_nightly / baseline / cadence recomputed from those files
#   match the frozen STAGE 03D master before any DRW refitting.
#
# Also prints the active Python executable/prefix to catch any
# environment-path mix-up.
#
# Read-only audit. No upstream file is modified.
# ============================================================

from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"
DRW_FILE = ROOT / "outputs" / "tables" / "stage03d_drw_master.csv"
OUT = ROOT / "outputs" / "audit" / "stage06c0b_nightly_drw_input_audit.txt"

if not DRW_FILE.exists():
    raise FileNotFoundError(DRW_FILE)

if not NIGHTLY_DIR.exists():
    raise FileNotFoundError(NIGHTLY_DIR)

drw = pd.read_csv(DRW_FILE)
drw["blazar_id"] = drw["blazar_id"].astype(str)

# Pick five unique sources spanning the nightly-count distribution.
src_summary = (
    drw.groupby("blazar_id", as_index=False)
    .agg(Nmax=("N_nightly", "max"))
    .sort_values("Nmax")
    .reset_index(drop=True)
)

qidx = sorted(set([
    0,
    int(round(0.25 * (len(src_summary) - 1))),
    int(round(0.50 * (len(src_summary) - 1))),
    int(round(0.75 * (len(src_summary) - 1))),
    len(src_summary) - 1,
]))

sample_ids = src_summary.loc[qidx, "blazar_id"].tolist()

lines = []
lines.append("BLAZAR_I - STAGE 06C0B NIGHTLY / DRW INPUT AUDIT")
lines.append("=" * 78)
lines.append("")
lines.append(f"sys.executable = {sys.executable}")
lines.append(f"sys.prefix     = {sys.prefix}")
lines.append(f"sys.base_prefix= {sys.base_prefix}")
lines.append("")
lines.append(f"NIGHTLY_DIR = {NIGHTLY_DIR}")
lines.append(f"DRW_FILE    = {DRW_FILE}")
lines.append("")
lines.append(f"Selected source IDs: {sample_ids}")

schema_printed = False

for bid in sample_ids:
    path = NIGHTLY_DIR / f"{bid}_NIGHTLY.parquet"

    if not path.exists():
        raise FileNotFoundError(path)

    x = pd.read_parquet(path)

    lines.append("")
    lines.append("-" * 78)
    lines.append(f"SOURCE: {bid}")
    lines.append(f"FILE: {path.name}")
    lines.append(f"rows={len(x)} columns={len(x.columns)}")

    if not schema_printed:
        lines.append("SCHEMA:")
        for c in x.columns:
            lines.append(f"  {c}    dtype={x[c].dtype}")
        schema_printed = True

    if "filter_name" not in x.columns:
        raise RuntimeError("Missing filter_name in nightly parquet.")

    lines.append(
        "filter counts = "
        + str(x["filter_name"].value_counts(dropna=False).to_dict())
    )

    # Identify likely magnitude/error/time columns.
    candidates = [
        c for c in x.columns
        if any(
            k in c.lower()
            for k in ["hmjd", "mjd", "mag", "err", "flux"]
        )
    ]

    lines.append("candidate analysis columns:")
    for c in candidates:
        s = x[c]
        lines.append(
            f"  {c}: nonnull={int(s.notna().sum())}, "
            f"unique={int(s.nunique(dropna=True))}"
        )

    if "hmjd" not in x.columns:
        raise RuntimeError(
            f"{bid}: expected hmjd column not found; actual columns={list(x.columns)}"
        )

    # Recompute sampling metrics and compare to STAGE 03D.
    for filt in ["g", "r"]:
        z = x.loc[
            x["filter_name"].astype(str).eq(filt)
        ].copy()

        t = pd.to_numeric(z["hmjd"], errors="coerce")
        t = t[np.isfinite(t)].sort_values().to_numpy(dtype=float)

        if len(t) == 0:
            lines.append(f"  {filt}: no finite hmjd rows")
            continue

        n_re = int(len(t))
        baseline_re = float(t[-1] - t[0]) if len(t) >= 2 else 0.0
        cadence_re = (
            float(np.median(np.diff(t)))
            if len(t) >= 2
            else np.nan
        )

        ref = drw.loc[
            drw["blazar_id"].eq(bid)
            &
            drw["filter_name"].astype(str).eq(filt)
        ]

        if len(ref) != 1:
            raise RuntimeError(
                f"{bid} {filt}: expected exactly one DRW row, found {len(ref)}"
            )

        rr = ref.iloc[0]

        n_ref = int(rr["N_nightly"])
        baseline_ref = float(rr["baseline_days"])
        cadence_ref = float(rr["median_cadence_days"])

        lines.append(
            f"  {filt}: "
            f"N recomputed/ref={n_re}/{n_ref}; "
            f"baseline recomputed/ref={baseline_re:.9f}/{baseline_ref:.9f}; "
            f"cadence recomputed/ref={cadence_re:.9f}/{cadence_ref:.9f}"
        )

        lines.append(
            f"       diffs: "
            f"dN={n_re - n_ref}; "
            f"dBaseline={baseline_re - baseline_ref:.3e}; "
            f"dCadence={cadence_re - cadence_ref:.3e}"
        )

text = "\n".join(lines)
OUT.write_text(text, encoding="utf-8")

print(text)
print()
print("AUDIT SAVED:")
print(OUT)
print()
print("STAGE 06C0B COMPLETE")
