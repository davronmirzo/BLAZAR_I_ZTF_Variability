# ============================================================
# BLAZAR_I — STAGE 09C1B
# DRW CALIBRATION AGGREGATION REPAIR + BINOMIAL UNCERTAINTY AUDIT
#
# Motivation:
#   Stage09C1 simulations themselves completed successfully, but the printed
#   "within factor 2" fractions were 0.0000 despite tau_hat/tau_true medians
#   near unity and 16--84% intervals largely inside [0.5, 2].
#
# Cause:
#   The replicate-level CSV stores the nullable boolean
#   within_factor2_true in a mixed column. After CSV round-trip pandas may
#   represent it as 1.0/0.0 rather than True/False. String-based boolean
#   parsing therefore maps "1.0" to False.
#
# Repair:
#   Recompute recovery DIRECTLY from the numeric ratio:
#       within_factor2_recomputed = 0.5 <= tau_hat/tau_true <= 2.0
#
#   Recompute all scenario/template summaries from the frozen simulation
#   master. NO simulation is rerun and NO fit is changed.
#
# Additional Q1-strength audit:
#   Wilson 95% confidence intervals for:
#       - WHITE_NULL false-positive gate rate
#       - OU gate recovery
#       - factor-2 tau recovery
#       - gate AND factor-2 recovery
#
# Inputs:
#   outputs/tables/stage09c1_drw_simulation_master.csv
#
# Outputs:
#   outputs/tables/stage09c1b_drw_scenario_summary_repaired.csv
#   outputs/tables/stage09c1b_drw_template_summary_repaired.csv
#   outputs/audit/stage09c1b_boolean_repair_audit.csv
#   outputs/audit/stage09c1b_summary.txt
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

IN_MASTER = TABLE_DIR / "stage09c1_drw_simulation_master.csv"

OUT_SCEN = TABLE_DIR / "stage09c1b_drw_scenario_summary_repaired.csv"
OUT_TEMPLATE = TABLE_DIR / "stage09c1b_drw_template_summary_repaired.csv"
OUT_AUDIT = AUDIT_DIR / "stage09c1b_boolean_repair_audit.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09c1b_summary.txt"

AUDIT_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce",
    )


def robust_bool(s):
    # Handle bool, 1/0, 1.0/0.0, and string variants.
    x = s.copy()

    if pd.api.types.is_bool_dtype(x):
        return x.fillna(False).astype(bool)

    num = pd.to_numeric(
        x,
        errors="coerce",
    )

    out = pd.Series(
        False,
        index=x.index,
        dtype=bool,
    )

    num_good = num.notna()

    out.loc[num_good] = (
        num.loc[num_good] != 0
    )

    rem = ~num_good

    if rem.any():
        txt = (
            x.loc[rem]
            .astype(str)
            .str.strip()
            .str.lower()
        )

        out.loc[rem] = txt.isin(
            [
                "true",
                "t",
                "yes",
                "y",
            ]
        )

    return out


def wilson_interval(k, n, z=1.959963984540054):
    if n <= 0:
        return (
            np.nan,
            np.nan,
        )

    p = k / n

    denom = (
        1.0
        +
        z * z / n
    )

    centre = (
        p
        +
        z * z / (2.0 * n)
    ) / denom

    half = (
        z
        *
        math.sqrt(
            (
                p * (1.0 - p) / n
                +
                z * z / (4.0 * n * n)
            )
        )
        /
        denom
    )

    return (
        max(
            0.0,
            centre - half,
        ),
        min(
            1.0,
            centre + half,
        ),
    )


if not IN_MASTER.exists():
    raise FileNotFoundError(
        IN_MASTER
    )

d = pd.read_csv(
    IN_MASTER,
    low_memory=False,
)

if len(d) != 2304:
    print(
        f"WARNING: expected 2304 rows from default run; found {len(d)}."
    )

required = [
    "scenario",
    "fit_status",
    "tau_interpretable_gate",
    "tau_hat_over_true",
]

missing = [
    c
    for c in required
    if c not in d.columns
]

if missing:
    raise RuntimeError(
        "Missing required columns: "
        +
        repr(
            missing
        )
    )

d["fit_ok"] = (
    d["fit_status"]
    .astype(str)
    .eq("OK")
)

d["gate_bool_recomputed"] = robust_bool(
    d["tau_interpretable_gate"]
)

ratio = numeric(
    d["tau_hat_over_true"]
)

d["within_factor2_recomputed"] = (
    ratio.notna()
    &
    (ratio >= 0.5)
    &
    (ratio <= 2.0)
)

d["gate_and_factor2_recomputed"] = (
    d["gate_bool_recomputed"]
    &
    d["within_factor2_recomputed"]
)

# Compare against the original serialized boolean, if present.
audit_rows = []

if "within_factor2_true" in d.columns:
    original_parsed = robust_bool(
        d["within_factor2_true"]
    )

    # Also reproduce the exact old Stage09C1 parser to prove the failure mode.
    old_parser = (
        d["within_factor2_true"]
        .astype(str)
        .str.strip()
        .str.lower()
        .isin(
            [
                "true",
                "1",
                "yes",
                "y",
            ]
        )
    )

    for scenario, g in d.groupby(
        "scenario"
    ):
        idx = g.index

        audit_rows.append({
            "scenario": scenario,
            "N": len(g),
            "old_parser_positive": int(
                old_parser.loc[idx].sum()
            ),
            "robust_parser_positive": int(
                original_parsed.loc[idx].sum()
            ),
            "numeric_recomputed_positive": int(
                d.loc[
                    idx,
                    "within_factor2_recomputed",
                ].sum()
            ),
            "old_vs_numeric_mismatch": int(
                (
                    old_parser.loc[idx]
                    !=
                    d.loc[
                        idx,
                        "within_factor2_recomputed",
                    ]
                ).sum()
            ),
        })

audit = pd.DataFrame(
    audit_rows
)

audit.to_csv(
    OUT_AUDIT,
    index=False,
)


# ============================================================
# SCENARIO SUMMARY
# ============================================================

scenario_rows = []

for scenario, g in d.groupby(
    "scenario"
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    n_ok = len(
        ok
    )

    k_gate = int(
        ok[
            "gate_bool_recomputed"
        ].sum()
    )

    gate_lo, gate_hi = wilson_interval(
        k_gate,
        n_ok,
    )

    row = {
        "scenario": scenario,
        "N_simulations": len(g),
        "N_fit_ok": n_ok,
        "fit_ok_fraction": (
            n_ok / len(g)
            if len(g)
            else np.nan
        ),
        "gate_positive_N": k_gate,
        "gate_positive_fraction": (
            k_gate / n_ok
            if n_ok
            else np.nan
        ),
        "gate_positive_ci95_low": gate_lo,
        "gate_positive_ci95_high": gate_hi,
        "median_delta_bic": (
            numeric(
                ok[
                    "delta_bic_white_minus_drw"
                ]
            ).median()
            if (
                n_ok
                and
                "delta_bic_white_minus_drw" in ok.columns
            )
            else np.nan
        ),
    }

    if scenario != "WHITE_NULL":
        ratios = numeric(
            ok[
                "tau_hat_over_true"
            ]
        ).replace(
            [np.inf, -np.inf],
            np.nan,
        ).dropna()

        abslog = numeric(
            ok[
                "abs_log10_tau_ratio"
            ]
        ).dropna()

        k_f2 = int(
            ok[
                "within_factor2_recomputed"
            ].sum()
        )

        k_both = int(
            ok[
                "gate_and_factor2_recomputed"
            ].sum()
        )

        f2_lo, f2_hi = wilson_interval(
            k_f2,
            n_ok,
        )

        both_lo, both_hi = wilson_interval(
            k_both,
            n_ok,
        )

        row.update({
            "tau_ratio_median": (
                ratios.median()
                if len(ratios)
                else np.nan
            ),
            "tau_ratio_p16": (
                ratios.quantile(
                    0.16
                )
                if len(ratios)
                else np.nan
            ),
            "tau_ratio_p84": (
                ratios.quantile(
                    0.84
                )
                if len(ratios)
                else np.nan
            ),
            "median_abs_log10_tau_ratio": (
                abslog.median()
                if len(abslog)
                else np.nan
            ),
            "within_factor2_N": k_f2,
            "within_factor2_fraction": (
                k_f2 / n_ok
                if n_ok
                else np.nan
            ),
            "within_factor2_ci95_low": f2_lo,
            "within_factor2_ci95_high": f2_hi,
            "gate_and_factor2_N": k_both,
            "gate_and_factor2_fraction": (
                k_both / n_ok
                if n_ok
                else np.nan
            ),
            "gate_and_factor2_ci95_low": both_lo,
            "gate_and_factor2_ci95_high": both_hi,
        })

    scenario_rows.append(
        row
    )

scenario_summary = pd.DataFrame(
    scenario_rows
)

scenario_summary.to_csv(
    OUT_SCEN,
    index=False,
)


# ============================================================
# TEMPLATE SUMMARY
# ============================================================

template_rows = []

for (
    template_id,
    scenario,
), g in d.groupby(
    [
        "template_id",
        "scenario",
    ]
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    n_ok = len(
        ok
    )

    ratios = numeric(
        ok[
            "tau_hat_over_true"
        ]
    ).replace(
        [np.inf, -np.inf],
        np.nan,
    ).dropna()

    template_rows.append({
        "template_id": template_id,
        "scenario": scenario,
        "N_simulations": len(g),
        "N_fit_ok": n_ok,
        "gate_positive_fraction": (
            float(
                ok[
                    "gate_bool_recomputed"
                ].mean()
            )
            if n_ok
            else np.nan
        ),
        "tau_ratio_median": (
            ratios.median()
            if len(ratios)
            else np.nan
        ),
        "within_factor2_fraction": (
            float(
                ok[
                    "within_factor2_recomputed"
                ].mean()
            )
            if (
                n_ok
                and
                scenario != "WHITE_NULL"
            )
            else np.nan
        ),
        "gate_and_factor2_fraction": (
            float(
                ok[
                    "gate_and_factor2_recomputed"
                ].mean()
            )
            if (
                n_ok
                and
                scenario != "WHITE_NULL"
            )
            else np.nan
        ),
    })

template_summary = pd.DataFrame(
    template_rows
)

template_summary.to_csv(
    OUT_TEMPLATE,
    index=False,
)


# ============================================================
# SUMMARY
# ============================================================

def get_scenario(
    name,
):
    hit = scenario_summary.loc[
        scenario_summary[
            "scenario"
        ].eq(name)
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


lines = [
    "BLAZAR_I - STAGE 09C1B FINAL SUMMARY",
    "=" * 80,
    "",
    "DRW calibration aggregation repair",
    "",
    "IMPORTANT:",
    "  The 2304 Stage09C1 simulations and all fitted parameters are unchanged.",
    "  Only the recovery-summary boolean aggregation was repaired.",
    "",
]

null = get_scenario(
    "WHITE_NULL"
)

if null is not None:
    lines += [
        "WHITE_NULL:",
        f"  fit success fraction          : {null['fit_ok_fraction']:.4f}",
        f"  false-positive DRW gate rate  : {null['gate_positive_fraction']:.4f}",
        f"  Wilson 95% CI                 : [{null['gate_positive_ci95_low']:.4f}, {null['gate_positive_ci95_high']:.4f}]",
        f"  median DeltaBIC               : {null['median_delta_bic']:.3f}",
        "",
    ]

for name in [
    "OU_SHORT",
    "OU_MID",
    "OU_LONG",
]:
    r = get_scenario(
        name
    )

    if r is None:
        continue

    lines += [
        f"{name}:",
        f"  DRW gate recovery             : {r['gate_positive_fraction']:.4f} [{r['gate_positive_ci95_low']:.4f}, {r['gate_positive_ci95_high']:.4f}]",
        f"  median tau_hat/tau_true       : {r['tau_ratio_median']:.3f}",
        f"  16-84% tau ratio              : [{r['tau_ratio_p16']:.3f}, {r['tau_ratio_p84']:.3f}]",
        f"  within factor 2               : {r['within_factor2_fraction']:.4f} [{r['within_factor2_ci95_low']:.4f}, {r['within_factor2_ci95_high']:.4f}]",
        f"  gate AND within factor 2      : {r['gate_and_factor2_fraction']:.4f} [{r['gate_and_factor2_ci95_low']:.4f}, {r['gate_and_factor2_ci95_high']:.4f}]",
        "",
    ]

lines += [
    "Repair audit:",
]

if len(audit):
    for _, r in audit.iterrows():
        lines.append(
            f"  {r['scenario']:10s}: "
            f"old_parser={int(r['old_parser_positive'])}, "
            f"numeric_recomputed={int(r['numeric_recomputed_positive'])}, "
            f"mismatch={int(r['old_vs_numeric_mismatch'])}"
        )

lines += [
    "",
    "Scientific interpretation:",
    "  - Use this repaired Stage09C1B summary in the manuscript/audit ledger.",
    "  - The original Stage09C1 tau estimates, DeltaBIC values, and gate",
    "    classifications remain valid.",
    "  - No simulation rerun is necessary.",
    "",
    "Files saved:",
    f"  {OUT_SCEN}",
    f"  {OUT_TEMPLATE}",
    f"  {OUT_AUDIT}",
    "",
    "Next:",
    "  STAGE 09C2 — colour-break false-positive / injection recovery.",
    "",
    "STAGE 09C1B COMPLETE",
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(
    summary
)
