# ============================================================
# BLAZAR_I — STAGE 09C0
# INJECTION-RECOVERY CALIBRATION DESIGN + TEMPLATE BANK
#
# Purpose:
#   Build deterministic, observation-conditioned template banks for the
#   reviewer-critical injection/recovery simulations that follow.
#
# Why a template bank?
#   Running thousands of full refits on all 1061 sources for every
#   injected condition is unnecessarily expensive. Instead we select
#   actual ZTF sampling/error patterns spanning the observed information
#   space, then perform calibrated null/injection experiments on those
#   real designs.
#
# Template banks:
#   A) SOURCE-FILTER bank (DRW / flux-PDF / rms-flux)
#      stratified across:
#        - optical class
#        - filter
#        - nightly N
#        - cadence
#        - photometric uncertainty
#        - fractional variability
#
#   B) COLOUR bank
#      stratified across:
#        - optical class
#        - N_colour_pairs
#        - r-band dynamic range
#        - pairing time offset
#
# No simulation and no endpoint refit is performed here.
#
# Outputs:
#   outputs/tables/stage09c0_source_filter_template_bank.csv
#   outputs/tables/stage09c0_colour_template_bank.csv
#   outputs/tables/stage09c0_template_coverage.csv
#   outputs/audit/stage09c0_summary.txt
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

DRW_FILE = TABLE_DIR / "stage03d_drw_master.csv"
PDF_FILE = TABLE_DIR / "stage03a_fluxpdf_master.csv"
COL_FILE = TABLE_DIR / "stage03c_colour_break_master.csv"
CONF_FILE = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"

OUT_SF = TABLE_DIR / "stage09c0_source_filter_template_bank.csv"
OUT_COL = TABLE_DIR / "stage09c0_colour_template_bank.csv"
OUT_COVER = TABLE_DIR / "stage09c0_template_coverage.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09c0_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

TARGET_SOURCE_FILTER = 48
TARGET_COLOUR = 36
SEED = 20260918


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce",
    )


def qbin(s, q, label_prefix):
    x = numeric(s)

    valid = x.notna()

    out = pd.Series(
        "MISSING",
        index=s.index,
        dtype="object",
    )

    if valid.sum() < q:
        out.loc[valid] = f"{label_prefix}0"
        return out

    try:
        b = pd.qcut(
            x.loc[valid],
            q=q,
            labels=False,
            duplicates="drop",
        )

        out.loc[valid] = (
            label_prefix
            +
            b.astype(int).astype(str)
        )

    except Exception:
        out.loc[valid] = f"{label_prefix}0"

    return out


def minmax_score(df, cols):
    score = pd.Series(
        0.0,
        index=df.index,
        dtype=float,
    )

    n = 0

    for c in cols:
        x = numeric(df[c])

        lo = x.quantile(0.05)
        hi = x.quantile(0.95)

        if (
            not np.isfinite(lo)
            or
            not np.isfinite(hi)
            or
            hi <= lo
        ):
            continue

        z = (
            (x - lo)
            /
            (hi - lo)
        ).clip(
            0,
            1,
        )

        score += z.fillna(0.5)
        n += 1

    if n == 0:
        return score

    return score / n


def deterministic_fill(
    selected,
    pool,
    n_target,
    diversity_cols,
):
    selected = selected.copy()

    selected_keys = set(
        selected["_key"]
        .astype(str)
        .tolist()
    )

    remaining = pool.loc[
        ~pool["_key"]
        .astype(str)
        .isin(selected_keys)
    ].copy()

    if len(selected) >= n_target:
        return selected.head(
            n_target
        ).copy()

    # Rank-based deterministic "space-filling" order.
    for c in diversity_cols:
        r = numeric(
            remaining[c]
        ).rank(
            method="average",
            pct=True,
        )

        remaining[
            f"_rank_{c}"
        ] = r.fillna(
            0.5
        )

    rank_cols = [
        f"_rank_{c}"
        for c in diversity_cols
    ]

    if rank_cols:
        # Alternate between low/high combined rank distance from centre.
        arr = remaining[
            rank_cols
        ].to_numpy(
            dtype=float
        )

        dist = np.sqrt(
            np.sum(
                (arr - 0.5) ** 2,
                axis=1,
            )
        )

        remaining["_diversity_priority"] = dist

        remaining = remaining.sort_values(
            [
                "_diversity_priority",
                "_key",
            ],
            ascending=[
                False,
                True,
            ],
        )

    need = (
        n_target
        -
        len(selected)
    )

    add = remaining.head(
        need
    ).copy()

    return pd.concat(
        [
            selected,
            add,
        ],
        ignore_index=True,
    )


for path in [
    DRW_FILE,
    PDF_FILE,
    COL_FILE,
    CONF_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

if not NIGHTLY_DIR.exists():
    raise FileNotFoundError(
        NIGHTLY_DIR
    )


# ============================================================
# SOURCE-FILTER BANK
# ============================================================

drw = pd.read_csv(
    DRW_FILE,
    low_memory=False,
)

pdf = pd.read_csv(
    PDF_FILE,
    low_memory=False,
)

conf = pd.read_csv(
    CONF_FILE,
    low_memory=False,
)

for df in [
    drw,
    pdf,
    conf,
]:
    df["blazar_id"] = (
        df["blazar_id"]
        .astype(str)
    )

drw["filter_name"] = (
    drw["filter_name"]
    .astype(str)
    .str.lower()
)

pdf["filter_name"] = (
    pdf["filter_name"]
    .astype(str)
    .str.lower()
)

sf = drw[
    [
        "blazar_id",
        "blazar_class",
        "filter_name",
        "N_nightly",
        "baseline_days",
        "median_cadence_days",
        "median_magerr",
        "tau_obs_days",
        "tau_rest_days",
        "tau_interpretable_primary",
    ]
].copy()

pdf_keep = pdf[
    [
        "blazar_id",
        "filter_name",
        "Fvar",
        "robust_amp_mag_p95_p05",
        "preferred_bic_model",
        "delta_bic_second_minus_best",
    ]
].copy()

sf = sf.merge(
    pdf_keep,
    on=[
        "blazar_id",
        "filter_name",
    ],
    how="left",
    validate="one_to_one",
)

sf = sf.merge(
    conf[
        [
            "blazar_id",
            "redshift",
            "sed_class",
            "median_mag_g",
            "median_mag_r",
            "ps1_host_proxy_ri",
        ]
    ],
    on="blazar_id",
    how="left",
    validate="many_to_one",
)

sf["median_mag_filter"] = np.where(
    sf["filter_name"].eq("g"),
    numeric(
        sf["median_mag_g"]
    ),
    numeric(
        sf["median_mag_r"]
    ),
)

sf["_key"] = (
    sf["blazar_id"]
    +
    "|"
    +
    sf["filter_name"]
)

sf["nightly_file"] = (
    sf["blazar_id"]
    .map(
        lambda x: str(
            NIGHTLY_DIR
            /
            f"{x}_NIGHTLY.parquet"
        )
    )
)

sf["nightly_file_exists"] = (
    sf["blazar_id"]
    .map(
        lambda x: (
            NIGHTLY_DIR
            /
            f"{x}_NIGHTLY.parquet"
        ).exists()
    )
)

sf = sf.loc[
    sf["nightly_file_exists"]
].copy()

# Require enough points to support every calibration family.
sf = sf.loc[
    numeric(
        sf["N_nightly"]
    )
    >=
    100
].copy()

sf["N_bin"] = qbin(
    sf["N_nightly"],
    4,
    "N",
)

sf["cadence_bin"] = qbin(
    sf["median_cadence_days"],
    2,
    "C",
)

sf["err_bin"] = qbin(
    sf["median_magerr"],
    2,
    "E",
)

sf["Fvar_bin"] = qbin(
    sf["Fvar"],
    2,
    "V",
)

# Primary grid: class x filter x N quartile x cadence half.
group_cols = [
    "blazar_class",
    "filter_name",
    "N_bin",
    "cadence_bin",
]

selected_rows = []

for _, g in sf.groupby(
    group_cols,
    dropna=False,
):
    g = g.copy()

    # choose row closest to within-cell medians in error and Fvar.
    err_med = numeric(
        g["median_magerr"]
    ).median()

    fvar_med = numeric(
        g["Fvar"]
    ).median()

    g["_cell_distance"] = (
        (
            numeric(
                g["median_magerr"]
            )
            -
            err_med
        ).abs()
        /
        (
            abs(err_med)
            +
            1e-12
        )
        +
        (
            numeric(
                g["Fvar"]
            )
            -
            fvar_med
        ).abs()
        /
        (
            abs(fvar_med)
            +
            1e-12
        )
    )

    g = g.sort_values(
        [
            "_cell_distance",
            "_key",
        ]
    )

    selected_rows.append(
        g.iloc[[0]]
    )

selected_sf = pd.concat(
    selected_rows,
    ignore_index=True,
)

selected_sf = deterministic_fill(
    selected_sf,
    sf,
    TARGET_SOURCE_FILTER,
    diversity_cols=[
        "N_nightly",
        "median_cadence_days",
        "median_magerr",
        "Fvar",
        "median_mag_filter",
    ],
)

selected_sf = (
    selected_sf
    .drop_duplicates(
        "_key"
    )
    .head(
        TARGET_SOURCE_FILTER
    )
    .copy()
)

selected_sf["template_id"] = [
    f"SF_{i:03d}"
    for i in range(
        1,
        len(selected_sf) + 1,
    )
]

keep_sf = [
    "template_id",
    "blazar_id",
    "blazar_class",
    "filter_name",
    "N_nightly",
    "baseline_days",
    "median_cadence_days",
    "median_magerr",
    "median_mag_filter",
    "Fvar",
    "robust_amp_mag_p95_p05",
    "preferred_bic_model",
    "delta_bic_second_minus_best",
    "tau_obs_days",
    "tau_rest_days",
    "tau_interpretable_primary",
    "redshift",
    "sed_class",
    "ps1_host_proxy_ri",
    "N_bin",
    "cadence_bin",
    "err_bin",
    "Fvar_bin",
    "nightly_file",
]

selected_sf[
    keep_sf
].to_csv(
    OUT_SF,
    index=False,
)


# ============================================================
# COLOUR TEMPLATE BANK
# ============================================================

col = pd.read_csv(
    COL_FILE,
    low_memory=False,
)

col["blazar_id"] = (
    col["blazar_id"]
    .astype(str)
)

# stage03c_colour_break_master.csv may already contain blazar_class.
# Avoid pandas suffixing it to blazar_class_x / blazar_class_y, which would
# remove the exact column name expected by the stratified template selector.
#
# Prefer the Stage03C class label when present because it belongs to the
# frozen diagnostic table; otherwise add it from the Stage09A2 master.
colour_conf_cols = [
    "blazar_id",
    "redshift",
    "sed_class",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
]

if "blazar_class" not in col.columns:
    colour_conf_cols.insert(
        1,
        "blazar_class",
    )

colour = col.merge(
    conf[
        colour_conf_cols
    ],
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

if "blazar_class" not in colour.columns:
    raise RuntimeError(
        "Colour template table has no blazar_class after merge."
    )

# Cross-check against the Stage09A2 source-level class label without
# altering the frozen Stage03C label.
class_check = conf[
    [
        "blazar_id",
        "blazar_class",
    ]
].rename(
    columns={
        "blazar_class": "blazar_class_stage09a2",
    }
)

colour = colour.merge(
    class_check,
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

class_mismatch = (
    colour["blazar_class"]
    .astype(str)
    .str.strip()
    .str.upper()
    !=
    colour["blazar_class_stage09a2"]
    .astype(str)
    .str.strip()
    .str.upper()
)

if class_mismatch.any():
    bad = colour.loc[
        class_mismatch,
        [
            "blazar_id",
            "blazar_class",
            "blazar_class_stage09a2",
        ],
    ].head(10)

    raise RuntimeError(
        "Stage03C vs Stage09A2 blazar_class mismatch. Examples:\n"
        + bad.to_string(index=False)
    )

colour = colour.drop(
    columns=[
        "blazar_class_stage09a2",
    ]
)

colour["_key"] = (
    colour["blazar_id"]
)

colour["nightly_file"] = (
    colour["blazar_id"]
    .map(
        lambda x: str(
            NIGHTLY_DIR
            /
            f"{x}_NIGHTLY.parquet"
        )
    )
)

colour["nightly_file_exists"] = (
    colour["blazar_id"]
    .map(
        lambda x: (
            NIGHTLY_DIR
            /
            f"{x}_NIGHTLY.parquet"
        ).exists()
    )
)

colour = colour.loc[
    colour["nightly_file_exists"]
].copy()

# At least 30 pairs so both linear and broken injected fits are meaningful.
colour = colour.loc[
    numeric(
        colour["N_colour_pairs"]
    )
    >=
    30
].copy()

colour["Ncolour_bin"] = qbin(
    colour["N_colour_pairs"],
    3,
    "N",
)

colour["range_bin"] = qbin(
    colour["r_mag_range"],
    3,
    "R",
)

colour["dt_bin"] = qbin(
    colour["pair_dt_hours_median"],
    2,
    "T",
)

group_cols_col = [
    "blazar_class",
    "Ncolour_bin",
    "range_bin",
]

selected_rows = []

for _, g in colour.groupby(
    group_cols_col,
    dropna=False,
):
    g = g.copy()

    dt_med = numeric(
        g["pair_dt_hours_median"]
    ).median()

    range_med = numeric(
        g["r_mag_range"]
    ).median()

    g["_cell_distance"] = (
        (
            numeric(
                g["pair_dt_hours_median"]
            )
            -
            dt_med
        ).abs()
        /
        (
            abs(dt_med)
            +
            1e-12
        )
        +
        (
            numeric(
                g["r_mag_range"]
            )
            -
            range_med
        ).abs()
        /
        (
            abs(range_med)
            +
            1e-12
        )
    )

    g = g.sort_values(
        [
            "_cell_distance",
            "_key",
        ]
    )

    selected_rows.append(
        g.iloc[[0]]
    )

selected_col = pd.concat(
    selected_rows,
    ignore_index=True,
)

selected_col = deterministic_fill(
    selected_col,
    colour,
    TARGET_COLOUR,
    diversity_cols=[
        "N_colour_pairs",
        "r_mag_range",
        "pair_dt_hours_median",
        "median_mag_r",
    ],
)

selected_col = (
    selected_col
    .drop_duplicates(
        "_key"
    )
    .head(
        TARGET_COLOUR
    )
    .copy()
)

selected_col["template_id"] = [
    f"COL_{i:03d}"
    for i in range(
        1,
        len(selected_col) + 1,
    )
]

keep_col = [
    "template_id",
    "blazar_id",
    "blazar_class",
    "N_colour_pairs",
    "r_mag_range",
    "pair_dt_hours_median",
    "spearman_rho",
    "single_slope_dcolor_dr",
    "break_r_mag",
    "break_slope_left",
    "break_slope_right",
    "delta_bic_single_minus_broken",
    "redshift",
    "sed_class",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
    "Ncolour_bin",
    "range_bin",
    "dt_bin",
    "nightly_file",
]

selected_col[
    keep_col
].to_csv(
    OUT_COL,
    index=False,
)


# ============================================================
# COVERAGE AUDIT
# ============================================================

cover_rows = []

def add_cover(
    bank_name,
    selected,
    population,
    columns,
):
    for c in columns:
        s_all = numeric(
            population[c]
        ).dropna()

        s_sel = numeric(
            selected[c]
        ).dropna()

        if len(s_all) == 0:
            continue

        cover_rows.append({
            "bank": bank_name,
            "variable": c,
            "population_N": len(s_all),
            "selected_N": len(s_sel),
            "population_p05": s_all.quantile(0.05),
            "population_p50": s_all.quantile(0.50),
            "population_p95": s_all.quantile(0.95),
            "selected_min": (
                s_sel.min()
                if len(s_sel)
                else np.nan
            ),
            "selected_p50": (
                s_sel.quantile(0.50)
                if len(s_sel)
                else np.nan
            ),
            "selected_max": (
                s_sel.max()
                if len(s_sel)
                else np.nan
            ),
            "covers_population_p05": (
                bool(
                    s_sel.min()
                    <=
                    s_all.quantile(0.05)
                )
                if len(s_sel)
                else False
            ),
            "covers_population_p95": (
                bool(
                    s_sel.max()
                    >=
                    s_all.quantile(0.95)
                )
                if len(s_sel)
                else False
            ),
        })


add_cover(
    "SOURCE_FILTER",
    selected_sf,
    sf,
    [
        "N_nightly",
        "baseline_days",
        "median_cadence_days",
        "median_magerr",
        "median_mag_filter",
        "Fvar",
    ],
)

add_cover(
    "COLOUR",
    selected_col,
    colour,
    [
        "N_colour_pairs",
        "r_mag_range",
        "pair_dt_hours_median",
        "median_mag_r",
    ],
)

coverage = pd.DataFrame(
    cover_rows
)

coverage.to_csv(
    OUT_COVER,
    index=False,
)


# ============================================================
# SUMMARY
# ============================================================

sf_class = (
    selected_sf
    .groupby(
        [
            "blazar_class",
            "filter_name",
        ]
    )
    .size()
    .to_dict()
)

col_class = (
    selected_col
    .groupby(
        "blazar_class"
    )
    .size()
    .to_dict()
)

coverage_pass = int(
    (
        coverage[
            "covers_population_p05"
        ]
        &
        coverage[
            "covers_population_p95"
        ]
    ).sum()
)

summary = f"""BLAZAR_I - STAGE 09C0 FINAL SUMMARY
================================================================================

Injection-recovery calibration template design

SOURCE-FILTER template bank:
  target                         : {TARGET_SOURCE_FILTER}
  selected                       : {len(selected_sf)}
  BLL g                          : {sf_class.get(('BLL','g'), 0)}
  BLL r                          : {sf_class.get(('BLL','r'), 0)}
  FSRQ g                         : {sf_class.get(('FSRQ','g'), 0)}
  FSRQ r                         : {sf_class.get(('FSRQ','r'), 0)}

COLOUR template bank:
  target                         : {TARGET_COLOUR}
  selected                       : {len(selected_col)}
  BLL                            : {col_class.get('BLL', 0)}
  FSRQ                           : {col_class.get('FSRQ', 0)}

Coverage audit:
  variables audited              : {len(coverage)}
  selected min/max span both
  population p05 and p95         : {coverage_pass}/{len(coverage)}

Scientific design:
  - Templates retain ACTUAL ZTF cadence and photometric-error structure.
  - Source-filter bank will be reused for DRW, PDF, and rms-flux simulations.
  - Colour bank will be reused for linear-null and broken-line injections.
  - Selection is deterministic and covers information-content extremes.
  - No observed endpoint is refit in Stage 09C0.

Planned calibration sequence:
  09C1  DRW null/injection recovery
  09C2  colour-break false-positive/recovery
  09C3  flux-PDF correlated-lognormal null + mixture injection
  09C4  rms-flux additive-null + multiplicative injection
  09C5  integrated calibration ledger

Files saved:
  {OUT_SF}
  {OUT_COL}
  {OUT_COVER}

STAGE 09C0 COMPLETE
"""

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(
    summary
)
