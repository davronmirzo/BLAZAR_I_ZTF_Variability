# ============================================================
# BLAZAR_I — STAGE 03B
# RMS–FLUX RELATION
#
# Input:
#   outputs/tables/stage02b3_GOLD_PLUS_SILVER.csv
#   data/processed/stage02b3_sources/BZI_xxxxx_NIGHTLY.parquet
#
# Primary, pre-specified method:
#   * NIGHTLY fluxes only
#   * time-ordered consecutive segments
#   * exactly 20 nightly points per segment
#   * incomplete final remainder is not used in the primary fit
#   * at least 8 complete segments required (>=160 nightly points)
#   * intrinsic segment rms:
#       rms_XS = sqrt(max(S^2 - mean(err^2), 0))
#   * Spearman and Pearson correlations between segment mean flux
#     and intrinsic rms
#   * OLS slope/intercept
#   * deterministic paired-segment bootstrap for slope/intercept
#   * Benjamini-Hochberg FDR after all source/filter fits
#
# Primary "strict positive rms–flux" gate after global FDR:
#   eligible fit
#   rho_S > 0
#   OLS slope > 0
#   bootstrap 95% lower bound on slope > 0
#   global BH q(Spearman) <= 0.05
#
# Notes:
#   * Mean flux is the arithmetic segment mean, as in the standard
#     rms–flux construction.
#   * No sigma clipping is performed here.
#   * Segment temporal span is saved for cadence/gap diagnostics.
#   * A later sensitivity stage should compare alternate segment sizes
#     and fixed-duration bins; primary results here remain frozen.
#
# Checkpoint unit:
#   1 blazar -> summary CSV + segment parquet + .done
# ============================================================

from pathlib import Path
import argparse
import math
import sys
import time
import traceback
import zlib

import numpy as np
import pandas as pd

from scipy.stats import spearmanr, pearsonr, linregress


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="Process at most this many unfinished blazars."
)

args = parser.parse_args()


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

SAMPLE_FILE = (
    ROOT / "outputs" / "tables"
    / "stage02b3_GOLD_PLUS_SILVER.csv"
)

NIGHTLY_DIR = (
    ROOT / "data" / "processed"
    / "stage02b3_sources"
)

OUT_DIR = (
    ROOT / "outputs" / "models"
    / "stage03b_rmflux"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# FROZEN CONFIG
# ============================================================

SEGMENT_N = 20
MIN_SEGMENTS = 8

BOOTSTRAP_N = 2000
BOOTSTRAP_BASE_SEED = 20260917

FDR_ALPHA = 0.05


# ============================================================
# OUTPUT HELPERS
# ============================================================

def summary_file(blazar_id):
    return OUT_DIR / f"{blazar_id}_03B_SUMMARY.csv"

def segment_file(blazar_id):
    return OUT_DIR / f"{blazar_id}_03B_SEGMENTS.parquet"

def done_file(blazar_id):
    return OUT_DIR / f"{blazar_id}.done"

def temp_path(path):
    return path.with_name(path.name + ".tmp")

def remove_if_exists(path):
    if path.exists():
        path.unlink()

def atomic_csv(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_csv(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)

def atomic_parquet(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_parquet(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)

def atomic_text(text, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    tmp.write_text(text, encoding="utf-8")
    remove_if_exists(path)
    tmp.replace(path)


# ============================================================
# BENJAMINI-HOCHBERG
# ============================================================

def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)

    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw_q = ranked * m / np.arange(1, m + 1)

    # Monotone from largest rank down.
    adj = np.minimum.accumulate(raw_q[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    q_valid = np.empty(m, dtype=float)
    q_valid[order] = adj

    q[valid] = q_valid

    return q


# ============================================================
# DETERMINISTIC BOOTSTRAP SEED
# ============================================================

def stable_seed(blazar_id, filt):
    token = (
        f"{BOOTSTRAP_BASE_SEED}|{blazar_id}|{filt}"
    ).encode("utf-8")

    return int(
        zlib.crc32(token) & 0xFFFFFFFF
    )


# ============================================================
# SEGMENT CONSTRUCTION
# ============================================================

SEGMENT_COLUMNS = [
    "blazar_id",
    "filter_name",
    "segment_index",
    "N_points",
    "hmjd_start",
    "hmjd_end",
    "hmjd_mid",
    "span_days",
    "mean_flux_jy",
    "median_flux_jy",
    "mean_fluxerr2_jy2",
    "sample_variance_jy2",
    "observed_rms_jy",
    "excess_variance_jy2",
    "intrinsic_rms_jy",
    "fractional_rms",
    "noise_dominated",
]


def build_segments(blazar_id, filt, nightly):
    x = nightly.loc[
        nightly["filter_name"].eq(filt),
        [
            "hmjd",
            "flux_jy",
            "fluxerr_jy",
        ],
    ].copy()

    for col in [
        "hmjd",
        "flux_jy",
        "fluxerr_jy",
    ]:
        x[col] = pd.to_numeric(
            x[col],
            errors="coerce"
        )

    x = x.loc[
        np.isfinite(x["hmjd"])
        & np.isfinite(x["flux_jy"])
        & np.isfinite(x["fluxerr_jy"])
        & (x["flux_jy"] > 0)
        & (x["fluxerr_jy"] >= 0)
    ].sort_values("hmjd").reset_index(drop=True)

    n_total = len(x)

    n_complete = n_total // SEGMENT_N
    n_used = n_complete * SEGMENT_N
    n_discarded = n_total - n_used

    rows = []

    for j in range(n_complete):
        a = j * SEGMENT_N
        b = a + SEGMENT_N

        seg = x.iloc[a:b]

        t = seg["hmjd"].to_numpy(dtype=float)
        f = seg["flux_jy"].to_numpy(dtype=float)
        e = seg["fluxerr_jy"].to_numpy(dtype=float)

        mean_f = float(np.mean(f))
        median_f = float(np.median(f))

        if len(f) >= 2:
            s2 = float(np.var(f, ddof=1))
        else:
            s2 = np.nan

        mean_e2 = float(np.mean(e ** 2))

        if np.isfinite(s2) and s2 >= 0:
            rms_obs = math.sqrt(s2)
            xs = s2 - mean_e2
            rms_xs = math.sqrt(max(xs, 0.0))
            noise_dominated = bool(xs <= 0)
        else:
            rms_obs = np.nan
            xs = np.nan
            rms_xs = np.nan
            noise_dominated = True

        if mean_f > 0 and np.isfinite(rms_xs):
            frac_rms = rms_xs / mean_f
        else:
            frac_rms = np.nan

        rows.append({
            "blazar_id": blazar_id,
            "filter_name": filt,
            "segment_index": j + 1,
            "N_points": len(seg),
            "hmjd_start": float(np.min(t)),
            "hmjd_end": float(np.max(t)),
            "hmjd_mid": float(np.median(t)),
            "span_days": float(np.max(t) - np.min(t)),
            "mean_flux_jy": mean_f,
            "median_flux_jy": median_f,
            "mean_fluxerr2_jy2": mean_e2,
            "sample_variance_jy2": s2,
            "observed_rms_jy": rms_obs,
            "excess_variance_jy2": xs,
            "intrinsic_rms_jy": rms_xs,
            "fractional_rms": frac_rms,
            "noise_dominated": noise_dominated,
        })

    segments = pd.DataFrame(
        rows,
        columns=SEGMENT_COLUMNS
    )

    meta = {
        "N_nightly_total": int(n_total),
        "N_points_used": int(n_used),
        "N_points_discarded_remainder": int(n_discarded),
        "N_segments": int(n_complete),
    }

    return segments, meta


# ============================================================
# VECTORIZED BOOTSTRAP OF OLS SLOPE / INTERCEPT
# ============================================================

def bootstrap_linear_fit(x, y, seed):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)

    out = {
        "boot_valid_N": 0,
        "slope_boot_median": np.nan,
        "slope_boot_p16": np.nan,
        "slope_boot_p84": np.nan,
        "slope_boot_p025": np.nan,
        "slope_boot_p975": np.nan,
        "intercept_boot_median_jy": np.nan,
        "intercept_boot_p16_jy": np.nan,
        "intercept_boot_p84_jy": np.nan,
        "intercept_boot_p025_jy": np.nan,
        "intercept_boot_p975_jy": np.nan,
    }

    if n < 2:
        return out

    rng = np.random.default_rng(seed)

    idx = rng.integers(
        0,
        n,
        size=(BOOTSTRAP_N, n),
        endpoint=False
    )

    xb = x[idx]
    yb = y[idx]

    xm = xb.mean(axis=1)
    ym = yb.mean(axis=1)

    dx = xb - xm[:, None]
    dy = yb - ym[:, None]

    denom = np.sum(dx ** 2, axis=1)
    numer = np.sum(dx * dy, axis=1)

    valid = (
        np.isfinite(denom)
        & np.isfinite(numer)
        & (denom > 0)
    )

    slopes = np.full(
        BOOTSTRAP_N,
        np.nan,
        dtype=float
    )

    intercepts = np.full(
        BOOTSTRAP_N,
        np.nan,
        dtype=float
    )

    slopes[valid] = (
        numer[valid]
        /
        denom[valid]
    )

    intercepts[valid] = (
        ym[valid]
        -
        slopes[valid] * xm[valid]
    )

    slopes = slopes[np.isfinite(slopes)]
    intercepts = intercepts[np.isfinite(intercepts)]

    out["boot_valid_N"] = int(len(slopes))

    if len(slopes) == 0:
        return out

    out.update({
        "slope_boot_median": float(np.median(slopes)),
        "slope_boot_p16": float(np.percentile(slopes, 16)),
        "slope_boot_p84": float(np.percentile(slopes, 84)),
        "slope_boot_p025": float(np.percentile(slopes, 2.5)),
        "slope_boot_p975": float(np.percentile(slopes, 97.5)),
        "intercept_boot_median_jy": float(np.median(intercepts)),
        "intercept_boot_p16_jy": float(np.percentile(intercepts, 16)),
        "intercept_boot_p84_jy": float(np.percentile(intercepts, 84)),
        "intercept_boot_p025_jy": float(np.percentile(intercepts, 2.5)),
        "intercept_boot_p975_jy": float(np.percentile(intercepts, 97.5)),
    })

    return out


# ============================================================
# ANALYZE ONE FILTER
# ============================================================

def analyze_filter(blazar_id, filt, nightly, meta):
    segments, seg_meta = build_segments(
        blazar_id,
        filt,
        nightly
    )

    row = {
        "blazar_id": blazar_id,
        "Source_Name": meta.get("Source_Name", np.nan),
        "ASSOC1": meta.get("ASSOC1", np.nan),
        "blazar_class": meta.get("blazar_class", np.nan),
        "sample_tier": meta.get("sample_tier", np.nan),
        "redshift_clean": meta.get("redshift_clean", np.nan),
        "SED_class_clean": meta.get("SED_class_clean", np.nan),
        "filter_name": filt,
        "segment_N_points": SEGMENT_N,
        **seg_meta,
        "fit_status": "NOT_RUN",
    }

    if len(segments) == 0:
        row["fit_status"] = "NO_COMPLETE_SEGMENTS"
        return row, segments

    row["segment_span_days_median"] = float(
        segments["span_days"].median()
    )

    row["segment_span_days_p90"] = float(
        segments["span_days"].quantile(0.90)
    )

    row["N_noise_dominated_segments"] = int(
        segments["noise_dominated"].sum()
    )

    row["noise_dominated_fraction"] = float(
        segments["noise_dominated"].mean()
    )

    if len(segments) < MIN_SEGMENTS:
        row["fit_status"] = (
            f"TOO_FEW_SEGMENTS_LT_{MIN_SEGMENTS}"
        )
        return row, segments

    x = segments["mean_flux_jy"].to_numpy(dtype=float)
    y = segments["intrinsic_rms_jy"].to_numpy(dtype=float)

    good = (
        np.isfinite(x)
        & np.isfinite(y)
        & (x > 0)
        & (y >= 0)
    )

    x = x[good]
    y = y[good]

    row["N_segments_fit"] = int(len(x))

    if len(x) < MIN_SEGMENTS:
        row["fit_status"] = (
            f"TOO_FEW_FINITE_SEGMENTS_LT_{MIN_SEGMENTS}"
        )
        return row, segments

    if (
        np.allclose(x, x[0])
        or
        np.allclose(y, y[0])
    ):
        row["fit_status"] = "DEGENERATE_RELATION"
        return row, segments

    try:
        rho_s, p_s = spearmanr(x, y)
        r_p, p_p = pearsonr(x, y)

        lr = linregress(x, y)

        row.update({
            "spearman_rho": float(rho_s),
            "spearman_p": float(p_s),
            "pearson_r": float(r_p),
            "pearson_p": float(p_p),
            "ols_slope": float(lr.slope),
            "ols_intercept_jy": float(lr.intercept),
            "ols_rvalue": float(lr.rvalue),
            "ols_pvalue": float(lr.pvalue),
            "ols_slope_stderr": float(lr.stderr),
            "ols_intercept_stderr_jy": (
                float(lr.intercept_stderr)
                if lr.intercept_stderr is not None
                else np.nan
            ),
        })

        boot = bootstrap_linear_fit(
            x,
            y,
            stable_seed(
                blazar_id,
                filt
            )
        )

        row.update(boot)

        # Pre-FDR diagnostics only.
        row["positive_spearman_raw_p05"] = bool(
            np.isfinite(row["spearman_p"])
            and row["spearman_rho"] > 0
            and row["spearman_p"] <= 0.05
        )

        row["positive_slope_boot95"] = bool(
            np.isfinite(row["slope_boot_p025"])
            and row["ols_slope"] > 0
            and row["slope_boot_p025"] > 0
        )

        row["fit_status"] = "OK"

    except Exception as exc:
        row["fit_status"] = (
            f"FIT_FAILED:{type(exc).__name__}"
        )

    return row, segments


# ============================================================
# LOAD SAMPLE
# ============================================================

sample = pd.read_csv(SAMPLE_FILE)

required_cols = [
    "blazar_id",
    "sample_tier",
    "blazar_class",
]

missing = [
    c for c in required_cols
    if c not in sample.columns
]

if missing:
    raise RuntimeError(
        "Missing sample columns: "
        + ", ".join(missing)
    )

sample["blazar_id"] = (
    sample["blazar_id"].astype(str)
)

source_ids = (
    sample["blazar_id"]
    .drop_duplicates()
    .tolist()
)

sample_lookup = (
    sample
    .drop_duplicates("blazar_id")
    .set_index("blazar_id")
)

N_SOURCE = len(source_ids)


# ============================================================
# HEADER
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 03B")
print("RMS–FLUX RELATION")
print("=" * 78)

print("Analysis sample =", N_SOURCE)
print("Points per segment =", SEGMENT_N)
print("Minimum segments =", MIN_SEGMENTS)
print("Bootstrap draws =", BOOTSTRAP_N)
print("FDR alpha =", FDR_ALPHA)


# ============================================================
# CHECKPOINT STATUS
# ============================================================

def source_complete(blazar_id):
    return (
        summary_file(blazar_id).exists()
        and segment_file(blazar_id).exists()
        and done_file(blazar_id).exists()
    )

complete_before = [
    bid
    for bid in source_ids
    if source_complete(bid)
]

print()
print(
    "Completed 03B sources on disk =",
    len(complete_before),
    "/",
    N_SOURCE
)

print(
    "Remaining 03B sources         =",
    N_SOURCE - len(complete_before)
)


# ============================================================
# PER-SOURCE LOOP
# ============================================================

processed_this_run = 0
session_start = time.time()

for source_number, blazar_id in enumerate(
    source_ids,
    start=1
):

    if source_complete(blazar_id):
        continue

    if (
        args.limit is not None
        and processed_this_run >= args.limit
    ):
        print()
        print(
            "Pilot limit reached:",
            args.limit
        )
        break

    nightly_path = (
        NIGHTLY_DIR
        / f"{blazar_id}_NIGHTLY.parquet"
    )

    if not nightly_path.exists():
        raise FileNotFoundError(
            nightly_path
        )

    if not done_file(blazar_id).exists():
        for path in [
            summary_file(blazar_id),
            segment_file(blazar_id),
        ]:
            remove_if_exists(path)
            remove_if_exists(
                temp_path(path)
            )

        remove_if_exists(
            temp_path(done_file(blazar_id))
        )

    print()
    print("=" * 78)
    print(
        f"SOURCE {source_number}/{N_SOURCE}"
    )
    print(
        "blazar_id =",
        blazar_id
    )

    t0 = time.time()

    try:
        nightly = pd.read_parquet(
            nightly_path
        )

        meta = (
            sample_lookup
            .loc[blazar_id]
            .to_dict()
        )

        summary_rows = []
        segment_frames = []

        for filt in ["g", "r"]:
            row, seg = analyze_filter(
                blazar_id=blazar_id,
                filt=filt,
                nightly=nightly,
                meta=meta,
            )

            summary_rows.append(row)

            if len(seg) > 0:
                segment_frames.append(seg)

        summary = pd.DataFrame(
            summary_rows
        )

        if segment_frames:
            segments = pd.concat(
                segment_frames,
                ignore_index=True
            )
        else:
            segments = pd.DataFrame(
                columns=SEGMENT_COLUMNS
            )

        atomic_csv(
            summary,
            summary_file(blazar_id)
        )

        atomic_parquet(
            segments,
            segment_file(blazar_id)
        )

        elapsed = time.time() - t0

        atomic_text(
            (
                "COMPLETE\n"
                f"blazar_id={blazar_id}\n"
                f"elapsed_seconds={elapsed:.6f}\n"
            ),
            done_file(blazar_id)
        )

        for _, rr in summary.iterrows():
            print(
                f"{rr['filter_name']}: "
                f"Nnight={int(rr['N_nightly_total'])}, "
                f"Nseg={int(rr['N_segments'])}, "
                f"rho={rr.get('spearman_rho', np.nan):.4f}, "
                f"slope={rr.get('ols_slope', np.nan):.4f}, "
                f"status={rr['fit_status']}"
            )

        print(
            "CHECKPOINT =",
            done_file(blazar_id).name
        )

        processed_this_run += 1

    except Exception:
        print()
        print(
            "FAILED SOURCE:",
            blazar_id
        )

        traceback.print_exc()

        fail_path = (
            AUDIT_DIR
            / "stage03b_last_failure.txt"
        )

        fail_path.write_text(
            (
                "BLAZAR_I STAGE 03B FAILURE\n"
                f"blazar_id={blazar_id}\n"
                f"source_number={source_number}/{N_SOURCE}\n"
            ),
            encoding="utf-8"
        )

        sys.exit(30)


# ============================================================
# CURRENT STATUS
# ============================================================

complete_now = [
    bid
    for bid in source_ids
    if source_complete(bid)
]

session_elapsed = (
    time.time() - session_start
)

print()
print("=" * 78)
print("STAGE 03B CURRENT STATUS")
print("=" * 78)

print(
    "Completed sources =",
    len(complete_now),
    "/",
    N_SOURCE
)

print(
    "Remaining         =",
    N_SOURCE - len(complete_now)
)

print(
    f"Session elapsed   = "
    f"{session_elapsed/60:.2f} min"
)


# ============================================================
# GLOBAL PRODUCTS
# ============================================================

if len(complete_now) == N_SOURCE:

    print()
    print(
        "All STAGE 03B sources complete."
    )

    summary_frames = []
    segment_frames = []

    for bid in source_ids:
        summary_frames.append(
            pd.read_csv(
                summary_file(bid)
            )
        )

        seg = pd.read_parquet(
            segment_file(bid)
        )

        if len(seg) > 0:
            segment_frames.append(seg)

    master = pd.concat(
        summary_frames,
        ignore_index=True
    )

    if segment_frames:
        segments_master = pd.concat(
            segment_frames,
            ignore_index=True
        )
    else:
        segments_master = pd.DataFrame(
            columns=SEGMENT_COLUMNS
        )

    # --------------------------------------------
    # FDR on eligible / successful fits
    # --------------------------------------------

    master["spearman_q_bh_global"] = np.nan
    master["spearman_q_bh_filter"] = np.nan

    ok_mask = (
        master["fit_status"].eq("OK")
        & np.isfinite(
            pd.to_numeric(
                master["spearman_p"],
                errors="coerce"
            )
        )
    )

    ok_idx = master.index[ok_mask]

    master.loc[
        ok_idx,
        "spearman_q_bh_global"
    ] = bh_qvalues(
        master.loc[
            ok_idx,
            "spearman_p"
        ].to_numpy(dtype=float)
    )

    for filt in ["g", "r"]:
        mask = (
            ok_mask
            & master["filter_name"].eq(filt)
        )

        idx = master.index[mask]

        master.loc[
            idx,
            "spearman_q_bh_filter"
        ] = bh_qvalues(
            master.loc[
                idx,
                "spearman_p"
            ].to_numpy(dtype=float)
        )

    # --------------------------------------------
    # Frozen strict positive gate
    # --------------------------------------------

    master["strict_positive_rmflux"] = False

    strict = (
        master["fit_status"].eq("OK")
        & (master["spearman_rho"] > 0)
        & (master["ols_slope"] > 0)
        & (master["slope_boot_p025"] > 0)
        & (
            master["spearman_q_bh_global"]
            <= FDR_ALPHA
        )
    )

    master.loc[
        strict,
        "strict_positive_rmflux"
    ] = True

    # --------------------------------------------
    # Save global master
    # --------------------------------------------

    MASTER_OUT = (
        TABLE_DIR
        / "stage03b_rmflux_master.csv"
    )

    SEGMENTS_OUT = (
        TABLE_DIR
        / "stage03b_segments_master.parquet"
    )

    master.to_csv(
        MASTER_OUT,
        index=False
    )

    segments_master.to_parquet(
        SEGMENTS_OUT,
        index=False
    )

    # --------------------------------------------
    # Source-level wide table
    # --------------------------------------------

    keep = [
        "blazar_id",
        "filter_name",
        "N_nightly_total",
        "N_points_used",
        "N_points_discarded_remainder",
        "N_segments",
        "N_noise_dominated_segments",
        "noise_dominated_fraction",
        "segment_span_days_median",
        "segment_span_days_p90",
        "spearman_rho",
        "spearman_p",
        "spearman_q_bh_global",
        "spearman_q_bh_filter",
        "pearson_r",
        "pearson_p",
        "ols_slope",
        "ols_intercept_jy",
        "ols_slope_stderr",
        "slope_boot_p025",
        "slope_boot_p975",
        "strict_positive_rmflux",
        "fit_status",
    ]

    wide = master[
        [c for c in keep if c in master.columns]
    ].pivot(
        index="blazar_id",
        columns="filter_name"
    )

    wide.columns = [
        f"{metric}_{filt}"
        for metric, filt in wide.columns
    ]

    wide = wide.reset_index()

    meta_cols = [
        "blazar_id",
        "Source_Name",
        "ASSOC1",
        "blazar_class",
        "sample_tier",
        "redshift_clean",
        "SED_class_clean",
    ]

    meta = (
        master[
            [c for c in meta_cols if c in master.columns]
        ]
        .drop_duplicates("blazar_id")
    )

    source_master = meta.merge(
        wide,
        on="blazar_id",
        how="left",
        validate="one_to_one"
    )

    SOURCE_OUT = (
        TABLE_DIR
        / "stage03b_source_master.csv"
    )

    source_master.to_csv(
        SOURCE_OUT,
        index=False
    )

    # --------------------------------------------
    # Population counts
    # --------------------------------------------

    ok = master.loc[
        master["fit_status"].eq("OK")
    ].copy()

    strict_df = master.loc[
        master["strict_positive_rmflux"]
    ].copy()

    # Both-band strict source count.
    p = master.pivot(
        index="blazar_id",
        columns="filter_name",
        values="strict_positive_rmflux"
    )

    both_strict = int(
        (
            p.get("g", False).fillna(False).astype(bool)
            &
            p.get("r", False).fillna(False).astype(bool)
        ).sum()
    )

    either_strict = int(
        (
            p.get("g", False).fillna(False).astype(bool)
            |
            p.get("r", False).fillna(False).astype(bool)
        ).sum()
    )

    SUMMARY_OUT = (
        AUDIT_DIR
        / "stage03b_summary.txt"
    )

    lines = [
        "BLAZAR_I - STAGE 03B FINAL SUMMARY",
        "=" * 72,
        "",
        "PRIMARY SEGMENTATION:",
        f"  points per segment          : {SEGMENT_N}",
        f"  minimum complete segments   : {MIN_SEGMENTS}",
        "  incomplete remainder        : discarded",
        "",
        "RMS DEFINITION:",
        "  rms_XS = sqrt(max(S^2 - mean(err^2), 0))",
        "",
        f"Analysis blazars             : {N_SOURCE}",
        f"Source-filter rows           : {len(master)}",
        f"Successful eligible fits     : {len(ok)}",
        f"Non-eligible/non-fit rows    : {len(master)-len(ok)}",
        "",
        f"Strict positive rows         : {len(strict_df)}",
        f"Sources strict in >=1 band   : {either_strict}",
        f"Sources strict in both bands : {both_strict}",
        "",
        "STRICT POSITIVE GATE:",
        "  fit_status == OK",
        "  Spearman rho > 0",
        "  OLS slope > 0",
        "  bootstrap slope 95% lower bound > 0",
        f"  global BH q <= {FDR_ALPHA:.2f}",
        "",
        "By filter:",
    ]

    for filt in ["g", "r"]:
        xx = master.loc[
            master["filter_name"].eq(filt)
        ]

        oo = xx.loc[
            xx["fit_status"].eq("OK")
        ]

        ss = xx.loc[
            xx["strict_positive_rmflux"]
        ]

        lines.append(
            f"  {filt}: eligible={len(oo)}, "
            f"strict_positive={len(ss)}"
        )

    lines += [
        "",
        "By class and filter:",
    ]

    grouped = (
        master.loc[
            master["fit_status"].eq("OK")
        ]
        .groupby(
            [
                "blazar_class",
                "filter_name",
            ],
            dropna=False
        )
    )

    for (cls, filt), xx in grouped:
        n_strict = int(
            xx["strict_positive_rmflux"].sum()
        )

        lines.append(
            f"  {cls} {filt}: "
            f"eligible={len(xx)}, "
            f"strict_positive={n_strict}"
        )

    final_summary = "\n".join(lines)

    SUMMARY_OUT.write_text(
        final_summary,
        encoding="utf-8"
    )

    print()
    print(final_summary)

    print()
    print("=" * 78)
    print("GLOBAL FILES SAVED")
    print("=" * 78)
    print(MASTER_OUT)
    print(SOURCE_OUT)
    print(SEGMENTS_OUT)
    print(SUMMARY_OUT)

    print()
    print("STAGE 03B COMPLETE")
