# ============================================================
# BLAZAR_I — STAGE 09C2
# COLOUR-BREAK NULL / INJECTION-RECOVERY CALIBRATION
#
# Purpose:
#   Calibrate the Stage03C continuous broken-line diagnostic under the
#   ACTUAL colour-pair x-distribution and g/r photometric uncertainties.
#
# Exact Stage03C fitting logic is reproduced:
#   y = g-r
#   x = r
#   single-line OLS
#   continuous hinge broken-line search
#   BIC = n*ln(RSS/n) + k*ln(n)
#   k_single = 3
#   k_broken = 5
#   MIN_BREAK_N = 30
#   MIN_SIDE_N = 10
#   MAX_BREAK_GRID = 200
#
# Diagnostic gates:
#   STRONG:
#       DeltaBIC >= 10
#
#   ROBUST_CENTRAL:
#       DeltaBIC >= 20
#       0.15 <= (break-rmin)/(rmax-rmin) <= 0.85
#
# Simulation scenarios:
#
#   LINEAR_NULL
#       True colour-magnitude relation is a single straight line using
#       the source's frozen Stage03C slope/intercept.
#
#   BREAK_MODERATE
#       Continuous central break. Slope change is scaled so that the
#       break-induced departure from the baseline linear relation reaches
#       ~0.75 residual sigma over a representative half-range.
#
#   BREAK_STRONG
#       Same construction but ~1.50 residual sigma.
#
# Observation model:
#   The observed r magnitude and colour are generated from:
#       r_obs = r_true + eps_r
#       (g-r)_obs = colour_true + eps_int + eps_g - eps_r
#
#   This preserves the key x-y measurement covariance caused by r appearing
#   in both x=r and y=g-r.
#
# Intrinsic colour scatter:
#   Estimated source-by-source from the frozen Stage03C single-line
#   residual variance after subtracting the median error-aware variance:
#       sigma_g^2 + (1+b)^2 sigma_r^2
#
# Important:
#   - No observed endpoint is refit or overwritten.
#   - Simulations are deterministic and resumable at replicate level.
#
# Default workload:
#   36 templates x 3 scenarios x 50 reps = 5400 simulated fits.
#
# Outputs:
#   outputs/models/stage09c2_colour_calibration/*.csv
#   outputs/tables/stage09c2_colour_simulation_master.csv
#   outputs/tables/stage09c2_colour_scenario_summary.csv
#   outputs/tables/stage09c2_colour_template_summary.csv
#   outputs/audit/stage09c2_summary.txt
# ============================================================

from pathlib import Path
import argparse
import math
import time
import zlib
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings(
    "ignore",
    category=RuntimeWarning,
)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

PAIR_DIR = (
    ROOT
    /
    "outputs"
    /
    "models"
    /
    "stage03c_colour_break"
)

MODEL_DIR = (
    ROOT
    /
    "outputs"
    /
    "models"
    /
    "stage09c2_colour_calibration"
)

TEMPLATE_FILE = (
    TABLE_DIR
    /
    "stage09c0_colour_template_bank.csv"
)

COLOUR_FILE = (
    TABLE_DIR
    /
    "stage03c_colour_break_master.csv"
)

OUT_MASTER = (
    TABLE_DIR
    /
    "stage09c2_colour_simulation_master.csv"
)

OUT_SCEN = (
    TABLE_DIR
    /
    "stage09c2_colour_scenario_summary.csv"
)

OUT_TEMPLATE = (
    TABLE_DIR
    /
    "stage09c2_colour_template_summary.csv"
)

OUT_SUMMARY = (
    AUDIT_DIR
    /
    "stage09c2_summary.txt"
)

for p in [
    TABLE_DIR,
    AUDIT_DIR,
    MODEL_DIR,
]:
    p.mkdir(
        parents=True,
        exist_ok=True,
    )


# ============================================================
# FROZEN STAGE03C CONFIG
# ============================================================

MIN_BREAK_N = 30
MIN_SIDE_N = 10
MAX_BREAK_GRID = 200

STRONG_DBIC = 10.0
ROBUST_DBIC = 20.0
ROBUST_FRAC_LO = 0.15
ROBUST_FRAC_HI = 0.85

BASE_SEED = 20260918

SCENARIOS = [
    "LINEAR_NULL",
    "BREAK_MODERATE",
    "BREAK_STRONG",
]


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--reps",
    type=int,
    default=50,
    help="Replicates per template/scenario. Default=50.",
)

parser.add_argument(
    "--limit-templates",
    type=int,
    default=None,
    help="Optional pilot limit on template count.",
)

args = parser.parse_args()

if args.reps < 1:
    raise RuntimeError(
        "--reps must be >=1"
    )


# ============================================================
# HELPERS
# ============================================================

def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce",
    )


def stable_seed(
    template_id,
    scenario,
    rep,
):
    token = (
        f"{BASE_SEED}|"
        f"{template_id}|"
        f"{scenario}|"
        f"{rep}"
    ).encode(
        "utf-8"
    )

    return int(
        zlib.crc32(
            token
        )
        &
        0xFFFFFFFF
    )


def deterministic_sign(
    template_id,
):
    token = (
        f"{BASE_SEED}|"
        f"{template_id}|"
        "CURVATURE_SIGN"
    ).encode(
        "utf-8"
    )

    value = (
        zlib.crc32(
            token
        )
        &
        0xFFFFFFFF
    )

    return (
        1.0
        if (
            value % 2
            ==
            0
        )
        else
        -1.0
    )


def wilson_interval(
    k,
    n,
    z=1.959963984540054,
):
    if n <= 0:
        return (
            np.nan,
            np.nan,
        )

    p = (
        k
        /
        n
    )

    denom = (
        1.0
        +
        z * z / n
    )

    centre = (
        p
        +
        z * z
        /
        (
            2.0 * n
        )
    ) / denom

    half = (
        z
        *
        math.sqrt(
            p
            *
            (
                1.0 - p
            )
            /
            n
            +
            z * z
            /
            (
                4.0
                *
                n
                *
                n
            )
        )
        /
        denom
    )

    return (
        max(
            0.0,
            centre - half,
        ),
        min(
            1.0,
            centre + half,
        ),
    )


# ============================================================
# EXACT STAGE03C OLS / BIC LOGIC
# ============================================================

def rss_floor(
    rss,
    y,
):
    y = np.asarray(
        y,
        dtype=float,
    )

    scale = np.var(
        y,
        ddof=0,
    )

    floor = max(
        1.0e-30,
        1.0e-12
        *
        max(
            scale,
            1.0,
        )
        *
        len(y),
    )

    return max(
        float(
            rss
        ),
        floor,
    )


def information_criteria(
    rss,
    n,
    k,
):
    rss = max(
        float(
            rss
        ),
        1.0e-300,
    )

    aic = (
        n
        *
        math.log(
            rss / n
        )
        +
        2.0
        *
        k
    )

    bic = (
        n
        *
        math.log(
            rss / n
        )
        +
        k
        *
        math.log(
            n
        )
    )

    return (
        aic,
        bic,
    )


def fit_single_line(
    x,
    y,
):
    x = np.asarray(
        x,
        dtype=float,
    )

    y = np.asarray(
        y,
        dtype=float,
    )

    n = len(
        x
    )

    x0 = float(
        np.median(
            x
        )
    )

    X = np.column_stack(
        [
            np.ones(
                n
            ),
            x - x0,
        ]
    )

    beta, _, _, _ = np.linalg.lstsq(
        X,
        y,
        rcond=None,
    )

    pred = (
        X
        @
        beta
    )

    resid = (
        y
        -
        pred
    )

    rss = rss_floor(
        np.sum(
            resid ** 2
        ),
        y,
    )

    aic, bic = information_criteria(
        rss,
        n,
        3,
    )

    return {
        "x0": x0,
        "intercept": float(
            beta[0]
        ),
        "slope": float(
            beta[1]
        ),
        "rss": float(
            rss
        ),
        "aic": float(
            aic
        ),
        "bic": float(
            bic
        ),
        "resid_std": float(
            math.sqrt(
                rss
                /
                n
            )
        ),
    }


def candidate_breaks(
    x,
):
    x = np.asarray(
        x,
        dtype=float,
    )

    xs = np.sort(
        np.unique(
            x
        )
    )

    n = len(
        x
    )

    if n < MIN_BREAK_N:
        return np.array(
            [],
            dtype=float,
        )

    vals = []

    for xb in xs:
        nl = int(
            np.sum(
                x <= xb
            )
        )

        nr = int(
            np.sum(
                x > xb
            )
        )

        if (
            nl >= MIN_SIDE_N
            and
            nr >= MIN_SIDE_N
        ):
            vals.append(
                float(
                    xb
                )
            )

    vals = np.asarray(
        vals,
        dtype=float,
    )

    if len(
        vals
    ) <= MAX_BREAK_GRID:
        return vals

    idx = np.linspace(
        0,
        len(vals) - 1,
        MAX_BREAK_GRID,
    ).round().astype(
        int
    )

    return np.unique(
        vals[
            idx
        ]
    )


def fit_broken_line(
    x,
    y,
):
    x = np.asarray(
        x,
        dtype=float,
    )

    y = np.asarray(
        y,
        dtype=float,
    )

    n = len(
        x
    )

    candidates = candidate_breaks(
        x
    )

    if len(
        candidates
    ) == 0:
        return None

    best = None

    for xb in candidates:
        dx = (
            x
            -
            xb
        )

        hinge = np.maximum(
            dx,
            0.0,
        )

        X = np.column_stack(
            [
                np.ones(
                    n
                ),
                dx,
                hinge,
            ]
        )

        beta, _, _, _ = np.linalg.lstsq(
            X,
            y,
            rcond=None,
        )

        pred = (
            X
            @
            beta
        )

        resid = (
            y
            -
            pred
        )

        rss = rss_floor(
            np.sum(
                resid ** 2
            ),
            y,
        )

        if (
            best is None
            or
            rss
            <
            best[
                "rss"
            ]
        ):
            b_left = float(
                beta[1]
            )

            delta = float(
                beta[2]
            )

            best = {
                "xb": float(
                    xb
                ),
                "c": float(
                    beta[0]
                ),
                "b_left": b_left,
                "b_right": float(
                    b_left
                    +
                    delta
                ),
                "delta_slope": delta,
                "rss": float(
                    rss
                ),
                "n_left": int(
                    np.sum(
                        x <= xb
                    )
                ),
                "n_right": int(
                    np.sum(
                        x > xb
                    )
                ),
            }

    if best is None:
        return None

    aic, bic = information_criteria(
        best[
            "rss"
        ],
        n,
        5,
    )

    best[
        "aic"
    ] = float(
        aic
    )

    best[
        "bic"
    ] = float(
        bic
    )

    return best


# ============================================================
# SOURCE-SPECIFIC INJECTION DESIGN
# ============================================================

def build_injection_design(
    template_row,
    frozen_row,
    pairs,
):
    r_true = numeric(
        pairs[
            "r_mag"
        ]
    ).to_numpy(
        dtype=float
    )

    gerr = numeric(
        pairs[
            "g_magerr"
        ]
    ).to_numpy(
        dtype=float
    )

    rerr = numeric(
        pairs[
            "r_magerr"
        ]
    ).to_numpy(
        dtype=float
    )

    colour_obs = numeric(
        pairs[
            "g_minus_r"
        ]
    ).to_numpy(
        dtype=float
    )

    good = (
        np.isfinite(
            r_true
        )
        &
        np.isfinite(
            gerr
        )
        &
        np.isfinite(
            rerr
        )
        &
        np.isfinite(
            colour_obs
        )
        &
        (
            gerr
            >
            0
        )
        &
        (
            rerr
            >
            0
        )
    )

    r_true = r_true[
        good
    ]
    gerr = gerr[
        good
    ]
    rerr = rerr[
        good
    ]
    colour_obs = colour_obs[
        good
    ]

    if len(
        r_true
    ) < MIN_BREAK_N:
        raise RuntimeError(
            "Template has fewer than "
            f"{MIN_BREAK_N} valid pairs."
        )

    x0 = float(
        frozen_row[
            "single_x0_rmag"
        ]
    )

    c0 = float(
        frozen_row[
            "single_intercept_at_x0"
        ]
    )

    b0 = float(
        frozen_row[
            "single_slope_dcolor_dr"
        ]
    )

    resid_std = float(
        frozen_row[
            "single_resid_std"
        ]
    )

    # Error-aware residual variance:
    # Var(g-r - b*r) approximately
    # sigma_g^2 + (1+b)^2 sigma_r^2.
    noise_var = (
        gerr ** 2
        +
        (
            1.0
            +
            b0
        ) ** 2
        *
        rerr ** 2
    )

    med_noise_var = float(
        np.median(
            noise_var
        )
    )

    sigma_int2 = max(
        0.0,
        resid_std ** 2
        -
        med_noise_var,
    )

    sigma_int = math.sqrt(
        sigma_int2
    )

    # Use the observed total residual scale for defining normalized
    # injected curvature strength.
    sigma_scale = max(
        resid_std,
        math.sqrt(
            med_noise_var
        ),
        0.01,
    )

    xb_true = float(
        np.median(
            r_true
        )
    )

    p10 = float(
        np.quantile(
            r_true,
            0.10,
        )
    )

    p90 = float(
        np.quantile(
            r_true,
            0.90,
        )
    )

    raw_range = float(
        np.max(
            r_true
        )
        -
        np.min(
            r_true
        )
    )

    halfspan = min(
        xb_true - p10,
        p90 - xb_true,
    )

    if (
        not np.isfinite(
            halfspan
        )
        or
        halfspan <= 0
    ):
        halfspan = max(
            raw_range
            /
            4.0,
            0.05,
        )

    sign = deterministic_sign(
        str(
            template_row[
                "template_id"
            ]
        )
    )

    # Symmetric slope change around the baseline b0.
    #
    # Edge departure relative to the baseline line is approximately:
    #   0.5 * |delta_slope| * halfspan.
    #
    # moderate: ~0.75 sigma
    # strong  : ~1.50 sigma
    delta_mod = (
        sign
        *
        (
            1.5
            *
            sigma_scale
            /
            halfspan
        )
    )

    delta_strong = (
        sign
        *
        (
            3.0
            *
            sigma_scale
            /
            halfspan
        )
    )

    # Avoid pathological numerical extremes while retaining source-specific
    # scaling. Any clipping is recorded.
    delta_mod_clip = float(
        np.clip(
            delta_mod,
            -2.0,
            2.0,
        )
    )

    delta_strong_clip = float(
        np.clip(
            delta_strong,
            -2.0,
            2.0,
        )
    )

    return {
        "r_true": r_true,
        "gerr": gerr,
        "rerr": rerr,
        "x0": x0,
        "c0": c0,
        "b0": b0,
        "resid_std": resid_std,
        "sigma_int": sigma_int,
        "sigma_scale": sigma_scale,
        "xb_true": xb_true,
        "r_range_true": raw_range,
        "halfspan": halfspan,
        "delta_mod": delta_mod_clip,
        "delta_strong": delta_strong_clip,
        "delta_mod_clipped": bool(
            not np.isclose(
                delta_mod,
                delta_mod_clip,
            )
        ),
        "delta_strong_clipped": bool(
            not np.isclose(
                delta_strong,
                delta_strong_clip,
            )
        ),
    }


def true_colour(
    r_true,
    design,
    scenario,
):
    x0 = design[
        "x0"
    ]
    c0 = design[
        "c0"
    ]
    b0 = design[
        "b0"
    ]

    if scenario == "LINEAR_NULL":
        return (
            c0
            +
            b0
            *
            (
                r_true
                -
                x0
            )
        )

    xb = design[
        "xb_true"
    ]

    if scenario == "BREAK_MODERATE":
        delta = design[
            "delta_mod"
        ]

    elif scenario == "BREAK_STRONG":
        delta = design[
            "delta_strong"
        ]

    else:
        raise RuntimeError(
            f"Unknown scenario: {scenario}"
        )

    b_left = (
        b0
        -
        0.5
        *
        delta
    )

    b_right = (
        b0
        +
        0.5
        *
        delta
    )

    # Construct a continuous broken relation and anchor it so that its
    # value at x0 agrees approximately with the frozen single-line relation.
    colour_at_xb_baseline = (
        c0
        +
        b0
        *
        (
            xb
            -
            x0
        )
    )

    dx = (
        r_true
        -
        xb
    )

    y = np.where(
        r_true
        <=
        xb,
        (
            colour_at_xb_baseline
            +
            b_left
            *
            dx
        ),
        (
            colour_at_xb_baseline
            +
            b_right
            *
            dx
        ),
    )

    return y


def simulate_one(
    template_row,
    design,
    scenario,
    rep,
):
    template_id = str(
        template_row[
            "template_id"
        ]
    )

    rng = np.random.default_rng(
        stable_seed(
            template_id,
            scenario,
            rep,
        )
    )

    r_true = design[
        "r_true"
    ]

    gerr = design[
        "gerr"
    ]

    rerr = design[
        "rerr"
    ]

    colour_true = true_colour(
        r_true,
        design,
        scenario,
    )

    eps_r = rng.normal(
        0.0,
        rerr,
    )

    eps_g = rng.normal(
        0.0,
        gerr,
    )

    eps_int = rng.normal(
        0.0,
        design[
            "sigma_int"
        ],
        size=len(
            r_true
        ),
    )

    x_obs = (
        r_true
        +
        eps_r
    )

    y_obs = (
        colour_true
        +
        eps_int
        +
        eps_g
        -
        eps_r
    )

    single = fit_single_line(
        x_obs,
        y_obs,
    )

    broken = fit_broken_line(
        x_obs,
        y_obs,
    )

    row = {
        "template_id": template_id,
        "blazar_id": str(
            template_row[
                "blazar_id"
            ]
        ),
        "blazar_class": template_row[
            "blazar_class"
        ],
        "scenario": scenario,
        "replicate": int(
            rep
        ),
        "N_pairs": int(
            len(
                x_obs
            )
        ),
        "sigma_intrinsic_colour": float(
            design[
                "sigma_int"
            ]
        ),
        "sigma_scale": float(
            design[
                "sigma_scale"
            ]
        ),
        "frozen_single_slope": float(
            design[
                "b0"
            ]
        ),
        "true_break_r_mag": (
            float(
                design[
                    "xb_true"
                ]
            )
            if scenario
            !=
            "LINEAR_NULL"
            else
            np.nan
        ),
        "true_delta_slope": (
            float(
                design[
                    "delta_mod"
                ]
            )
            if scenario
            ==
            "BREAK_MODERATE"
            else
            (
                float(
                    design[
                        "delta_strong"
                    ]
                )
                if scenario
                ==
                "BREAK_STRONG"
                else
                0.0
            )
        ),
        "r_range_true": float(
            design[
                "r_range_true"
            ]
        ),
        "single_bic": float(
            single[
                "bic"
            ]
        ),
        "fit_status": "OK",
    }

    if broken is None:
        row[
            "fit_status"
        ] = "NO_VALID_BREAK"
        row[
            "strong_break_bic10"
        ] = False
        row[
            "robust_central_break"
        ] = False
        return row

    dbic = (
        single[
            "bic"
        ]
        -
        broken[
            "bic"
        ]
    )

    xmin = float(
        np.min(
            x_obs
        )
    )

    xmax = float(
        np.max(
            x_obs
        )
    )

    xrange = (
        xmax
        -
        xmin
    )

    break_frac = (
        (
            broken[
                "xb"
            ]
            -
            xmin
        )
        /
        xrange
        if xrange > 0
        else np.nan
    )

    strong = bool(
        dbic
        >=
        STRONG_DBIC
    )

    robust = bool(
        dbic
        >=
        ROBUST_DBIC
        and
        np.isfinite(
            break_frac
        )
        and
        (
            ROBUST_FRAC_LO
            <=
            break_frac
            <=
            ROBUST_FRAC_HI
        )
    )

    if scenario != "LINEAR_NULL":
        break_err_frac = (
            abs(
                broken[
                    "xb"
                ]
                -
                design[
                    "xb_true"
                ]
            )
            /
            max(
                design[
                    "r_range_true"
                ],
                1.0e-12,
            )
        )

        break_localized = bool(
            break_err_frac
            <=
            0.10
        )

        sign_correct = bool(
            np.sign(
                broken[
                    "delta_slope"
                ]
            )
            ==
            np.sign(
                row[
                    "true_delta_slope"
                ]
            )
        )

    else:
        break_err_frac = np.nan
        break_localized = np.nan
        sign_correct = np.nan

    row.update({
        "break_r_mag_hat": float(
            broken[
                "xb"
            ]
        ),
        "break_slope_left_hat": float(
            broken[
                "b_left"
            ]
        ),
        "break_slope_right_hat": float(
            broken[
                "b_right"
            ]
        ),
        "break_delta_slope_hat": float(
            broken[
                "delta_slope"
            ]
        ),
        "break_N_left": int(
            broken[
                "n_left"
            ]
        ),
        "break_N_right": int(
            broken[
                "n_right"
            ]
        ),
        "break_bic": float(
            broken[
                "bic"
            ]
        ),
        "delta_bic_single_minus_broken": float(
            dbic
        ),
        "break_fraction_hat": float(
            break_frac
        ),
        "strong_break_bic10": strong,
        "robust_central_break": robust,
        "break_error_fraction_of_range": break_err_frac,
        "break_localized_within_0p10_range": break_localized,
        "delta_slope_sign_correct": sign_correct,
        "robust_and_localized": (
            bool(
                robust
                and
                break_localized
            )
            if scenario
            !=
            "LINEAR_NULL"
            else
            np.nan
        ),
    })

    return row


# ============================================================
# LOAD INPUTS
# ============================================================

for path in [
    TEMPLATE_FILE,
    COLOUR_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

templates = pd.read_csv(
    TEMPLATE_FILE,
    low_memory=False,
)

colour_master = pd.read_csv(
    COLOUR_FILE,
    low_memory=False,
)

templates[
    "blazar_id"
] = (
    templates[
        "blazar_id"
    ]
    .astype(
        str
    )
)

colour_master[
    "blazar_id"
] = (
    colour_master[
        "blazar_id"
    ]
    .astype(
        str
    )
)

required_frozen = [
    "blazar_id",
    "single_x0_rmag",
    "single_intercept_at_x0",
    "single_slope_dcolor_dr",
    "single_resid_std",
]

missing = [
    c
    for c in required_frozen
    if c not in colour_master.columns
]

if missing:
    raise RuntimeError(
        "Stage03C master missing columns: "
        +
        repr(
            missing
        )
    )

frozen_lookup = (
    colour_master
    .drop_duplicates(
        "blazar_id"
    )
    .set_index(
        "blazar_id"
    )
)

if args.limit_templates is not None:
    templates = templates.head(
        args.limit_templates
    ).copy()

if len(
    templates
) == 0:
    raise RuntimeError(
        "No colour templates selected."
    )

print(
    "=" * 80
)

print(
    "BLAZAR_I — STAGE 09C2 COLOUR-BREAK CALIBRATION"
)

print(
    "=" * 80
)

print(
    "Templates =",
    len(
        templates
    ),
)

print(
    "Scenarios =",
    len(
        SCENARIOS
    ),
)

print(
    "Replicates/template/scenario =",
    args.reps,
)

print(
    "Target simulations =",
    len(
        templates
    )
    *
    len(
        SCENARIOS
    )
    *
    args.reps,
)


# ============================================================
# RESUMABLE CELL LOOP
# ============================================================

all_frames = []

cell_index = 0

n_cells = (
    len(
        templates
    )
    *
    len(
        SCENARIOS
    )
)

t0 = time.time()

for _, template_row in templates.iterrows():
    bid = str(
        template_row[
            "blazar_id"
        ]
    )

    template_id = str(
        template_row[
            "template_id"
        ]
    )

    if bid not in frozen_lookup.index:
        raise RuntimeError(
            f"Missing Stage03C frozen row for {bid}"
        )

    frozen_row = frozen_lookup.loc[
        bid
    ]

    if isinstance(
        frozen_row,
        pd.DataFrame,
    ):
        if len(
            frozen_row
        ) != 1:
            raise RuntimeError(
                f"Duplicate Stage03C rows for {bid}"
            )

        frozen_row = frozen_row.iloc[
            0
        ]

    pair_file = (
        PAIR_DIR
        /
        f"{bid}_03C_PAIRS.parquet"
    )

    if not pair_file.exists():
        raise FileNotFoundError(
            pair_file
        )

    pairs = pd.read_parquet(
        pair_file
    )

    design = build_injection_design(
        template_row,
        frozen_row,
        pairs,
    )

    for scenario in SCENARIOS:
        cell_index += 1

        cell_file = (
            MODEL_DIR
            /
            f"{template_id}_{scenario}.csv"
        )

        if cell_file.exists():
            prev = pd.read_csv(
                cell_file,
                low_memory=False,
            )
        else:
            prev = pd.DataFrame()

        done_reps = set()

        if (
            len(
                prev
            )
            and
            "replicate"
            in prev.columns
        ):
            done_reps = set(
                numeric(
                    prev[
                        "replicate"
                    ]
                )
                .dropna()
                .astype(
                    int
                )
                .tolist()
            )

        rows = []

        for rep in range(
            1,
            args.reps + 1,
        ):
            if rep in done_reps:
                continue

            try:
                row = simulate_one(
                    template_row,
                    design,
                    scenario,
                    rep,
                )

            except Exception as exc:
                row = {
                    "template_id": template_id,
                    "blazar_id": bid,
                    "blazar_class": template_row[
                        "blazar_class"
                    ],
                    "scenario": scenario,
                    "replicate": int(
                        rep
                    ),
                    "fit_status": (
                        f"EXCEPTION:"
                        f"{type(exc).__name__}:"
                        f"{exc}"
                    ),
                }

            rows.append(
                row
            )

            current = pd.concat(
                [
                    prev,
                    pd.DataFrame(
                        rows
                    ),
                ],
                ignore_index=True,
            )

            current = (
                current
                .sort_values(
                    "replicate"
                )
                .drop_duplicates(
                    "replicate",
                    keep="last",
                )
            )

            current.to_csv(
                cell_file,
                index=False,
            )

        final_cell = pd.read_csv(
            cell_file,
            low_memory=False,
        )

        final_cell = final_cell.loc[
            numeric(
                final_cell[
                    "replicate"
                ]
            )
            <=
            args.reps
        ].copy()

        all_frames.append(
            final_cell
        )

        elapsed = (
            time.time()
            -
            t0
        )

        print(
            f"Cell {cell_index}/{n_cells} "
            f"{template_id} {scenario}: "
            f"saved_reps={len(final_cell)} "
            f"elapsed={elapsed/60.0:.1f} min"
        )


# ============================================================
# AGGREGATE
# ============================================================

master = pd.concat(
    all_frames,
    ignore_index=True,
)

master.to_csv(
    OUT_MASTER,
    index=False,
)

master[
    "fit_ok"
] = (
    master[
        "fit_status"
    ]
    .astype(
        str
    )
    .eq(
        "OK"
    )
)


def robust_bool(
    s,
):
    num = pd.to_numeric(
        s,
        errors="coerce",
    )

    out = pd.Series(
        False,
        index=s.index,
        dtype=bool,
    )

    good_num = num.notna()

    out.loc[
        good_num
    ] = (
        num.loc[
            good_num
        ]
        !=
        0
    )

    rem = (
        ~good_num
    )

    if rem.any():
        txt = (
            s.loc[
                rem
            ]
            .astype(
                str
            )
            .str.strip()
            .str.lower()
        )

        out.loc[
            rem
        ] = txt.isin(
            [
                "true",
                "t",
                "yes",
                "y",
            ]
        )

    return out


master[
    "strong_bool"
] = robust_bool(
    master[
        "strong_break_bic10"
    ]
)

master[
    "robust_bool"
] = robust_bool(
    master[
        "robust_central_break"
    ]
)

master[
    "localized_bool"
] = robust_bool(
    master.get(
        "break_localized_within_0p10_range",
        pd.Series(
            False,
            index=master.index,
        ),
    )
)

master[
    "sign_correct_bool"
] = robust_bool(
    master.get(
        "delta_slope_sign_correct",
        pd.Series(
            False,
            index=master.index,
        ),
    )
)

master[
    "robust_localized_bool"
] = (
    master[
        "robust_bool"
    ]
    &
    master[
        "localized_bool"
    ]
)


# ============================================================
# SCENARIO SUMMARY
# ============================================================

scenario_rows = []

for scenario, g in master.groupby(
    "scenario"
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    n = len(
        ok
    )

    k_strong = int(
        ok[
            "strong_bool"
        ].sum()
    )

    k_robust = int(
        ok[
            "robust_bool"
        ].sum()
    )

    strong_lo, strong_hi = wilson_interval(
        k_strong,
        n,
    )

    robust_lo, robust_hi = wilson_interval(
        k_robust,
        n,
    )

    row = {
        "scenario": scenario,
        "N_simulations": len(
            g
        ),
        "N_fit_ok": n,
        "fit_ok_fraction": (
            n
            /
            len(
                g
            )
            if len(
                g
            )
            else np.nan
        ),
        "strong_break_N": k_strong,
        "strong_break_fraction": (
            k_strong
            /
            n
            if n
            else np.nan
        ),
        "strong_break_ci95_low": strong_lo,
        "strong_break_ci95_high": strong_hi,
        "robust_break_N": k_robust,
        "robust_break_fraction": (
            k_robust
            /
            n
            if n
            else np.nan
        ),
        "robust_break_ci95_low": robust_lo,
        "robust_break_ci95_high": robust_hi,
        "median_delta_bic": (
            numeric(
                ok[
                    "delta_bic_single_minus_broken"
                ]
            ).median()
            if n
            else np.nan
        ),
    }

    if scenario != "LINEAR_NULL":
        k_loc = int(
            ok[
                "localized_bool"
            ].sum()
        )

        k_sign = int(
            ok[
                "sign_correct_bool"
            ].sum()
        )

        k_rl = int(
            ok[
                "robust_localized_bool"
            ].sum()
        )

        loc_lo, loc_hi = wilson_interval(
            k_loc,
            n,
        )

        rl_lo, rl_hi = wilson_interval(
            k_rl,
            n,
        )

        break_err = numeric(
            ok[
                "break_error_fraction_of_range"
            ]
        ).dropna()

        row.update({
            "localized_N": k_loc,
            "localized_fraction": (
                k_loc
                /
                n
                if n
                else np.nan
            ),
            "localized_ci95_low": loc_lo,
            "localized_ci95_high": loc_hi,
            "slope_change_sign_correct_N": k_sign,
            "slope_change_sign_correct_fraction": (
                k_sign
                /
                n
                if n
                else np.nan
            ),
            "robust_and_localized_N": k_rl,
            "robust_and_localized_fraction": (
                k_rl
                /
                n
                if n
                else np.nan
            ),
            "robust_and_localized_ci95_low": rl_lo,
            "robust_and_localized_ci95_high": rl_hi,
            "median_break_error_fraction": (
                break_err.median()
                if len(
                    break_err
                )
                else np.nan
            ),
            "p90_break_error_fraction": (
                break_err.quantile(
                    0.90
                )
                if len(
                    break_err
                )
                else np.nan
            ),
        })

    scenario_rows.append(
        row
    )

scenario_summary = pd.DataFrame(
    scenario_rows
)

scenario_summary.to_csv(
    OUT_SCEN,
    index=False,
)


# ============================================================
# TEMPLATE SUMMARY
# ============================================================

template_rows = []

for (
    template_id,
    scenario,
), g in master.groupby(
    [
        "template_id",
        "scenario",
    ]
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    template_rows.append({
        "template_id": template_id,
        "scenario": scenario,
        "N_simulations": len(
            g
        ),
        "N_fit_ok": len(
            ok
        ),
        "strong_break_fraction": (
            float(
                ok[
                    "strong_bool"
                ].mean()
            )
            if len(
                ok
            )
            else np.nan
        ),
        "robust_break_fraction": (
            float(
                ok[
                    "robust_bool"
                ].mean()
            )
            if len(
                ok
            )
            else np.nan
        ),
        "localized_fraction": (
            float(
                ok[
                    "localized_bool"
                ].mean()
            )
            if (
                len(
                    ok
                )
                and
                scenario
                !=
                "LINEAR_NULL"
            )
            else np.nan
        ),
        "robust_and_localized_fraction": (
            float(
                ok[
                    "robust_localized_bool"
                ].mean()
            )
            if (
                len(
                    ok
                )
                and
                scenario
                !=
                "LINEAR_NULL"
            )
            else np.nan
        ),
        "median_delta_bic": (
            numeric(
                ok[
                    "delta_bic_single_minus_broken"
                ]
            ).median()
            if len(
                ok
            )
            else np.nan
        ),
    })

template_summary = pd.DataFrame(
    template_rows
)

template_summary.to_csv(
    OUT_TEMPLATE,
    index=False,
)


# ============================================================
# FINAL SUMMARY
# ============================================================

def get_scenario(
    name,
):
    hit = scenario_summary.loc[
        scenario_summary[
            "scenario"
        ].eq(
            name
        )
    ]

    if len(
        hit
    ) != 1:
        return None

    return hit.iloc[
        0
    ]


lines = [
    "BLAZAR_I - STAGE 09C2 FINAL SUMMARY",
    "=" * 80,
    "",
    "Colour-break observation-conditioned null / injection calibration",
    "",
    f"Templates                       : {len(templates)}",
    f"Replicates/template/scenario    : {args.reps}",
    f"Total simulations               : {len(master)}",
    "",
]

null = get_scenario(
    "LINEAR_NULL"
)

if null is not None:
    lines += [
        "LINEAR_NULL:",
        f"  fit success fraction          : {null['fit_ok_fraction']:.4f}",
        f"  strong-break false positive   : {null['strong_break_fraction']:.4f} [{null['strong_break_ci95_low']:.4f}, {null['strong_break_ci95_high']:.4f}]",
        f"  robust-central false positive : {null['robust_break_fraction']:.4f} [{null['robust_break_ci95_low']:.4f}, {null['robust_break_ci95_high']:.4f}]",
        f"  median DeltaBIC               : {null['median_delta_bic']:.3f}",
        "",
    ]

for name in [
    "BREAK_MODERATE",
    "BREAK_STRONG",
]:
    r = get_scenario(
        name
    )

    if r is None:
        continue

    lines += [
        f"{name}:",
        f"  strong-break recovery         : {r['strong_break_fraction']:.4f} [{r['strong_break_ci95_low']:.4f}, {r['strong_break_ci95_high']:.4f}]",
        f"  robust-central recovery       : {r['robust_break_fraction']:.4f} [{r['robust_break_ci95_low']:.4f}, {r['robust_break_ci95_high']:.4f}]",
        f"  break localized <=0.10 range : {r['localized_fraction']:.4f} [{r['localized_ci95_low']:.4f}, {r['localized_ci95_high']:.4f}]",
        f"  slope-change sign correct     : {r['slope_change_sign_correct_fraction']:.4f}",
        f"  robust AND localized          : {r['robust_and_localized_fraction']:.4f} [{r['robust_and_localized_ci95_low']:.4f}, {r['robust_and_localized_ci95_high']:.4f}]",
        f"  median break error/range      : {r['median_break_error_fraction']:.4f}",
        f"  median DeltaBIC               : {r['median_delta_bic']:.3f}",
        "",
    ]

lines += [
    "Interpretation locks:",
    "  - Null false-positive rates are conditioned on actual source-specific",
    "    r-magnitude distributions and g/r measurement uncertainties.",
    "  - Simulated x-y covariance explicitly includes the shared r-band error.",
    "  - Moderate/strong injections are normalized to each template's",
    "    observed residual scatter and magnitude leverage.",
    "  - Recovery calibrates detectability, not the physical origin of a break.",
    "  - The manuscript should continue to describe colour breaks as empirical",
    "    population diagnostics unless independently physically identified.",
    "",
    "Files saved:",
    f"  {OUT_MASTER}",
    f"  {OUT_SCEN}",
    f"  {OUT_TEMPLATE}",
    "",
    "Checkpoint directory:",
    f"  {MODEL_DIR}",
    "",
    "Next:",
    "  STAGE 09C3 — flux-PDF correlated-lognormal null / mixture injection.",
    "",
    "STAGE 09C2 COMPLETE",
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(
    summary
)
