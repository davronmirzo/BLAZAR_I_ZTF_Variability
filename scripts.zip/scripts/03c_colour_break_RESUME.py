# ============================================================
# BLAZAR_I — STAGE 03C
# COLOUR–MAGNITUDE RELATION + CONTINUOUS BROKEN-LINE SEARCH
#
# Input:
#   outputs/tables/stage02b3_GOLD_PLUS_SILVER.csv
#   data/processed/stage02b3_sources/BZI_xxxxx_NIGHTLY.parquet
#
# Primary empirical relation:
#   y = (g-r)
#   x = r magnitude
#
# Pairing:
#   same night_id
#   |Delta t(g-r)| <= 0.25 d  (frozen from STAGE 02B3)
#
# Models:
#   1) single straight line
#   2) continuous broken line
#
# Broken-line parameterization for a fixed break xb:
#   y = c + b_left*(x-xb) + db*max(0, x-xb)
#   b_right = b_left + db
#
# Model selection:
#   empirical Gaussian-residual BIC:
#       BIC = n*ln(RSS/n) + k*ln(n)
#   where residual variance is estimated from the data.
#   k_single = 3  (intercept, slope, residual variance)
#   k_broken = 5  (c, b_left, db, break, residual variance)
#
# Primary strong-break flag:
#   N_colour >= 30
#   at least 10 points on each side of break
#   Delta BIC = BIC_single - BIC_broken >= 10
#
# Notes:
#   * No sigma clipping.
#   * Primary model selection is empirical OLS in colour-vs-r space.
#   * Photometric errors and x-y covariance are saved but not used
#     in the primary BIC; later robustness can use ODR / tighter
#     simultaneity cuts.
#   * With x=r magnitude:
#       positive slope -> bluer when brighter (BWB)
#       negative slope -> redder when brighter (RWB)
#
# Checkpoint unit:
#   1 blazar -> summary CSV + paired-colour parquet + .done
# ============================================================

from pathlib import Path
import argparse
import math
import sys
import time
import traceback

import numpy as np
import pandas as pd

from scipy.stats import spearmanr, pearsonr, linregress


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="Process at most this many unfinished blazars."
)

args = parser.parse_args()


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

SAMPLE_FILE = (
    ROOT / "outputs" / "tables"
    / "stage02b3_GOLD_PLUS_SILVER.csv"
)

NIGHTLY_DIR = (
    ROOT / "data" / "processed"
    / "stage02b3_sources"
)

OUT_DIR = (
    ROOT / "outputs" / "models"
    / "stage03c_colour_break"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# FROZEN CONFIG
# ============================================================

PAIR_TOL_DAYS = 0.25

MIN_SINGLE_N = 15
MIN_BREAK_N = 30
MIN_SIDE_N = 10

STRONG_BREAK_DELTA_BIC = 10.0

# At most this many candidate break locations are searched.
MAX_BREAK_GRID = 200

FDR_ALPHA = 0.05


# ============================================================
# OUTPUT HELPERS
# ============================================================

def summary_file(blazar_id):
    return OUT_DIR / f"{blazar_id}_03C_SUMMARY.csv"

def pairs_file(blazar_id):
    return OUT_DIR / f"{blazar_id}_03C_PAIRS.parquet"

def done_file(blazar_id):
    return OUT_DIR / f"{blazar_id}.done"

def temp_path(path):
    return path.with_name(path.name + ".tmp")

def remove_if_exists(path):
    if path.exists():
        path.unlink()

def atomic_csv(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_csv(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)

def atomic_parquet(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_parquet(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)

def atomic_text(text, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    tmp.write_text(text, encoding="utf-8")
    remove_if_exists(path)
    tmp.replace(path)


# ============================================================
# BH-FDR
# ============================================================

def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)

    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw_q = ranked * m / np.arange(1, m + 1)

    adj = np.minimum.accumulate(
        raw_q[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0
    )

    q_valid = np.empty(
        m,
        dtype=float
    )

    q_valid[order] = adj

    q[valid] = q_valid

    return q


# ============================================================
# PAIR g AND r NIGHTLY DATA
# ============================================================

PAIR_COLUMNS = [
    "blazar_id",
    "night_id",
    "hmjd_g",
    "hmjd_r",
    "dt_gr_days",
    "dt_gr_hours",
    "g_mag",
    "g_magerr",
    "r_mag",
    "r_magerr",
    "g_minus_r",
    "g_minus_r_err",
]


def build_colour_pairs(blazar_id, nightly):

    required = [
        "filter_name",
        "night_id",
        "hmjd",
        "mag",
        "magerr",
    ]

    missing = [
        c
        for c in required
        if c not in nightly.columns
    ]

    if missing:
        raise RuntimeError(
            f"{blazar_id}: missing nightly columns: "
            + ", ".join(missing)
        )

    g = (
        nightly.loc[
            nightly["filter_name"].eq("g"),
            [
                "night_id",
                "hmjd",
                "mag",
                "magerr",
            ],
        ]
        .rename(
            columns={
                "hmjd": "hmjd_g",
                "mag": "g_mag",
                "magerr": "g_magerr",
            }
        )
        .copy()
    )

    r = (
        nightly.loc[
            nightly["filter_name"].eq("r"),
            [
                "night_id",
                "hmjd",
                "mag",
                "magerr",
            ],
        ]
        .rename(
            columns={
                "hmjd": "hmjd_r",
                "mag": "r_mag",
                "magerr": "r_magerr",
            }
        )
        .copy()
    )

    if len(g) == 0 or len(r) == 0:
        return pd.DataFrame(
            columns=PAIR_COLUMNS
        )

    for df in [g, r]:
        for col in df.columns:
            df[col] = pd.to_numeric(
                df[col],
                errors="coerce"
            )

    pairs = g.merge(
        r,
        on="night_id",
        how="inner",
        validate="one_to_one"
    )

    pairs = pairs.loc[
        np.isfinite(pairs["hmjd_g"])
        & np.isfinite(pairs["hmjd_r"])
        & np.isfinite(pairs["g_mag"])
        & np.isfinite(pairs["r_mag"])
        & np.isfinite(pairs["g_magerr"])
        & np.isfinite(pairs["r_magerr"])
        & (pairs["g_magerr"] > 0)
        & (pairs["r_magerr"] > 0)
    ].copy()

    pairs["dt_gr_days"] = np.abs(
        pairs["hmjd_g"]
        -
        pairs["hmjd_r"]
    )

    pairs = pairs.loc[
        pairs["dt_gr_days"]
        <=
        PAIR_TOL_DAYS
    ].copy()

    pairs["dt_gr_hours"] = (
        24.0
        *
        pairs["dt_gr_days"]
    )

    pairs["g_minus_r"] = (
        pairs["g_mag"]
        -
        pairs["r_mag"]
    )

    pairs["g_minus_r_err"] = np.sqrt(
        pairs["g_magerr"] ** 2
        +
        pairs["r_magerr"] ** 2
    )

    pairs.insert(
        0,
        "blazar_id",
        blazar_id
    )

    return (
        pairs[
            PAIR_COLUMNS
        ]
        .sort_values("night_id")
        .reset_index(drop=True)
    )


# ============================================================
# OLS HELPERS
# ============================================================

def rss_floor(rss, y):
    y = np.asarray(y, dtype=float)

    # Numerical floor only; not a scientific scatter floor.
    scale = np.var(y, ddof=0)

    floor = max(
        1.0e-30,
        1.0e-12
        *
        max(scale, 1.0)
        *
        len(y)
    )

    return max(
        float(rss),
        floor
    )


def information_criteria(rss, n, k):
    rss = max(float(rss), 1.0e-300)

    aic = (
        n * math.log(rss / n)
        +
        2.0 * k
    )

    bic = (
        n * math.log(rss / n)
        +
        k * math.log(n)
    )

    return aic, bic


def fit_single_line(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)

    x0 = float(
        np.median(x)
    )

    X = np.column_stack(
        [
            np.ones(n),
            x - x0,
        ]
    )

    beta, _, _, _ = np.linalg.lstsq(
        X,
        y,
        rcond=None
    )

    pred = X @ beta

    resid = y - pred

    rss = rss_floor(
        np.sum(resid ** 2),
        y
    )

    k = 3

    aic, bic = information_criteria(
        rss,
        n,
        k
    )

    return {
        "single_x0_rmag": x0,
        "single_intercept_at_x0": float(beta[0]),
        "single_slope_dcolor_dr": float(beta[1]),
        "single_rss": float(rss),
        "single_aic": float(aic),
        "single_bic": float(bic),
        "single_resid_std": float(
            math.sqrt(
                rss / n
            )
        ),
    }


def candidate_breaks(x):
    x = np.asarray(x, dtype=float)

    xs = np.sort(
        np.unique(x)
    )

    n = len(x)

    if n < MIN_BREAK_N:
        return np.array(
            [],
            dtype=float
        )

    # Candidate values are restricted by actual point counts
    # on each side, not only by quantiles.
    vals = []

    for xb in xs:
        nl = int(
            np.sum(
                x <= xb
            )
        )

        nr = int(
            np.sum(
                x > xb
            )
        )

        if (
            nl >= MIN_SIDE_N
            and
            nr >= MIN_SIDE_N
        ):
            vals.append(
                float(xb)
            )

    vals = np.asarray(
        vals,
        dtype=float
    )

    if len(vals) <= MAX_BREAK_GRID:
        return vals

    # Deterministic thinning of candidate grid.
    idx = np.linspace(
        0,
        len(vals) - 1,
        MAX_BREAK_GRID
    ).round().astype(int)

    return np.unique(
        vals[idx]
    )


def fit_broken_line(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)

    candidates = candidate_breaks(
        x
    )

    if len(candidates) == 0:
        return None

    best = None

    for xb in candidates:

        dx = x - xb

        hinge = np.maximum(
            dx,
            0.0
        )

        X = np.column_stack(
            [
                np.ones(n),
                dx,
                hinge,
            ]
        )

        beta, _, _, _ = np.linalg.lstsq(
            X,
            y,
            rcond=None
        )

        pred = X @ beta

        resid = y - pred

        rss = rss_floor(
            np.sum(
                resid ** 2
            ),
            y
        )

        if (
            best is None
            or rss < best["rss"]
        ):
            b_left = float(
                beta[1]
            )

            delta = float(
                beta[2]
            )

            b_right = (
                b_left
                +
                delta
            )

            best = {
                "xb": float(xb),
                "c": float(beta[0]),
                "b_left": b_left,
                "b_right": float(b_right),
                "delta_slope": delta,
                "rss": float(rss),
                "n_left": int(
                    np.sum(
                        x <= xb
                    )
                ),
                "n_right": int(
                    np.sum(
                        x > xb
                    )
                ),
            }

    if best is None:
        return None

    # intercept + left slope + slope change + break + residual variance
    k = 5

    aic, bic = information_criteria(
        best["rss"],
        n,
        k
    )

    best["aic"] = float(aic)
    best["bic"] = float(bic)

    return best


# ============================================================
# ANALYZE ONE SOURCE
# ============================================================

def analyze_source(blazar_id, nightly, meta):

    pairs = build_colour_pairs(
        blazar_id,
        nightly
    )

    n = len(pairs)

    row = {
        "blazar_id": blazar_id,
        "Source_Name": meta.get(
            "Source_Name",
            np.nan
        ),
        "ASSOC1": meta.get(
            "ASSOC1",
            np.nan
        ),
        "blazar_class": meta.get(
            "blazar_class",
            np.nan
        ),
        "sample_tier": meta.get(
            "sample_tier",
            np.nan
        ),
        "redshift_clean": meta.get(
            "redshift_clean",
            np.nan
        ),
        "SED_class_clean": meta.get(
            "SED_class_clean",
            np.nan
        ),
        "N_colour_pairs": int(n),
        "pair_tolerance_days": PAIR_TOL_DAYS,
        "fit_status": "NOT_RUN",
    }

    if n == 0:
        row["fit_status"] = "NO_COLOUR_PAIRS"
        return row, pairs

    row["pair_dt_hours_median"] = float(
        pairs["dt_gr_hours"].median()
    )

    row["pair_dt_hours_p90"] = float(
        pairs["dt_gr_hours"].quantile(
            0.90
        )
    )

    row["pair_dt_hours_max"] = float(
        pairs["dt_gr_hours"].max()
    )

    row["r_mag_min"] = float(
        pairs["r_mag"].min()
    )

    row["r_mag_max"] = float(
        pairs["r_mag"].max()
    )

    row["r_mag_range"] = float(
        row["r_mag_max"]
        -
        row["r_mag_min"]
    )

    row["g_minus_r_median"] = float(
        pairs["g_minus_r"].median()
    )

    row["g_minus_r_std"] = (
        float(
            pairs["g_minus_r"].std(
                ddof=1
            )
        )
        if n >= 2
        else np.nan
    )

    if n < MIN_SINGLE_N:
        row["fit_status"] = (
            f"TOO_FEW_PAIRS_LT_{MIN_SINGLE_N}"
        )
        return row, pairs

    x = pairs["r_mag"].to_numpy(
        dtype=float
    )

    y = pairs["g_minus_r"].to_numpy(
        dtype=float
    )

    if (
        np.allclose(
            x,
            x[0]
        )
        or
        np.allclose(
            y,
            y[0]
        )
    ):
        row["fit_status"] = (
            "DEGENERATE_RELATION"
        )
        return row, pairs

    try:
        rho_s, p_s = spearmanr(
            x,
            y
        )

        r_p, p_p = pearsonr(
            x,
            y
        )

        lr = linregress(
            x,
            y
        )

        row.update({
            "spearman_rho": float(rho_s),
            "spearman_p": float(p_s),
            "pearson_r": float(r_p),
            "pearson_p": float(p_p),
            "linear_slope_linregress": float(
                lr.slope
            ),
            "linear_intercept_linregress": float(
                lr.intercept
            ),
            "linear_slope_stderr": float(
                lr.stderr
            ),
        })

        single = fit_single_line(
            x,
            y
        )

        row.update(
            single
        )

        # Direction convention with x=r magnitude:
        # positive slope => colour larger when fainter,
        # hence bluer when brighter.
        slope = row[
            "single_slope_dcolor_dr"
        ]

        if slope > 0:
            row[
                "single_trend_direction"
            ] = "BWB"

        elif slope < 0:
            row[
                "single_trend_direction"
            ] = "RWB"

        else:
            row[
                "single_trend_direction"
            ] = "FLAT"

        broken = None

        if n >= MIN_BREAK_N:
            broken = fit_broken_line(
                x,
                y
            )

        if broken is not None:

            row.update({
                "break_r_mag": broken["xb"],
                "break_color_g_minus_r": broken["c"],
                "break_slope_left": broken["b_left"],
                "break_slope_right": broken["b_right"],
                "break_delta_slope": broken["delta_slope"],
                "break_N_left": broken["n_left"],
                "break_N_right": broken["n_right"],
                "break_rss": broken["rss"],
                "break_aic": broken["aic"],
                "break_bic": broken["bic"],
            })

            row[
                "delta_bic_single_minus_broken"
            ] = float(
                row["single_bic"]
                -
                row["break_bic"]
            )

            row[
                "delta_aic_single_minus_broken"
            ] = float(
                row["single_aic"]
                -
                row["break_aic"]
            )

            row[
                "strong_break_bic10"
            ] = bool(
                row[
                    "delta_bic_single_minus_broken"
                ]
                >=
                STRONG_BREAK_DELTA_BIC
            )

        else:

            row[
                "strong_break_bic10"
            ] = False

        row["fit_status"] = "OK"

    except Exception as exc:

        row["fit_status"] = (
            f"FIT_FAILED:{type(exc).__name__}"
        )

    return row, pairs


# ============================================================
# LOAD SAMPLE
# ============================================================

sample = pd.read_csv(
    SAMPLE_FILE
)

required_sample = [
    "blazar_id",
    "sample_tier",
    "blazar_class",
]

missing_sample = [
    c
    for c in required_sample
    if c not in sample.columns
]

if missing_sample:
    raise RuntimeError(
        "Missing sample columns: "
        + ", ".join(
            missing_sample
        )
    )

sample["blazar_id"] = (
    sample["blazar_id"]
    .astype(str)
)

source_ids = (
    sample["blazar_id"]
    .drop_duplicates()
    .tolist()
)

sample_lookup = (
    sample
    .drop_duplicates(
        "blazar_id"
    )
    .set_index(
        "blazar_id"
    )
)

N_SOURCE = len(
    source_ids
)


# ============================================================
# HEADER
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 03C")
print("COLOUR–MAGNITUDE + CONTINUOUS BROKEN-LINE SEARCH")
print("=" * 78)

print(
    "Analysis sample =",
    N_SOURCE
)

print(
    "Pair tolerance =",
    PAIR_TOL_DAYS,
    "d"
)

print(
    "Minimum single-line N =",
    MIN_SINGLE_N
)

print(
    "Minimum break-fit N =",
    MIN_BREAK_N
)

print(
    "Minimum points per break side =",
    MIN_SIDE_N
)

print(
    "Strong break threshold DeltaBIC =",
    STRONG_BREAK_DELTA_BIC
)


# ============================================================
# CHECKPOINT STATUS
# ============================================================

def source_complete(blazar_id):
    return (
        summary_file(
            blazar_id
        ).exists()
        and
        pairs_file(
            blazar_id
        ).exists()
        and
        done_file(
            blazar_id
        ).exists()
    )


complete_before = [
    bid
    for bid in source_ids
    if source_complete(
        bid
    )
]

print()

print(
    "Completed 03C sources on disk =",
    len(
        complete_before
    ),
    "/",
    N_SOURCE
)

print(
    "Remaining 03C sources         =",
    N_SOURCE
    -
    len(
        complete_before
    )
)


# ============================================================
# PER-SOURCE LOOP
# ============================================================

processed_this_run = 0

session_start = time.time()


for source_number, blazar_id in enumerate(
    source_ids,
    start=1
):

    if source_complete(
        blazar_id
    ):
        continue

    if (
        args.limit is not None
        and
        processed_this_run
        >=
        args.limit
    ):
        print()
        print(
            "Pilot limit reached:",
            args.limit
        )
        break

    nightly_path = (
        NIGHTLY_DIR
        /
        f"{blazar_id}_NIGHTLY.parquet"
    )

    if not nightly_path.exists():
        raise FileNotFoundError(
            nightly_path
        )

    if not done_file(
        blazar_id
    ).exists():

        for path in [
            summary_file(
                blazar_id
            ),
            pairs_file(
                blazar_id
            ),
        ]:

            remove_if_exists(
                path
            )

            remove_if_exists(
                temp_path(
                    path
                )
            )

        remove_if_exists(
            temp_path(
                done_file(
                    blazar_id
                )
            )
        )

    print()
    print("=" * 78)

    print(
        f"SOURCE "
        f"{source_number}/{N_SOURCE}"
    )

    print(
        "blazar_id =",
        blazar_id
    )

    t0 = time.time()

    try:

        nightly = pd.read_parquet(
            nightly_path
        )

        meta = (
            sample_lookup
            .loc[
                blazar_id
            ]
            .to_dict()
        )

        row, pairs = analyze_source(
            blazar_id=blazar_id,
            nightly=nightly,
            meta=meta,
        )

        summary = pd.DataFrame(
            [
                row
            ]
        )

        atomic_csv(
            summary,
            summary_file(
                blazar_id
            )
        )

        atomic_parquet(
            pairs,
            pairs_file(
                blazar_id
            )
        )

        elapsed = (
            time.time()
            -
            t0
        )

        atomic_text(
            (
                "COMPLETE\n"
                f"blazar_id={blazar_id}\n"
                f"elapsed_seconds={elapsed:.6f}\n"
            ),
            done_file(
                blazar_id
            )
        )

        rr = summary.iloc[0]

        print(
            "Colour pairs =",
            int(
                rr[
                    "N_colour_pairs"
                ]
            )
        )

        print(
            "Spearman rho =",
            (
                f"{rr.get('spearman_rho', np.nan):.4f}"
            )
        )

        print(
            "Single slope =",
            (
                f"{rr.get('single_slope_dcolor_dr', np.nan):.4f}"
            )
        )

        print(
            "DeltaBIC(single-broken) =",
            (
                f"{rr.get('delta_bic_single_minus_broken', np.nan):.3f}"
            )
        )

        print(
            "Strong break =",
            bool(
                rr.get(
                    "strong_break_bic10",
                    False
                )
            )
        )

        print(
            "status =",
            rr[
                "fit_status"
            ]
        )

        print(
            "CHECKPOINT =",
            done_file(
                blazar_id
            ).name
        )

        processed_this_run += 1

    except Exception:

        print()
        print(
            "FAILED SOURCE:",
            blazar_id
        )

        traceback.print_exc()

        fail_path = (
            AUDIT_DIR
            /
            "stage03c_last_failure.txt"
        )

        fail_path.write_text(
            (
                "BLAZAR_I STAGE 03C FAILURE\n"
                f"blazar_id={blazar_id}\n"
                f"source_number="
                f"{source_number}/"
                f"{N_SOURCE}\n"
            ),
            encoding="utf-8"
        )

        sys.exit(
            30
        )


# ============================================================
# CURRENT STATUS
# ============================================================

complete_now = [
    bid
    for bid in source_ids
    if source_complete(
        bid
    )
]

session_elapsed = (
    time.time()
    -
    session_start
)

print()
print("=" * 78)
print("STAGE 03C CURRENT STATUS")
print("=" * 78)

print(
    "Completed sources =",
    len(
        complete_now
    ),
    "/",
    N_SOURCE
)

print(
    "Remaining         =",
    N_SOURCE
    -
    len(
        complete_now
    )
)

print(
    f"Session elapsed   = "
    f"{session_elapsed/60:.2f} min"
)


# ============================================================
# GLOBAL PRODUCTS
# ============================================================

if len(
    complete_now
) == N_SOURCE:

    print()
    print(
        "All STAGE 03C sources complete."
    )

    summary_frames = []
    pair_frames = []

    for bid in source_ids:

        summary_frames.append(
            pd.read_csv(
                summary_file(
                    bid
                )
            )
        )

        pp = pd.read_parquet(
            pairs_file(
                bid
            )
        )

        if len(
            pp
        ) > 0:
            pair_frames.append(
                pp
            )

    master = pd.concat(
        summary_frames,
        ignore_index=True
    )

    if pair_frames:

        pairs_master = pd.concat(
            pair_frames,
            ignore_index=True
        )

    else:

        pairs_master = pd.DataFrame(
            columns=PAIR_COLUMNS
        )

    # --------------------------------------------
    # BH-FDR for the monotonic colour trend
    # --------------------------------------------

    master[
        "spearman_q_bh_global"
    ] = np.nan

    ok_mask = (
        master[
            "fit_status"
        ].eq(
            "OK"
        )
        &
        np.isfinite(
            pd.to_numeric(
                master[
                    "spearman_p"
                ],
                errors="coerce"
            )
        )
    )

    idx = master.index[
        ok_mask
    ]

    master.loc[
        idx,
        "spearman_q_bh_global"
    ] = bh_qvalues(
        master.loc[
            idx,
            "spearman_p"
        ].to_numpy(
            dtype=float
        )
    )

    master[
        "significant_monotonic_colour"
    ] = (
        master[
            "fit_status"
        ].eq(
            "OK"
        )
        &
        (
            master[
                "spearman_q_bh_global"
            ]
            <=
            FDR_ALPHA
        )
    )

    # --------------------------------------------
    # Save global tables
    # --------------------------------------------

    MASTER_OUT = (
        TABLE_DIR
        /
        "stage03c_colour_break_master.csv"
    )

    PAIRS_OUT = (
        TABLE_DIR
        /
        "stage03c_colour_pairs_master.parquet"
    )

    master.to_csv(
        MASTER_OUT,
        index=False
    )

    pairs_master.to_parquet(
        PAIRS_OUT,
        index=False
    )

    # Compact candidate table.
    candidates = master.loc[
        master[
            "strong_break_bic10"
        ].fillna(
            False
        ).astype(
            bool
        )
    ].copy()

    CANDIDATE_OUT = (
        TABLE_DIR
        /
        "stage03c_strong_break_candidates.csv"
    )

    candidates.to_csv(
        CANDIDATE_OUT,
        index=False
    )

    # --------------------------------------------
    # Summary
    # --------------------------------------------

    ok = master.loc[
        master[
            "fit_status"
        ].eq(
            "OK"
        )
    ].copy()

    strong = master.loc[
        master[
            "strong_break_bic10"
        ].fillna(
            False
        ).astype(
            bool
        )
    ].copy()

    significant_colour = master.loc[
        master[
            "significant_monotonic_colour"
        ]
    ].copy()

    bwb = significant_colour.loc[
        significant_colour[
            "single_slope_dcolor_dr"
        ] > 0
    ]

    rwb = significant_colour.loc[
        significant_colour[
            "single_slope_dcolor_dr"
        ] < 0
    ]

    lines = [
        "BLAZAR_I - STAGE 03C FINAL SUMMARY",
        "=" * 72,
        "",
        "PRIMARY COLOUR RELATION:",
        "  y = g-r",
        "  x = r magnitude",
        (
            "  pair tolerance = "
            f"{PAIR_TOL_DAYS:.2f} d"
        ),
        "",
        "BROKEN-LINE GATE:",
        (
            "  minimum colour pairs = "
            f"{MIN_BREAK_N}"
        ),
        (
            "  minimum points per side = "
            f"{MIN_SIDE_N}"
        ),
        (
            "  strong break if DeltaBIC >= "
            f"{STRONG_BREAK_DELTA_BIC:.1f}"
        ),
        "",
        (
            "Analysis blazars                 : "
            f"{N_SOURCE}"
        ),
        (
            "Successful colour fits           : "
            f"{len(ok)}"
        ),
        (
            "Non-fit rows                     : "
            f"{len(master)-len(ok)}"
        ),
        (
            "Strong broken-line candidates    : "
            f"{len(strong)}"
        ),
        (
            "BH-significant monotonic colours : "
            f"{len(significant_colour)}"
        ),
        (
            "  BWB among significant          : "
            f"{len(bwb)}"
        ),
        (
            "  RWB among significant          : "
            f"{len(rwb)}"
        ),
        "",
        "By class:",
    ]

    for cls in [
        "BLL",
        "FSRQ",
    ]:

        xx = master.loc[
            master[
                "blazar_class"
            ].eq(
                cls
            )
        ]

        ss = xx.loc[
            xx[
                "strong_break_bic10"
            ].fillna(
                False
            ).astype(
                bool
            )
        ]

        cc = xx.loc[
            xx[
                "significant_monotonic_colour"
            ]
        ]

        lines.append(
            f"  {cls}: "
            f"N={len(xx)}, "
            f"strong_break={len(ss)}, "
            f"significant_colour={len(cc)}"
        )

    final_summary = "\n".join(
        lines
    )

    SUMMARY_OUT = (
        AUDIT_DIR
        /
        "stage03c_summary.txt"
    )

    SUMMARY_OUT.write_text(
        final_summary,
        encoding="utf-8"
    )

    print()
    print(
        final_summary
    )

    print()
    print("=" * 78)
    print("GLOBAL FILES SAVED")
    print("=" * 78)

    print(
        MASTER_OUT
    )

    print(
        PAIRS_OUT
    )

    print(
        CANDIDATE_OUT
    )

    print(
        SUMMARY_OUT
    )

    print()
    print(
        "STAGE 03C COMPLETE"
    )
