# ============================================================
# BLAZAR_I — STAGE 09A0
# Q1-REVIEWER CRITICAL REBUILD: CONFOUNDER / HOST-PROXY SCHEMA AUDIT
#
# Purpose:
#   Inventory every existing source-level table for covariates relevant to
#   stronger FSRQ/BLL inference before any new model is fit.
#
# We specifically audit availability/completeness of:
#   - redshift / redshift-known
#   - synchrotron SED class
#   - gamma-ray energy flux / variability index
#   - optical brightness / optical variability amplitude
#   - sky position
#   - possible host-galaxy / morphology proxies already present
#   - source-level IDs needed for merging
#
# Safety:
#   - read-only relative to all upstream products
#   - no statistical endpoint is refit
#   - no catalogue is downloaded
#
# Outputs:
#   outputs/audit/stage09a0_candidate_column_inventory.csv
#   outputs/audit/stage09a0_file_inventory.csv
#   outputs/audit/stage09a0_covariate_coverage.csv
#   outputs/audit/stage09a0_summary.txt
# ============================================================

from pathlib import Path
import re
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

SEARCH_DIRS = [
    ROOT / "data" / "interim",
    ROOT / "data" / "processed",
    ROOT / "outputs" / "tables",
]

AUDIT_DIR = ROOT / "outputs" / "audit"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

OUT_COLS = AUDIT_DIR / "stage09a0_candidate_column_inventory.csv"
OUT_FILES = AUDIT_DIR / "stage09a0_file_inventory.csv"
OUT_COVER = AUDIT_DIR / "stage09a0_covariate_coverage.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09a0_summary.txt"

PATTERNS = {
    "id": re.compile(
        r"(blazar[_ ]?id|source[_ ]?name|fermi[_ ]?name|assoc|counterpart|object[_ ]?id)",
        re.I,
    ),
    "class": re.compile(
        r"(blazar[_ ]?class|class1|optical[_ ]?class|source[_ ]?class)",
        re.I,
    ),
    "redshift": re.compile(
        r"(^z$|redshift|z[_ ]?known|known[_ ]?z)",
        re.I,
    ),
    "sed": re.compile(
        r"(sed|synch|lsp|isp|hsp)",
        re.I,
    ),
    "gamma_flux": re.compile(
        r"(energy.?flux|flux1000|gamma.*flux|flux.*gamma)",
        re.I,
    ),
    "gamma_variability": re.compile(
        r"(variability.?index|var.?index|fractional.?variability)",
        re.I,
    ),
    "sky": re.compile(
        r"(^ra$|^dec$|ra[_ ]|dec[_ ]|counterpart.*ra|counterpart.*dec)",
        re.I,
    ),
    "optical_brightness": re.compile(
        r"(median.*mag|mean.*mag|mag.*median|mag.*mean|r[_ ]?mag|g[_ ]?mag|brightness)",
        re.I,
    ),
    "optical_variability": re.compile(
        r"(fvar|dynamic.?range|mag.?range|amplitude|std.*mag|rms)",
        re.I,
    ),
    "host_proxy": re.compile(
        r"(host|morph|extended|psf|kron|petro|shape|class.?star|stellarity|gaia.*excess|ruwe)",
        re.I,
    ),
}

def read_schema(path):
    suf = path.suffix.lower()

    if suf == ".csv":
        return pd.read_csv(
            path,
            nrows=5,
            low_memory=False,
        )

    if suf in {".parquet", ".pq"}:
        return pd.read_parquet(
            path
        ).head(5)

    return None

def read_full_if_reasonable(path, max_bytes=200_000_000):
    if path.stat().st_size > max_bytes:
        return None

    suf = path.suffix.lower()

    try:
        if suf == ".csv":
            return pd.read_csv(
                path,
                low_memory=False,
            )

        if suf in {".parquet", ".pq"}:
            return pd.read_parquet(
                path
            )
    except Exception:
        return None

    return None

files = []

for directory in SEARCH_DIRS:
    if not directory.exists():
        continue

    for path in directory.rglob("*"):
        if (
            path.is_file()
            and
            path.suffix.lower() in {".csv", ".parquet", ".pq"}
        ):
            files.append(path)

files = sorted(
    set(files),
    key=lambda p: str(p).lower(),
)

file_rows = []
candidate_rows = []

for path in files:
    rel = str(
        path.relative_to(ROOT)
    )

    try:
        df = read_schema(
            path
        )

        if df is None:
            continue

        cols = list(
            df.columns
        )

        file_rows.append({
            "relative_path": rel,
            "suffix": path.suffix.lower(),
            "size_bytes": path.stat().st_size,
            "n_columns": len(cols),
            "schema_status": "OK",
        })

        for col in cols:
            categories = [
                name
                for name, pat in PATTERNS.items()
                if pat.search(str(col))
            ]

            if categories:
                candidate_rows.append({
                    "relative_path": rel,
                    "column": str(col),
                    "categories": ";".join(categories),
                    "sample_values": " | ".join(
                        map(
                            str,
                            df[col]
                            .dropna()
                            .astype(str)
                            .head(3)
                            .tolist()
                        )
                    ),
                })

    except Exception as exc:
        file_rows.append({
            "relative_path": rel,
            "suffix": path.suffix.lower(),
            "size_bytes": path.stat().st_size,
            "n_columns": np.nan,
            "schema_status": f"ERROR: {type(exc).__name__}: {exc}",
        })

file_df = pd.DataFrame(
    file_rows
)

cand_df = pd.DataFrame(
    candidate_rows
)

file_df.to_csv(
    OUT_FILES,
    index=False,
)

cand_df.to_csv(
    OUT_COLS,
    index=False,
)

# ------------------------------------------------------------
# Coverage audit for likely source-level master tables.
# We choose tables containing blazar_id + blazar_class and one or more
# science covariates of interest, preferring compact source-level files.
# ------------------------------------------------------------

coverage_rows = []

for rel in cand_df["relative_path"].drop_duplicates().tolist():
    path = ROOT / rel

    try:
        df = read_full_if_reasonable(
            path
        )

        if df is None or len(df) == 0:
            continue

        cols = set(
            map(str, df.columns)
        )

        id_col = None

        for c in [
            "blazar_id",
            "BLAZAR_ID",
            "source_id",
        ]:
            if c in cols:
                id_col = c
                break

        class_col = None

        for c in [
            "blazar_class",
            "CLASS1",
            "class1",
            "optical_class",
        ]:
            if c in cols:
                class_col = c
                break

        if id_col is None or class_col is None:
            continue

        # Source-level uniqueness is preferred.
        n_rows = len(df)
        n_unique = df[id_col].astype(str).nunique()

        source_level_ratio = (
            n_unique / n_rows
            if n_rows > 0
            else np.nan
        )

        for col in df.columns:
            cats = [
                name
                for name, pat in PATTERNS.items()
                if pat.search(str(col))
            ]

            relevant = set(cats) & {
                "redshift",
                "sed",
                "gamma_flux",
                "gamma_variability",
                "sky",
                "optical_brightness",
                "optical_variability",
                "host_proxy",
            }

            if not relevant:
                continue

            s = df[col]

            finite_n = int(
                pd.to_numeric(
                    s,
                    errors="coerce",
                ).notna().sum()
            )

            nonempty_n = int(
                s.notna().sum()
            )

            for cls in [
                "BLL",
                "FSRQ",
            ]:
                mask = (
                    df[class_col]
                    .astype(str)
                    .str.upper()
                    .eq(cls)
                )

                n_cls = int(
                    mask.sum()
                )

                if n_cls == 0:
                    continue

                nonempty_cls = int(
                    s.loc[mask]
                    .notna()
                    .sum()
                )

                coverage_rows.append({
                    "relative_path": rel,
                    "n_rows": n_rows,
                    "n_unique_ids": n_unique,
                    "source_level_ratio": source_level_ratio,
                    "id_col": id_col,
                    "class_col": class_col,
                    "class": cls,
                    "covariate_column": str(col),
                    "categories": ";".join(sorted(relevant)),
                    "N_class": n_cls,
                    "N_nonmissing_class": nonempty_cls,
                    "fraction_nonmissing_class": nonempty_cls / n_cls,
                    "N_nonmissing_all": nonempty_n,
                    "N_numeric_all": finite_n,
                })

    except Exception:
        continue

cover_df = pd.DataFrame(
    coverage_rows
)

cover_df.to_csv(
    OUT_COVER,
    index=False,
)

# ------------------------------------------------------------
# Human-readable summary
# ------------------------------------------------------------

n_files = len(file_df)
n_ok = int(
    file_df["schema_status"]
    .eq("OK")
    .sum()
) if len(file_df) else 0

n_candidates = len(cand_df)

host_hits = (
    cand_df.loc[
        cand_df["categories"]
        .str.contains(
            "host_proxy",
            na=False,
        )
    ]
    if len(cand_df)
    else pd.DataFrame()
)

red_hits = (
    cand_df.loc[
        cand_df["categories"]
        .str.contains(
            "redshift",
            na=False,
        )
    ]
    if len(cand_df)
    else pd.DataFrame()
)

sed_hits = (
    cand_df.loc[
        cand_df["categories"]
        .str.contains(
            "sed",
            na=False,
        )
    ]
    if len(cand_df)
    else pd.DataFrame()
)

gamma_hits = (
    cand_df.loc[
        cand_df["categories"]
        .str.contains(
            "gamma_flux|gamma_variability",
            regex=True,
            na=False,
        )
    ]
    if len(cand_df)
    else pd.DataFrame()
)

opt_hits = (
    cand_df.loc[
        cand_df["categories"]
        .str.contains(
            "optical_brightness|optical_variability",
            regex=True,
            na=False,
        )
    ]
    if len(cand_df)
    else pd.DataFrame()
)

def compact_hits(df, max_rows=12):
    if df is None or len(df) == 0:
        return "  none"

    lines = []

    for _, r in df.head(max_rows).iterrows():
        lines.append(
            f"  {r['relative_path']} :: {r['column']}"
        )

    if len(df) > max_rows:
        lines.append(
            f"  ... +{len(df)-max_rows} more"
        )

    return "\n".join(lines)

summary = f"""BLAZAR_I - STAGE 09A0 FINAL SUMMARY
================================================================================

Q1-reviewer critical rebuild: confounder / host-proxy schema audit

Files scanned:
  candidate table files      : {n_files}
  schema readable            : {n_ok}
  candidate columns          : {n_candidates}

Existing redshift-related columns:
{compact_hits(red_hits)}

Existing SED-related columns:
{compact_hits(sed_hits)}

Existing gamma-ray covariates:
{compact_hits(gamma_hits)}

Existing optical brightness/variability covariates:
{compact_hits(opt_hits)}

Existing host/morphology proxy candidates:
{compact_hits(host_hits)}

Interpretation:
  - This stage does not fit any new endpoint model.
  - If no credible host/morphology proxy is already present, STAGE 09A1
    will add an external host proxy rather than inventing one.
  - Existing redshift/SED/gamma/optical covariates will be used to define
    nested Q1-reviewer confounder models before host augmentation.

Files saved:
  {OUT_FILES}
  {OUT_COLS}
  {OUT_COVER}

Next:
  STAGE 09A1 — construct the exact confounder-analysis master table and
  determine whether external host-galaxy augmentation is required.

STAGE 09A0 COMPLETE
"""

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
