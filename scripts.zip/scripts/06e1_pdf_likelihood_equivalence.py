# ============================================================
# BLAZAR_I — STAGE 06E1
# FROZEN FLUX-PDF LIKELIHOOD / BIC / ROBUST-GATE EQUIVALENCE AUDIT
#
# Purpose:
#   Independently reconstruct STAGE 03A likelihoods and BIC values
#   from the frozen fitted parameters and the nightly flux data
#   before performing any sampling-sensitivity refits.
#
# Models:
#   1) Gaussian in flux:
#        f ~ Normal(mu_f, sigma_f)
#        k = 2
#
#   2) Lognormal in flux:
#        ln f ~ Normal(mu_ln, sigma_ln)
#        p(f) = Normal(ln f | mu_ln, sigma_ln) / f
#        k = 2
#
#   3) Two-component lognormal mixture:
#        ln f ~ w1 N(mu1,s1) + w2 N(mu2,s2)
#        p(f) = mixture_density(ln f) / f
#        k = 5
#
# Robust-double gate reconstructed:
#   preferred BIC model == DOUBLE_LOGNORMAL
#   DeltaBIC(second-best - best) >= 10
#   smaller component weight >= 0.10
#   Ashman-style separation D >= 2
#
# Separation convention tested:
#   D = sqrt(2) * |mu2-mu1| / sqrt(s1^2+s2^2)
#
# Expected if exact:
#   likelihood/BIC differences ~ floating-point precision,
#   preferred-model mismatches = 0,
#   robust-double mismatches = 0,
#   source-level robust-both count = 322.
#
# Read-only relative to frozen STAGE 03A.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
from scipy.special import logsumexp

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

MASTER_FILE = TABLE_DIR / "stage03a_fluxpdf_master.csv"

OUT_TABLE = TABLE_DIR / "stage06e1_pdf_likelihood_equivalence.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06e1_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


def normal_logpdf(x, mu, sigma):
    return (
        -0.5 * np.log(2.0 * np.pi)
        - np.log(sigma)
        - 0.5 * ((x - mu) / sigma) ** 2
    )


def finite_abs_stats(x):
    x = np.asarray(x, dtype=float)
    x = np.abs(x[np.isfinite(x)])

    if len(x) == 0:
        return (
            np.nan,
            np.nan,
            np.nan,
        )

    return (
        float(np.median(x)),
        float(np.quantile(x, 0.95)),
        float(np.max(x)),
    )


def choose_bic_model(
    gauss_bic,
    lnorm_bic,
    dlnorm_bic,
):
    vals = {
        "GAUSSIAN": float(gauss_bic),
        "LOGNORMAL": float(lnorm_bic),
        "DOUBLE_LOGNORMAL": float(dlnorm_bic),
    }

    ordered = sorted(
        vals.items(),
        key=lambda kv: kv[1],
    )

    best_name = ordered[0][0]
    delta_second = (
        ordered[1][1]
        -
        ordered[0][1]
    )

    return (
        best_name,
        float(delta_second),
    )


if not MASTER_FILE.exists():
    raise FileNotFoundError(
        MASTER_FILE
    )

master = pd.read_csv(
    MASTER_FILE
)

if len(master) != 2122:
    raise RuntimeError(
        f"Expected STAGE03A rows=2122; got {len(master)}"
    )

master["blazar_id"] = (
    master["blazar_id"]
    .astype(str)
)

rows = []

print("=" * 78)
print("BLAZAR_I — STAGE 06E1")
print("FROZEN FLUX-PDF LIKELIHOOD / BIC / GATE EQUIVALENCE AUDIT")
print("=" * 78)

for i, (
    bid,
    group
) in enumerate(
    master.groupby(
        "blazar_id",
        sort=True
    ),
    start=1,
):
    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    nightly = pd.read_parquet(
        path
    )

    for _, rr in group.iterrows():
        filt = str(
            rr["filter_name"]
        )

        x = nightly.loc[
            nightly[
                "filter_name"
            ].astype(str).eq(filt),
            "flux_jy",
        ]

        f = pd.to_numeric(
            x,
            errors="coerce"
        ).to_numpy(
            dtype=float
        )

        f = f[
            np.isfinite(f)
            &
            (f > 0)
        ]

        n = len(f)

        if n != int(
            rr["N_nightly"]
        ):
            raise RuntimeError(
                f"{bid} {filt}: N mismatch "
                f"{n} vs frozen {int(rr['N_nightly'])}"
            )

        lnf = np.log(f)

        # --------------------------------------------------------
        # Gaussian flux likelihood
        # --------------------------------------------------------
        g_mu = float(
            rr["gauss_mu_flux"]
        )

        g_sig = float(
            rr["gauss_sigma_flux"]
        )

        if not (
            np.isfinite(g_sig)
            and
            g_sig > 0
        ):
            raise RuntimeError(
                f"{bid} {filt}: invalid Gaussian sigma"
            )

        ll_g = float(
            normal_logpdf(
                f,
                g_mu,
                g_sig
            ).sum()
        )

        bic_g = (
            2.0 * math.log(n)
            -
            2.0 * ll_g
        )

        # --------------------------------------------------------
        # Single lognormal, evaluated in flux space
        # --------------------------------------------------------
        l_mu = float(
            rr["lnorm_mu_lnflux"]
        )

        l_sig = float(
            rr["lnorm_sigma_lnflux"]
        )

        if not (
            np.isfinite(l_sig)
            and
            l_sig > 0
        ):
            raise RuntimeError(
                f"{bid} {filt}: invalid lognormal sigma"
            )

        ll_l_flux = float(
            (
                normal_logpdf(
                    lnf,
                    l_mu,
                    l_sig
                )
                -
                lnf
            ).sum()
        )

        bic_l_flux = (
            2.0 * math.log(n)
            -
            2.0 * ll_l_flux
        )

        # Candidate no-Jacobian convention, diagnostic only.
        ll_l_lnspace = float(
            normal_logpdf(
                lnf,
                l_mu,
                l_sig
            ).sum()
        )

        bic_l_lnspace = (
            2.0 * math.log(n)
            -
            2.0 * ll_l_lnspace
        )

        # --------------------------------------------------------
        # Double lognormal mixture
        # --------------------------------------------------------
        w1 = float(
            rr["dlnorm_weight_low"]
        )

        w2 = float(
            rr["dlnorm_weight_high"]
        )

        mu1 = float(
            rr["dlnorm_mu_low_lnflux"]
        )

        mu2 = float(
            rr["dlnorm_mu_high_lnflux"]
        )

        s1 = float(
            rr["dlnorm_sigma_low_lnflux"]
        )

        s2 = float(
            rr["dlnorm_sigma_high_lnflux"]
        )

        if not (
            w1 > 0
            and
            w2 > 0
            and
            s1 > 0
            and
            s2 > 0
        ):
            raise RuntimeError(
                f"{bid} {filt}: invalid double-lognormal parameters"
            )

        comp = np.vstack(
            [
                math.log(w1)
                +
                normal_logpdf(
                    lnf,
                    mu1,
                    s1
                ),
                math.log(w2)
                +
                normal_logpdf(
                    lnf,
                    mu2,
                    s2
                ),
            ]
        )

        logmix_ln = logsumexp(
            comp,
            axis=0
        )

        ll_d_flux = float(
            (
                logmix_ln
                -
                lnf
            ).sum()
        )

        bic_d_flux = (
            5.0 * math.log(n)
            -
            2.0 * ll_d_flux
        )

        ll_d_lnspace = float(
            logmix_ln.sum()
        )

        bic_d_lnspace = (
            5.0 * math.log(n)
            -
            2.0 * ll_d_lnspace
        )

        # Frozen log-likelihoods inferred from frozen BIC values.
        ll_g_from_bic = (
            2.0 * math.log(n)
            -
            float(rr["gauss_bic"])
        ) / 2.0

        ll_l_from_bic = (
            2.0 * math.log(n)
            -
            float(rr["lnorm_bic"])
        ) / 2.0

        ll_d_from_bic = (
            5.0 * math.log(n)
            -
            float(rr["dlnorm_bic"])
        ) / 2.0

        # Reconstructed preferred model under flux-space likelihood.
        pref, delta_second = choose_bic_model(
            bic_g,
            bic_l_flux,
            bic_d_flux,
        )

        # Separation candidates.
        sep_ashman = (
            math.sqrt(2.0)
            *
            abs(mu2 - mu1)
            /
            math.sqrt(
                s1 ** 2
                +
                s2 ** 2
            )
        )

        sep_simple_sum = (
            abs(mu2 - mu1)
            /
            math.sqrt(
                s1 ** 2
                +
                s2 ** 2
            )
        )

        sep_frozen = float(
            rr[
                "dlnorm_component_separation"
            ]
        )

        smaller_weight = min(
            w1,
            w2
        )

        robust_recon = (
            pref == "DOUBLE_LOGNORMAL"
            and
            delta_second >= 10.0
            and
            smaller_weight >= 0.10
            and
            sep_ashman >= 2.0
        )

        robust_frozen = (
            str(
                rr[
                    "preferred_bic_model"
                ]
            )
            ==
            "DOUBLE_LOGNORMAL"
            and
            float(
                rr[
                    "delta_bic_second_minus_best"
                ]
            )
            >=
            10.0
            and
            smaller_weight >= 0.10
            and
            sep_frozen >= 2.0
        )

        rows.append({
            "blazar_id": bid,
            "blazar_class": rr[
                "blazar_class"
            ],
            "filter_name": filt,
            "N_nightly": n,

            "gauss_ll_reconstructed": ll_g,
            "gauss_ll_from_frozen_bic": ll_g_from_bic,
            "gauss_ll_diff": (
                ll_g
                -
                ll_g_from_bic
            ),
            "gauss_bic_reconstructed": bic_g,
            "gauss_bic_frozen": float(
                rr["gauss_bic"]
            ),
            "gauss_bic_diff": (
                bic_g
                -
                float(
                    rr["gauss_bic"]
                )
            ),

            "lnorm_ll_fluxspace": ll_l_flux,
            "lnorm_ll_lnspace": ll_l_lnspace,
            "lnorm_ll_from_frozen_bic": ll_l_from_bic,
            "lnorm_ll_fluxspace_diff": (
                ll_l_flux
                -
                ll_l_from_bic
            ),
            "lnorm_ll_lnspace_diff": (
                ll_l_lnspace
                -
                ll_l_from_bic
            ),
            "lnorm_bic_fluxspace": bic_l_flux,
            "lnorm_bic_lnspace": bic_l_lnspace,
            "lnorm_bic_frozen": float(
                rr["lnorm_bic"]
            ),

            "dlnorm_ll_fluxspace": ll_d_flux,
            "dlnorm_ll_lnspace": ll_d_lnspace,
            "dlnorm_ll_from_frozen_bic": ll_d_from_bic,
            "dlnorm_ll_fluxspace_diff": (
                ll_d_flux
                -
                ll_d_from_bic
            ),
            "dlnorm_ll_lnspace_diff": (
                ll_d_lnspace
                -
                ll_d_from_bic
            ),
            "dlnorm_bic_fluxspace": bic_d_flux,
            "dlnorm_bic_lnspace": bic_d_lnspace,
            "dlnorm_bic_frozen": float(
                rr["dlnorm_bic"]
            ),

            "preferred_bic_frozen": str(
                rr[
                    "preferred_bic_model"
                ]
            ),
            "preferred_bic_reconstructed": pref,
            "preferred_bic_match": bool(
                pref
                ==
                str(
                    rr[
                        "preferred_bic_model"
                    ]
                )
            ),

            "delta_bic_second_frozen": float(
                rr[
                    "delta_bic_second_minus_best"
                ]
            ),
            "delta_bic_second_reconstructed": delta_second,
            "delta_bic_second_diff": (
                delta_second
                -
                float(
                    rr[
                        "delta_bic_second_minus_best"
                    ]
                )
            ),

            "smaller_component_weight": smaller_weight,
            "separation_frozen": sep_frozen,
            "separation_ashman": sep_ashman,
            "separation_simple_sum": sep_simple_sum,
            "separation_ashman_diff": (
                sep_ashman
                -
                sep_frozen
            ),
            "separation_simple_sum_diff": (
                sep_simple_sum
                -
                sep_frozen
            ),

            "robust_double_frozen_reconstructed_from_columns": robust_frozen,
            "robust_double_reconstructed": robust_recon,
            "robust_double_match": bool(
                robust_frozen
                ==
                robust_recon
            ),
        })

    if (
        i % 100 == 0
        or
        i == 1061
    ):
        print(
            f"Processed {i}/1061 sources"
        )

out = pd.DataFrame(
    rows
)

if len(out) != 2122:
    raise RuntimeError(
        f"Expected output rows=2122; got {len(out)}"
    )

out.to_csv(
    OUT_TABLE,
    index=False
)


# ============================================================
# SOURCE-LEVEL ROBUST-BOTH COUNT
# ============================================================

wide = out.pivot(
    index="blazar_id",
    columns="filter_name",
    values="robust_double_reconstructed"
)

if not (
    "g" in wide.columns
    and
    "r" in wide.columns
):
    raise RuntimeError(
        "Missing g/r columns in reconstructed robust gate."
    )

robust_both_count = int(
    (
        wide["g"].astype(bool)
        &
        wide["r"].astype(bool)
    ).sum()
)


# ============================================================
# SUMMARY
# ============================================================

g_ll = finite_abs_stats(
    out[
        "gauss_ll_diff"
    ]
)

l_flux = finite_abs_stats(
    out[
        "lnorm_ll_fluxspace_diff"
    ]
)

l_ln = finite_abs_stats(
    out[
        "lnorm_ll_lnspace_diff"
    ]
)

d_flux = finite_abs_stats(
    out[
        "dlnorm_ll_fluxspace_diff"
    ]
)

d_ln = finite_abs_stats(
    out[
        "dlnorm_ll_lnspace_diff"
    ]
)

delta_stats = finite_abs_stats(
    out[
        "delta_bic_second_diff"
    ]
)

sep_a = finite_abs_stats(
    out[
        "separation_ashman_diff"
    ]
)

sep_s = finite_abs_stats(
    out[
        "separation_simple_sum_diff"
    ]
)

pref_mismatch = int(
    (
        ~out[
            "preferred_bic_match"
        ]
    ).sum()
)

robust_mismatch = int(
    (
        ~out[
            "robust_double_match"
        ]
    ).sum()
)

lines = [
    "BLAZAR_I - STAGE 06E1 FINAL SUMMARY",
    "=" * 78,
    "",
    f"Rows audited: {len(out)}",
    "",
    "ABSOLUTE LOG-LIKELIHOOD DIFFERENCES",
    "(reconstructed minus likelihood inferred from frozen BIC):",
    (
        "  Gaussian flux: "
        f"median={g_ll[0]:.3e}, "
        f"p95={g_ll[1]:.3e}, "
        f"max={g_ll[2]:.3e}"
    ),
    (
        "  Lognormal FLUX-SPACE: "
        f"median={l_flux[0]:.3e}, "
        f"p95={l_flux[1]:.3e}, "
        f"max={l_flux[2]:.3e}"
    ),
    (
        "  Lognormal LN-SPACE no-Jacobian: "
        f"median={l_ln[0]:.3e}, "
        f"p95={l_ln[1]:.3e}, "
        f"max={l_ln[2]:.3e}"
    ),
    (
        "  Double-lognormal FLUX-SPACE: "
        f"median={d_flux[0]:.3e}, "
        f"p95={d_flux[1]:.3e}, "
        f"max={d_flux[2]:.3e}"
    ),
    (
        "  Double-lognormal LN-SPACE no-Jacobian: "
        f"median={d_ln[0]:.3e}, "
        f"p95={d_ln[1]:.3e}, "
        f"max={d_ln[2]:.3e}"
    ),
    "",
    "BIC CLASSIFICATION:",
    (
        f"  preferred-model mismatches = "
        f"{pref_mismatch}/{len(out)}"
    ),
    (
        "  abs DeltaBIC(second-best) difference: "
        f"median={delta_stats[0]:.3e}, "
        f"p95={delta_stats[1]:.3e}, "
        f"max={delta_stats[2]:.3e}"
    ),
    "",
    "COMPONENT-SEPARATION CONVENTION:",
    (
        "  Ashman D abs difference: "
        f"median={sep_a[0]:.3e}, "
        f"p95={sep_a[1]:.3e}, "
        f"max={sep_a[2]:.3e}"
    ),
    (
        "  simple-sum abs difference: "
        f"median={sep_s[0]:.3e}, "
        f"p95={sep_s[1]:.3e}, "
        f"max={sep_s[2]:.3e}"
    ),
    "",
    "ROBUST-DOUBLE GATE:",
    (
        f"  row-level mismatches = "
        f"{robust_mismatch}/{len(out)}"
    ),
    (
        f"  reconstructed robust-both source count = "
        f"{robust_both_count}/1061"
    ),
    "",
    "DECISION RULE:",
    (
        "  Proceed to sampling-sensitivity refits only if the "
        "flux-space likelihood convention, separation convention, "
        "preferred model, and robust-double gate reproduce the "
        "frozen STAGE 03A results to numerical precision."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_TABLE)
print(OUT_SUMMARY)
print()
print("STAGE 06E1 COMPLETE")
