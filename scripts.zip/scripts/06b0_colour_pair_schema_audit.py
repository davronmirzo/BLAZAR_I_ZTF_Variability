# ============================================================
# BLAZAR_I — STAGE 06B0
# COLOUR-BREAK ROBUSTNESS INPUT SCHEMA / COVERAGE AUDIT
#
# Purpose:
#   Inspect the frozen STAGE 03C paired-colour parquet so that
#   tighter simultaneity and error-aware robustness analyses can
#   be built from the actual available columns without guessing.
#
# Read-only audit. No upstream file is changed.
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

PAIR_FILE = ROOT / "outputs" / "tables" / "stage03c_colour_pairs_master.parquet"
MASTER_FILE = ROOT / "outputs" / "tables" / "stage03c_colour_break_master.csv"
OUT_AUDIT = ROOT / "outputs" / "audit" / "stage06b0_colour_pair_schema.txt"

if not PAIR_FILE.exists():
    raise FileNotFoundError(PAIR_FILE)
if not MASTER_FILE.exists():
    raise FileNotFoundError(MASTER_FILE)

pairs = pd.read_parquet(PAIR_FILE)
master = pd.read_csv(MASTER_FILE)

lines = []
lines.append("BLAZAR_I - STAGE 06B0 COLOUR-PAIR SCHEMA AUDIT")
lines.append("=" * 72)
lines.append("")
lines.append(f"PAIR rows      : {len(pairs)}")
lines.append(f"PAIR columns   : {len(pairs.columns)}")
lines.append(f"MASTER rows    : {len(master)}")
lines.append("")
lines.append("PAIR COLUMNS:")
for c in pairs.columns:
    lines.append(f"  {c}    dtype={pairs[c].dtype}")

keywords = [
    "dt", "time", "hmjd", "mjd",
    "g_", "r_", "mag", "err",
    "color", "colour", "flux",
]
cand = [
    c for c in pairs.columns
    if any(k in c.lower() for k in keywords)
]

lines.append("")
lines.append("CANDIDATE ANALYSIS COLUMNS:")
for c in cand:
    s = pairs[c]
    lines.append(
        f"  {c}: nonnull={int(s.notna().sum())}, unique={int(s.nunique(dropna=True))}"
    )

lines.append("")
lines.append("NUMERIC SUMMARIES:")
for c in cand:
    s = pd.to_numeric(pairs[c], errors="coerce")
    if s.notna().sum() == 0:
        continue
    q = s.quantile([0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99])
    lines.append("")
    lines.append(f"[{c}]")
    lines.append(
        f"  N={int(s.notna().sum())} min={s.min():.6g} "
        f"median={s.median():.6g} max={s.max():.6g}"
    )
    lines.append(
        "  " + ", ".join(
            f"p{int(k*100):02d}={v:.6g}"
            for k, v in q.items()
        )
    )

dt_cols = [
    c for c in pairs.columns
    if ("dt" in c.lower() or "sep" in c.lower())
]

lines.append("")
lines.append("TIMING-CUT COVERAGE:")
if dt_cols:
    for c in dt_cols:
        s = pd.to_numeric(pairs[c], errors="coerce")
        if s.notna().sum() == 0:
            continue
        lines.append(f"  column={c}")
        for thr in [0.0416666667, 0.0833333333, 0.1666666667, 0.25, 1.0, 2.0, 4.0, 6.0]:
            n = int((s.abs() <= thr).sum())
            lines.append(f"    |value| <= {thr:.10g}: {n}")
else:
    lines.append("  no obvious dt/sep column found")

text = "\n".join(lines)

OUT_AUDIT.write_text(text, encoding="utf-8")

print(text)
print()
print("AUDIT SAVED:")
print(OUT_AUDIT)
print()
print("STAGE 06B0 COMPLETE")
