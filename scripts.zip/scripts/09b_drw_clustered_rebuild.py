# ============================================================
# BLAZAR_I — STAGE 09B
# Q1 DRW CONTINUOUS-TIMESCALE REBUILD:
# SOURCE-CLUSTERED + GEE + SOURCE-LEVEL CONFIRMATION
#
# Motivation:
#   Earlier Stage 06C3 treated g/r source-filter rows with HC3 errors.
#   Because g and r from the same blazar are not independent, a Q1
#   reviewer can challenge the nominal uncertainty (pseudo-replication).
#
# This stage removes that weakness in four complementary ways:
#
#   1) Row-level OLS with cluster-robust covariance, clustered by blazar_id.
#   2) GEE with exchangeable within-source correlation.
#   3) One-row-per-source BOTH-band geometric-mean tau_rest model.
#   4) Separate g-only and r-only models (no repeated rows).
#
# The same source-filter keys are used for PRIMARY plus all three Stage06C2
# perturbations whenever "COMMON_ALL4" results are reported.
#
# Confounder sequence (NO SED in global class models because Stage09A4
# demonstrated severe class x SED non-overlap):
#
#   D0 = FSRQ + filter + sampling controls
#   D1 = D0 + redshift + gamma energy flux + gamma variability
#   D2 = D1 + filter-specific optical brightness + PS1 host proxy
#
# LSP-only D2 is also reported as an overlap-restricted sensitivity.
#
# Outcome:
#   log10(tau_rest_days)
# Effect:
#   factor = 10**beta_FSRQ
#   factor < 1 => shorter FSRQ rest-frame DRW timescale
#
# Inputs:
#   outputs/tables/stage03d_drw_master.csv
#   outputs/tables/stage06c2_drw_sensitivity_master.csv
#   outputs/tables/stage09a2_q1_confounder_master_ps1.csv
#
# Outputs:
#   outputs/tables/stage09b_drw_common_analysis_master.csv
#   outputs/tables/stage09b_clustered_drw_models.csv
#   outputs/tables/stage09b_gee_drw_models.csv
#   outputs/tables/stage09b_source_level_drw_models.csv
#   outputs/tables/stage09b_single_band_drw_models.csv
#   outputs/tables/stage09b_covariance_comparison.csv
#   outputs/tables/stage09b_lsp_only_drw_models.csv
#   outputs/audit/stage09b_summary.txt
#
# No upstream file is overwritten.
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.genmod.cov_struct import Exchangeable

warnings.filterwarnings("ignore", category=RuntimeWarning)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

DRW_FILE = TABLE_DIR / "stage03d_drw_master.csv"
SENS_FILE = TABLE_DIR / "stage06c2_drw_sensitivity_master.csv"
CONF_FILE = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"

OUT_MASTER = TABLE_DIR / "stage09b_drw_common_analysis_master.csv"
OUT_CLUSTER = TABLE_DIR / "stage09b_clustered_drw_models.csv"
OUT_GEE = TABLE_DIR / "stage09b_gee_drw_models.csv"
OUT_SOURCE = TABLE_DIR / "stage09b_source_level_drw_models.csv"
OUT_BAND = TABLE_DIR / "stage09b_single_band_drw_models.csv"
OUT_COV = TABLE_DIR / "stage09b_covariance_comparison.csv"
OUT_LSP = TABLE_DIR / "stage09b_lsp_only_drw_models.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09b_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

SCHEMES = [
    "PRIMARY",
    "THIN_HALF",
    "BASELINE_CENTRAL80",
    "SEASONAL_DENSE_QUARTER_DROP",
]


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def zscore_inplace(df, cols):
    for c in cols:
        x = numeric(df[c])
        mu = x.mean()
        sd = x.std(ddof=1)

        if np.isfinite(sd) and sd > 0:
            df[c] = (x - mu) / sd
        else:
            df[c] = np.nan


def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)

    good = np.isfinite(p)

    if good.sum() == 0:
        return q

    pv = p[good]
    order = np.argsort(pv)
    ranked = pv[order]
    m = len(ranked)

    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[good] = qv

    return q


def prepare_rows(df, predictors, outcome="tau_rest_days", subset=None,
                 standardize=None):
    if subset is None:
        subset = pd.Series(True, index=df.index)

    if standardize is None:
        standardize = []

    cols = [
        "blazar_id",
        "blazar_class",
        outcome,
        *predictors,
    ]

    # preserve order while deduplicating
    cols = list(dict.fromkeys(cols))

    w = df.loc[subset, cols].copy()

    w["blazar_id"] = w["blazar_id"].astype(str)

    for c in [outcome, *predictors]:
        w[c] = numeric(w[c])

    w = (
        w.replace([np.inf, -np.inf], np.nan)
        .dropna()
    )

    w = w.loc[w[outcome] > 0].copy()

    if len(w) == 0:
        return w

    w["log10_tau"] = np.log10(w[outcome])

    zscore_inplace(w, standardize)
    w = w.dropna()

    return w


def effect_from_fit(fit, key="FSRQ"):
    ci = fit.conf_int()

    beta = float(fit.params[key])
    lo = float(ci.loc[key, 0])
    hi = float(ci.loc[key, 1])

    return {
        "beta_log10_tau_FSRQ": beta,
        "beta_ci95_low": lo,
        "beta_ci95_high": hi,
        "factor_FSRQ_vs_BLL": 10.0 ** beta,
        "factor_ci95_low": 10.0 ** lo,
        "factor_ci95_high": 10.0 ** hi,
        "p_value": float(fit.pvalues[key]),
    }


def base_counts(w):
    return {
        "N_rows": int(len(w)),
        "N_sources": int(w["blazar_id"].nunique()),
        "N_FSRQ_rows": int(
            (
                w["blazar_class"]
                .astype(str)
                .eq("FSRQ")
            ).sum()
        ),
        "N_BLL_rows": int(
            (
                w["blazar_class"]
                .astype(str)
                .eq("BLL")
            ).sum()
        ),
    }


def fit_cluster_ols(df, predictors, model_name, scheme, sample_name,
                    subset=None, standardize=None):
    w = prepare_rows(
        df,
        predictors=predictors,
        subset=subset,
        standardize=standardize,
    )

    meta = {
        "model_name": model_name,
        "scheme": scheme,
        "sample_name": sample_name,
        "covariance": "CLUSTER_BLAZAR_ID",
        **base_counts(w),
    }

    if len(w) < 50 or w["blazar_id"].nunique() < 30:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "beta_ci95_low": np.nan,
            "beta_ci95_high": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": "TOO_FEW_ROWS_OR_CLUSTERS",
        }

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            w["log10_tau"].astype(float),
            X,
        ).fit(
            cov_type="cluster",
            cov_kwds={
                "groups": w["blazar_id"].astype(str),
                "use_correction": True,
            },
        )

        eff = effect_from_fit(fit)

        return {
            **meta,
            **eff,
            "r2": float(fit.rsquared),
            "status": "OK",
        }

    except Exception as exc:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "beta_ci95_low": np.nan,
            "beta_ci95_high": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": f"FIT_FAILED:{type(exc).__name__}",
        }


def fit_hc3_ols(df, predictors, model_name, scheme, sample_name,
                subset=None, standardize=None):
    w = prepare_rows(
        df,
        predictors=predictors,
        subset=subset,
        standardize=standardize,
    )

    meta = {
        "model_name": model_name,
        "scheme": scheme,
        "sample_name": sample_name,
        "covariance": "HC3",
        **base_counts(w),
    }

    if len(w) < 50:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "beta_ci95_low": np.nan,
            "beta_ci95_high": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": "TOO_FEW_ROWS",
        }

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            w["log10_tau"].astype(float),
            X,
        ).fit(
            cov_type="HC3",
        )

        eff = effect_from_fit(fit)

        return {
            **meta,
            **eff,
            "r2": float(fit.rsquared),
            "status": "OK",
        }

    except Exception as exc:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "beta_ci95_low": np.nan,
            "beta_ci95_high": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": f"FIT_FAILED:{type(exc).__name__}",
        }


def fit_gee(df, predictors, model_name, scheme, sample_name,
            subset=None, standardize=None):
    w = prepare_rows(
        df,
        predictors=predictors,
        subset=subset,
        standardize=standardize,
    )

    meta = {
        "model_name": model_name,
        "scheme": scheme,
        "sample_name": sample_name,
        "covariance": "GEE_EXCHANGEABLE",
        **base_counts(w),
    }

    if len(w) < 50 or w["blazar_id"].nunique() < 30:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "beta_ci95_low": np.nan,
            "beta_ci95_high": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "scale": np.nan,
            "dep_params": np.nan,
            "status": "TOO_FEW_ROWS_OR_CLUSTERS",
        }

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add",
    )

    try:
        model = sm.GEE(
            w["log10_tau"].astype(float),
            X,
            groups=w["blazar_id"].astype(str),
            family=sm.families.Gaussian(),
            cov_struct=Exchangeable(),
        )

        fit = model.fit(
            maxiter=200,
        )

        eff = effect_from_fit(fit)

        dep = getattr(
            fit.cov_struct,
            "dep_params",
            np.nan,
        )

        try:
            dep = float(np.asarray(dep).ravel()[0])
        except Exception:
            dep = np.nan

        return {
            **meta,
            **eff,
            "scale": float(fit.scale),
            "dep_params": dep,
            "status": "OK",
        }

    except Exception as exc:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "beta_ci95_low": np.nan,
            "beta_ci95_high": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "scale": np.nan,
            "dep_params": np.nan,
            "status": f"FIT_FAILED:{type(exc).__name__}",
        }


def fit_source_ols(df, predictors, model_name, scheme, sample_name):
    w = df[
        [
            "blazar_id",
            "blazar_class",
            "tau_rest_geo",
            *predictors,
        ]
    ].copy()

    for c in ["tau_rest_geo", *predictors]:
        w[c] = numeric(w[c])

    w = (
        w.replace([np.inf, -np.inf], np.nan)
        .dropna()
    )

    w = w.loc[w["tau_rest_geo"] > 0].copy()

    standardize = [
        c
        for c in predictors
        if c != "FSRQ"
    ]

    zscore_inplace(w, standardize)
    w = w.dropna()

    meta = {
        "model_name": model_name,
        "scheme": scheme,
        "sample_name": sample_name,
        "covariance": "HC3_SOURCE_LEVEL",
        "N_sources": int(len(w)),
        "N_FSRQ": int(
            w["blazar_class"]
            .astype(str)
            .eq("FSRQ")
            .sum()
        ),
        "N_BLL": int(
            w["blazar_class"]
            .astype(str)
            .eq("BLL")
            .sum()
        ),
    }

    if len(w) < 50:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": "TOO_FEW_SOURCES",
        }

    y = np.log10(
        w["tau_rest_geo"].astype(float)
    )

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            y,
            X,
        ).fit(
            cov_type="HC3",
        )

        eff = effect_from_fit(fit)

        return {
            **meta,
            **eff,
            "r2": float(fit.rsquared),
            "status": "OK",
        }

    except Exception as exc:
        return {
            **meta,
            "beta_log10_tau_FSRQ": np.nan,
            "factor_FSRQ_vs_BLL": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": f"FIT_FAILED:{type(exc).__name__}",
        }


# ============================================================
# LOAD / VALIDATE INPUTS
# ============================================================

for path in [
    DRW_FILE,
    SENS_FILE,
    CONF_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

drw = pd.read_csv(
    DRW_FILE,
    low_memory=False,
)

sens = pd.read_csv(
    SENS_FILE,
    low_memory=False,
)

conf = pd.read_csv(
    CONF_FILE,
    low_memory=False,
)

for df in [drw, sens, conf]:
    if "blazar_id" not in df.columns:
        raise RuntimeError("Missing blazar_id")

    df["blazar_id"] = df["blazar_id"].astype(str)

if len(drw) != 2122:
    raise RuntimeError(
        f"Expected Stage03D N=2122 rows, got {len(drw)}"
    )

if len(conf) != 1061:
    raise RuntimeError(
        f"Expected Stage09A2 N=1061 rows, got {len(conf)}"
    )

required_drw = [
    "blazar_id",
    "blazar_class",
    "filter_name",
    "N_nightly",
    "baseline_days",
    "median_cadence_days",
    "median_magerr",
    "tau_rest_days",
    "tau_interpretable_primary",
]

required_sens = [
    "blazar_id",
    "blazar_class",
    "filter_name",
    "scheme",
    "N_modified",
    "baseline_days",
    "median_cadence_days",
    "tau_rest_days",
    "tau_interpretable_sensitivity",
    "fit_status",
]

required_conf = [
    "blazar_id",
    "blazar_class",
    "FSRQ",
    "redshift",
    "sed_class",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
    "ps1_host_proxy_hq_available",
]

for c in required_drw:
    if c not in drw.columns:
        raise RuntimeError(
            f"Stage03D missing column: {c}"
        )

for c in required_sens:
    if c not in sens.columns:
        raise RuntimeError(
            f"Stage06C2 missing column: {c}"
        )

for c in required_conf:
    if c not in conf.columns:
        raise RuntimeError(
            f"Stage09A2 missing column: {c}"
        )

drw["tau_interpretable_primary"] = as_bool(
    drw["tau_interpretable_primary"]
)

sens["tau_interpretable_sensitivity"] = as_bool(
    sens["tau_interpretable_sensitivity"]
)

conf["ps1_host_proxy_hq_available"] = as_bool(
    conf["ps1_host_proxy_hq_available"]
)

drw["filter_name"] = (
    drw["filter_name"]
    .astype(str)
    .str.lower()
)

sens["filter_name"] = (
    sens["filter_name"]
    .astype(str)
    .str.lower()
)

# ============================================================
# DEFINE COMMON SOURCE-FILTER SUPPORT ACROSS PRIMARY + ALL 3 PERTURBATIONS
# ============================================================

primary_interp = drw.loc[
    drw["tau_interpretable_primary"]
    &
    numeric(drw["tau_rest_days"]).notna()
].copy()

primary_interp["key"] = (
    primary_interp["blazar_id"]
    +
    "|"
    +
    primary_interp["filter_name"]
)

sens_ok = sens.loc[
    sens["fit_status"]
    .astype(str)
    .eq("OK")
].copy()

sens_ok["key"] = (
    sens_ok["blazar_id"]
    +
    "|"
    +
    sens_ok["filter_name"]
)

interp_wide = (
    sens_ok
    .pivot_table(
        index="key",
        columns="scheme",
        values="tau_interpretable_sensitivity",
        aggfunc="first",
    )
)

missing_scheme_cols = [
    s
    for s in SCHEMES[1:]
    if s not in interp_wide.columns
]

if missing_scheme_cols:
    raise RuntimeError(
        "Stage06C2 missing expected schemes: "
        + repr(missing_scheme_cols)
    )

common_sens_keys = set(
    interp_wide.index[
        interp_wide[
            SCHEMES[1:]
        ].fillna(False).all(axis=1)
    ].tolist()
)

primary_keys = set(
    primary_interp["key"].tolist()
)

common_all4_keys = (
    common_sens_keys
    &
    primary_keys
)

print("=" * 80)
print("BLAZAR_I — STAGE 09B DRW CLUSTERED REBUILD")
print("=" * 80)
print("Primary interpretable source-filter keys =", len(primary_keys))
print("Interpretable in all 3 perturbations     =", len(common_sens_keys))
print("Common PRIMARY + all 3 perturbations     =", len(common_all4_keys))


# ============================================================
# BUILD UNIFIED ROW-LEVEL DATASET
# ============================================================

# Frozen original median_magerr is retained as the pre-diagnostic
# photometric-error control for all perturbations, matching Stage06C3 logic.
frozen_controls = drw[
    [
        "blazar_id",
        "filter_name",
        "median_magerr",
    ]
].copy()

frozen_controls = frozen_controls.rename(
    columns={
        "median_magerr": "median_magerr_frozen",
    }
)

# PRIMARY rows
p = drw.loc[
    drw["tau_interpretable_primary"]
].copy()

p["key"] = (
    p["blazar_id"]
    +
    "|"
    +
    p["filter_name"]
)

p = p.loc[
    p["key"].isin(common_all4_keys)
].copy()

p["scheme"] = "PRIMARY"
p["N_used"] = numeric(p["N_nightly"])
p["baseline_used"] = numeric(p["baseline_days"])
p["cadence_used"] = numeric(p["median_cadence_days"])
p["tau_rest_used"] = numeric(p["tau_rest_days"])
p["median_magerr_frozen"] = numeric(p["median_magerr"])

p_keep = p[
    [
        "blazar_id",
        "blazar_class",
        "filter_name",
        "scheme",
        "N_used",
        "baseline_used",
        "cadence_used",
        "median_magerr_frozen",
        "tau_rest_used",
    ]
].copy()

# Sensitivity rows
s = sens_ok.loc[
    sens_ok["scheme"].isin(SCHEMES[1:])
].copy()

s["key"] = (
    s["blazar_id"]
    +
    "|"
    +
    s["filter_name"]
)

s = s.loc[
    s["key"].isin(common_all4_keys)
].copy()

s = s.merge(
    frozen_controls,
    on=[
        "blazar_id",
        "filter_name",
    ],
    how="left",
    validate="many_to_one",
)

s["N_used"] = numeric(s["N_modified"])
s["baseline_used"] = numeric(s["baseline_days"])
s["cadence_used"] = numeric(s["median_cadence_days"])
s["tau_rest_used"] = numeric(s["tau_rest_days"])

s_keep = s[
    [
        "blazar_id",
        "blazar_class",
        "filter_name",
        "scheme",
        "N_used",
        "baseline_used",
        "cadence_used",
        "median_magerr_frozen",
        "tau_rest_used",
    ]
].copy()

all_rows = pd.concat(
    [
        p_keep,
        s_keep,
    ],
    ignore_index=True,
)

# Merge source-level astrophysical confounders.
conf_keep = conf[
    [
        "blazar_id",
        "FSRQ",
        "redshift",
        "sed_class",
        "log10_gamma_energy_flux",
        "log1p_gamma_variability_index",
        "median_mag_g",
        "median_mag_r",
        "ps1_host_proxy_ri",
        "ps1_host_proxy_hq_available",
    ]
].copy()

all_rows = all_rows.merge(
    conf_keep,
    on="blazar_id",
    how="left",
    validate="many_to_one",
)

all_rows["filter_r"] = (
    all_rows["filter_name"]
    .astype(str)
    .eq("r")
    .astype(int)
)

all_rows["optical_mag_filter"] = np.where(
    all_rows["filter_name"]
    .astype(str)
    .eq("g"),
    numeric(all_rows["median_mag_g"]),
    numeric(all_rows["median_mag_r"]),
)

all_rows["log1p_N_used"] = np.log1p(
    numeric(all_rows["N_used"])
)

all_rows["log10_baseline_used"] = np.where(
    numeric(all_rows["baseline_used"]) > 0,
    np.log10(
        numeric(all_rows["baseline_used"])
    ),
    np.nan,
)

all_rows["log10_cadence_used"] = np.where(
    numeric(all_rows["cadence_used"]) > 0,
    np.log10(
        numeric(all_rows["cadence_used"])
    ),
    np.nan,
)

all_rows = all_rows.rename(
    columns={
        "tau_rest_used": "tau_rest_days",
    }
)

# One exact row per key x scheme.
if all_rows.duplicated(
    subset=[
        "blazar_id",
        "filter_name",
        "scheme",
    ]
).any():
    raise RuntimeError(
        "Duplicate blazar/filter/scheme rows in Stage09B master."
    )

expected_rows = (
    len(common_all4_keys)
    *
    len(SCHEMES)
)

if len(all_rows) != expected_rows:
    raise RuntimeError(
        f"Expected {expected_rows} common rows, got {len(all_rows)}"
    )

all_rows.to_csv(
    OUT_MASTER,
    index=False,
)


# ============================================================
# MODEL DEFINITIONS
# ============================================================

D0 = [
    "FSRQ",
    "filter_r",
    "log1p_N_used",
    "log10_baseline_used",
    "log10_cadence_used",
    "median_magerr_frozen",
]

D1 = [
    *D0,
    "redshift",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
]

D2 = [
    *D1,
    "optical_mag_filter",
    "ps1_host_proxy_ri",
]

STD_D0 = [
    "log1p_N_used",
    "log10_baseline_used",
    "log10_cadence_used",
    "median_magerr_frozen",
]

STD_D1 = [
    *STD_D0,
    "redshift",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
]

STD_D2 = [
    *STD_D1,
    "optical_mag_filter",
    "ps1_host_proxy_ri",
]


# ============================================================
# CLUSTER-ROBUST + GEE MODELS, SAME D2 COMPLETE-CASE ROWS
# ============================================================

cluster_rows = []
gee_rows = []
cov_rows = []

for scheme in SCHEMES:
    ds = all_rows.loc[
        all_rows["scheme"].eq(scheme)
    ].copy()

    # Keep exact D2 complete-case support for D0-D2 trajectory.
    common_d2 = (
        ds["ps1_host_proxy_hq_available"]
        &
        ds[
            [
                "tau_rest_days",
                *[
                    c
                    for c in D2
                    if c not in {"FSRQ", "filter_r"}
                ],
            ]
        ]
        .replace([np.inf, -np.inf], np.nan)
        .notna()
        .all(axis=1)
    )

    for tag, predictors, std in [
        ("D0", D0, STD_D0),
        ("D1", D1, STD_D1),
        ("D2", D2, STD_D2),
    ]:
        cluster_rows.append(
            fit_cluster_ols(
                ds,
                predictors=predictors,
                model_name=f"{scheme}_{tag}_CLUSTER",
                scheme=scheme,
                sample_name="common_all4_same_D2_complete_case",
                subset=common_d2,
                standardize=std,
            )
        )

        gee_rows.append(
            fit_gee(
                ds,
                predictors=predictors,
                model_name=f"{scheme}_{tag}_GEE",
                scheme=scheme,
                sample_name="common_all4_same_D2_complete_case",
                subset=common_d2,
                standardize=std,
            )
        )

    # Direct HC3 vs clustered covariance comparison for the final D2 model.
    hc3 = fit_hc3_ols(
        ds,
        predictors=D2,
        model_name=f"{scheme}_D2_HC3",
        scheme=scheme,
        sample_name="common_all4_same_D2_complete_case",
        subset=common_d2,
        standardize=STD_D2,
    )

    clu = fit_cluster_ols(
        ds,
        predictors=D2,
        model_name=f"{scheme}_D2_CLUSTER_COMPARE",
        scheme=scheme,
        sample_name="common_all4_same_D2_complete_case",
        subset=common_d2,
        standardize=STD_D2,
    )

    cov_rows.extend(
        [
            hc3,
            clu,
        ]
    )

cluster = pd.DataFrame(cluster_rows)
gee = pd.DataFrame(gee_rows)
cov_compare = pd.DataFrame(cov_rows)

cluster["q_BH_within_depth"] = np.nan
gee["q_BH_within_depth"] = np.nan

for tag in ["D0", "D1", "D2"]:
    mask = cluster["model_name"].str.contains(
        f"_{tag}_CLUSTER$",
        regex=True,
    )

    cluster.loc[
        mask,
        "q_BH_within_depth"
    ] = bh_qvalues(
        cluster.loc[
            mask,
            "p_value",
        ].to_numpy(dtype=float)
    )

    mask2 = gee["model_name"].str.contains(
        f"_{tag}_GEE$",
        regex=True,
    )

    gee.loc[
        mask2,
        "q_BH_within_depth"
    ] = bh_qvalues(
        gee.loc[
            mask2,
            "p_value",
        ].to_numpy(dtype=float)
    )

cluster.to_csv(OUT_CLUSTER, index=False)
gee.to_csv(OUT_GEE, index=False)
cov_compare.to_csv(OUT_COV, index=False)


# ============================================================
# SOURCE-LEVEL BOTH-BAND GEOMETRIC-MEAN ANALYSIS
# ============================================================

source_rows = []
source_master_tables = {}

for scheme in SCHEMES:
    ds = all_rows.loc[
        all_rows["scheme"].eq(scheme)
    ].copy()

    # D2 complete rows first.
    good = (
        ds["ps1_host_proxy_hq_available"]
        &
        ds[
            [
                "tau_rest_days",
                *[
                    c
                    for c in D2
                    if c not in {"FSRQ", "filter_r"}
                ],
            ]
        ]
        .replace([np.inf, -np.inf], np.nan)
        .notna()
        .all(axis=1)
    )

    ds = ds.loc[good].copy()

    counts = (
        ds.groupby("blazar_id")
        ["filter_name"]
        .nunique()
    )

    both_ids = set(
        counts.index[
            counts >= 2
        ].tolist()
    )

    ds = ds.loc[
        ds["blazar_id"].isin(both_ids)
    ].copy()

    src = (
        ds.groupby(
            [
                "blazar_id",
                "blazar_class",
            ],
            as_index=False,
        )
        .agg(
            FSRQ=("FSRQ", "first"),
            tau_rest_geo=(
                "tau_rest_days",
                lambda x: float(
                    np.exp(
                        np.mean(
                            np.log(
                                np.asarray(
                                    x,
                                    dtype=float,
                                )
                            )
                        )
                    )
                ),
            ),
            log1p_N_mean=("log1p_N_used", "mean"),
            log10_baseline_mean=("log10_baseline_used", "mean"),
            log10_cadence_mean=("log10_cadence_used", "mean"),
            median_magerr_mean=("median_magerr_frozen", "mean"),
            redshift=("redshift", "first"),
            log10_gamma_energy_flux=("log10_gamma_energy_flux", "first"),
            log1p_gamma_variability_index=("log1p_gamma_variability_index", "first"),
            optical_mag_mean=("optical_mag_filter", "mean"),
            ps1_host_proxy_ri=("ps1_host_proxy_ri", "first"),
            sed_class=("sed_class", "first"),
        )
    )

    source_master_tables[scheme] = src

    S0 = [
        "FSRQ",
        "log1p_N_mean",
        "log10_baseline_mean",
        "log10_cadence_mean",
        "median_magerr_mean",
    ]

    S1 = [
        *S0,
        "redshift",
        "log10_gamma_energy_flux",
        "log1p_gamma_variability_index",
    ]

    S2 = [
        *S1,
        "optical_mag_mean",
        "ps1_host_proxy_ri",
    ]

    for tag, predictors in [
        ("S0", S0),
        ("S1", S1),
        ("S2", S2),
    ]:
        source_rows.append(
            fit_source_ols(
                src,
                predictors=predictors,
                model_name=f"{scheme}_{tag}_SOURCE",
                scheme=scheme,
                sample_name="both_band_geometric_mean_common_all4",
            )
        )

source_models = pd.DataFrame(source_rows)

source_models["q_BH_within_depth"] = np.nan

for tag in ["S0", "S1", "S2"]:
    mask = source_models["model_name"].str.contains(
        f"_{tag}_SOURCE$",
        regex=True,
    )

    source_models.loc[
        mask,
        "q_BH_within_depth"
    ] = bh_qvalues(
        source_models.loc[
            mask,
            "p_value",
        ].to_numpy(dtype=float)
    )

source_models.to_csv(
    OUT_SOURCE,
    index=False,
)


# ============================================================
# SINGLE-BAND D2 MODELS — NO REPEATED MEASURES
# ============================================================

band_rows = []

for scheme in SCHEMES:
    ds = all_rows.loc[
        all_rows["scheme"].eq(scheme)
    ].copy()

    for filt in ["g", "r"]:
        x = ds.loc[
            ds["filter_name"].eq(filt)
        ].copy()

        common_d2 = (
            x["ps1_host_proxy_hq_available"]
            &
            x[
                [
                    "tau_rest_days",
                    *[
                        c
                        for c in D2
                        if c not in {"FSRQ", "filter_r"}
                    ],
                ]
            ]
            .replace([np.inf, -np.inf], np.nan)
            .notna()
            .all(axis=1)
        )

        # filter_r is constant and therefore removed.
        B2 = [
            c
            for c in D2
            if c != "filter_r"
        ]

        STD_B2 = [
            c
            for c in STD_D2
        ]

        row = fit_hc3_ols(
            x,
            predictors=B2,
            model_name=f"{scheme}_{filt}_D2_SINGLE_BAND",
            scheme=scheme,
            sample_name=f"single_band_{filt}_common_all4_D2",
            subset=common_d2,
            standardize=STD_B2,
        )

        band_rows.append(row)

band_models = pd.DataFrame(band_rows)
band_models["q_BH_all"] = bh_qvalues(
    band_models["p_value"].to_numpy(dtype=float)
)
band_models.to_csv(
    OUT_BAND,
    index=False,
)


# ============================================================
# LSP-ONLY D2 CLUSTERED MODELS
# ============================================================

lsp_rows = []

for scheme in SCHEMES:
    ds = all_rows.loc[
        all_rows["scheme"].eq(scheme)
    ].copy()

    common_d2 = (
        ds["ps1_host_proxy_hq_available"]
        &
        ds["sed_class"].astype(str).eq("LSP")
        &
        ds[
            [
                "tau_rest_days",
                *[
                    c
                    for c in D2
                    if c not in {"FSRQ", "filter_r"}
                ],
            ]
        ]
        .replace([np.inf, -np.inf], np.nan)
        .notna()
        .all(axis=1)
    )

    lsp_rows.append(
        fit_cluster_ols(
            ds,
            predictors=D2,
            model_name=f"{scheme}_D2_LSP_CLUSTER",
            scheme=scheme,
            sample_name="LSP_only_common_all4_D2",
            subset=common_d2,
            standardize=STD_D2,
        )
    )

lsp_models = pd.DataFrame(lsp_rows)
lsp_models["q_BH_all"] = bh_qvalues(
    lsp_models["p_value"].to_numpy(dtype=float)
)
lsp_models.to_csv(
    OUT_LSP,
    index=False,
)


# ============================================================
# WITHIN-SOURCE g/r CORRELATION AUDIT
# ============================================================

pair_corr_rows = []

for scheme in SCHEMES:
    ds = all_rows.loc[
        all_rows["scheme"].eq(scheme)
    ].copy()

    # Known-z valid tau rows only.
    ds = ds.loc[
        numeric(ds["tau_rest_days"]).notna()
        &
        (numeric(ds["tau_rest_days"]) > 0)
    ].copy()

    wide = ds.pivot(
        index="blazar_id",
        columns="filter_name",
        values="tau_rest_days",
    )

    if (
        "g" in wide.columns
        and
        "r" in wide.columns
    ):
        w = wide[
            ["g", "r"]
        ].dropna()

        if len(w) >= 10:
            corr = float(
                np.corrcoef(
                    np.log10(
                        w["g"].to_numpy(dtype=float)
                    ),
                    np.log10(
                        w["r"].to_numpy(dtype=float)
                    ),
                )[0, 1]
            )
        else:
            corr = np.nan

        pair_corr_rows.append({
            "scheme": scheme,
            "N_both_band_sources": len(w),
            "pearson_r_logtau_g_r": corr,
        })

pair_corr = pd.DataFrame(
    pair_corr_rows
)

# ============================================================
# SUMMARY
# ============================================================

def get_model(frame, name):
    hit = frame.loc[
        frame["model_name"].eq(name)
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


def fmt_factor(r):
    if r is None:
        return "NA"

    if (
        r["status"] != "OK"
        or
        not np.isfinite(
            r["factor_FSRQ_vs_BLL"]
        )
    ):
        return str(r["status"])

    return (
        f"factor={r['factor_FSRQ_vs_BLL']:.3f} "
        f"[{r['factor_ci95_low']:.3f},"
        f"{r['factor_ci95_high']:.3f}], "
        f"p={r['p_value']:.3g}, "
        f"rows={int(r.get('N_rows', np.nan)) if pd.notna(r.get('N_rows', np.nan)) else 'NA'}, "
        f"sources={int(r.get('N_sources', np.nan)) if pd.notna(r.get('N_sources', np.nan)) else 'NA'}"
    )


def fmt_source_factor(r):
    if r is None:
        return "NA"

    if (
        r["status"] != "OK"
        or
        not np.isfinite(
            r["factor_FSRQ_vs_BLL"]
        )
    ):
        return str(r["status"])

    return (
        f"factor={r['factor_FSRQ_vs_BLL']:.3f} "
        f"[{r['factor_ci95_low']:.3f},"
        f"{r['factor_ci95_high']:.3f}], "
        f"p={r['p_value']:.3g}, "
        f"Nsrc={int(r['N_sources'])}"
    )


lines = [
    "BLAZAR_I - STAGE 09B FINAL SUMMARY",
    "=" * 80,
    "",
    "DRW continuous rest-frame timescale rebuild",
    "",
    f"Common source-filter keys PRIMARY + all 3 perturbations: {len(common_all4_keys)}",
    f"Unified analysis rows (4 schemes): {len(all_rows)}",
    "",
    "Within-source g/r log-tau correlation:",
]

for _, r in pair_corr.iterrows():
    lines.append(
        f"  {r['scheme']:30s}: "
        f"r={r['pearson_r_logtau_g_r']:.3f}, "
        f"N_both={int(r['N_both_band_sources'])}"
    )

lines += [
    "",
    "CLUSTER-ROBUST ROW-LEVEL MODELS:",
]

for scheme in SCHEMES:
    lines.append(f"  {scheme}:")

    for tag in ["D0", "D1", "D2"]:
        lines.append(
            f"    {tag}: "
            + fmt_factor(
                get_model(
                    cluster,
                    f"{scheme}_{tag}_CLUSTER",
                )
            )
        )

lines += [
    "",
    "GEE EXCHANGEABLE CONFIRMATION (D2):",
]

for scheme in SCHEMES:
    lines.append(
        f"  {scheme:30s}: "
        + fmt_factor(
            get_model(
                gee,
                f"{scheme}_D2_GEE",
            )
        )
    )

lines += [
    "",
    "ONE-ROW-PER-SOURCE BOTH-BAND GEOMETRIC-MEAN TAU (S2):",
]

for scheme in SCHEMES:
    lines.append(
        f"  {scheme:30s}: "
        + fmt_source_factor(
            get_model(
                source_models,
                f"{scheme}_S2_SOURCE",
            )
        )
    )

lines += [
    "",
    "SINGLE-BAND D2 MODELS:",
]

for scheme in SCHEMES:
    for filt in ["g", "r"]:
        lines.append(
            f"  {scheme:30s} {filt}: "
            + fmt_factor(
                get_model(
                    band_models,
                    f"{scheme}_{filt}_D2_SINGLE_BAND",
                )
            )
        )

lines += [
    "",
    "LSP-ONLY D2 CLUSTERED MODELS:",
]

for scheme in SCHEMES:
    lines.append(
        f"  {scheme:30s}: "
        + fmt_factor(
            get_model(
                lsp_models,
                f"{scheme}_D2_LSP_CLUSTER",
            )
        )
    )

lines += [
    "",
    "COVARIANCE CHECK:",
    "  stage09b_covariance_comparison.csv contains HC3 and source-clustered",
    "  uncertainty estimates on the exact same D2 rows for each scheme.",
    "",
    "INTERPRETATION LOCKS:",
    "  - Cluster-robust/GEE/source-level/single-band agreement is the",
    "    criterion for a Q1-strength DRW class result.",
    "  - The coefficient is associative, not causal.",
    "  - Global models intentionally exclude SED because Stage09A4 showed",
    "    severe optical-class x SED support violation.",
    "  - LSP-only models provide the common-SED sensitivity comparison.",
    "  - Filter-specific optical magnitude is used instead of simultaneous",
    "    g and r brightness predictors, avoiding the Stage09A4 VIF~43 issue.",
    "",
    "Files saved:",
    f"  {OUT_MASTER}",
    f"  {OUT_CLUSTER}",
    f"  {OUT_GEE}",
    f"  {OUT_SOURCE}",
    f"  {OUT_BAND}",
    f"  {OUT_COV}",
    f"  {OUT_LSP}",
    "",
    "Next:",
    "  If the DRW direction survives these independent inferential forms,",
    "  proceed to STAGE 09C injection-recovery calibration.",
    "",
    "STAGE 09B COMPLETE",
]

summary = "\n".join(lines)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
