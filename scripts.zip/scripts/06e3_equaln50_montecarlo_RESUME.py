# ============================================================
# BLAZAR_I — STAGE 06E3
# REPEATED EQUAL-N50 MONTE-CARLO FLUX-PDF SENSITIVITY
#
# Motivation:
#   STAGE 06E2 showed that robust-double prevalence is strongly
#   sample-size dependent. A single deterministic EQUAL_N50 draw
#   retained the FSRQ/BLL class contrast but yielded only 45 robust-
#   both sources and low individual-source overlap with the frozen
#   classification.
#
# Goal:
#   Separate a population-level class contrast from the instability
#   of individual robust-double labels by repeating equal-N sampling.
#
# Design:
#   - exactly 50 nightly points per source/filter
#   - all 1061 GOLD+SILVER sources are included
#   - 30 deterministic Monte-Carlo replicates
#   - source/filter-specific seed for each replicate
#   - frozen STAGE 03A fitting recipe
#   - source-level robust BOTH requires robust-double in both g and r
#
# Outputs:
#   1) replicate-level robust-both prevalence and raw FSRQ/BLL OR
#   2) source-level recovery frequency across 30 replicates
#   3) class-level recovery summaries
#   4) final audit summary
#
# Resumable:
#   each completed replicate is saved separately and reused.
# ============================================================

from pathlib import Path
import hashlib
import math
import warnings

import numpy as np
import pandas as pd
from scipy.special import logsumexp
from scipy.stats import fisher_exact
from sklearn.mixture import GaussianMixture
from sklearn.exceptions import ConvergenceWarning

warnings.filterwarnings(
    "ignore",
    category=ConvergenceWarning,
)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
MODEL_DIR = ROOT / "outputs" / "models" / "stage06e3_equaln50_replicates"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

MASTER_FILE = TABLE_DIR / "stage03a_fluxpdf_master.csv"

OUT_REPS = TABLE_DIR / "stage06e3_equaln50_replicate_summary.csv"
OUT_SOURCE = TABLE_DIR / "stage06e3_equaln50_source_recovery.csv"
OUT_CLASS = TABLE_DIR / "stage06e3_equaln50_class_recovery.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06e3_summary.txt"

MODEL_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

SCHEMA_VERSION = "06E3_v1"

N_REPLICATES = 30
N_EQUAL = 50

RANDOM_STATE_GMM = 20260917
N_INIT = 10
MAX_ITER = 500
REG_COVAR = 1e-4


def stable_seed(*parts):
    key = "||".join(
        str(x)
        for x in parts
    ).encode(
        "utf-8"
    )

    h = hashlib.sha256(
        key
    ).digest()

    return int.from_bytes(
        h[:8],
        byteorder="little",
        signed=False,
    ) % (2**32 - 1)


def normal_logpdf(x, mu, sigma):
    return (
        -0.5 * np.log(2.0 * np.pi)
        - np.log(sigma)
        - 0.5 * ((x - mu) / sigma) ** 2
    )


def choose_model(bic_g, bic_l, bic_d):
    vals = {
        "GAUSSIAN": float(bic_g),
        "LOGNORMAL": float(bic_l),
        "DOUBLE_LOGNORMAL": float(bic_d),
    }

    ordered = sorted(
        vals.items(),
        key=lambda kv: kv[1],
    )

    return (
        ordered[0][0],
        float(
            ordered[1][1]
            -
            ordered[0][1]
        ),
    )


def fit_pdf(flux):
    f = np.asarray(
        flux,
        dtype=float
    )

    f = f[
        np.isfinite(f)
        &
        (f > 0)
    ]

    n = len(f)

    if n != N_EQUAL:
        raise RuntimeError(
            f"Expected N={N_EQUAL}; got {n}"
        )

    lnf = np.log(f)

    # Gaussian in flux.
    g_mu = float(
        np.mean(f)
    )

    g_sig = float(
        np.std(
            f,
            ddof=0
        )
    )

    if not (
        np.isfinite(g_sig)
        and
        g_sig > 0
    ):
        raise RuntimeError(
            "Invalid Gaussian sigma."
        )

    ll_g = float(
        normal_logpdf(
            f,
            g_mu,
            g_sig
        ).sum()
    )

    bic_g = (
        2.0 * math.log(n)
        -
        2.0 * ll_g
    )

    # Single lognormal in flux space.
    l_mu = float(
        np.mean(lnf)
    )

    l_sig = float(
        np.std(
            lnf,
            ddof=0
        )
    )

    if not (
        np.isfinite(l_sig)
        and
        l_sig > 0
    ):
        raise RuntimeError(
            "Invalid lognormal sigma."
        )

    ll_l = float(
        (
            normal_logpdf(
                lnf,
                l_mu,
                l_sig
            )
            -
            lnf
        ).sum()
    )

    bic_l = (
        2.0 * math.log(n)
        -
        2.0 * ll_l
    )

    # Double-lognormal mixture in ln F.
    gm = GaussianMixture(
        n_components=2,
        covariance_type="full",
        n_init=N_INIT,
        max_iter=MAX_ITER,
        reg_covar=REG_COVAR,
        random_state=RANDOM_STATE_GMM,
    )

    gm.fit(
        lnf.reshape(
            -1,
            1
        )
    )

    means = gm.means_[
        :,
        0
    ].astype(float)

    order = np.argsort(
        means
    )

    means = means[
        order
    ]

    weights = gm.weights_[
        order
    ].astype(float)

    sigmas = np.sqrt(
        gm.covariances_[
            order,
            0,
            0
        ].astype(float)
    )

    comp = np.vstack(
        [
            math.log(weights[0])
            +
            normal_logpdf(
                lnf,
                means[0],
                sigmas[0]
            ),
            math.log(weights[1])
            +
            normal_logpdf(
                lnf,
                means[1],
                sigmas[1]
            ),
        ]
    )

    ll_d = float(
        (
            logsumexp(
                comp,
                axis=0
            )
            -
            lnf
        ).sum()
    )

    bic_d = (
        5.0 * math.log(n)
        -
        2.0 * ll_d
    )

    sep = (
        math.sqrt(2.0)
        *
        abs(
            means[1]
            -
            means[0]
        )
        /
        math.sqrt(
            sigmas[0] ** 2
            +
            sigmas[1] ** 2
        )
    )

    smaller_weight = float(
        min(
            weights[0],
            weights[1]
        )
    )

    preferred, delta = choose_model(
        bic_g,
        bic_l,
        bic_d,
    )

    robust = bool(
        preferred
        ==
        "DOUBLE_LOGNORMAL"
        and
        delta >= 10.0
        and
        smaller_weight >= 0.10
        and
        sep >= 2.0
    )

    return {
        "preferred": preferred,
        "delta_second": float(delta),
        "smaller_weight": smaller_weight,
        "separation": float(sep),
        "robust_double": robust,
        "gmm_converged": bool(
            gm.converged_
        ),
    }


def frozen_robust(rr):
    smaller = min(
        float(
            rr["dlnorm_weight_low"]
        ),
        float(
            rr["dlnorm_weight_high"]
        ),
    )

    return bool(
        str(
            rr["preferred_bic_model"]
        )
        ==
        "DOUBLE_LOGNORMAL"
        and
        float(
            rr["delta_bic_second_minus_best"]
        )
        >=
        10.0
        and
        smaller >= 0.10
        and
        float(
            rr["dlnorm_component_separation"]
        )
        >=
        2.0
    )


def fisher_class_or(source_df):
    fs = source_df.loc[
        source_df[
            "blazar_class"
        ].eq("FSRQ"),
        "robust_both",
    ].astype(bool)

    bl = source_df.loc[
        source_df[
            "blazar_class"
        ].eq("BLL"),
        "robust_both",
    ].astype(bool)

    a = int(
        fs.sum()
    )
    b = int(
        len(fs) - a
    )
    c = int(
        bl.sum()
    )
    d = int(
        len(bl) - c
    )

    OR, p = fisher_exact(
        [
            [a, b],
            [c, d],
        ],
        alternative="two-sided",
    )

    return (
        a,
        len(fs),
        c,
        len(bl),
        float(OR),
        float(p),
    )


def quantiles(x):
    x = np.asarray(
        x,
        dtype=float
    )

    return {
        "median": float(
            np.median(x)
        ),
        "p05": float(
            np.quantile(
                x,
                0.05
            )
        ),
        "p95": float(
            np.quantile(
                x,
                0.95
            )
        ),
        "min": float(
            np.min(x)
        ),
        "max": float(
            np.max(x)
        ),
    }


# ============================================================
# LOAD FROZEN MASTER + NIGHTLY CACHE
# ============================================================

if not MASTER_FILE.exists():
    raise FileNotFoundError(
        MASTER_FILE
    )

master = pd.read_csv(
    MASTER_FILE
)

if len(master) != 2122:
    raise RuntimeError(
        f"Expected 2122 rows; got {len(master)}"
    )

master[
    "blazar_id"
] = master[
    "blazar_id"
].astype(str)

master[
    "frozen_robust_double"
] = master.apply(
    frozen_robust,
    axis=1,
)

source_info = (
    master[
        [
            "blazar_id",
            "blazar_class",
        ]
    ]
    .drop_duplicates()
    .sort_values(
        "blazar_id"
    )
    .reset_index(
        drop=True
    )
)

source_ids = source_info[
    "blazar_id"
].tolist()

class_map = dict(
    zip(
        source_info[
            "blazar_id"
        ],
        source_info[
            "blazar_class"
        ],
    )
)

frozen_wide = master.pivot(
    index="blazar_id",
    columns="filter_name",
    values="frozen_robust_double",
)

frozen_both = (
    frozen_wide["g"].astype(bool)
    &
    frozen_wide["r"].astype(bool)
).to_dict()

print("=" * 78)
print("BLAZAR_I — STAGE 06E3")
print("REPEATED EQUAL-N50 MONTE-CARLO FLUX-PDF SENSITIVITY")
print("=" * 78)
print(f"Replicates = {N_REPLICATES}")
print(f"Equal N per source/filter = {N_EQUAL}")
print()

# Cache nightly arrays once to avoid repeated parquet I/O.
nightly_cache = {}

for i, bid in enumerate(
    source_ids,
    start=1,
):
    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    x = pd.read_parquet(
        path,
        columns=[
            "filter_name",
            "hmjd",
            "flux_jy",
        ]
    )

    per_filter = {}

    for filt in [
        "g",
        "r",
    ]:
        y = x.loc[
            x[
                "filter_name"
            ].astype(str).eq(filt)
        ].copy()

        y[
            "hmjd"
        ] = pd.to_numeric(
            y[
                "hmjd"
            ],
            errors="coerce"
        )

        y[
            "flux_jy"
        ] = pd.to_numeric(
            y[
                "flux_jy"
            ],
            errors="coerce"
        )

        y = y.loc[
            np.isfinite(
                y[
                    "hmjd"
                ]
            )
            &
            np.isfinite(
                y[
                    "flux_jy"
                ]
            )
            &
            (
                y[
                    "flux_jy"
                ]
                >
                0
            )
        ].sort_values(
            "hmjd"
        )

        flux = y[
            "flux_jy"
        ].to_numpy(
            dtype=float
        )

        if len(flux) < N_EQUAL:
            raise RuntimeError(
                f"{bid} {filt}: N={len(flux)} < {N_EQUAL}"
            )

        per_filter[
            filt
        ] = flux

    nightly_cache[
        bid
    ] = per_filter

    if (
        i % 200 == 0
        or
        i == len(source_ids)
    ):
        print(
            f"Cached nightly data {i}/{len(source_ids)}"
        )


# ============================================================
# REPLICATES
# ============================================================

rep_summary_rows = []

for rep in range(
    1,
    N_REPLICATES + 1
):
    rep_file = (
        MODEL_DIR
        /
        f"replicate_{rep:03d}.csv"
    )

    valid_cache = False

    if rep_file.exists():
        try:
            rep_df = pd.read_csv(
                rep_file
            )

            valid_cache = bool(
                len(rep_df) == 1061
                and
                "schema_version" in rep_df.columns
                and
                rep_df[
                    "schema_version"
                ].astype(str).eq(
                    SCHEMA_VERSION
                ).all()
                and
                rep_df[
                    "replicate"
                ].eq(rep).all()
            )
        except Exception:
            valid_cache = False

    if not valid_cache:
        rows = []

        for j, bid in enumerate(
            source_ids,
            start=1,
        ):
            robust_filter = {}
            converged_filter = {}

            for filt in [
                "g",
                "r",
            ]:
                flux = nightly_cache[
                    bid
                ][
                    filt
                ]

                rng = np.random.default_rng(
                    stable_seed(
                        SCHEMA_VERSION,
                        rep,
                        bid,
                        filt,
                    )
                )

                idx = np.sort(
                    rng.choice(
                        len(flux),
                        size=N_EQUAL,
                        replace=False,
                    )
                )

                fit = fit_pdf(
                    flux[
                        idx
                    ]
                )

                robust_filter[
                    filt
                ] = bool(
                    fit[
                        "robust_double"
                    ]
                )

                converged_filter[
                    filt
                ] = bool(
                    fit[
                        "gmm_converged"
                    ]
                )

            rows.append({
                "schema_version": SCHEMA_VERSION,
                "replicate": rep,
                "blazar_id": bid,
                "blazar_class": class_map[
                    bid
                ],
                "frozen_robust_both": bool(
                    frozen_both[
                        bid
                    ]
                ),
                "robust_g": robust_filter[
                    "g"
                ],
                "robust_r": robust_filter[
                    "r"
                ],
                "robust_both": bool(
                    robust_filter[
                        "g"
                    ]
                    and
                    robust_filter[
                        "r"
                    ]
                ),
                "converged_g": converged_filter[
                    "g"
                ],
                "converged_r": converged_filter[
                    "r"
                ],
            })

        rep_df = pd.DataFrame(
            rows
        )

        tmp = rep_file.with_suffix(
            ".tmp"
        )

        rep_df.to_csv(
            tmp,
            index=False
        )

        tmp.replace(
            rep_file
        )

    # Normalize booleans after cache load.
    for c in [
        "frozen_robust_both",
        "robust_g",
        "robust_r",
        "robust_both",
        "converged_g",
        "converged_r",
    ]:
        rep_df[c] = (
            rep_df[c]
            .astype(str)
            .str.strip()
            .str.lower()
            .isin(
                [
                    "true",
                    "1",
                    "yes",
                    "y",
                ]
            )
        )

    if not (
        rep_df[
            "converged_g"
        ].all()
        and
        rep_df[
            "converged_r"
        ].all()
    ):
        raise RuntimeError(
            f"Replicate {rep}: non-converged GMM fit detected."
        )

    a, nf, c, nb, OR, p = fisher_class_or(
        rep_df
    )

    frozen = rep_df[
        "frozen_robust_both"
    ].astype(bool).to_numpy()

    new = rep_df[
        "robust_both"
    ].astype(bool).to_numpy()

    both = int(
        np.logical_and(
            frozen,
            new
        ).sum()
    )

    frozen_pos = int(
        frozen.sum()
    )

    new_pos = int(
        new.sum()
    )

    union = int(
        np.logical_or(
            frozen,
            new
        ).sum()
    )

    rep_summary_rows.append({
        "replicate": rep,
        "N_sources": len(
            rep_df
        ),
        "robust_both_total": new_pos,
        "robust_both_fraction": (
            new_pos
            /
            len(rep_df)
        ),
        "frozen_positive_recovered": both,
        "frozen_positive_retention": (
            both
            /
            frozen_pos
        ),
        "jaccard_vs_frozen": (
            both
            /
            union
            if union > 0
            else np.nan
        ),
        "FSRQ_positive": a,
        "FSRQ_total": nf,
        "BLL_positive": c,
        "BLL_total": nb,
        "raw_OR_FSRQ_vs_BLL": OR,
        "fisher_p": p,
    })

    print(
        f"Replicate {rep:02d}/{N_REPLICATES}: "
        f"robust-both={new_pos}, "
        f"FSRQ={a}/{nf}, BLL={c}/{nb}, "
        f"OR={OR:.3f}, p={p:.3g}"
    )


rep_summary = pd.DataFrame(
    rep_summary_rows
)

rep_summary.to_csv(
    OUT_REPS,
    index=False
)


# ============================================================
# SOURCE-LEVEL RECOVERY
# ============================================================

all_rep_parts = []

for rep in range(
    1,
    N_REPLICATES + 1
):
    path = (
        MODEL_DIR
        /
        f"replicate_{rep:03d}.csv"
    )

    x = pd.read_csv(
        path,
        usecols=[
            "replicate",
            "blazar_id",
            "blazar_class",
            "frozen_robust_both",
            "robust_both",
        ]
    )

    for c in [
        "frozen_robust_both",
        "robust_both",
    ]:
        x[c] = (
            x[c]
            .astype(str)
            .str.strip()
            .str.lower()
            .isin(
                [
                    "true",
                    "1",
                    "yes",
                    "y",
                ]
            )
        )

    all_rep_parts.append(
        x
    )

all_rep = pd.concat(
    all_rep_parts,
    ignore_index=True
)

source_recovery = (
    all_rep.groupby(
        [
            "blazar_id",
            "blazar_class",
            "frozen_robust_both",
        ],
        as_index=False,
    )
    .agg(
        robust_both_replicates=(
            "robust_both",
            "sum"
        ),
        robust_both_recovery_fraction=(
            "robust_both",
            "mean"
        ),
    )
)

source_recovery[
    "N_replicates"
] = N_REPLICATES

source_recovery.to_csv(
    OUT_SOURCE,
    index=False
)


# ============================================================
# CLASS-LEVEL RECOVERY SUMMARY
# ============================================================

class_rows = []

for cls in [
    "BLL",
    "FSRQ",
]:
    x = source_recovery.loc[
        source_recovery[
            "blazar_class"
        ].eq(cls)
    ].copy()

    xf = x.loc[
        x[
            "frozen_robust_both"
        ]
    ].copy()

    class_rows.append({
        "blazar_class": cls,
        "N_sources": len(
            x
        ),
        "N_frozen_robust_both": len(
            xf
        ),
        "median_recovery_all_sources": float(
            x[
                "robust_both_recovery_fraction"
            ].median()
        ),
        "median_recovery_frozen_positive": float(
            xf[
                "robust_both_recovery_fraction"
            ].median()
        ) if len(xf) > 0 else np.nan,
        "p25_recovery_frozen_positive": float(
            xf[
                "robust_both_recovery_fraction"
            ].quantile(
                0.25
            )
        ) if len(xf) > 0 else np.nan,
        "p75_recovery_frozen_positive": float(
            xf[
                "robust_both_recovery_fraction"
            ].quantile(
                0.75
            )
        ) if len(xf) > 0 else np.nan,
        "frozen_positive_recovery_ge_0p50": int(
            (
                xf[
                    "robust_both_recovery_fraction"
                ]
                >=
                0.50
            ).sum()
        ) if len(xf) > 0 else 0,
        "frozen_positive_recovery_ge_0p80": int(
            (
                xf[
                    "robust_both_recovery_fraction"
                ]
                >=
                0.80
            ).sum()
        ) if len(xf) > 0 else 0,
    })

class_summary = pd.DataFrame(
    class_rows
)

class_summary.to_csv(
    OUT_CLASS,
    index=False
)


# ============================================================
# FINAL SUMMARY
# ============================================================

count_q = quantiles(
    rep_summary[
        "robust_both_total"
    ]
)

frac_q = quantiles(
    rep_summary[
        "robust_both_fraction"
    ]
)

or_q = quantiles(
    rep_summary[
        "raw_OR_FSRQ_vs_BLL"
    ]
)

p_q = quantiles(
    rep_summary[
        "fisher_p"
    ]
)

ret_q = quantiles(
    rep_summary[
        "frozen_positive_retention"
    ]
)

jac_q = quantiles(
    rep_summary[
        "jaccard_vs_frozen"
    ]
)

n_or_gt1 = int(
    (
        rep_summary[
            "raw_OR_FSRQ_vs_BLL"
        ]
        >
        1.0
    ).sum()
)

n_p_lt05 = int(
    (
        rep_summary[
            "fisher_p"
        ]
        <
        0.05
    ).sum()
)

n_p_lt01 = int(
    (
        rep_summary[
            "fisher_p"
        ]
        <
        0.01
    ).sum()
)

lines = [
    "BLAZAR_I - STAGE 06E3 FINAL SUMMARY",
    "=" * 78,
    "",
    (
        f"Repeated equal-N experiment: "
        f"{N_REPLICATES} replicates x "
        f"{N_EQUAL} nights/source/filter"
    ),
    "",
    "ROBUST-BOTH PREVALENCE ACROSS REPLICATES:",
    (
        f"  count median={count_q['median']:.1f}, "
        f"5-95%={count_q['p05']:.1f}-{count_q['p95']:.1f}, "
        f"range={count_q['min']:.0f}-{count_q['max']:.0f}"
    ),
    (
        f"  fraction median={frac_q['median']:.4f}, "
        f"5-95%={frac_q['p05']:.4f}-{frac_q['p95']:.4f}"
    ),
    "",
    "FROZEN-POSITIVE RECOVERY:",
    (
        f"  retention median={ret_q['median']:.3f}, "
        f"5-95%={ret_q['p05']:.3f}-{ret_q['p95']:.3f}"
    ),
    (
        f"  Jaccard median={jac_q['median']:.3f}, "
        f"5-95%={jac_q['p05']:.3f}-{jac_q['p95']:.3f}"
    ),
    "",
    "FSRQ vs BLL ROBUST-BOTH CLASS CONTRAST:",
    (
        f"  OR median={or_q['median']:.3f}, "
        f"5-95%={or_q['p05']:.3f}-{or_q['p95']:.3f}, "
        f"range={or_q['min']:.3f}-{or_q['max']:.3f}"
    ),
    (
        f"  OR > 1 in {n_or_gt1}/{N_REPLICATES} replicates"
    ),
    (
        f"  Fisher p<0.05 in {n_p_lt05}/{N_REPLICATES}; "
        f"p<0.01 in {n_p_lt01}/{N_REPLICATES}"
    ),
    (
        f"  p-value median={p_q['median']:.3g}, "
        f"5-95%={p_q['p05']:.3g}-{p_q['p95']:.3g}"
    ),
    "",
    "SOURCE-LEVEL RECOVERY AMONG FROZEN ROBUST-BOTH SOURCES:",
]

for _, rr in class_summary.iterrows():
    lines.append(
        f"  {rr['blazar_class']}: "
        f"Nfrozen={int(rr['N_frozen_robust_both'])}, "
        f"median recovery={rr['median_recovery_frozen_positive']:.3f}, "
        f"IQR={rr['p25_recovery_frozen_positive']:.3f}-"
        f"{rr['p75_recovery_frozen_positive']:.3f}, "
        f">=0.50: {int(rr['frozen_positive_recovery_ge_0p50'])}, "
        f">=0.80: {int(rr['frozen_positive_recovery_ge_0p80'])}"
    )

lines += [
    "",
    "INTERPRETATION GUIDE:",
    (
        "  If the OR remains >1 across nearly all equal-N replicates "
        "while individual-source recovery is low, the defensible "
        "conclusion is a population-level FSRQ excess in mixture-like "
        "flux structure, not a stable catalogue of physically bimodal "
        "individual sources."
    ),
    (
        "  Absolute robust-double prevalence should not be treated as "
        "sampling invariant because BIC evidence changes strongly when "
        "the number of nightly measurements is reduced."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_REPS)
print(OUT_SOURCE)
print(OUT_CLASS)
print(OUT_SUMMARY)
print()
print("STAGE 06E3 COMPLETE")
