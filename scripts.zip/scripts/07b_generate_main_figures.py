# ============================================================
# BLAZAR_I — STAGE 07B
# FINAL MAIN-TEXT FIGURES 1--7
#
# Purpose:
#   Generate publication-ready vector PDF figures and high-resolution
#   PNG previews directly from the frozen result tables.
#
# Rules:
#   - no statistics are refit;
#   - no seaborn;
#   - one axes per figure;
#   - matplotlib default colour cycle is used (no custom palette);
#   - PDF is the manuscript master, PNG is a review preview.
#
# Outputs:
#   outputs/figures/Figure01_sample_selection.pdf/png
#   outputs/figures/Figure02_diagnostic_incidence.pdf/png
#   outputs/figures/Figure03_primary_class_effects.pdf/png
#   outputs/figures/Figure04_rmflux_colour_sensitivity.pdf/png
#   outputs/figures/Figure05_drw_timescale_robustness.pdf/png
#   outputs/figures/Figure06_pdf_sampling_sensitivity.pdf/png
#   outputs/figures/Figure07_selection_robustness.pdf/png
#   manuscript/stage07b_figure_captions.tex
#   outputs/audit/stage07b_summary.txt
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
FIG_DIR = ROOT / "outputs" / "figures"
AUDIT_DIR = ROOT / "outputs" / "audit"
MANUSCRIPT_DIR = ROOT / "manuscript"

FIG_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)
MANUSCRIPT_DIR.mkdir(parents=True, exist_ok=True)

FILES = {
    "pop": TABLE_DIR / "stage04_population_master.csv",
    "class05c": TABLE_DIR / "stage05c_clean_class_models.csv",
    "dyn06a3": TABLE_DIR / "stage06a3_dynamic_range_models.csv",
    "cmh06a3": TABLE_DIR / "stage06a3_dynamic_range_cmh.csv",
    "drw06c3": TABLE_DIR / "stage06c3_drw_restframe_class_models.csv",
    "bin06d5": TABLE_DIR / "stage06d5_common_support_ipw_binary_models.csv",
    "cross06d5": TABLE_DIR / "stage06d5_common_support_ipw_rmflux_colour.csv",
    "cont06d5": TABLE_DIR / "stage06d5_common_support_ipw_continuous_models.csv",
    "bal06d4b": TABLE_DIR / "stage06d4b_common_support_balance_summary.csv",
    "pdf06e2": TABLE_DIR / "stage06e2_pdf_source_robustboth_stability.csv",
    "pdfcls06e2": TABLE_DIR / "stage06e2_pdf_class_robustboth.csv",
    "pdfrep06e3": TABLE_DIR / "stage06e3_equaln50_replicate_summary.csv",
}

for name, path in FILES.items():
    if not path.exists():
        raise FileNotFoundError(f"{name}: {path}")

D = {
    k: pd.read_csv(v)
    for k, v in FILES.items()
}

# Publication defaults. No custom colour/style palette is set.
plt.rcParams.update({
    "font.size": 10,
    "axes.labelsize": 10,
    "axes.titlesize": 11,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "figure.dpi": 140,
    "savefig.dpi": 350,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def save_figure(fig, stem):
    pdf = FIG_DIR / f"{stem}.pdf"
    png = FIG_DIR / f"{stem}.png"

    fig.savefig(
        pdf,
        bbox_inches="tight",
    )

    fig.savefig(
        png,
        bbox_inches="tight",
        dpi=350,
    )

    plt.close(fig)

    return pdf, png


def one(df, **conds):
    x = df.copy()

    for c, v in conds.items():
        x = x.loc[
            x[c].eq(v)
        ]

    if len(x) != 1:
        raise RuntimeError(
            f"Expected one row for {conds}; got {len(x)}"
        )

    return x.iloc[0]


def forest_xerr(est, lo, hi):
    est = np.asarray(est, dtype=float)
    lo = np.asarray(lo, dtype=float)
    hi = np.asarray(hi, dtype=float)

    return np.vstack([
        est - lo,
        hi - est,
    ])


# ============================================================
# FIGURE 1 — SAMPLE CONSTRUCTION / SUPPORT
# ============================================================

labels = [
    "Clean Fermi parent",
    "ZTF matched",
    "Final GOLD+SILVER",
]

counts = np.array([
    1901,
    1456,
    1061,
])

fig = plt.figure(
    figsize=(7.2, 4.4)
)

ax = fig.gca()

y = np.arange(
    len(labels)
)

bars = ax.barh(
    y,
    counts,
)

ax.set_yticks(
    y,
    labels=labels,
)

ax.invert_yaxis()

ax.set_xlabel(
    "Number of sources"
)

ax.set_title(
    "Sample construction and empirical sky-support restriction"
)

for yy, bar, n in zip(
    y,
    bars,
    counts,
):
    ax.text(
        n + 25,
        yy,
        f"{n}",
        va="center",
    )

ax.set_xlim(
    0,
    2150,
)

ax.text(
    0.02,
    -0.22,
    (
        "Common-support target: N=1548; "
        "parent Dec extends to -85.7 deg, whereas the final analysis "
        "sample begins near -31.3 deg."
    ),
    transform=ax.transAxes,
    ha="left",
    va="top",
    wrap=True,
)

ax.text(
    0.02,
    -0.36,
    (
        "Selection-weighted inference therefore targets the empirically "
        "overlapping sky region rather than the full 1901-source parent."
    ),
    transform=ax.transAxes,
    ha="left",
    va="top",
    wrap=True,
)

fig.subplots_adjust(
    left=0.26,
    bottom=0.31,
    right=0.95,
    top=0.88,
)

save_figure(
    fig,
    "Figure01_sample_selection",
)


# ============================================================
# FIGURE 2 — DIAGNOSTIC INCIDENCE BY CLASS
# ============================================================

pop = D["pop"].copy()

flags = [
    (
        "Robust double-lognormal\nboth bands",
        "pdf_robust_double_both",
    ),
    (
        "Strict rms-flux\nboth bands",
        "rmflux_strict_both",
    ),
    (
        "Robust central\ncolour break",
        "colour_robust_central_break",
    ),
    (
        "DRW interpretable\nboth bands",
        "drw_interpretable_both",
    ),
]

classes = [
    "BLL",
    "FSRQ",
]

frac = {
    cls: []
    for cls in classes
}

err_lo = {
    cls: []
    for cls in classes
}

err_hi = {
    cls: []
    for cls in classes
}

# Wilson interval, computed only for visualization of raw incidence.
z = 1.959963984540054

for cls in classes:
    sub = pop.loc[
        pop["blazar_class"].eq(cls)
    ]

    n = len(sub)

    for _, col in flags:
        k = int(
            sub[col]
            .astype(bool)
            .sum()
        )

        p = k / n

        den = 1.0 + z*z/n

        centre = (
            p
            +
            z*z/(2*n)
        ) / den

        half = (
            z
            *
            math.sqrt(
                p*(1-p)/n
                +
                z*z/(4*n*n)
            )
            /
            den
        )

        lo = max(
            0.0,
            centre - half
        )

        hi = min(
            1.0,
            centre + half
        )

        frac[cls].append(
            p
        )

        err_lo[cls].append(
            p - lo
        )

        err_hi[cls].append(
            hi - p
        )

fig = plt.figure(
    figsize=(8.4, 5.0)
)

ax = fig.gca()

x = np.arange(
    len(flags)
)

width = 0.34

for j, cls in enumerate(classes):
    shift = (
        -width/2
        if j == 0
        else width/2
    )

    ax.bar(
        x + shift,
        frac[cls],
        width=width,
        label=cls,
        yerr=np.vstack([
            err_lo[cls],
            err_hi[cls],
        ]),
        capsize=3,
    )

ax.set_xticks(
    x,
    labels=[
        a
        for a, _ in flags
    ],
)

ax.set_ylabel(
    "Source fraction"
)

ax.set_ylim(
    0,
    1,
)

ax.set_title(
    "Class-resolved incidence of the four population diagnostics"
)

ax.legend(
    frameon=False,
)

ax.text(
    0.01,
    -0.19,
    (
        "Raw fractions with Wilson 95% intervals. Diagnostic incidence "
        "is not interpreted as a physical-state prevalence."
    ),
    transform=ax.transAxes,
    ha="left",
    va="top",
)

fig.subplots_adjust(
    left=0.11,
    bottom=0.26,
    right=0.97,
    top=0.90,
)

save_figure(
    fig,
    "Figure02_diagnostic_incidence",
)


# ============================================================
# FIGURE 3 — PRIMARY CLASS EFFECTS
# ============================================================

c05 = D["class05c"].copy()

wanted = [
    (
        "PDF robust-double",
        "PDF_CLASS_PRE_DIAGNOSTIC_CONTROLS",
    ),
    (
        "Strict rms-flux",
        "RMFLUX_CLASS_ELIGIBLE_PRE_DIAGNOSTIC_CONTROLS",
    ),
    (
        "Colour curvature",
        "COLOUR_CLASS_MINIMAL_DETECTABILITY_CONTROLS",
    ),
    (
        "Colour + dynamic range",
        "COLOUR_CLASS_PLUS_DYNAMIC_RANGE_SENSITIVITY",
    ),
    (
        "DRW interpretable",
        "DRW_CLASS_PRE_DIAGNOSTIC_CONTROLS",
    ),
]

rows = []

for label, model in wanted:
    r = one(
        c05,
        model_name=model,
    )

    rows.append({
        "label": label,
        "est": float(
            r["odds_ratio"]
        ),
        "lo": float(
            r["or_ci95_low"]
        ),
        "hi": float(
            r["or_ci95_high"]
        ),
    })

df = pd.DataFrame(
    rows
)

fig = plt.figure(
    figsize=(7.4, 4.8)
)

ax = fig.gca()

y = np.arange(
    len(df)
)

ax.errorbar(
    df["est"],
    y,
    xerr=forest_xerr(
        df["est"],
        df["lo"],
        df["hi"],
    ),
    fmt="o",
    capsize=3,
)

ax.axvline(
    1.0,
    linestyle="--",
    linewidth=1,
)

ax.set_xscale(
    "log"
)

ax.set_yticks(
    y,
    labels=df["label"],
)

ax.invert_yaxis()

ax.set_xlabel(
    "FSRQ/BLL odds ratio"
)

ax.set_title(
    "Primary controlled class effects"
)

fig.subplots_adjust(
    left=0.30,
    right=0.96,
    bottom=0.15,
    top=0.90,
)

save_figure(
    fig,
    "Figure03_primary_class_effects",
)


# ============================================================
# FIGURE 4 — RMS-FLUX -> COLOUR SENSITIVITY
# ============================================================

dyn = D["dyn06a3"].copy()
cmh = D["cmh06a3"].copy()

scheme_labels = {
    "PRIMARY20": "Primary20",
    "S10_OCCUPANCY": "S10",
    "S20_SPAN120": "S20 span<=120 d",
    "S30_OCCUPANCY": "S30",
    "S90D_FIXED": "90-d fixed",
}

rows = []

for scheme, display in scheme_labels.items():
    for model, mlabel in [
        (
            "M0_MINIMAL",
            "minimal",
        ),
        (
            "M1_LINEAR_RANGE",
            "+ dynamic range",
        ),
    ]:
        r = one(
            dyn,
            scheme=scheme,
            model_name=model,
        )

        rows.append({
            "label": f"{display}: {mlabel}",
            "est": float(
                r["odds_ratio"]
            ),
            "lo": float(
                r["or_ci95_low"]
            ),
            "hi": float(
                r["or_ci95_high"]
            ),
        })

# Add primary spline + CMH rows.
r = one(
    dyn,
    scheme="PRIMARY20",
    model_name="M2_SPLINE_RANGE_DF4",
)

rows.append({
    "label": "Primary20: spline range",
    "est": float(
        r["odds_ratio"]
    ),
    "lo": float(
        r["or_ci95_low"]
    ),
    "hi": float(
        r["or_ci95_high"]
    ),
})

r = one(
    cmh,
    scheme="PRIMARY20",
)

rows.append({
    "label": "Primary20: CMH range strata",
    "est": float(
        r["cmh_pooled_or"]
    ),
    "lo": float(
        r["cmh_ci95_low"]
    ),
    "hi": float(
        r["cmh_ci95_high"]
    ),
})

df = pd.DataFrame(
    rows
)

fig = plt.figure(
    figsize=(8.6, 6.5)
)

ax = fig.gca()

y = np.arange(
    len(df)
)

ax.errorbar(
    df["est"],
    y,
    xerr=forest_xerr(
        df["est"],
        df["lo"],
        df["hi"],
    ),
    fmt="o",
    capsize=3,
)

ax.axvline(
    1.0,
    linestyle="--",
    linewidth=1,
)

ax.set_xscale(
    "log"
)

ax.set_yticks(
    y,
    labels=df["label"],
)

ax.invert_yaxis()

ax.set_xlabel(
    "Odds ratio for robust colour curvature"
)

ax.set_title(
    "rms-flux to colour-curvature association across sensitivity models"
)

fig.subplots_adjust(
    left=0.34,
    right=0.96,
    bottom=0.12,
    top=0.92,
)

save_figure(
    fig,
    "Figure04_rmflux_colour_sensitivity",
)


# ============================================================
# FIGURE 5 — DRW TIMESCALE ROBUSTNESS
# ============================================================

drw = D["drw06c3"].copy()

common = drw.loc[
    drw[
        "sample_definition"
    ].eq(
        "interpretable_all_three_schemes"
    )
].copy()

name_map = {
    "THIN_HALF_COMMON": "Thin half",
    "BASELINE_CENTRAL80_COMMON": "Central 80% baseline",
    "SEASONAL_DENSE_QUARTER_DROP_COMMON": "Drop dense seasonal quarter",
}

rows = []

for key, label in name_map.items():
    r = one(
        common,
        model_name=key,
    )

    rows.append({
        "label": label,
        "est": float(
            r["factor_FSRQ_vs_BLL"]
        ),
        "lo": float(
            r["factor_ci95_low"]
        ),
        "hi": float(
            r["factor_ci95_high"]
        ),
    })

# Selection-weighted g/r checks.
cont = D["cont06d5"].copy()

for endpoint, label in [
    (
        "TAU_REST_G_INTERPRETABLE",
        "Common-support IPW: g",
    ),
    (
        "TAU_REST_R_INTERPRETABLE",
        "Common-support IPW: r",
    ),
]:
    r = one(
        cont,
        endpoint=endpoint,
        model="COMMON_RAW",
    )

    rows.append({
        "label": label,
        "est": float(
            r["factor_FSRQ_vs_BLL"]
        ),
        "lo": float(
            r["factor_ci95_low"]
        ),
        "hi": float(
            r["factor_ci95_high"]
        ),
    })

df = pd.DataFrame(
    rows
)

fig = plt.figure(
    figsize=(7.8, 5.0)
)

ax = fig.gca()

y = np.arange(
    len(df)
)

ax.errorbar(
    df["est"],
    y,
    xerr=forest_xerr(
        df["est"],
        df["lo"],
        df["hi"],
    ),
    fmt="o",
    capsize=3,
)

ax.axvline(
    1.0,
    linestyle="--",
    linewidth=1,
)

ax.set_yticks(
    y,
    labels=df["label"],
)

ax.invert_yaxis()

ax.set_xlabel(
    "Multiplicative factor in rest-frame DRW timescale (FSRQ/BLL)"
)

ax.set_title(
    "Rest-frame DRW timescale contrast and robustness"
)

fig.subplots_adjust(
    left=0.34,
    right=0.96,
    bottom=0.16,
    top=0.90,
)

save_figure(
    fig,
    "Figure05_drw_timescale_robustness",
)


# ============================================================
# FIGURE 6 — PDF SAMPLING SENSITIVITY
# ============================================================

pdfstab = D["pdf06e2"].copy()
pdfcls = D["pdfcls06e2"].copy()
pdfrep = D["pdfrep06e3"].copy()

# Base full-light-curve point.
base_count = 322
base_or = float(
    one(
        D["bin06d5"],
        endpoint="PDF_ROBUST_DOUBLE_BOTH",
        model="UNWEIGHTED",
    )["OR"]
)

fig = plt.figure(
    figsize=(7.5, 5.4)
)

ax = fig.gca()

# Repeated equal-N50 realizations.
ax.scatter(
    pdfrep[
        "robust_both_total"
    ],
    pdfrep[
        "raw_OR_FSRQ_vs_BLL"
    ],
    marker="o",
    alpha=0.55,
    label="30 repeated EQUAL_N50",
)

# Deterministic 06E2 schemes.
for scheme, marker in [
    (
        "THIN_HALF",
        "s",
    ),
    (
        "EQUAL_N50",
        "^",
    ),
    (
        "MINSEP_7D",
        "D",
    ),
]:
    rs = one(
        pdfstab,
        scheme=scheme,
    )

    rc = one(
        pdfcls,
        scheme=scheme,
    )

    ax.scatter(
        [
            float(
                rs[
                    "sensitivity_robust_both"
                ]
            )
        ],
        [
            float(
                rc[
                    "raw_OR_FSRQ_vs_BLL"
                ]
            )
        ],
        marker=marker,
        s=70,
        label=scheme,
    )

# Frozen full sample.
ax.scatter(
    [
        base_count
    ],
    [
        base_or
    ],
    marker="*",
    s=120,
    label="Frozen full light curve",
)

ax.axhline(
    1.0,
    linestyle="--",
    linewidth=1,
)

ax.set_xlabel(
    "Number of robust-double-both sources"
)

ax.set_ylabel(
    "Raw FSRQ/BLL odds ratio"
)

ax.set_title(
    "Flux-PDF sampling sensitivity"
)

ax.legend(
    frameon=False,
    loc="best",
)

ax.text(
    0.02,
    0.02,
    (
        "Equal-N resampling sharply reduces robust-both incidence, "
        "while the class contrast remains above unity."
    ),
    transform=ax.transAxes,
    ha="left",
    va="bottom",
)

fig.subplots_adjust(
    left=0.13,
    right=0.96,
    bottom=0.14,
    top=0.90,
)

save_figure(
    fig,
    "Figure06_pdf_sampling_sensitivity",
)


# ============================================================
# FIGURE 7 — COMMON-SUPPORT SELECTION ROBUSTNESS
# ============================================================

binary = D["bin06d5"].copy()
continuous = D["cont06d5"].copy()
cross = D["cross06d5"].copy()
balance = D["bal06d4b"].copy()

rows = []

for endpoint, label in [
    (
        "PDF_ROBUST_DOUBLE_BOTH",
        "PDF robust-double",
    ),
    (
        "RMFLUX_STRICT_BOTH_ELIGIBLE",
        "Strict rms-flux",
    ),
    (
        "COLOUR_ROBUST_CENTRAL_BREAK",
        "Colour curvature",
    ),
    (
        "DRW_INTERPRETABLE_BOTH",
        "DRW interpretable",
    ),
]:
    for model, state in [
        (
            "UNWEIGHTED",
            "Unweighted",
        ),
        (
            "COMMON_RAW",
            "Common-support IPW",
        ),
    ]:
        r = one(
            binary,
            endpoint=endpoint,
            model=model,
        )

        rows.append({
            "label": label,
            "state": state,
            "est": float(
                r["OR"]
            ),
        })

# Cross diagnostic.
for model, state in [
    (
        "UNWEIGHTED",
        "Unweighted",
    ),
    (
        "COMMON_RAW",
        "Common-support IPW",
    ),
]:
    r = one(
        cross,
        model=model,
        term="rmflux_strict_both",
    )

    rows.append({
        "label": "rms-flux -> colour",
        "state": state,
        "est": float(
            r["OR"]
        ),
    })

# Fvar and tau continuous factors.
for endpoint, label in [
    (
        "FVAR_G",
        "Fvar g",
    ),
    (
        "FVAR_R",
        "Fvar r",
    ),
    (
        "TAU_REST_G_INTERPRETABLE",
        "tau_rest g",
    ),
    (
        "TAU_REST_R_INTERPRETABLE",
        "tau_rest r",
    ),
]:
    for model, state in [
        (
            "UNWEIGHTED",
            "Unweighted",
        ),
        (
            "COMMON_RAW",
            "Common-support IPW",
        ),
    ]:
        r = one(
            continuous,
            endpoint=endpoint,
            model=model,
        )

        rows.append({
            "label": label,
            "state": state,
            "est": float(
                r[
                    "factor_FSRQ_vs_BLL"
                ]
            ),
        })

df = pd.DataFrame(
    rows
)

order = [
    "PDF robust-double",
    "Strict rms-flux",
    "Colour curvature",
    "DRW interpretable",
    "rms-flux -> colour",
    "Fvar g",
    "Fvar r",
    "tau_rest g",
    "tau_rest r",
]

fig = plt.figure(
    figsize=(8.2, 6.2)
)

ax = fig.gca()

ypos = {
    label: i
    for i, label in enumerate(order)
}

for label in order:
    sub = df.loc[
        df["label"].eq(label)
    ]

    if len(sub) != 2:
        raise RuntimeError(
            f"Figure 7 missing paired estimates for {label}"
        )

    u = float(
        sub.loc[
            sub["state"].eq(
                "Unweighted"
            ),
            "est"
        ].iloc[0]
    )

    w = float(
        sub.loc[
            sub["state"].eq(
                "Common-support IPW"
            ),
            "est"
        ].iloc[0]
    )

    yy = ypos[label]

    ax.plot(
        [
            u,
            w
        ],
        [
            yy,
            yy
        ],
        linewidth=1,
    )

    ax.scatter(
        [
            u
        ],
        [
            yy
        ],
        marker="o",
        label=(
            "Unweighted"
            if yy == 0
            else None
        ),
    )

    ax.scatter(
        [
            w
        ],
        [
            yy
        ],
        marker="s",
        label=(
            "Common-support IPW"
            if yy == 0
            else None
        ),
    )

ax.axvline(
    1.0,
    linestyle="--",
    linewidth=1,
)

ax.set_xscale(
    "log"
)

ax.set_yticks(
    np.arange(
        len(order)
    ),
    labels=order,
)

ax.invert_yaxis()

ax.set_xlabel(
    "Relative effect (null = 1)"
)

ax.set_title(
    "Unweighted versus common-support weighted estimates"
)

ax.legend(
    frameon=False,
    loc="best",
)

bal = one(
    balance,
    weight_scheme="COMMON_RAW",
)

ax.text(
    0.01,
    -0.16,
    (
        f"COMMON_RAW balance: max|SMD|={bal['max_abs_smd']:.3f}, "
        f"Dec KS={bal['dec_weighted_KS']:.3f}, "
        f"ESS={bal['weight_ESS']:.1f}."
    ),
    transform=ax.transAxes,
    ha="left",
    va="top",
)

fig.subplots_adjust(
    left=0.28,
    right=0.96,
    bottom=0.22,
    top=0.90,
)

save_figure(
    fig,
    "Figure07_selection_robustness",
)


# ============================================================
# CAPTIONS / SUMMARY
# ============================================================

captions = r"""
% ============================================================
% BLAZAR_I — STAGE 07B MAIN-FIGURE CAPTIONS
% ============================================================

\begin{figure}
\centering
\includegraphics[width=\linewidth]{../outputs/figures/Figure01_sample_selection.pdf}
\caption{Construction of the optical analysis sample. The clean Fermi parent contains 1901 FSRQ+BLL sources, 1456 have at least one matched ZTF $g$ or $r$ object, and 1061 satisfy the final GOLD+SILVER quality criteria. The common-support parent used for selection-weighted sensitivity analyses contains 1548 sources and excludes the southern sky region with no empirical final-sample support.}
\label{fig:sample_selection}
\end{figure}

\begin{figure}
\centering
\includegraphics[width=\linewidth]{../outputs/figures/Figure02_diagnostic_incidence.pdf}
\caption{Raw BLL and FSRQ incidence of the four source-level population diagnostics, with Wilson 95\% intervals. These are diagnostic incidences rather than direct physical-state prevalences.}
\label{fig:diagnostic_incidence}
\end{figure}

\begin{figure}
\centering
\includegraphics[width=\linewidth]{../outputs/figures/Figure03_primary_class_effects.pdf}
\caption{Primary controlled FSRQ/BLL class effects for the binary diagnostics. The vertical line marks an odds ratio of unity. The robust-double PDF result is included for context but is treated as supportive because its common-support weighted estimate becomes marginal.}
\label{fig:class_effects}
\end{figure}

\begin{figure}
\centering
\includegraphics[width=\linewidth]{../outputs/figures/Figure04_rmflux_colour_sensitivity.pdf}
\caption{Association between strict positive rms--flux behaviour and robust colour-state curvature. The primary 20-point classification remains positive after linear, spline, and range-stratified adjustment, whereas alternative segmentations show stronger attenuation after conditioning on optical dynamic range.}
\label{fig:rmflux_colour}
\end{figure}

\begin{figure}
\centering
\includegraphics[width=\linewidth]{../outputs/figures/Figure05_drw_timescale_robustness.pdf}
\caption{FSRQ/BLL multiplicative factor in rest-frame DRW timescale. Values below unity indicate shorter FSRQ timescales. The controlled class contrast remains close to 0.51--0.52 under three actual-data sampling perturbations; common-support weighted class-only estimates point in the same direction.}
\label{fig:drw_timescales}
\end{figure}

\begin{figure}
\centering
\includegraphics[width=\linewidth]{../outputs/figures/Figure06_pdf_sampling_sensitivity.pdf}
\caption{Sampling sensitivity of the robust double-lognormal flux-PDF diagnostic. Restricting or thinning the light curves sharply reduces the number of sources classified as robust-double in both bands, while the FSRQ/BLL population contrast remains above unity across all repeated equal-$N$ realizations.}
\label{fig:pdf_sampling}
\end{figure}

\begin{figure}
\centering
\includegraphics[width=\linewidth]{../outputs/figures/Figure07_selection_robustness.pdf}
\caption{Comparison of unweighted and common-support weighted endpoint estimates. The weighting model achieves excellent covariate balance within the empirically supported sky target and leaves the principal rms--flux, colour, fractional-variability, and DRW-timescale conclusions qualitatively unchanged; the PDF class contrast shows the strongest attenuation.}
\label{fig:selection_robustness}
\end{figure}
""".strip()

CAPTION_FILE = MANUSCRIPT_DIR / "stage07b_figure_captions.tex"

CAPTION_FILE.write_text(
    captions,
    encoding="utf-8",
)

summary = """BLAZAR_I - STAGE 07B FINAL SUMMARY
================================================================================

Main-text figures generated:
  Figure 1  Sample construction / common-support scope
  Figure 2  Diagnostic incidence by optical class
  Figure 3  Primary controlled class effects
  Figure 4  rms-flux -> colour-curvature sensitivity
  Figure 5  DRW rest-frame timescale robustness
  Figure 6  Flux-PDF sampling sensitivity
  Figure 7  Common-support selection robustness

Formats:
  vector PDF masters
  350-dpi PNG review previews

No statistical model was refit.

Manuscript figure labels:
  fig:sample_selection
  fig:diagnostic_incidence
  fig:class_effects
  fig:rmflux_colour
  fig:drw_timescales
  fig:pdf_sampling
  fig:selection_robustness

STAGE 07B COMPLETE
"""

SUMMARY_FILE = AUDIT_DIR / "stage07b_summary.txt"

SUMMARY_FILE.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
print("FILES SAVED")
print("================================================================================")

for i in range(
    1,
    8,
):
    matches = sorted(
        FIG_DIR.glob(
            f"Figure{i:02d}_*"
        )
    )

    for p in matches:
        print(p)

print(CAPTION_FILE)
print(SUMMARY_FILE)
