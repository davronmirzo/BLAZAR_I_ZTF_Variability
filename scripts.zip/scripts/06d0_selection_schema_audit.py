# ============================================================
# BLAZAR_I — STAGE 06D0
# SELECTION-FUNCTION INPUT / SCHEMA AUDIT
#
# Purpose:
#   Inventory the frozen source-level products needed to quantify
#   the selection flow from the clean Fermi parent sample to the
#   final GOLD+SILVER ZTF analysis sample.
#
# This audit searches existing outputs/tables products rather than
# assuming exact filenames.
#
# Read-only. No upstream files are modified.
# ============================================================

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT = AUDIT_DIR / "stage06d0_selection_schema_audit.txt"

patterns = [
    "stage01*.csv",
    "stage02b1*.csv",
    "stage02b2*.csv",
    "stage02b3*.csv",
    "stage04_population_master.csv",
]

files = []
for pat in patterns:
    files.extend(sorted(TABLE_DIR.glob(pat)))

# de-duplicate, preserve order
seen = set()
uniq = []
for f in files:
    if f not in seen:
        uniq.append(f)
        seen.add(f)
files = uniq

if not files:
    raise FileNotFoundError(
        f"No matching source-level tables found in {TABLE_DIR}"
    )

selection_keywords = [
    "blazar_id",
    "source_name",
    "assoc",
    "class",
    "sed",
    "redshift",
    "flag",
    "clean",
    "gold",
    "silver",
    "sample",
    "tier",
    "ztf",
    "object",
    "radius",
    "distance",
    "match",
    "night",
    "baseline",
    "colour",
    "color",
    "pair",
    "raw",
    "epoch",
    "signif",
    "flux",
    "variability",
    "frac_variability",
    "ra_opt",
    "dec_opt",
]

lines = []
lines.append("BLAZAR_I - STAGE 06D0 SELECTION-FUNCTION SCHEMA AUDIT")
lines.append("=" * 78)

for path in files:
    try:
        df = pd.read_csv(path)
    except Exception as exc:
        lines.append("")
        lines.append(f"FILE: {path.name}")
        lines.append(f"  READ FAILED: {type(exc).__name__}: {exc}")
        continue

    lines.append("")
    lines.append(f"FILE: {path.name}")
    lines.append(f"  rows={len(df)} columns={len(df.columns)}")

    # Common identifier diagnostics.
    for idcol in ["blazar_id", "Source_Name", "Source_Name_clean", "ASSOC1"]:
        if idcol in df.columns:
            lines.append(
                f"  {idcol}: nonnull={int(df[idcol].notna().sum())}, "
                f"unique={int(df[idcol].nunique(dropna=True))}"
            )

    # Candidate selection columns.
    cand = [
        c for c in df.columns
        if any(k in c.lower() for k in selection_keywords)
    ]

    lines.append("  CANDIDATE SELECTION COLUMNS:")
    for c in cand:
        s = df[c]
        line = (
            f"    {c}: dtype={s.dtype}, "
            f"nonnull={int(s.notna().sum())}, "
            f"unique={int(s.nunique(dropna=True))}"
        )

        # For low-cardinality variables, expose counts.
        if s.nunique(dropna=True) <= 12:
            try:
                vc = s.value_counts(dropna=False).head(20).to_dict()
                line += f", counts={vc}"
            except Exception:
                pass

        lines.append(line)

text = "\n".join(lines)
OUT.write_text(text, encoding="utf-8")

print(text)
print()
print("AUDIT SAVED:")
print(OUT)
print()
print("STAGE 06D0 COMPLETE")
