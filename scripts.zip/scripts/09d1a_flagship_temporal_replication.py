# ============================================================
# BLAZAR_I — STAGE 09D1A
# FLAGSHIP TEMPORAL REPLICATION:
# EARLY/LATE RMS-FLUX + COLOUR-CURVATURE REFITS
#
# Purpose:
#   Refit the two diagnostics that define the main cross-diagnostic headline
#   on independent temporal blocks of the SAME sources.
#
# Analysis set:
#   The Stage09D0 pre-outcome common eligibility set:
#       rms-flux eligible in BOTH g/r in BOTH halves
#       colour-break eligible in BOTH halves
#
#   Expected from Stage09D0: 409 sources (305 BLL, 104 FSRQ).
#
# Temporal split:
#   Uses the frozen per-source t_split saved by Stage09D0.
#
# RMS-FLUX:
#   Exact Stage03B primary recipe within each half:
#       consecutive 20-night segments
#       >=8 complete segments
#       intrinsic rms = sqrt(max(S^2 - mean(err^2), 0))
#       Spearman + OLS
#       2000 paired-segment bootstrap
#       BH-FDR within EARLY and LATE test families separately
#
#   Primary half-specific strict flag:
#       rho > 0
#       slope > 0
#       bootstrap p2.5 > 0
#       BH q <= 0.05
#
#   Also saves a frozen-global-p sensitivity flag using the empirical
#   Stage03B p threshold corresponding to q_global<=0.05.
#
# COLOUR:
#   Exact Stage03C OLS/BIC continuous-hinge search within each half:
#       N>=30 pairs
#       >=10 each side
#       robust central break:
#           DeltaBIC >=20
#           0.15 <= break_fraction <=0.85
#
# Temporal association:
#   For EARLY and LATE separately:
#       unadjusted 2x2 OR
#       logistic: colour_break ~ rmflux_strict_both + FSRQ
#       logistic: + standardized half-specific r magnitude range
#
# Important:
#   EARLY and LATE are temporal validation blocks, NOT independent source
#   samples.  These models assess temporal reproducibility of direction and
#   magnitude; they are not a new causal analysis.
#
# Outputs:
#   outputs/tables/stage09d1a_rmflux_half_master.csv
#   outputs/tables/stage09d1a_colour_half_master.csv
#   outputs/tables/stage09d1a_source_half_endpoints.csv
#   outputs/tables/stage09d1a_association_summary.csv
#   outputs/tables/stage09d1a_crosshalf_stability.csv
#   outputs/audit/stage09d1a_summary.txt
# ============================================================

from pathlib import Path
import math
import zlib
import warnings

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, linregress, fisher_exact
from sklearn.metrics import cohen_kappa_score
import statsmodels.api as sm

warnings.filterwarnings("ignore", category=RuntimeWarning)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

ELIG_FILE = TABLE_DIR / "stage09d0_temporal_source_eligibility.csv"
COUNT_FILE = TABLE_DIR / "stage09d0_temporal_split_counts.csv"
PRIMARY_RMF_FILE = TABLE_DIR / "stage03b_rmflux_master.csv"

OUT_RMF = TABLE_DIR / "stage09d1a_rmflux_half_master.csv"
OUT_COL = TABLE_DIR / "stage09d1a_colour_half_master.csv"
OUT_SOURCE = TABLE_DIR / "stage09d1a_source_half_endpoints.csv"
OUT_ASSOC = TABLE_DIR / "stage09d1a_association_summary.csv"
OUT_STABILITY = TABLE_DIR / "stage09d1a_crosshalf_stability.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09d1a_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

SEGMENT_N = 20
MIN_SEGMENTS = 8
BOOTSTRAP_N = 2000
FDR_ALPHA = 0.05
BOOTSTRAP_BASE_SEED = 20260919

PAIR_TOL_DAYS = 0.25
MIN_BREAK_N = 30
MIN_SIDE_N = 10
MAX_BREAK_GRID = 200

ROBUST_DBIC = 20.0
ROBUST_FRAC_LO = 0.15
ROBUST_FRAC_HI = 0.85


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def parse_bool_series(s):
    num = pd.to_numeric(s, errors="coerce")
    out = pd.Series(False, index=s.index, dtype=bool)

    good = num.notna()
    out.loc[good] = num.loc[good] != 0

    rem = ~good
    if rem.any():
        txt = (
            s.loc[rem]
            .astype(str)
            .str.strip()
            .str.lower()
        )
        out.loc[rem] = txt.isin(
            ["true", "t", "yes", "y"]
        )

    return out


def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)
    if valid.sum() == 0:
        return q

    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    m = len(ranked)

    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[valid] = qv

    return q


def stable_seed(bid, filt, half):
    token = (
        f"{BOOTSTRAP_BASE_SEED}|"
        f"{bid}|{filt}|{half}"
    ).encode("utf-8")

    return int(
        zlib.crc32(token)
        &
        0xFFFFFFFF
    )


# ============================================================
# RMS-FLUX
# ============================================================

def build_segments(d):
    x = (
        d[
            [
                "hmjd",
                "flux_jy",
                "fluxerr_jy",
            ]
        ]
        .copy()
        .sort_values("hmjd")
        .reset_index(drop=True)
    )

    for c in x.columns:
        x[c] = numeric(x[c])

    x = x.loc[
        np.isfinite(x["hmjd"])
        &
        np.isfinite(x["flux_jy"])
        &
        np.isfinite(x["fluxerr_jy"])
        &
        (x["flux_jy"] > 0)
        &
        (x["fluxerr_jy"] >= 0)
    ].copy()

    n_complete = len(x) // SEGMENT_N
    rows = []

    for j in range(n_complete):
        seg = x.iloc[
            j * SEGMENT_N:
            (j + 1) * SEGMENT_N
        ]

        t = seg["hmjd"].to_numpy(dtype=float)
        f = seg["flux_jy"].to_numpy(dtype=float)
        e = seg["fluxerr_jy"].to_numpy(dtype=float)

        mean_f = float(np.mean(f))
        s2 = float(np.var(f, ddof=1))
        mean_e2 = float(np.mean(e ** 2))

        xs = s2 - mean_e2
        rms_xs = math.sqrt(max(xs, 0.0))

        rows.append({
            "segment_index": j + 1,
            "mean_flux_jy": mean_f,
            "intrinsic_rms_jy": rms_xs,
            "span_days": float(np.max(t) - np.min(t)),
            "noise_dominated": bool(xs <= 0),
        })

    return pd.DataFrame(rows)


def bootstrap_slope(x, y, seed):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)
    rng = np.random.default_rng(seed)

    idx = rng.integers(
        0,
        n,
        size=(BOOTSTRAP_N, n),
        endpoint=False,
    )

    xb = x[idx]
    yb = y[idx]

    xm = xb.mean(axis=1)
    ym = yb.mean(axis=1)

    dx = xb - xm[:, None]
    dy = yb - ym[:, None]

    denom = np.sum(dx ** 2, axis=1)
    numer = np.sum(dx * dy, axis=1)

    good = (
        np.isfinite(denom)
        &
        np.isfinite(numer)
        &
        (denom > 0)
    )

    slopes = numer[good] / denom[good]
    slopes = slopes[np.isfinite(slopes)]

    if len(slopes) == 0:
        return {
            "boot_valid_N": 0,
            "slope_boot_median": np.nan,
            "slope_boot_p025": np.nan,
            "slope_boot_p975": np.nan,
        }

    return {
        "boot_valid_N": int(len(slopes)),
        "slope_boot_median": float(np.median(slopes)),
        "slope_boot_p025": float(np.percentile(slopes, 2.5)),
        "slope_boot_p975": float(np.percentile(slopes, 97.5)),
    }


def fit_rmflux_half(bid, filt, half, d):
    seg = build_segments(d)

    row = {
        "blazar_id": bid,
        "filter_name": filt,
        "half": half,
        "N_nightly": int(len(d)),
        "N_segments": int(len(seg)),
        "fit_status": "NOT_RUN",
    }

    if len(seg) < MIN_SEGMENTS:
        row["fit_status"] = (
            f"TOO_FEW_SEGMENTS_LT_{MIN_SEGMENTS}"
        )
        return row

    x = seg["mean_flux_jy"].to_numpy(dtype=float)
    y = seg["intrinsic_rms_jy"].to_numpy(dtype=float)

    good = (
        np.isfinite(x)
        &
        np.isfinite(y)
        &
        (x > 0)
        &
        (y >= 0)
    )

    x = x[good]
    y = y[good]

    row["N_segments_fit"] = int(len(x))

    if len(x) < MIN_SEGMENTS:
        row["fit_status"] = (
            f"TOO_FEW_FINITE_SEGMENTS_LT_{MIN_SEGMENTS}"
        )
        return row

    if np.allclose(x, x[0]) or np.allclose(y, y[0]):
        row["fit_status"] = "DEGENERATE_RELATION"
        return row

    rho, p = spearmanr(x, y)
    lr = linregress(x, y)

    boot = bootstrap_slope(
        x,
        y,
        stable_seed(bid, filt, half),
    )

    row.update({
        "spearman_rho": float(rho),
        "spearman_p": float(p),
        "ols_slope": float(lr.slope),
        "ols_intercept_jy": float(lr.intercept),
        "noise_dominated_fraction": float(
            seg["noise_dominated"].mean()
        ),
        "segment_span_days_median": float(
            seg["span_days"].median()
        ),
        **boot,
        "fit_status": "OK",
    })

    return row


# ============================================================
# COLOUR
# ============================================================

def rss_floor(rss, y):
    y = np.asarray(y, dtype=float)
    scale = np.var(y, ddof=0)

    floor = max(
        1.0e-30,
        1.0e-12
        *
        max(scale, 1.0)
        *
        len(y),
    )

    return max(float(rss), floor)


def information_criteria(rss, n, k):
    rss = max(float(rss), 1.0e-300)

    aic = (
        n * math.log(rss / n)
        +
        2.0 * k
    )

    bic = (
        n * math.log(rss / n)
        +
        k * math.log(n)
    )

    return aic, bic


def fit_single_line(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)
    x0 = float(np.median(x))

    X = np.column_stack(
        [
            np.ones(n),
            x - x0,
        ]
    )

    beta, _, _, _ = np.linalg.lstsq(
        X,
        y,
        rcond=None,
    )

    pred = X @ beta
    resid = y - pred
    rss = rss_floor(np.sum(resid ** 2), y)

    aic, bic = information_criteria(
        rss,
        n,
        3,
    )

    return {
        "single_x0_rmag": x0,
        "single_intercept_at_x0": float(beta[0]),
        "single_slope_dcolor_dr": float(beta[1]),
        "single_rss": float(rss),
        "single_aic": float(aic),
        "single_bic": float(bic),
        "single_resid_std": float(
            math.sqrt(rss / n)
        ),
    }


def candidate_breaks(x):
    x = np.asarray(x, dtype=float)
    xs = np.sort(np.unique(x))

    if len(x) < MIN_BREAK_N:
        return np.array([], dtype=float)

    vals = []

    for xb in xs:
        nl = int(np.sum(x <= xb))
        nr = int(np.sum(x > xb))

        if (
            nl >= MIN_SIDE_N
            and
            nr >= MIN_SIDE_N
        ):
            vals.append(float(xb))

    vals = np.asarray(vals, dtype=float)

    if len(vals) <= MAX_BREAK_GRID:
        return vals

    idx = np.linspace(
        0,
        len(vals) - 1,
        MAX_BREAK_GRID,
    ).round().astype(int)

    return np.unique(vals[idx])


def fit_broken_line(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)
    candidates = candidate_breaks(x)

    if len(candidates) == 0:
        return None

    best = None

    for xb in candidates:
        dx = x - xb
        hinge = np.maximum(dx, 0.0)

        X = np.column_stack(
            [
                np.ones(n),
                dx,
                hinge,
            ]
        )

        beta, _, _, _ = np.linalg.lstsq(
            X,
            y,
            rcond=None,
        )

        pred = X @ beta
        resid = y - pred
        rss = rss_floor(np.sum(resid ** 2), y)

        if best is None or rss < best["rss"]:
            b_left = float(beta[1])
            delta = float(beta[2])

            best = {
                "xb": float(xb),
                "c": float(beta[0]),
                "b_left": b_left,
                "b_right": float(
                    b_left + delta
                ),
                "delta_slope": delta,
                "rss": float(rss),
                "n_left": int(np.sum(x <= xb)),
                "n_right": int(np.sum(x > xb)),
            }

    if best is None:
        return None

    aic, bic = information_criteria(
        best["rss"],
        n,
        5,
    )

    best["aic"] = float(aic)
    best["bic"] = float(bic)

    return best


def build_colour_pairs(d):
    g = (
        d.loc[
            d["filter_name"].eq("g"),
            [
                "night_id",
                "hmjd",
                "mag",
                "magerr",
            ],
        ]
        .rename(
            columns={
                "hmjd": "hmjd_g",
                "mag": "g_mag",
                "magerr": "g_magerr",
            }
        )
        .copy()
    )

    r = (
        d.loc[
            d["filter_name"].eq("r"),
            [
                "night_id",
                "hmjd",
                "mag",
                "magerr",
            ],
        ]
        .rename(
            columns={
                "hmjd": "hmjd_r",
                "mag": "r_mag",
                "magerr": "r_magerr",
            }
        )
        .copy()
    )

    p = g.merge(
        r,
        on="night_id",
        how="inner",
        validate="one_to_one",
    )

    for c in [
        "hmjd_g",
        "hmjd_r",
        "g_mag",
        "g_magerr",
        "r_mag",
        "r_magerr",
    ]:
        p[c] = numeric(p[c])

    p = p.loc[
        np.isfinite(p["hmjd_g"])
        &
        np.isfinite(p["hmjd_r"])
        &
        np.isfinite(p["g_mag"])
        &
        np.isfinite(p["r_mag"])
        &
        np.isfinite(p["g_magerr"])
        &
        np.isfinite(p["r_magerr"])
        &
        (p["g_magerr"] > 0)
        &
        (p["r_magerr"] > 0)
    ].copy()

    p["dt_days"] = np.abs(
        p["hmjd_g"]
        -
        p["hmjd_r"]
    )

    p = p.loc[
        p["dt_days"]
        <=
        PAIR_TOL_DAYS
    ].copy()

    p["hmjd_pair"] = 0.5 * (
        p["hmjd_g"]
        +
        p["hmjd_r"]
    )

    p["g_minus_r"] = (
        p["g_mag"]
        -
        p["r_mag"]
    )

    return p


def fit_colour_half(bid, half, p):
    row = {
        "blazar_id": bid,
        "half": half,
        "N_colour_pairs": int(len(p)),
        "fit_status": "NOT_RUN",
    }

    if len(p) < MIN_BREAK_N:
        row["fit_status"] = (
            f"TOO_FEW_PAIRS_LT_{MIN_BREAK_N}"
        )
        return row

    x = p["r_mag"].to_numpy(dtype=float)
    y = p["g_minus_r"].to_numpy(dtype=float)

    if np.allclose(x, x[0]) or np.allclose(y, y[0]):
        row["fit_status"] = "DEGENERATE_RELATION"
        return row

    single = fit_single_line(x, y)
    broken = fit_broken_line(x, y)

    row.update(single)

    row["r_mag_min"] = float(np.min(x))
    row["r_mag_max"] = float(np.max(x))
    row["r_mag_range"] = float(
        row["r_mag_max"]
        -
        row["r_mag_min"]
    )

    if broken is None:
        row["robust_central_break"] = False
        row["fit_status"] = "NO_VALID_BREAK"
        return row

    dbic = (
        single["single_bic"]
        -
        broken["bic"]
    )

    denom = row["r_mag_range"]

    break_frac = (
        (
            broken["xb"]
            -
            row["r_mag_min"]
        )
        /
        denom
        if denom > 0
        else np.nan
    )

    robust = bool(
        dbic >= ROBUST_DBIC
        and
        np.isfinite(break_frac)
        and
        ROBUST_FRAC_LO
        <= break_frac
        <= ROBUST_FRAC_HI
    )

    row.update({
        "break_r_mag": float(broken["xb"]),
        "break_slope_left": float(broken["b_left"]),
        "break_slope_right": float(broken["b_right"]),
        "break_delta_slope": float(broken["delta_slope"]),
        "break_N_left": int(broken["n_left"]),
        "break_N_right": int(broken["n_right"]),
        "break_bic": float(broken["bic"]),
        "delta_bic_single_minus_broken": float(dbic),
        "break_fraction": float(break_frac),
        "robust_central_break": robust,
        "fit_status": "OK",
    })

    return row


# ============================================================
# ASSOCIATION HELPERS
# ============================================================

def contingency_or(exposure, outcome):
    e = np.asarray(exposure, dtype=bool)
    y = np.asarray(outcome, dtype=bool)

    a = int(np.sum(e & y))
    b = int(np.sum(e & ~y))
    c = int(np.sum(~e & y))
    d = int(np.sum(~e & ~y))

    table = np.array(
        [
            [a, b],
            [c, d],
        ],
        dtype=int,
    )

    orr, p = fisher_exact(
        table,
        alternative="two-sided",
    )

    # Haldane-Anscombe CI if needed.
    aa, bb, cc, dd = (
        a + 0.5,
        b + 0.5,
        c + 0.5,
        d + 0.5,
    )

    logor = math.log(
        (aa * dd)
        /
        (bb * cc)
    )

    se = math.sqrt(
        1.0 / aa
        +
        1.0 / bb
        +
        1.0 / cc
        +
        1.0 / dd
    )

    lo = math.exp(
        logor
        -
        1.959963984540054
        *
        se
    )

    hi = math.exp(
        logor
        +
        1.959963984540054
        *
        se
    )

    return {
        "N": len(e),
        "n11": a,
        "n10": b,
        "n01": c,
        "n00": d,
        "OR": float(orr),
        "ci95_low": float(lo),
        "ci95_high": float(hi),
        "p": float(p),
    }


def zscore(s):
    x = numeric(s)
    mu = x.mean()
    sd = x.std(ddof=0)

    if not np.isfinite(sd) or sd <= 0:
        return pd.Series(
            np.zeros(len(x)),
            index=x.index,
            dtype=float,
        )

    return (
        x - mu
    ) / sd


def fit_logistic(df, predictors, focal):
    cols = [
        "colour_robust_central_break",
        *predictors,
    ]

    x = df[cols].copy()

    for c in cols:
        x[c] = numeric(x[c])

    x = x.dropna()

    if len(x) < 30:
        return {
            "N": len(x),
            "OR": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": "TOO_FEW_COMPLETE_CASES",
        }

    y = x[
        "colour_robust_central_break"
    ].to_numpy(dtype=float)

    X = sm.add_constant(
        x[predictors].astype(float),
        has_constant="add",
    )

    try:
        model = sm.GLM(
            y,
            X,
            family=sm.families.Binomial(),
        )

        fit = model.fit(
            cov_type="HC3",
        )

        beta = float(
            fit.params[focal]
        )

        se = float(
            fit.bse[focal]
        )

        p = float(
            fit.pvalues[focal]
        )

        return {
            "N": len(x),
            "OR": math.exp(beta),
            "ci95_low": math.exp(
                beta
                -
                1.959963984540054
                *
                se
            ),
            "ci95_high": math.exp(
                beta
                +
                1.959963984540054
                *
                se
            ),
            "p": p,
            "status": "OK",
        }

    except Exception as exc:
        return {
            "N": len(x),
            "OR": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": (
                f"FAILED:{type(exc).__name__}"
            ),
        }


# ============================================================
# LOAD ELIGIBILITY + SPLITS
# ============================================================

for path in [
    ELIG_FILE,
    COUNT_FILE,
    PRIMARY_RMF_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

elig = pd.read_csv(
    ELIG_FILE,
    low_memory=False,
)

elig["blazar_id"] = (
    elig["blazar_id"]
    .astype(str)
)

elig["flagship_temporal_eligible"] = (
    parse_bool_series(
        elig["flagship_temporal_eligible"]
    )
)

elig = elig.loc[
    elig["flagship_temporal_eligible"]
].copy()

if len(elig) == 0:
    raise RuntimeError(
        "No flagship temporal eligible sources."
    )

counts = pd.read_csv(
    COUNT_FILE,
    low_memory=False,
)

counts["blazar_id"] = (
    counts["blazar_id"]
    .astype(str)
)

split_lookup = (
    counts[
        [
            "blazar_id",
            "t_split",
        ]
    ]
    .drop_duplicates(
        "blazar_id"
    )
    .set_index(
        "blazar_id"
    )
)

primary_rmf = pd.read_csv(
    PRIMARY_RMF_FILE,
    low_memory=False,
)

primary_ok = (
    primary_rmf[
        "fit_status"
    ]
    .astype(str)
    .eq("OK")
)

primary_sig = (
    primary_ok
    &
    (
        numeric(
            primary_rmf[
                "spearman_q_bh_global"
            ]
        )
        <=
        FDR_ALPHA
    )
)

if not primary_sig.any():
    raise RuntimeError(
        "Cannot derive frozen Stage03B p cutoff."
    )

FROZEN_GLOBAL_P_CUTOFF = float(
    numeric(
        primary_rmf.loc[
            primary_sig,
            "spearman_p",
        ]
    ).max()
)

source_ids = (
    elig["blazar_id"]
    .tolist()
)

print("=" * 80)
print("BLAZAR_I — STAGE 09D1A FLAGSHIP TEMPORAL REPLICATION")
print("=" * 80)
print("Common eligible sources =", len(source_ids))
print(
    "BLL / FSRQ =",
    int(
        elig["blazar_class"]
        .astype(str)
        .eq("BLL")
        .sum()
    ),
    "/",
    int(
        elig["blazar_class"]
        .astype(str)
        .eq("FSRQ")
        .sum()
    ),
)
print(
    "Frozen global Spearman p cutoff =",
    f"{FROZEN_GLOBAL_P_CUTOFF:.8g}",
)


# ============================================================
# REFIT ALL SOURCES
# ============================================================

rmf_rows = []
col_rows = []

for i, bid in enumerate(
    source_ids,
    start=1,
):
    if bid not in split_lookup.index:
        raise RuntimeError(
            f"Missing t_split for {bid}"
        )

    tsplit = float(
        split_lookup.loc[
            bid,
            "t_split",
        ]
    )

    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(path)

    d = pd.read_parquet(path)

    d["filter_name"] = (
        d["filter_name"]
        .astype(str)
        .str.lower()
        .str.strip()
    )

    for c in [
        "night_id",
        "hmjd",
        "mag",
        "magerr",
        "flux_jy",
        "fluxerr_jy",
    ]:
        d[c] = numeric(d[c])

    d = d.loc[
        d["filter_name"].isin(["g", "r"])
        &
        np.isfinite(d["hmjd"])
        &
        np.isfinite(d["mag"])
        &
        np.isfinite(d["magerr"])
        &
        np.isfinite(d["flux_jy"])
        &
        np.isfinite(d["fluxerr_jy"])
        &
        (d["magerr"] > 0)
        &
        (d["flux_jy"] > 0)
        &
        (d["fluxerr_jy"] >= 0)
    ].copy()

    pairs = build_colour_pairs(d)

    for half in [
        "EARLY",
        "LATE",
    ]:
        if half == "EARLY":
            dh = d.loc[
                d["hmjd"]
                <=
                tsplit
            ].copy()

            ph = pairs.loc[
                pairs["hmjd_pair"]
                <=
                tsplit
            ].copy()

        else:
            dh = d.loc[
                d["hmjd"]
                >
                tsplit
            ].copy()

            ph = pairs.loc[
                pairs["hmjd_pair"]
                >
                tsplit
            ].copy()

        for filt in [
            "g",
            "r",
        ]:
            df = dh.loc[
                dh["filter_name"].eq(filt)
            ].copy()

            rr = fit_rmflux_half(
                bid,
                filt,
                half,
                df,
            )

            rmf_rows.append(rr)

        cr = fit_colour_half(
            bid,
            half,
            ph,
        )

        col_rows.append(cr)

    if (
        i % 50 == 0
        or
        i == len(source_ids)
    ):
        print(
            f"Refit {i}/{len(source_ids)} sources"
        )

rmf = pd.DataFrame(
    rmf_rows
)

col = pd.DataFrame(
    col_rows
)


# ============================================================
# HALF-SPECIFIC FDR + STRICT FLAGS
# ============================================================

rmf["spearman_q_bh_half"] = np.nan
rmf["strict_positive_bh_half"] = False
rmf["strict_positive_frozen_p"] = False

for half in [
    "EARLY",
    "LATE",
]:
    mask = (
        rmf["half"].eq(half)
        &
        rmf["fit_status"].eq("OK")
        &
        numeric(
            rmf["spearman_p"]
        ).notna()
    )

    idx = rmf.index[
        mask
    ]

    q = bh_qvalues(
        numeric(
            rmf.loc[
                idx,
                "spearman_p",
            ]
        ).to_numpy(dtype=float)
    )

    rmf.loc[
        idx,
        "spearman_q_bh_half",
    ] = q

    base = (
        mask
        &
        (
            numeric(
                rmf["spearman_rho"]
            )
            >
            0
        )
        &
        (
            numeric(
                rmf["ols_slope"]
            )
            >
            0
        )
        &
        (
            numeric(
                rmf["slope_boot_p025"]
            )
            >
            0
        )
    )

    rmf.loc[
        base
        &
        (
            numeric(
                rmf["spearman_q_bh_half"]
            )
            <=
            FDR_ALPHA
        ),
        "strict_positive_bh_half",
    ] = True

    rmf.loc[
        base
        &
        (
            numeric(
                rmf["spearman_p"]
            )
            <=
            FROZEN_GLOBAL_P_CUTOFF
        ),
        "strict_positive_frozen_p",
    ] = True

rmf.to_csv(
    OUT_RMF,
    index=False,
)

col.to_csv(
    OUT_COL,
    index=False,
)


# ============================================================
# SOURCE-HALF ENDPOINTS
# ============================================================

meta = (
    elig[
        [
            "blazar_id",
            "blazar_class",
        ]
    ]
    .drop_duplicates(
        "blazar_id"
    )
)

rmf_piv = (
    rmf.pivot(
        index=[
            "blazar_id",
            "half",
        ],
        columns="filter_name",
        values=[
            "strict_positive_bh_half",
            "strict_positive_frozen_p",
        ],
    )
)

source_rows = []

for _, cr in col.iterrows():
    bid = str(
        cr["blazar_id"]
    )

    half = str(
        cr["half"]
    )

    key = (
        bid,
        half,
    )

    sg = bool(
        rmf_piv.loc[
            key,
            (
                "strict_positive_bh_half",
                "g",
            ),
        ]
    )

    sr = bool(
        rmf_piv.loc[
            key,
            (
                "strict_positive_bh_half",
                "r",
            ),
        ]
    )

    fg = bool(
        rmf_piv.loc[
            key,
            (
                "strict_positive_frozen_p",
                "g",
            ),
        ]
    )

    fr = bool(
        rmf_piv.loc[
            key,
            (
                "strict_positive_frozen_p",
                "r",
            ),
        ]
    )

    source_rows.append({
        "blazar_id": bid,
        "half": half,
        "rmflux_strict_g": sg,
        "rmflux_strict_r": sr,
        "rmflux_strict_both": bool(
            sg and sr
        ),
        "rmflux_frozenp_g": fg,
        "rmflux_frozenp_r": fr,
        "rmflux_frozenp_both": bool(
            fg and fr
        ),
        "colour_robust_central_break": bool(
            cr["robust_central_break"]
        ),
        "colour_delta_bic": cr.get(
            "delta_bic_single_minus_broken",
            np.nan,
        ),
        "r_mag_range_half": cr.get(
            "r_mag_range",
            np.nan,
        ),
        "break_r_mag": cr.get(
            "break_r_mag",
            np.nan,
        ),
    })

source = pd.DataFrame(
    source_rows
)

source = source.merge(
    meta,
    on="blazar_id",
    how="left",
    validate="many_to_one",
)

source["FSRQ"] = (
    source["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

source["r_range_z"] = np.nan

for half in [
    "EARLY",
    "LATE",
]:
    idx = source.index[
        source["half"].eq(half)
    ]

    source.loc[
        idx,
        "r_range_z",
    ] = zscore(
        source.loc[
            idx,
            "r_mag_range_half",
        ]
    ).to_numpy()

source.to_csv(
    OUT_SOURCE,
    index=False,
)


# ============================================================
# ASSOCIATION SUMMARY
# ============================================================

assoc_rows = []

for half in [
    "EARLY",
    "LATE",
]:
    x = source.loc[
        source["half"].eq(half)
    ].copy()

    cont = contingency_or(
        x["rmflux_strict_both"],
        x["colour_robust_central_break"],
    )

    assoc_rows.append({
        "half": half,
        "model": "UNADJUSTED_2X2",
        "focal": "rmflux_strict_both",
        **cont,
        "status": "OK",
    })

    m0 = fit_logistic(
        x,
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
        ],
        focal="rmflux_strict_both",
    )

    assoc_rows.append({
        "half": half,
        "model": "MINIMAL_CLASS",
        "focal": "rmflux_strict_both",
        **m0,
    })

    m1 = fit_logistic(
        x,
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
            "r_range_z",
        ],
        focal="rmflux_strict_both",
    )

    assoc_rows.append({
        "half": half,
        "model": "PLUS_DYNAMIC_RANGE",
        "focal": "rmflux_strict_both",
        **m1,
    })

assoc = pd.DataFrame(
    assoc_rows
)

assoc.to_csv(
    OUT_ASSOC,
    index=False,
)


# ============================================================
# CROSS-HALF STABILITY
# ============================================================

wide = source.pivot(
    index="blazar_id",
    columns="half",
    values=[
        "rmflux_strict_both",
        "colour_robust_central_break",
        "rmflux_frozenp_both",
    ],
)

stability_rows = []

for endpoint in [
    "rmflux_strict_both",
    "rmflux_frozenp_both",
    "colour_robust_central_break",
]:
    e = (
        wide[
            (
                endpoint,
                "EARLY",
            )
        ]
        .astype(bool)
    )

    l = (
        wide[
            (
                endpoint,
                "LATE",
            )
        ]
        .astype(bool)
    )

    both_pos = int(
        (e & l).sum()
    )

    either_pos = int(
        (e | l).sum()
    )

    agreement = float(
        (e == l).mean()
    )

    kappa = float(
        cohen_kappa_score(
            e.astype(int),
            l.astype(int),
        )
    )

    stability_rows.append({
        "endpoint": endpoint,
        "N_sources": len(e),
        "early_positive": int(e.sum()),
        "late_positive": int(l.sum()),
        "positive_both_halves": both_pos,
        "positive_either_half": either_pos,
        "positive_retention_early_to_late": (
            both_pos / int(e.sum())
            if int(e.sum()) > 0
            else np.nan
        ),
        "jaccard_positive": (
            both_pos / either_pos
            if either_pos > 0
            else np.nan
        ),
        "overall_agreement": agreement,
        "cohen_kappa": kappa,
    })

stability = pd.DataFrame(
    stability_rows
)

stability.to_csv(
    OUT_STABILITY,
    index=False,
)


# ============================================================
# FINAL SUMMARY
# ============================================================

def assoc_row(half, model):
    hit = assoc.loc[
        assoc["half"].eq(half)
        &
        assoc["model"].eq(model)
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


def stab_row(endpoint):
    hit = stability.loc[
        stability["endpoint"].eq(endpoint)
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


lines = [
    "BLAZAR_I - STAGE 09D1A FINAL SUMMARY",
    "=" * 80,
    "",
    "FLAGSHIP TEMPORAL EARLY/LATE REPLICATION",
    "",
    f"Common pre-outcome eligible sources : {len(source_ids)}",
    f"  BLL                               : {int(meta['blazar_class'].astype(str).eq('BLL').sum())}",
    f"  FSRQ                              : {int(meta['blazar_class'].astype(str).eq('FSRQ').sum())}",
    f"Frozen Stage03B p reference         : {FROZEN_GLOBAL_P_CUTOFF:.8g}",
    "",
]

for half in [
    "EARLY",
    "LATE",
]:
    x = source.loc[
        source["half"].eq(half)
    ]

    lines += [
        f"{half}:",
        f"  rms-flux strict BOTH             : {int(x['rmflux_strict_both'].sum())}/{len(x)}",
        f"  rms-flux frozen-p BOTH          : {int(x['rmflux_frozenp_both'].sum())}/{len(x)}",
        f"  robust-central colour break     : {int(x['colour_robust_central_break'].sum())}/{len(x)}",
    ]

    for model in [
        "UNADJUSTED_2X2",
        "MINIMAL_CLASS",
        "PLUS_DYNAMIC_RANGE",
    ]:
        r = assoc_row(
            half,
            model,
        )

        if r is not None:
            lines.append(
                f"  rms->colour {model:20s}: "
                f"OR={r['OR']:.3f}, "
                f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
                f"p={r['p']:.3g}, N={int(r['N'])}"
            )

    lines.append("")

lines.append(
    "CROSS-HALF ENDPOINT STABILITY:"
)

for endpoint in [
    "rmflux_strict_both",
    "colour_robust_central_break",
]:
    r = stab_row(endpoint)

    if r is not None:
        lines += [
            f"  {endpoint}:",
            f"    early / late positive         : {int(r['early_positive'])} / {int(r['late_positive'])}",
            f"    positive both halves          : {int(r['positive_both_halves'])}",
            f"    Jaccard positive              : {r['jaccard_positive']:.3f}",
            f"    overall agreement             : {r['overall_agreement']:.3f}",
            f"    Cohen kappa                   : {r['cohen_kappa']:.3f}",
        ]

lines += [
    "",
    "Interpretation locks:",
    "  - EARLY and LATE are repeated temporal blocks of the same sources.",
    "  - Reproducible association direction across halves is stronger evidence",
    "    than significance in only one half; p-values are not independent.",
    "  - Dynamic-range-adjusted half models are the key temporal sensitivity.",
    "  - Endpoint instability is expected because Stage09C showed incomplete",
    "    recovery for both strict rms-flux and robust colour-break diagnostics.",
    "  - No causal interpretation is permitted.",
    "",
    "Files saved:",
    f"  {OUT_RMF}",
    f"  {OUT_COL}",
    f"  {OUT_SOURCE}",
    f"  {OUT_ASSOC}",
    f"  {OUT_STABILITY}",
    "",
    "Next:",
    "  STAGE 09D1B — early/late DRW refits on the known-redshift temporal",
    "  support set, followed by source-clustered temporal comparison.",
    "",
    "STAGE 09D1A COMPLETE",
]

summary = "\n".join(lines)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
