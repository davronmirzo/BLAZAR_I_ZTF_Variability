# ============================================================
# BLAZAR_I — STAGE 09C1
# DRW NULL / INJECTION-RECOVERY CALIBRATION
#
# Purpose:
#   Calibrate the DRW interpretability gate and tau recovery using
#   ACTUAL ZTF cadence and photometric-error arrays from the Stage09C0
#   source-filter template bank.
#
# Simulation scenarios per template:
#   WHITE_NULL
#       Intrinsic uncorrelated Gaussian variability + measurement noise.
#
#   OU_SHORT
#       True tau = max(3 * cadence, 1.0 d)
#
#   OU_MID
#       True tau = geometric mean of OU_SHORT and 0.05 * baseline
#
#   OU_LONG
#       True tau = 0.08 * baseline
#
# Injection amplitude:
#   Frozen Stage03D stationary DRW sigma for that source/filter, clipped
#   to [0.03, 1.0] mag.  The same intrinsic RMS scale is used by WHITE_NULL.
#
# Fitting / gate:
#   White-noise null + exact irregular OU likelihood
#   DeltaBIC >= 10
#   tau >= 2 * median cadence
#   tau <= baseline / 10
#   tau not within 2% of either log-search boundary
#
# Important:
#   - True injected tau is NEVER used to initialise the fitter.
#   - The fitter uses deterministic generic multi-starts based only on
#     cadence/baseline and the simulated light curve.
#   - Results are resumable at the replicate level.
#
# Default workload:
#   48 templates x 4 scenarios x 12 reps = 2304 simulated fits.
#
# Outputs:
#   outputs/models/stage09c1_drw_calibration/*.csv
#   outputs/tables/stage09c1_drw_simulation_master.csv
#   outputs/tables/stage09c1_drw_scenario_summary.csv
#   outputs/tables/stage09c1_drw_template_summary.csv
#   outputs/audit/stage09c1_summary.txt
# ============================================================

from pathlib import Path
import argparse
import math
import time
import zlib
import warnings

import numpy as np
import pandas as pd
from scipy.optimize import minimize

warnings.filterwarnings("ignore", category=RuntimeWarning)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
MODEL_DIR = ROOT / "outputs" / "models" / "stage09c1_drw_calibration"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

TEMPLATE_FILE = TABLE_DIR / "stage09c0_source_filter_template_bank.csv"
DRW_FILE = TABLE_DIR / "stage03d_drw_master.csv"

OUT_MASTER = TABLE_DIR / "stage09c1_drw_simulation_master.csv"
OUT_SCEN = TABLE_DIR / "stage09c1_drw_scenario_summary.csv"
OUT_TEMPLATE = TABLE_DIR / "stage09c1_drw_template_summary.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09c1_summary.txt"

for p in [
    TABLE_DIR,
    AUDIT_DIR,
    MODEL_DIR,
]:
    p.mkdir(parents=True, exist_ok=True)

BASE_SEED = 20260918

SCENARIOS = [
    "WHITE_NULL",
    "OU_SHORT",
    "OU_MID",
    "OU_LONG",
]

SIGMA_MIN = 1.0e-5
SIGMA_MAX_HARD = 5.0


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--reps",
    type=int,
    default=12,
    help="Replicates per template/scenario. Default=12.",
)

parser.add_argument(
    "--limit-templates",
    type=int,
    default=None,
    help="Optional pilot limit on number of templates.",
)

args = parser.parse_args()

if args.reps < 1:
    raise RuntimeError("--reps must be >= 1.")


# ============================================================
# UTILITIES
# ============================================================

def as_bool(v):
    if isinstance(v, (bool, np.bool_)):
        return bool(v)

    return str(v).strip().lower() in {
        "true",
        "1",
        "yes",
        "y",
    }


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce",
    )


def stable_seed(
    template_id,
    scenario,
    rep,
):
    token = (
        f"{BASE_SEED}|{template_id}|{scenario}|{rep}"
    ).encode("utf-8")

    return int(
        zlib.crc32(token)
        &
        0xFFFFFFFF
    )


def robust_scale(y):
    y = np.asarray(
        y,
        dtype=float,
    )

    med = np.nanmedian(y)
    mad = np.nanmedian(
        np.abs(
            y - med
        )
    )

    nmad = 1.4826 * mad

    sd = np.nanstd(
        y,
        ddof=1,
    )

    for v in [
        nmad,
        sd,
        0.05,
    ]:
        if (
            np.isfinite(v)
            and
            v > 0
        ):
            return float(v)

    return 0.05


def near_log_bound(
    tau,
    lo,
    hi,
    frac=0.02,
):
    lt = math.log(tau)
    llo = math.log(lo)
    lhi = math.log(hi)

    pos = (
        (lt - llo)
        /
        (lhi - llo)
    )

    return (
        bool(pos <= frac),
        bool(pos >= 1.0 - frac),
        float(pos),
    )


# ============================================================
# LIKELIHOODS
# ============================================================

def white_loglike_pars(
    pars,
    y,
    err,
):
    mu, log_sigma = pars

    sigma = math.exp(
        log_sigma
    )

    var = (
        err ** 2
        +
        sigma ** 2
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= 0)
    ):
        return -np.inf

    resid = (
        y - mu
    )

    return -0.5 * float(
        np.sum(
            np.log(
                2.0
                *
                np.pi
                *
                var
            )
            +
            resid ** 2
            /
            var
        )
    )


def drw_loglike_pars(
    pars,
    t,
    y,
    err,
):
    mu, log_tau, log_sigma = pars

    tau = math.exp(
        log_tau
    )
    sigma = math.exp(
        log_sigma
    )

    if not (
        np.isfinite(mu)
        and
        np.isfinite(tau)
        and
        np.isfinite(sigma)
        and
        tau > 0
        and
        sigma > 0
    ):
        return -np.inf

    sigma2 = sigma ** 2

    m_pred = 0.0
    p_pred = sigma2
    ll = 0.0

    n = len(t)

    for i in range(n):
        obs_var = (
            p_pred
            +
            err[i] ** 2
        )

        if not (
            np.isfinite(obs_var)
            and
            obs_var > 0
        ):
            return -np.inf

        innov = (
            y[i]
            -
            mu
            -
            m_pred
        )

        ll += -0.5 * (
            math.log(
                2.0
                *
                math.pi
                *
                obs_var
            )
            +
            innov ** 2
            /
            obs_var
        )

        gain = (
            p_pred
            /
            obs_var
        )

        m_post = (
            m_pred
            +
            gain
            *
            innov
        )

        p_post = (
            p_pred
            *
            (
                1.0
                -
                gain
            )
        )

        if i == n - 1:
            break

        dt = (
            t[i + 1]
            -
            t[i]
        )

        if not (
            np.isfinite(dt)
            and
            dt >= 0
        ):
            return -np.inf

        a = math.exp(
            -dt
            /
            tau
        )

        q = (
            sigma2
            *
            (
                -math.expm1(
                    -2.0
                    *
                    dt
                    /
                    tau
                )
            )
        )

        m_pred = (
            a
            *
            m_post
        )

        p_pred = (
            a ** 2
            *
            p_post
            +
            q
        )

    return float(
        ll
    )


# ============================================================
# FITTERS
# ============================================================

def fit_white(
    y,
    err,
):
    med = float(
        np.median(y)
    )

    sd = robust_scale(
        y
    )

    mu_pad = max(
        2.0,
        5.0 * sd,
    )

    sigma_hi = min(
        SIGMA_MAX_HARD,
        max(
            1.0,
            10.0 * sd,
        ),
    )

    bounds = [
        (
            med - mu_pad,
            med + mu_pad,
        ),
        (
            math.log(SIGMA_MIN),
            math.log(sigma_hi),
        ),
    ]

    starts = [
        [
            med,
            math.log(
                max(
                    SIGMA_MIN,
                    min(
                        sigma_hi,
                        sd,
                    ),
                )
            ),
        ],
        [
            float(
                np.mean(y)
            ),
            math.log(
                max(
                    SIGMA_MIN,
                    min(
                        sigma_hi,
                        0.5 * sd,
                    ),
                )
            ),
        ],
    ]

    best = None

    for start in starts:
        start = np.asarray(
            [
                np.clip(
                    start[0],
                    bounds[0][0],
                    bounds[0][1],
                ),
                np.clip(
                    start[1],
                    bounds[1][0],
                    bounds[1][1],
                ),
            ],
            dtype=float,
        )

        res = minimize(
            lambda p: -white_loglike_pars(
                p,
                y,
                err,
            ),
            x0=start,
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 250,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(
            res.fun
        ):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    mu, log_sigma = best.x

    return {
        "success": bool(
            best.success
        ),
        "mu": float(mu),
        "sigma_intrinsic": float(
            math.exp(
                log_sigma
            )
        ),
        "loglike": float(
            -best.fun
        ),
    }


def fit_drw(
    t,
    y,
    err,
    cadence,
    baseline,
):
    med = float(
        np.median(y)
    )

    sd = robust_scale(
        y
    )

    tau_low = max(
        0.5,
        0.25 * cadence,
    )

    tau_high = max(
        100.0,
        10.0 * baseline,
    )

    mu_pad = max(
        2.0,
        5.0 * sd,
    )

    sigma_hi = min(
        SIGMA_MAX_HARD,
        max(
            1.0,
            10.0 * sd,
        ),
    )

    bounds = [
        (
            med - mu_pad,
            med + mu_pad,
        ),
        (
            math.log(tau_low),
            math.log(tau_high),
        ),
        (
            math.log(SIGMA_MIN),
            math.log(sigma_hi),
        ),
    ]

    tau_candidates = [
        max(
            tau_low,
            min(
                tau_high,
                3.0 * cadence,
            ),
        ),
        max(
            tau_low,
            min(
                tau_high,
                math.sqrt(
                    max(
                        3.0 * cadence,
                        tau_low,
                    )
                    *
                    max(
                        0.05 * baseline,
                        tau_low,
                    )
                ),
            ),
        ),
        max(
            tau_low,
            min(
                tau_high,
                0.05 * baseline,
            ),
        ),
    ]

    starts = []

    for tau0 in tau_candidates:
        starts.append(
            [
                med,
                math.log(
                    tau0
                ),
                math.log(
                    max(
                        SIGMA_MIN,
                        min(
                            sigma_hi,
                            sd,
                        ),
                    )
                ),
            ]
        )

    best = None

    for start in starts:
        start = np.asarray(
            [
                np.clip(
                    start[0],
                    bounds[0][0],
                    bounds[0][1],
                ),
                np.clip(
                    start[1],
                    bounds[1][0],
                    bounds[1][1],
                ),
                np.clip(
                    start[2],
                    bounds[2][0],
                    bounds[2][1],
                ),
            ],
            dtype=float,
        )

        res = minimize(
            lambda p: -drw_loglike_pars(
                p,
                t,
                y,
                err,
            ),
            x0=start,
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 400,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(
            res.fun
        ):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    mu, log_tau, log_sigma = (
        best.x
    )

    tau = float(
        math.exp(
            log_tau
        )
    )

    near_lo, near_hi, logpos = near_log_bound(
        tau,
        tau_low,
        tau_high,
        frac=0.02,
    )

    return {
        "success": bool(
            best.success
        ),
        "mu": float(mu),
        "tau": tau,
        "sigma_stationary": float(
            math.exp(
                log_sigma
            )
        ),
        "loglike": float(
            -best.fun
        ),
        "tau_low": float(
            tau_low
        ),
        "tau_high": float(
            tau_high
        ),
        "near_lo": near_lo,
        "near_hi": near_hi,
        "logpos": logpos,
    }


# ============================================================
# SIMULATORS
# ============================================================

def simulate_white(
    rng,
    mu,
    sigma_intrinsic,
    err,
):
    intrinsic = rng.normal(
        0.0,
        sigma_intrinsic,
        size=len(err),
    )

    measurement = rng.normal(
        0.0,
        err,
    )

    return (
        mu
        +
        intrinsic
        +
        measurement
    )


def simulate_ou(
    rng,
    t,
    mu,
    tau,
    sigma_stationary,
    err,
):
    n = len(t)

    latent = np.empty(
        n,
        dtype=float,
    )

    latent[0] = rng.normal(
        0.0,
        sigma_stationary,
    )

    sigma2 = (
        sigma_stationary ** 2
    )

    for i in range(
        1,
        n,
    ):
        dt = (
            t[i]
            -
            t[i - 1]
        )

        a = math.exp(
            -dt
            /
            tau
        )

        q = (
            sigma2
            *
            (
                -math.expm1(
                    -2.0
                    *
                    dt
                    /
                    tau
                )
            )
        )

        latent[i] = (
            a
            *
            latent[i - 1]
            +
            rng.normal(
                0.0,
                math.sqrt(
                    max(
                        q,
                        0.0,
                    )
                ),
            )
        )

    measurement = rng.normal(
        0.0,
        err,
    )

    return (
        mu
        +
        latent
        +
        measurement
    )


# ============================================================
# ONE REPLICATE
# ============================================================

def run_one(
    template_row,
    drw_row,
    scenario,
    rep,
):
    bid = str(
        template_row[
            "blazar_id"
        ]
    )

    filt = str(
        template_row[
            "filter_name"
        ]
    ).lower()

    template_id = str(
        template_row[
            "template_id"
        ]
    )

    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    d = pd.read_parquet(
        path
    )

    x = d.loc[
        d["filter_name"]
        .astype(str)
        .str.lower()
        .eq(filt)
    ].copy()

    x = (
        x.sort_values(
            "hmjd"
        )
        .reset_index(
            drop=True
        )
    )

    t = numeric(
        x["hmjd"]
    ).to_numpy(
        dtype=float
    )

    mag = numeric(
        x["mag"]
    ).to_numpy(
        dtype=float
    )

    err = numeric(
        x["magerr"]
    ).to_numpy(
        dtype=float
    )

    good = (
        np.isfinite(t)
        &
        np.isfinite(mag)
        &
        np.isfinite(err)
        &
        (err > 0)
    )

    t = t[good]
    mag = mag[good]
    err = err[good]

    if len(t) < 50:
        raise RuntimeError(
            f"{template_id}: too few valid nightly points"
        )

    baseline = float(
        t[-1] - t[0]
    )

    cadence = float(
        np.median(
            np.diff(t)
        )
    )

    mu = float(
        np.median(
            mag
        )
    )

    sigma_obs = robust_scale(
        mag
    )

    sigma_frozen = pd.to_numeric(
        pd.Series(
            [
                drw_row[
                    "sigma_drw_stationary_mag"
                ]
            ]
        ),
        errors="coerce",
    ).iloc[0]

    if not np.isfinite(
        sigma_frozen
    ):
        sigma_frozen = sigma_obs

    sigma_inj = float(
        np.clip(
            sigma_frozen,
            0.03,
            1.0,
        )
    )

    tau_short = max(
        3.0 * cadence,
        1.0,
    )

    tau_long = (
        0.08
        *
        baseline
    )

    tau_mid = math.sqrt(
        tau_short
        *
        (
            0.05
            *
            baseline
        )
    )

    tau_true_map = {
        "WHITE_NULL": np.nan,
        "OU_SHORT": tau_short,
        "OU_MID": tau_mid,
        "OU_LONG": tau_long,
    }

    tau_true = tau_true_map[
        scenario
    ]

    rng = np.random.default_rng(
        stable_seed(
            template_id,
            scenario,
            rep,
        )
    )

    if scenario == "WHITE_NULL":
        y = simulate_white(
            rng,
            mu=mu,
            sigma_intrinsic=sigma_inj,
            err=err,
        )
    else:
        y = simulate_ou(
            rng,
            t=t,
            mu=mu,
            tau=tau_true,
            sigma_stationary=sigma_inj,
            err=err,
        )

    white = fit_white(
        y,
        err,
    )

    drw = fit_drw(
        t,
        y,
        err,
        cadence=cadence,
        baseline=baseline,
    )

    row = {
        "template_id": template_id,
        "blazar_id": bid,
        "blazar_class": template_row[
            "blazar_class"
        ],
        "filter_name": filt,
        "scenario": scenario,
        "replicate": int(rep),
        "N_nightly": int(
            len(t)
        ),
        "baseline_days": baseline,
        "median_cadence_days": cadence,
        "median_magerr": float(
            np.median(
                err
            )
        ),
        "sigma_injected_mag": sigma_inj,
        "tau_true_days": (
            float(
                tau_true
            )
            if np.isfinite(
                tau_true
            )
            else np.nan
        ),
        "fit_status": "NOT_RUN",
    }

    if white is None:
        row[
            "fit_status"
        ] = "WHITE_FIT_FAILED"
        return row

    if drw is None:
        row[
            "fit_status"
        ] = "DRW_FIT_FAILED"
        return row

    n = len(t)

    bic_white = (
        2.0
        *
        math.log(n)
        -
        2.0
        *
        white[
            "loglike"
        ]
    )

    bic_drw = (
        3.0
        *
        math.log(n)
        -
        2.0
        *
        drw[
            "loglike"
        ]
    )

    delta_bic = (
        bic_white
        -
        bic_drw
    )

    tau_hat = drw[
        "tau"
    ]

    gate = (
        bool(
            drw[
                "success"
            ]
        )
        and
        delta_bic >= 10.0
        and
        tau_hat >= 2.0 * cadence
        and
        tau_hat <= baseline / 10.0
        and
        not drw[
            "near_lo"
        ]
        and
        not drw[
            "near_hi"
        ]
    )

    if np.isfinite(
        tau_true
    ):
        ratio = (
            tau_hat
            /
            tau_true
        )

        abs_log10_ratio = abs(
            math.log10(
                ratio
            )
        )

        within_factor2 = bool(
            0.5
            <=
            ratio
            <=
            2.0
        )
    else:
        ratio = np.nan
        abs_log10_ratio = np.nan
        within_factor2 = np.nan

    row.update({
        "optimizer_success_white": bool(
            white[
                "success"
            ]
        ),
        "optimizer_success_drw": bool(
            drw[
                "success"
            ]
        ),
        "bic_white": bic_white,
        "bic_drw": bic_drw,
        "delta_bic_white_minus_drw": delta_bic,
        "tau_hat_days": tau_hat,
        "tau_over_cadence": (
            tau_hat
            /
            cadence
        ),
        "tau_over_baseline": (
            tau_hat
            /
            baseline
        ),
        "near_lower_bound": bool(
            drw[
                "near_lo"
            ]
        ),
        "near_upper_bound": bool(
            drw[
                "near_hi"
            ]
        ),
        "tau_interpretable_gate": bool(
            gate
        ),
        "tau_hat_over_true": ratio,
        "abs_log10_tau_ratio": abs_log10_ratio,
        "within_factor2_true": within_factor2,
        "fit_status": "OK",
    })

    return row


# ============================================================
# LOAD INPUTS
# ============================================================

for path in [
    TEMPLATE_FILE,
    DRW_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

templates = pd.read_csv(
    TEMPLATE_FILE,
    low_memory=False,
)

drw_master = pd.read_csv(
    DRW_FILE,
    low_memory=False,
)

templates["blazar_id"] = (
    templates["blazar_id"]
    .astype(str)
)

drw_master["blazar_id"] = (
    drw_master["blazar_id"]
    .astype(str)
)

templates["filter_name"] = (
    templates["filter_name"]
    .astype(str)
    .str.lower()
)

drw_master["filter_name"] = (
    drw_master["filter_name"]
    .astype(str)
    .str.lower()
)

if args.limit_templates is not None:
    templates = templates.head(
        args.limit_templates
    ).copy()

if len(templates) == 0:
    raise RuntimeError(
        "No templates selected."
    )

drw_lookup = (
    drw_master
    .set_index(
        [
            "blazar_id",
            "filter_name",
        ]
    )
)

print(
    "=" * 80
)
print(
    "BLAZAR_I — STAGE 09C1 DRW CALIBRATION"
)
print(
    "=" * 80
)
print(
    "Templates =", len(templates)
)
print(
    "Scenarios =", len(SCENARIOS)
)
print(
    "Replicates per scenario/template =", args.reps
)
print(
    "Target fits =",
    len(templates)
    *
    len(SCENARIOS)
    *
    args.reps,
)


# ============================================================
# RESUMABLE CELL LOOP
# ============================================================

all_frames = []

cell_index = 0
n_cells = (
    len(templates)
    *
    len(SCENARIOS)
)

t0 = time.time()

for _, template_row in templates.iterrows():
    key = (
        str(
            template_row[
                "blazar_id"
            ]
        ),
        str(
            template_row[
                "filter_name"
            ]
        ).lower(),
    )

    if key not in drw_lookup.index:
        raise RuntimeError(
            f"Template key absent from Stage03D: {key}"
        )

    drw_row = drw_lookup.loc[
        key
    ]

    if isinstance(
        drw_row,
        pd.DataFrame,
    ):
        if len(drw_row) != 1:
            raise RuntimeError(
                f"Duplicate Stage03D key: {key}"
            )
        drw_row = drw_row.iloc[0]

    template_id = str(
        template_row[
            "template_id"
        ]
    )

    for scenario in SCENARIOS:
        cell_index += 1

        cell_file = (
            MODEL_DIR
            /
            f"{template_id}_{scenario}.csv"
        )

        if cell_file.exists():
            prev = pd.read_csv(
                cell_file,
                low_memory=False,
            )
        else:
            prev = pd.DataFrame()

        done_reps = set()

        if (
            len(prev)
            and
            "replicate" in prev.columns
        ):
            done_reps = set(
                pd.to_numeric(
                    prev[
                        "replicate"
                    ],
                    errors="coerce",
                )
                .dropna()
                .astype(int)
                .tolist()
            )

        rows = []

        for rep in range(
            1,
            args.reps + 1,
        ):
            if rep in done_reps:
                continue

            try:
                row = run_one(
                    template_row,
                    drw_row,
                    scenario,
                    rep,
                )
            except Exception as exc:
                row = {
                    "template_id": template_id,
                    "blazar_id": template_row[
                        "blazar_id"
                    ],
                    "blazar_class": template_row[
                        "blazar_class"
                    ],
                    "filter_name": template_row[
                        "filter_name"
                    ],
                    "scenario": scenario,
                    "replicate": rep,
                    "fit_status": (
                        f"EXCEPTION:{type(exc).__name__}:"
                        f"{exc}"
                    ),
                }

            rows.append(
                row
            )

            # Save after every replicate so a power/network interruption
            # loses at most one simulation.
            current = pd.concat(
                [
                    prev,
                    pd.DataFrame(
                        rows
                    ),
                ],
                ignore_index=True,
            )

            current = (
                current
                .sort_values(
                    "replicate"
                )
                .drop_duplicates(
                    "replicate",
                    keep="last",
                )
            )

            current.to_csv(
                cell_file,
                index=False,
            )

        final_cell = pd.read_csv(
            cell_file,
            low_memory=False,
        )

        all_frames.append(
            final_cell.loc[
                pd.to_numeric(
                    final_cell[
                        "replicate"
                    ],
                    errors="coerce",
                )
                <=
                args.reps
            ].copy()
        )

        elapsed = (
            time.time()
            -
            t0
        )

        print(
            f"Cell {cell_index}/{n_cells} "
            f"{template_id} {scenario}: "
            f"saved_reps={len(final_cell)} "
            f"elapsed={elapsed/60.0:.1f} min"
        )


# ============================================================
# AGGREGATE
# ============================================================

master = pd.concat(
    all_frames,
    ignore_index=True,
)

master.to_csv(
    OUT_MASTER,
    index=False,
)

master[
    "gate_bool"
] = (
    master[
        "tau_interpretable_gate"
    ]
    .astype(str)
    .str.strip()
    .str.lower()
    .isin(
        [
            "true",
            "1",
            "yes",
            "y",
        ]
    )
)

master[
    "within_factor2_bool"
] = (
    master[
        "within_factor2_true"
    ]
    .astype(str)
    .str.strip()
    .str.lower()
    .isin(
        [
            "true",
            "1",
            "yes",
            "y",
        ]
    )
)

master[
    "fit_ok"
] = (
    master[
        "fit_status"
    ]
    .astype(str)
    .eq(
        "OK"
    )
)


# ============================================================
# SCENARIO SUMMARY
# ============================================================

scenario_rows = []

for scenario, g in master.groupby(
    "scenario",
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    row = {
        "scenario": scenario,
        "N_simulations": len(g),
        "N_fit_ok": len(ok),
        "fit_ok_fraction": (
            len(ok) / len(g)
            if len(g)
            else np.nan
        ),
        "gate_positive_N": int(
            ok[
                "gate_bool"
            ].sum()
        ),
        "gate_positive_fraction": (
            float(
                ok[
                    "gate_bool"
                ].mean()
            )
            if len(ok)
            else np.nan
        ),
        "median_delta_bic": (
            numeric(
                ok[
                    "delta_bic_white_minus_drw"
                ]
            )
            .median()
            if len(ok)
            else np.nan
        ),
    }

    if scenario != "WHITE_NULL":
        ratios = numeric(
            ok[
                "tau_hat_over_true"
            ]
        ).replace(
            [np.inf, -np.inf],
            np.nan,
        ).dropna()

        abslog = numeric(
            ok[
                "abs_log10_tau_ratio"
            ]
        ).dropna()

        row.update({
            "tau_ratio_median": (
                ratios.median()
                if len(ratios)
                else np.nan
            ),
            "tau_ratio_p16": (
                ratios.quantile(
                    0.16
                )
                if len(ratios)
                else np.nan
            ),
            "tau_ratio_p84": (
                ratios.quantile(
                    0.84
                )
                if len(ratios)
                else np.nan
            ),
            "median_abs_log10_tau_ratio": (
                abslog.median()
                if len(abslog)
                else np.nan
            ),
            "within_factor2_fraction": (
                float(
                    ok[
                        "within_factor2_bool"
                    ].mean()
                )
                if len(ok)
                else np.nan
            ),
            "gate_and_factor2_fraction": (
                float(
                    (
                        ok[
                            "gate_bool"
                        ]
                        &
                        ok[
                            "within_factor2_bool"
                        ]
                    ).mean()
                )
                if len(ok)
                else np.nan
            ),
        })

    scenario_rows.append(
        row
    )

scenario_summary = pd.DataFrame(
    scenario_rows
)

scenario_summary.to_csv(
    OUT_SCEN,
    index=False,
)


# ============================================================
# TEMPLATE-LEVEL SUMMARY
# ============================================================

template_rows = []

for (
    template_id,
    scenario,
), g in master.groupby(
    [
        "template_id",
        "scenario",
    ]
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    ratios = numeric(
        ok.get(
            "tau_hat_over_true",
            pd.Series(
                dtype=float
            ),
        )
    ).replace(
        [np.inf, -np.inf],
        np.nan,
    ).dropna()

    template_rows.append({
        "template_id": template_id,
        "scenario": scenario,
        "N_simulations": len(g),
        "N_fit_ok": len(ok),
        "gate_positive_fraction": (
            float(
                ok[
                    "gate_bool"
                ].mean()
            )
            if len(ok)
            else np.nan
        ),
        "tau_ratio_median": (
            ratios.median()
            if len(ratios)
            else np.nan
        ),
        "within_factor2_fraction": (
            float(
                ok[
                    "within_factor2_bool"
                ].mean()
            )
            if (
                len(ok)
                and
                scenario != "WHITE_NULL"
            )
            else np.nan
        ),
    })

template_summary = pd.DataFrame(
    template_rows
)

template_summary.to_csv(
    OUT_TEMPLATE,
    index=False,
)


# ============================================================
# FINAL SUMMARY
# ============================================================

def get_scenario(
    name,
):
    hit = scenario_summary.loc[
        scenario_summary[
            "scenario"
        ]
        .eq(
            name
        )
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


lines = [
    "BLAZAR_I - STAGE 09C1 FINAL SUMMARY",
    "=" * 80,
    "",
    "DRW observation-conditioned null / injection-recovery calibration",
    "",
    f"Templates                       : {len(templates)}",
    f"Replicates/template/scenario    : {args.reps}",
    f"Total simulations               : {len(master)}",
    "",
]

null = get_scenario(
    "WHITE_NULL"
)

if null is not None:
    lines += [
        "WHITE_NULL:",
        f"  fit success fraction          : {null['fit_ok_fraction']:.4f}",
        f"  false-positive DRW gate rate  : {null['gate_positive_fraction']:.4f}",
        f"  median DeltaBIC               : {null['median_delta_bic']:.3f}",
        "",
    ]

for name in [
    "OU_SHORT",
    "OU_MID",
    "OU_LONG",
]:
    r = get_scenario(
        name
    )

    if r is None:
        continue

    lines += [
        f"{name}:",
        f"  fit success fraction          : {r['fit_ok_fraction']:.4f}",
        f"  DRW gate recovery             : {r['gate_positive_fraction']:.4f}",
        f"  median tau_hat/tau_true       : {r['tau_ratio_median']:.3f}",
        f"  16-84% tau ratio              : [{r['tau_ratio_p16']:.3f}, {r['tau_ratio_p84']:.3f}]",
        f"  within factor 2               : {r['within_factor2_fraction']:.4f}",
        f"  gate AND within factor 2      : {r['gate_and_factor2_fraction']:.4f}",
        "",
    ]

lines += [
    "Interpretation locks:",
    "  - WHITE_NULL gate-positive fraction estimates the empirical false",
    "    positive rate under observation-conditioned uncorrelated variability.",
    "  - OU recovery measures detection + timescale estimation under actual",
    "    ZTF cadence/error patterns, not an idealized regular grid.",
    "  - Short/mid/long regimes probe cadence proximity, central sensitivity,",
    "    and the upper interpretability-gate neighborhood.",
    "  - These simulations calibrate the diagnostic; they do not prove that",
    "    real blazar variability is exactly an OU process.",
    "",
    "Files saved:",
    f"  {OUT_MASTER}",
    f"  {OUT_SCEN}",
    f"  {OUT_TEMPLATE}",
    "",
    "Checkpoint directory:",
    f"  {MODEL_DIR}",
    "",
    "Next:",
    "  STAGE 09C2 — colour-break false-positive and injection recovery.",
    "",
    "STAGE 09C1 COMPLETE",
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(
    summary
)
