# ============================================================
# BLAZAR_I — STAGE 06B2
# CONTROLLED CLASS EFFECT + POSITIVE-BREAK STABILITY
#
# Inputs:
#   outputs/tables/stage06b1_colour_erroraware_master.csv
#   outputs/tables/stage03c_colour_pairs_master.parquet
#
# Goals:
#   1) Test the FSRQ/BLL difference in robust error-aware breaks
#      at T6H, T2H, T1H after controlling detectability.
#   2) Separate a minimal detectability model from a
#      dynamic-range sensitivity model.
#   3) Repeat on a common source set that has successful fits
#      at all three timing cuts, so changing sample composition
#      cannot drive the trend.
#   4) Quantify positive-class retention as timing is tightened.
#
# Minimal detectability controls:
#   log1p(N_pairs), median |dt|, median colour error
#
# Dynamic-range sensitivity additionally controls:
#   r_mag_range
#
# Upstream frozen products are read-only.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

MASTER_FILE = TABLE_DIR / "stage06b1_colour_erroraware_master.csv"
PAIR_FILE = TABLE_DIR / "stage03c_colour_pairs_master.parquet"

OUT_MODELS = TABLE_DIR / "stage06b2_colour_class_controlled.csv"
OUT_STABILITY = TABLE_DIR / "stage06b2_positive_break_stability.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06b2_summary.txt"

CUTS = {
    "T6H": 6.0,
    "T2H": 2.0,
    "T1H": 1.0,
}


def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)
    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def safe_log1p(s):
    x = numeric(s)
    out = pd.Series(np.nan, index=x.index, dtype=float)
    good = np.isfinite(x) & (x >= 0)
    out.loc[good] = np.log1p(x.loc[good])
    return out


def zscore_inplace(df, cols):
    for c in cols:
        x = numeric(df[c])
        mu = x.mean()
        sd = x.std(ddof=1)
        if np.isfinite(sd) and sd > 0:
            df[c] = (x - mu) / sd
        else:
            df[c] = np.nan


def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)
    valid = np.isfinite(p)
    if valid.sum() == 0:
        return q
    pv = p[valid]
    m = len(pv)
    order = np.argsort(pv)
    ranked = pv[order]
    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)
    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[valid] = qv
    return q


def fit_logit(df, outcome, predictors, model_name, standardize):
    w = df[[outcome] + predictors].copy()
    w[outcome] = as_bool(w[outcome]).astype(int)

    for c in predictors:
        w[c] = numeric(w[c])

    w = w.replace([np.inf, -np.inf], np.nan).dropna()
    zscore_inplace(w, standardize)
    w = w.dropna()

    y = w[outcome].astype(float)
    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add"
    )

    fit = sm.GLM(
        y,
        X,
        family=sm.families.Binomial(),
    ).fit(
        cov_type="HC3",
        maxiter=300,
    )

    ci = fit.conf_int()
    beta = float(fit.params["FSRQ"])

    return {
        "model_name": model_name,
        "N": int(len(w)),
        "N_event": int(y.sum()),
        "event_fraction": float(y.mean()),
        "odds_ratio_FSRQ": math.exp(beta),
        "or_ci95_low": math.exp(float(ci.loc["FSRQ", 0])),
        "or_ci95_high": math.exp(float(ci.loc["FSRQ", 1])),
        "p_value": float(fit.pvalues["FSRQ"]),
        "aic": float(fit.aic),
    }


for path in [MASTER_FILE, PAIR_FILE]:
    if not path.exists():
        raise FileNotFoundError(path)

m = pd.read_csv(MASTER_FILE)
pairs = pd.read_parquet(PAIR_FILE)

m["blazar_id"] = m["blazar_id"].astype(str)
pairs["blazar_id"] = pairs["blazar_id"].astype(str)

m["robust_flag"] = as_bool(
    m["robust_central_break_bic20_ea"]
)

m["FSRQ"] = (
    m["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

# ------------------------------------------------------------
# Source/cut detectability summaries directly from frozen pairs.
# ------------------------------------------------------------

detect_rows = []

for cut, hours in CUTS.items():
    x = pairs.loc[
        numeric(pairs["dt_gr_hours"]).abs() <= hours,
        [
            "blazar_id",
            "dt_gr_hours",
            "g_minus_r_err",
        ],
    ].copy()

    g = x.groupby("blazar_id", sort=False)

    stat = g.agg(
        N_pairs_check=("blazar_id", "size"),
        pair_dt_hours_median=("dt_gr_hours", "median"),
        colour_err_median=("g_minus_r_err", "median"),
    ).reset_index()

    stat["timing_cut"] = cut
    detect_rows.append(stat)

detect = pd.concat(detect_rows, ignore_index=True)

d = m.merge(
    detect,
    on=["blazar_id", "timing_cut"],
    how="left",
    validate="one_to_one",
)

d["logNpairs"] = safe_log1p(d["N_pairs"])

# Check pair-count consistency.
count_mismatch = int(
    (
        numeric(d["N_pairs"])
        !=
        numeric(d["N_pairs_check"])
    ).fillna(True).sum()
)

if count_mismatch != 0:
    raise RuntimeError(
        f"N_pairs mismatch between 06B1 master and frozen pair table: {count_mismatch}"
    )

# ------------------------------------------------------------
# Common-fit source set.
# ------------------------------------------------------------

ok = (
    d["fit_status"]
    .astype(str)
    .eq("OK")
)

ok_wide = (
    d.assign(ok=ok)
    .pivot(
        index="blazar_id",
        columns="timing_cut",
        values="ok"
    )
)

common_ids = ok_wide.index[
    ok_wide[list(CUTS)].all(axis=1)
]

# ------------------------------------------------------------
# Controlled models.
# ------------------------------------------------------------

model_rows = []

minimal_controls = [
    "logNpairs",
    "pair_dt_hours_median",
    "colour_err_median",
]

range_controls = minimal_controls + [
    "r_mag_range",
]

for cut in CUTS:
    x = d.loc[
        d["timing_cut"].eq(cut)
        &
        d["fit_status"].astype(str).eq("OK")
    ].copy()

    # Cut-specific sample.
    row = fit_logit(
        x,
        outcome="robust_flag",
        predictors=["FSRQ"] + minimal_controls,
        model_name=f"{cut}_CUTSPEC_MINIMAL",
        standardize=minimal_controls,
    )
    row["timing_cut"] = cut
    row["sample_definition"] = "cut_specific_fit_OK"
    row["control_set"] = "minimal_detectability"
    model_rows.append(row)

    row = fit_logit(
        x,
        outcome="robust_flag",
        predictors=["FSRQ"] + range_controls,
        model_name=f"{cut}_CUTSPEC_PLUS_RANGE",
        standardize=range_controls,
    )
    row["timing_cut"] = cut
    row["sample_definition"] = "cut_specific_fit_OK"
    row["control_set"] = "plus_dynamic_range"
    model_rows.append(row)

    # Common all-cut source sample.
    xc = x.loc[
        x["blazar_id"].isin(common_ids)
    ].copy()

    row = fit_logit(
        xc,
        outcome="robust_flag",
        predictors=["FSRQ"] + minimal_controls,
        model_name=f"{cut}_COMMON_MINIMAL",
        standardize=minimal_controls,
    )
    row["timing_cut"] = cut
    row["sample_definition"] = "fit_OK_all_three_cuts"
    row["control_set"] = "minimal_detectability"
    model_rows.append(row)

    row = fit_logit(
        xc,
        outcome="robust_flag",
        predictors=["FSRQ"] + range_controls,
        model_name=f"{cut}_COMMON_PLUS_RANGE",
        standardize=range_controls,
    )
    row["timing_cut"] = cut
    row["sample_definition"] = "fit_OK_all_three_cuts"
    row["control_set"] = "plus_dynamic_range"
    model_rows.append(row)

models = pd.DataFrame(model_rows)

models["q_BH_all_class_models"] = bh_qvalues(
    models["p_value"].to_numpy(dtype=float)
)

for sample_def in models["sample_definition"].unique():
    for control_set in models["control_set"].unique():
        mask = (
            models["sample_definition"].eq(sample_def)
            &
            models["control_set"].eq(control_set)
        )
        models.loc[
            mask,
            "q_BH_within_family"
        ] = bh_qvalues(
            models.loc[
                mask,
                "p_value"
            ].to_numpy(dtype=float)
        )

models.to_csv(OUT_MODELS, index=False)

# ------------------------------------------------------------
# Positive-break retention / overlap.
# ------------------------------------------------------------

stability_rows = []

base = d.loc[
    d["timing_cut"].eq("T6H")
    &
    d["fit_status"].astype(str).eq("OK"),
    ["blazar_id", "robust_flag"]
].set_index("blazar_id")

for cut in ["T2H", "T1H"]:
    tight = d.loc[
        d["timing_cut"].eq(cut)
        &
        d["fit_status"].astype(str).eq("OK"),
        ["blazar_id", "robust_flag"]
    ].set_index("blazar_id")

    ids = base.index.intersection(tight.index)

    a = base.loc[ids, "robust_flag"].astype(bool)
    b = tight.loc[ids, "robust_flag"].astype(bool)

    n_base_pos = int(a.sum())
    n_tight_pos = int(b.sum())
    n_both = int((a & b).sum())

    stability_rows.append({
        "comparison": f"T6H_vs_{cut}",
        "N_common_fit_OK": int(len(ids)),
        "T6H_positive_N": n_base_pos,
        f"{cut}_positive_N": n_tight_pos,
        "both_positive_N": n_both,
        "retention_of_T6H_positive": (
            n_both / n_base_pos
            if n_base_pos > 0 else np.nan
        ),
        "fraction_of_tight_positive_also_T6H": (
            n_both / n_tight_pos
            if n_tight_pos > 0 else np.nan
        ),
    })

stability = pd.DataFrame(stability_rows)
stability.to_csv(OUT_STABILITY, index=False)

# ------------------------------------------------------------
# Summary.
# ------------------------------------------------------------

lines = [
    "BLAZAR_I - STAGE 06B2 FINAL SUMMARY",
    "=" * 72,
    "",
    f"Sources fit OK at all three cuts: {len(common_ids)}",
    "",
    "CONTROLLED FSRQ CLASS EFFECTS:",
]

for _, rr in models.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['odds_ratio_FSRQ']:.3f}, "
        f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
        f"p={rr['p_value']:.3g}, "
        f"q_family={rr['q_BH_within_family']:.3g}"
    )

lines += [
    "",
    "POSITIVE-BREAK RETENTION:",
]

for _, rr in stability.iterrows():
    cut = rr["comparison"].split("_vs_")[1]
    lines.append(
        f"  {rr['comparison']}: "
        f"Ncommon={int(rr['N_common_fit_OK'])}, "
        f"T6H+={int(rr['T6H_positive_N'])}, "
        f"{cut}+={int(rr[f'{cut}_positive_N'])}, "
        f"both={int(rr['both_positive_N'])}, "
        f"retain_T6H={rr['retention_of_T6H_positive']:.3f}, "
        f"tight_positive_also_T6H={rr['fraction_of_tight_positive_also_T6H']:.3f}"
    )

summary = "\n".join(lines)
OUT_SUMMARY.write_text(summary, encoding="utf-8")

print("=" * 78)
print("BLAZAR_I — STAGE 06B2")
print("CONTROLLED CLASS EFFECT + POSITIVE-BREAK STABILITY")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_MODELS)
print(OUT_STABILITY)
print(OUT_SUMMARY)
print()
print("STAGE 06B2 COMPLETE")
