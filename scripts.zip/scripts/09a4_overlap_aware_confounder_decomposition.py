# ============================================================
# BLAZAR_I — STAGE 09A4
# OVERLAP-AWARE CONFOUNDER DECOMPOSITION
#
# Motivation:
#   Stage 09A3 showed large coefficient movement after the block
#   {redshift + SED + gamma} was added. However optical class and
#   synchrotron SED class have severe non-overlap (especially HSP FSRQs).
#
# Scientific goal:
#   Separate genuine adjustment from non-identifiable / overlap-poor
#   adjustment. Do NOT treat a global optical-class coefficient adjusted
#   for SED as a primary estimand when SED support is nearly absent in one
#   optical class.
#
# Strategy:
#   A) Audit optical-class x SED support explicitly.
#   B) Refit nested class models WITHOUT SED in the all-class sequence:
#        Z0 coverage
#        Z1 + redshift
#        Z2 + gamma
#        Z3 + optical brightness
#        Z4 + PS1 host proxy
#      on the SAME known-z/HQ-host endpoint-specific sample.
#   C) Repeat within LSP only, where both FSRQ and BLL have usable overlap.
#   D) Fit the SED-adjusted all-class model only as a DIAGNOSTIC of
#      coefficient instability; mark it non-primary.
#   E) Refit the flagship rms-flux -> colour association using the same
#      overlap-aware logic.
#
# No continuous DRW tau model is fit here.
#
# Outputs:
#   outputs/tables/stage09a4_sed_overlap_audit.csv
#   outputs/tables/stage09a4_overlap_aware_binary_models.csv
#   outputs/tables/stage09a4_lsp_only_binary_models.csv
#   outputs/tables/stage09a4_rmflux_colour_models.csv
#   outputs/tables/stage09a4_design_diagnostics.csv
#   outputs/audit/stage09a4_summary.txt
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import chi2_contingency
from statsmodels.stats.outliers_influence import variance_inflation_factor

warnings.filterwarnings("ignore", category=RuntimeWarning)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

MASTER_FILE = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"
STAGE04_FILE = TABLE_DIR / "stage04_population_master.csv"

OUT_OVERLAP = TABLE_DIR / "stage09a4_sed_overlap_audit.csv"
OUT_BINARY = TABLE_DIR / "stage09a4_overlap_aware_binary_models.csv"
OUT_LSP = TABLE_DIR / "stage09a4_lsp_only_binary_models.csv"
OUT_XDIAG = TABLE_DIR / "stage09a4_rmflux_colour_models.csv"
OUT_DESIGN = TABLE_DIR / "stage09a4_design_diagnostics.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09a4_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def complete_mask(df, cols):
    mask = pd.Series(True, index=df.index)

    for c in cols:
        if c not in df.columns:
            raise RuntimeError(f"Missing required column: {c}")

        x = numeric(df[c]).replace([np.inf, -np.inf], np.nan)
        mask &= x.notna()

    return mask


def zscore_inplace(df, cols):
    for c in cols:
        x = numeric(df[c])
        mu = x.mean()
        sd = x.std(ddof=1)

        if np.isfinite(sd) and sd > 0:
            df[c] = (x - mu) / sd
        else:
            df[c] = np.nan


def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)

    good = np.isfinite(p)

    if good.sum() == 0:
        return q

    pv = p[good]
    order = np.argsort(pv)
    ranked = pv[order]
    m = len(ranked)

    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[good] = qv

    return q


def fit_logit(
    df,
    outcome,
    predictors,
    key_predictor,
    model_name,
    sample_name,
    subset_mask,
    standardize,
    interpretation_status="PRIMARY_SENSITIVITY",
):
    cols = [outcome, *predictors]

    w = df.loc[subset_mask, cols].copy()

    w[outcome] = as_bool(w[outcome]).astype(int)

    for c in predictors:
        w[c] = numeric(w[c])

    w = (
        w.replace([np.inf, -np.inf], np.nan)
        .dropna()
    )

    zscore_inplace(w, standardize)
    w = w.dropna()

    base = {
        "model_name": model_name,
        "sample_name": sample_name,
        "interpretation_status": interpretation_status,
        "outcome": outcome,
        "key_predictor": key_predictor,
        "N": int(len(w)),
        "N_BLL": (
            int((w["FSRQ"] == 0).sum())
            if "FSRQ" in w.columns
            else np.nan
        ),
        "N_FSRQ": (
            int((w["FSRQ"] == 1).sum())
            if "FSRQ" in w.columns
            else np.nan
        ),
    }

    if len(w) < 50:
        return {
            **base,
            "N_event": np.nan,
            "event_fraction": np.nan,
            "coef_log_odds": np.nan,
            "odds_ratio": np.nan,
            "or_ci95_low": np.nan,
            "or_ci95_high": np.nan,
            "p_value": np.nan,
            "aic": np.nan,
            "status": "TOO_FEW_ROWS",
        }

    y = w[outcome].astype(float)

    if y.nunique() < 2:
        return {
            **base,
            "N_event": int(y.sum()),
            "event_fraction": float(y.mean()),
            "coef_log_odds": np.nan,
            "odds_ratio": np.nan,
            "or_ci95_low": np.nan,
            "or_ci95_high": np.nan,
            "p_value": np.nan,
            "aic": np.nan,
            "status": "DEGENERATE_OUTCOME",
        }

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.GLM(
            y,
            X,
            family=sm.families.Binomial(),
        ).fit(
            cov_type="HC3",
            maxiter=500,
        )

        ci = fit.conf_int()

        beta = float(fit.params[key_predictor])
        lo = float(ci.loc[key_predictor, 0])
        hi = float(ci.loc[key_predictor, 1])

        return {
            **base,
            "N_event": int(y.sum()),
            "event_fraction": float(y.mean()),
            "coef_log_odds": beta,
            "odds_ratio": math.exp(beta),
            "or_ci95_low": math.exp(lo),
            "or_ci95_high": math.exp(hi),
            "p_value": float(fit.pvalues[key_predictor]),
            "aic": float(fit.aic),
            "status": "OK",
        }

    except Exception as exc:
        return {
            **base,
            "N_event": int(y.sum()),
            "event_fraction": float(y.mean()),
            "coef_log_odds": np.nan,
            "odds_ratio": np.nan,
            "or_ci95_low": np.nan,
            "or_ci95_high": np.nan,
            "p_value": np.nan,
            "aic": np.nan,
            "status": f"FIT_FAILED:{type(exc).__name__}",
        }


def design_diagnostics(
    df,
    predictors,
    sample_mask,
    design_name,
    standardize,
):
    w = df.loc[sample_mask, predictors].copy()

    for c in predictors:
        w[c] = numeric(w[c])

    w = (
        w.replace([np.inf, -np.inf], np.nan)
        .dropna()
    )

    zscore_inplace(w, standardize)
    w = w.dropna()

    rows = []

    if len(w) < 20:
        return pd.DataFrame([{
            "design_name": design_name,
            "metric": "status",
            "predictor": "",
            "value": np.nan,
            "note": "TOO_FEW_ROWS",
        }])

    X = w[predictors].astype(float).copy()

    # Drop any zero-variance columns from matrix diagnostics.
    keep = [
        c
        for c in predictors
        if np.nanstd(X[c].to_numpy(dtype=float)) > 0
    ]

    X = X[keep]

    if len(keep) == 0:
        return pd.DataFrame()

    Xc = sm.add_constant(
        X,
        has_constant="add",
    )

    try:
        cond = float(
            np.linalg.cond(
                Xc.to_numpy(dtype=float)
            )
        )
    except Exception:
        cond = np.nan

    rows.append({
        "design_name": design_name,
        "metric": "condition_number",
        "predictor": "",
        "value": cond,
        "note": f"N={len(w)}",
    })

    arr = Xc.to_numpy(dtype=float)

    for j, c in enumerate(Xc.columns):
        if c == "const":
            continue

        try:
            vif = float(
                variance_inflation_factor(
                    arr,
                    j,
                )
            )
        except Exception:
            vif = np.nan

        rows.append({
            "design_name": design_name,
            "metric": "VIF",
            "predictor": c,
            "value": vif,
            "note": f"N={len(w)}",
        })

    return pd.DataFrame(rows)


# ============================================================
# LOAD / VALIDATE
# ============================================================

for p in [MASTER_FILE, STAGE04_FILE]:
    if not p.exists():
        raise FileNotFoundError(p)

d = pd.read_csv(MASTER_FILE, low_memory=False)
s04 = pd.read_csv(STAGE04_FILE, low_memory=False)

if len(d) != 1061:
    raise RuntimeError(
        f"Expected 1061 Stage09A2 rows, got {len(d)}"
    )

d["blazar_id"] = d["blazar_id"].astype(str)
s04["blazar_id"] = s04["blazar_id"].astype(str)

if d["blazar_id"].duplicated().any():
    raise RuntimeError("Duplicate blazar_id in Stage09A2 master.")

if "col_N_colour_pairs" not in s04.columns:
    raise RuntimeError("stage04 master lacks col_N_colour_pairs.")

d = d.merge(
    s04[
        [
            "blazar_id",
            "col_N_colour_pairs",
        ]
    ].drop_duplicates("blazar_id"),
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

d["colour_logN"] = np.log1p(
    numeric(d["col_N_colour_pairs"])
)

for c in [
    "endpoint_pdf_robust_double_both",
    "endpoint_rmflux_strict_both",
    "endpoint_rmflux_eligible_both",
    "endpoint_colour_robust_central",
    "endpoint_drw_interpretable_both",
    "ps1_host_proxy_hq_available",
]:
    d[c] = as_bool(d[c])

numeric_cols = [
    "FSRQ",
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
    "redshift",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
    "SED_ISP",
    "SED_HSP",
    "SED_UNKNOWN",
    "colour_logN",
    "colour_pair_dt_hours_median",
    "colour_r_mag_range",
]

for c in numeric_cols:
    d[c] = numeric(d[c])


# ============================================================
# A) SED OVERLAP AUDIT
# ============================================================

overlap_rows = []

sample_masks = {
    "FULL_1061": pd.Series(True, index=d.index),
    "HQ_HOST_1050LIKE": d["ps1_host_proxy_hq_available"],
    "KNOWNZ_HQ_HOST": (
        d["ps1_host_proxy_hq_available"]
        &
        d["redshift"].notna()
    ),
}

sed_levels = [
    "LSP",
    "ISP",
    "HSP",
    "UNKNOWN",
]

for sample_name, mask in sample_masks.items():
    w = d.loc[mask].copy()

    for sed in sed_levels:
        sw = w.loc[
            w["sed_class"]
            .astype(str)
            .eq(sed)
        ]

        n_bll = int(
            sw["blazar_class"]
            .astype(str)
            .eq("BLL")
            .sum()
        )

        n_fsrq = int(
            sw["blazar_class"]
            .astype(str)
            .eq("FSRQ")
            .sum()
        )

        n_tot = n_bll + n_fsrq

        overlap_rows.append({
            "sample_name": sample_name,
            "sed_class": sed,
            "N_total": n_tot,
            "N_BLL": n_bll,
            "N_FSRQ": n_fsrq,
            "P_FSRQ_given_SED": (
                n_fsrq / n_tot
                if n_tot > 0
                else np.nan
            ),
            "support_min_class_ge20": (
                min(n_bll, n_fsrq) >= 20
            ),
            "support_min_class_ge10": (
                min(n_bll, n_fsrq) >= 10
            ),
        })

overlap = pd.DataFrame(overlap_rows)

# Cramer's V on the full optical-class x SED table.
ct = pd.crosstab(
    d["blazar_class"].astype(str),
    d["sed_class"].astype(str),
)

chi2, _, _, _ = chi2_contingency(
    ct.to_numpy(),
    correction=False,
)

n_ct = ct.to_numpy().sum()
r, k = ct.shape

cramers_v = math.sqrt(
    chi2
    /
    (
        n_ct
        *
        max(
            1,
            min(r - 1, k - 1),
        )
    )
)

overlap["full_sample_cramers_v_class_vs_sed"] = cramers_v
overlap.to_csv(OUT_OVERLAP, index=False)


# ============================================================
# B) OVERLAP-AWARE ALL-CLASS MODELS: NO SED
# ============================================================

COV = [
    "FSRQ",
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
]

Z1 = [
    *COV,
    "redshift",
]

Z2 = [
    *Z1,
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
]

Z3 = [
    *Z2,
    "median_mag_g",
    "median_mag_r",
]

Z4 = [
    *Z3,
    "ps1_host_proxy_ri",
]

Z4_SED_DIAGNOSTIC = [
    *Z4,
    "SED_ISP",
    "SED_HSP",
    "SED_UNKNOWN",
]

STANDARD_CONT = [
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
    "redshift",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
]

endpoint_map = {
    "PDF": "endpoint_pdf_robust_double_both",
    "RMF": "endpoint_rmflux_strict_both",
    "COLOUR": "endpoint_colour_robust_central",
    "DRW_GATE": "endpoint_drw_interpretable_both",
}

binary_rows = []

for short, outcome in endpoint_map.items():

    endpoint_mask = pd.Series(True, index=d.index)

    if short == "RMF":
        endpoint_mask &= d["endpoint_rmflux_eligible_both"]

    # Exact common sample for Z0-Z4 and SED diagnostic.
    common = (
        endpoint_mask
        &
        d["ps1_host_proxy_hq_available"]
        &
        complete_mask(
            d,
            [
                "redshift",
                "log10_gamma_energy_flux",
                "log1p_gamma_variability_index",
                "median_mag_g",
                "median_mag_r",
                "ps1_host_proxy_ri",
                "log1p_N_nightly_mean_gr",
                "log10_baseline_mean_gr",
                "log10_cadence_mean_gr",
                "median_magerr_mean_gr",
            ],
        )
    )

    for tag, predictors in [
        ("Z0_COVERAGE", COV),
        ("Z1_PLUS_REDSHIFT", Z1),
        ("Z2_PLUS_GAMMA", Z2),
        ("Z3_PLUS_BRIGHTNESS", Z3),
        ("Z4_PLUS_HOST", Z4),
    ]:
        binary_rows.append(
            fit_logit(
                d,
                outcome=outcome,
                predictors=predictors,
                key_predictor="FSRQ",
                model_name=f"{short}_{tag}",
                sample_name="same_knownz_hq_host_noSED",
                subset_mask=common,
                standardize=[
                    c
                    for c in predictors
                    if (
                        c != "FSRQ"
                    )
                ],
                interpretation_status="OVERLAP_AWARE_SENSITIVITY",
            )
        )

    # SED-adjusted coefficient only to expose the instability caused by
    # poor class x SED overlap. It is deliberately not a primary estimand.
    binary_rows.append(
        fit_logit(
            d,
            outcome=outcome,
            predictors=Z4_SED_DIAGNOSTIC,
            key_predictor="FSRQ",
            model_name=f"{short}_Z5_ADD_SED_DIAGNOSTIC_ONLY",
            sample_name="same_knownz_hq_host_with_poor_SED_overlap",
            subset_mask=common,
            standardize=STANDARD_CONT,
            interpretation_status="NONPRIMARY_POOR_SED_OVERLAP",
        )
    )

binary = pd.DataFrame(binary_rows)

binary["q_BH_within_depth"] = np.nan

binary["depth"] = (
    binary["model_name"]
    .str.extract(
        r"_(Z[0-5][^_]*)",
        expand=False,
    )
)

for depth in binary["depth"].dropna().unique():
    mask = binary["depth"].eq(depth)

    binary.loc[
        mask,
        "q_BH_within_depth"
    ] = bh_qvalues(
        binary.loc[
            mask,
            "p_value",
        ].to_numpy(dtype=float)
    )

binary.to_csv(OUT_BINARY, index=False)


# ============================================================
# C) LSP-ONLY CLASS MODELS
# ============================================================

lsp_rows = []

lsp_mask = (
    d["sed_class"]
    .astype(str)
    .eq("LSP")
)

for short, outcome in endpoint_map.items():

    endpoint_mask = lsp_mask.copy()

    if short == "RMF":
        endpoint_mask &= d["endpoint_rmflux_eligible_both"]

    common = (
        endpoint_mask
        &
        d["ps1_host_proxy_hq_available"]
        &
        complete_mask(
            d,
            [
                "redshift",
                "log10_gamma_energy_flux",
                "log1p_gamma_variability_index",
                "median_mag_g",
                "median_mag_r",
                "ps1_host_proxy_ri",
                "log1p_N_nightly_mean_gr",
                "log10_baseline_mean_gr",
                "log10_cadence_mean_gr",
                "median_magerr_mean_gr",
            ],
        )
    )

    for tag, predictors in [
        ("LSP_Z0_COVERAGE", COV),
        ("LSP_Z1_PLUS_REDSHIFT", Z1),
        ("LSP_Z2_PLUS_GAMMA", Z2),
        ("LSP_Z3_PLUS_BRIGHTNESS", Z3),
        ("LSP_Z4_PLUS_HOST", Z4),
    ]:
        lsp_rows.append(
            fit_logit(
                d,
                outcome=outcome,
                predictors=predictors,
                key_predictor="FSRQ",
                model_name=f"{short}_{tag}",
                sample_name="LSP_only_same_knownz_hq_host",
                subset_mask=common,
                standardize=[
                    c
                    for c in predictors
                    if c != "FSRQ"
                ],
                interpretation_status="LSP_OVERLAP_RESTRICTED",
            )
        )

lsp_models = pd.DataFrame(lsp_rows)

lsp_models["q_BH_within_depth"] = np.nan
lsp_models["depth"] = (
    lsp_models["model_name"]
    .str.extract(
        r"_(LSP_Z[0-4][^_]*)",
        expand=False,
    )
)

for depth in lsp_models["depth"].dropna().unique():
    mask = lsp_models["depth"].eq(depth)

    lsp_models.loc[
        mask,
        "q_BH_within_depth"
    ] = bh_qvalues(
        lsp_models.loc[
            mask,
            "p_value",
        ].to_numpy(dtype=float)
    )

lsp_models.to_csv(OUT_LSP, index=False)


# ============================================================
# D) FLAGSHIP RMS-FLUX -> COLOUR: OVERLAP-AWARE
# ============================================================

X0 = [
    "endpoint_rmflux_strict_both",
    "FSRQ",
    "colour_logN",
    "colour_pair_dt_hours_median",
]

X1 = [
    *X0,
    "redshift",
]

X2 = [
    *X1,
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
]

X3 = [
    *X2,
    "median_mag_g",
    "median_mag_r",
]

X4 = [
    *X3,
    "ps1_host_proxy_ri",
]

X5 = [
    *X4,
    "colour_r_mag_range",
]

x_common = (
    d["endpoint_rmflux_eligible_both"]
    &
    d["ps1_host_proxy_hq_available"]
    &
    complete_mask(
        d,
        [
            "colour_logN",
            "colour_pair_dt_hours_median",
            "redshift",
            "log10_gamma_energy_flux",
            "log1p_gamma_variability_index",
            "median_mag_g",
            "median_mag_r",
            "ps1_host_proxy_ri",
            "colour_r_mag_range",
        ],
    )
)

x_rows = []

for tag, predictors in [
    ("X0_DETECTABILITY", X0),
    ("X1_PLUS_REDSHIFT", X1),
    ("X2_PLUS_GAMMA", X2),
    ("X3_PLUS_BRIGHTNESS", X3),
    ("X4_PLUS_HOST", X4),
    ("X5_PLUS_DYNAMIC_RANGE", X5),
]:
    x_rows.append(
        fit_logit(
            d,
            outcome="endpoint_colour_robust_central",
            predictors=predictors,
            key_predictor="endpoint_rmflux_strict_both",
            model_name=tag,
            sample_name="same_x5_knownz_hq_host_noSED",
            subset_mask=x_common,
            standardize=[
                c
                for c in predictors
                if (
                    c
                    not in {
                        "endpoint_rmflux_strict_both",
                        "FSRQ",
                    }
                )
            ],
            interpretation_status="FLAGSHIP_OVERLAP_AWARE",
        )
    )

xdiag = pd.DataFrame(x_rows)
xdiag["q_BH_nested_models"] = bh_qvalues(
    xdiag["p_value"].to_numpy(dtype=float)
)

xdiag.to_csv(OUT_XDIAG, index=False)


# ============================================================
# E) DESIGN DIAGNOSTICS
# ============================================================

design_frames = []

# Use PDF common sample as a representative full endpoint-independent
# design sample; all non-RMF binary endpoints share the same covariates.
design_common = (
    d["ps1_host_proxy_hq_available"]
    &
    complete_mask(
        d,
        [
            "redshift",
            "log10_gamma_energy_flux",
            "log1p_gamma_variability_index",
            "median_mag_g",
            "median_mag_r",
            "ps1_host_proxy_ri",
            "log1p_N_nightly_mean_gr",
            "log10_baseline_mean_gr",
            "log10_cadence_mean_gr",
            "median_magerr_mean_gr",
        ],
    )
)

design_frames.append(
    design_diagnostics(
        d,
        predictors=Z4,
        sample_mask=design_common,
        design_name="ALL_CLASS_NO_SED_Z4",
        standardize=STANDARD_CONT,
    )
)

design_frames.append(
    design_diagnostics(
        d,
        predictors=Z4_SED_DIAGNOSTIC,
        sample_mask=design_common,
        design_name="ALL_CLASS_WITH_SED_DIAGNOSTIC",
        standardize=STANDARD_CONT,
    )
)

design_frames.append(
    design_diagnostics(
        d,
        predictors=Z4,
        sample_mask=(
            design_common
            &
            lsp_mask
        ),
        design_name="LSP_ONLY_Z4",
        standardize=STANDARD_CONT,
    )
)

design = pd.concat(
    design_frames,
    ignore_index=True,
)

design.to_csv(OUT_DESIGN, index=False)


# ============================================================
# SUMMARY
# ============================================================

def get_model(frame, name):
    hit = frame.loc[
        frame["model_name"].eq(name)
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


def fmt_or(r):
    if r is None:
        return "NA"

    if (
        r["status"] != "OK"
        or
        not np.isfinite(r["odds_ratio"])
    ):
        return str(r["status"])

    return (
        f"OR={r['odds_ratio']:.3f} "
        f"[{r['or_ci95_low']:.3f},"
        f"{r['or_ci95_high']:.3f}], "
        f"p={r['p_value']:.3g}, "
        f"N={int(r['N'])} "
        f"(BLL={int(r['N_BLL'])},FSRQ={int(r['N_FSRQ'])})"
    )


lines = [
    "BLAZAR_I - STAGE 09A4 FINAL SUMMARY",
    "=" * 80,
    "",
    "WHY THIS STAGE WAS REQUIRED",
    "  Stage 09A3 added SED class to global FSRQ/BLL models even though",
    "  optical class and SED class have severe empirical non-overlap.",
    "  Therefore SED-adjusted global class coefficients are diagnostic",
    "  sensitivity results, not primary class estimands.",
    "",
    f"Full-sample Cramer's V(class, SED) = {cramers_v:.4f}",
    "",
    "SED support (FULL_1061):",
]

full_overlap = overlap.loc[
    overlap["sample_name"].eq("FULL_1061")
]

for _, r in full_overlap.iterrows():
    lines.append(
        f"  {r['sed_class']:7s}: "
        f"BLL={int(r['N_BLL'])}, "
        f"FSRQ={int(r['N_FSRQ'])}, "
        f"P(FSRQ|SED)={r['P_FSRQ_given_SED']:.3f}, "
        f"min-class>=20={bool(r['support_min_class_ge20'])}"
    )

lines += [
    "",
    "OVERLAP-AWARE ALL-CLASS CLASS EFFECTS (same known-z/HQ-host sample; NO SED):",
]

for short in [
    "PDF",
    "RMF",
    "COLOUR",
    "DRW_GATE",
]:
    lines.append(f"  {short}:")

    for tag in [
        "Z0_COVERAGE",
        "Z1_PLUS_REDSHIFT",
        "Z2_PLUS_GAMMA",
        "Z3_PLUS_BRIGHTNESS",
        "Z4_PLUS_HOST",
        "Z5_ADD_SED_DIAGNOSTIC_ONLY",
    ]:
        lines.append(
            f"    {tag:29s}: "
            + fmt_or(
                get_model(
                    binary,
                    f"{short}_{tag}",
                )
            )
        )

lines += [
    "",
    "LSP-ONLY CLASS EFFECTS (overlap-restricted):",
]

for short in [
    "PDF",
    "RMF",
    "COLOUR",
    "DRW_GATE",
]:
    lines.append(f"  {short}:")

    for tag in [
        "LSP_Z0_COVERAGE",
        "LSP_Z1_PLUS_REDSHIFT",
        "LSP_Z2_PLUS_GAMMA",
        "LSP_Z3_PLUS_BRIGHTNESS",
        "LSP_Z4_PLUS_HOST",
    ]:
        lines.append(
            f"    {tag:29s}: "
            + fmt_or(
                get_model(
                    lsp_models,
                    f"{short}_{tag}",
                )
            )
        )

lines += [
    "",
    "FLAGSHIP RMS-FLUX -> COLOUR (NO SED; same sample):",
]

for name in [
    "X0_DETECTABILITY",
    "X1_PLUS_REDSHIFT",
    "X2_PLUS_GAMMA",
    "X3_PLUS_BRIGHTNESS",
    "X4_PLUS_HOST",
    "X5_PLUS_DYNAMIC_RANGE",
]:
    lines.append(
        f"  {name:24s}: "
        + fmt_or(
            get_model(
                xdiag,
                name,
            )
        )
    )

# Pull key VIFs.
def max_vif(design_name):
    w = design.loc[
        design["design_name"].eq(design_name)
        &
        design["metric"].eq("VIF")
    ]

    if len(w) == 0:
        return (np.nan, "")

    idx = w["value"].astype(float).idxmax()
    rr = design.loc[idx]

    return (
        float(rr["value"]),
        str(rr["predictor"]),
    )

vif_no_sed, pred_no_sed = max_vif(
    "ALL_CLASS_NO_SED_Z4"
)

vif_sed, pred_sed = max_vif(
    "ALL_CLASS_WITH_SED_DIAGNOSTIC"
)

lines += [
    "",
    "DESIGN DIAGNOSTICS:",
    f"  max VIF no-SED design : {vif_no_sed:.3f} ({pred_no_sed})",
    f"  max VIF with SED      : {vif_sed:.3f} ({pred_sed})",
    "",
    "INTERPRETATION LOCKS:",
    "  - Do not interpret the global SED-adjusted class coefficient as a",
    "    primary FSRQ/BLL effect because SED support is severely asymmetric.",
    "  - Use the no-SED incremental sequence to identify which observed",
    "    covariate block attenuates each class contrast.",
    "  - Use LSP-only models as the direct optical-class comparison at",
    "    approximately common SED support.",
    "  - Preserve BLL-only SED models for SED science.",
    "  - The rms-flux -> colour association remains a separate flagship",
    "    cross-diagnostic result and is tested without forcing SED overlap.",
    "",
    "Files saved:",
    f"  {OUT_OVERLAP}",
    f"  {OUT_BINARY}",
    f"  {OUT_LSP}",
    f"  {OUT_XDIAG}",
    f"  {OUT_DESIGN}",
    "",
    "Next after interpreting 09A4:",
    "  STAGE 09B — source-clustered DRW continuous-timescale rebuild.",
    "",
    "STAGE 09A4 COMPLETE",
]

summary = "\n".join(lines)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
