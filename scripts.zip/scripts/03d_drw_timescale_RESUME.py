# ============================================================
# BLAZAR_I — STAGE 03D
# DRW / OU STOCHASTIC TIMESCALE ANALYSIS
#
# Input:
#   outputs/tables/stage02b3_GOLD_PLUS_SILVER.csv
#   data/processed/stage02b3_sources/BZI_xxxxx_NIGHTLY.parquet
#
# Model:
#   nightly magnitude y(t) = mu + X(t) + measurement noise
#   X(t) is an Ornstein-Uhlenbeck / damped-random-walk process:
#
#       Cov[X(t_i),X(t_j)] = sigma_DRW^2 * exp(-|dt|/tau)
#
#   where sigma_DRW is the stationary magnitude standard deviation
#   and tau is the observed-frame damping timescale.
#
# Exact irregular-time likelihood:
#   evaluated with the scalar Kalman recursion in O(N).
#
# Comparison null:
#   independent intrinsic-scatter (white-noise) model with
#   heteroscedastic measurement errors.
#
# Primary interpretable-timescale gate (pre-specified):
#   fit_status == OK
#   optimizer converged
#   DeltaBIC = BIC_white - BIC_DRW >= 10
#   tau_obs >= 2 * median cadence
#   tau_obs <= baseline / 10
#   tau solution is not near the numerical search boundary
#
# IMPORTANT:
#   * Fits are performed in MAGNITUDE space, a standard DRW
#     representation for AGN optical light curves.
#   * All fits are retained, but only gate-passing tau values should
#     be interpreted as characteristic stochastic timescales.
#   * tau_rest = tau_obs/(1+z) is reported only when z is finite > 0.
#   * No sigma clipping is applied here.
#
# Checkpoint unit:
#   1 blazar -> 2-row CSV (g,r) + .done
# ============================================================

from pathlib import Path
import argparse
import math
import sys
import time
import traceback

import numpy as np
import pandas as pd

from scipy.optimize import minimize


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="Process at most this many unfinished blazars."
)

args = parser.parse_args()


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

SAMPLE_FILE = (
    ROOT / "outputs" / "tables"
    / "stage02b3_GOLD_PLUS_SILVER.csv"
)

NIGHTLY_DIR = (
    ROOT / "data" / "processed"
    / "stage02b3_sources"
)

OUT_DIR = (
    ROOT / "outputs" / "models"
    / "stage03d_drw"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# FROZEN CONFIG
# ============================================================

MIN_N = 50

# Numerical search range for tau.
TAU_LOWER_ABS_DAYS = 0.5
TAU_UPPER_BASELINE_FACTOR = 10.0

# Primary physical/interpretable gate.
MIN_TAU_CADENCE_FACTOR = 2.0
MAX_TAU_BASELINE_FRACTION = 0.10
MIN_DELTA_BIC_DRW_VS_WHITE = 10.0

# Numerical-boundary flag:
# fraction of the available log(tau) search range.
BOUNDARY_LOG_FRACTION = 0.02

# Multi-start optimizer.
MAXITER = 600
FTOL = 1.0e-10

# Deterministic tau start fractions of the observed baseline.
TAU_START_BASELINE_FRACTIONS = (
    0.01,
    0.03,
    0.10,
    0.30,
)

# Additional cadence-based starts.
TAU_START_CADENCE_FACTORS = (
    2.0,
    5.0,
    10.0,
)


# ============================================================
# OUTPUT HELPERS
# ============================================================

def result_file(blazar_id):
    return OUT_DIR / f"{blazar_id}_03D.csv"

def done_file(blazar_id):
    return OUT_DIR / f"{blazar_id}.done"

def temp_path(path):
    return path.with_name(path.name + ".tmp")

def remove_if_exists(path):
    if path.exists():
        path.unlink()

def atomic_csv(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_csv(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)

def atomic_text(text, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    tmp.write_text(text, encoding="utf-8")
    remove_if_exists(path)
    tmp.replace(path)


# ============================================================
# NUMERICAL HELPERS
# ============================================================

LOG2PI = math.log(2.0 * math.pi)
TINY = 1.0e-14


def finite_median_positive_dt(t):
    t = np.asarray(t, dtype=float)
    t = np.sort(t[np.isfinite(t)])

    if len(t) < 2:
        return np.nan

    dt = np.diff(t)
    dt = dt[np.isfinite(dt) & (dt > 0)]

    if len(dt) == 0:
        return np.nan

    return float(np.median(dt))


def safe_std(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]

    if len(x) < 2:
        return np.nan

    return float(np.std(x, ddof=1))


# ============================================================
# EXACT OU / DRW NEGATIVE LOG-LIKELIHOOD
# ============================================================

def drw_nll(theta, t, y, yerr):
    mu, log_tau, log_sig = theta

    tau = math.exp(log_tau)
    sig = math.exp(log_sig)

    if (
        not np.isfinite(mu)
        or not np.isfinite(tau)
        or not np.isfinite(sig)
        or tau <= 0
        or sig <= 0
    ):
        return np.inf

    sig2 = sig * sig

    # Stationary prior for latent OU state.
    m = 0.0
    p = sig2

    nll = 0.0
    last_t = None

    for ti, yi, ei in zip(t, y, yerr):

        if last_t is not None:
            dt = ti - last_t

            if dt < 0:
                return np.inf

            a = math.exp(
                -dt / tau
            )

            p = (
                a * a * p
                +
                sig2 * (1.0 - a * a)
            )

            m = a * m

        obs_var = p + ei * ei

        if (
            not np.isfinite(obs_var)
            or obs_var <= TINY
        ):
            return np.inf

        resid = (
            yi
            -
            mu
            -
            m
        )

        nll += 0.5 * (
            LOG2PI
            +
            math.log(obs_var)
            +
            resid * resid / obs_var
        )

        # Kalman measurement update.
        k = p / obs_var

        m = (
            m
            +
            k * resid
        )

        p = (
            p
            *
            (1.0 - k)
        )

        p = max(
            p,
            TINY
        )

        last_t = ti

    return float(nll)


# ============================================================
# WHITE-INTRINSIC-SCATTER NULL MODEL
# ============================================================

def white_nll(theta, y, yerr):
    mu, log_sig = theta

    sig = math.exp(log_sig)

    if (
        not np.isfinite(mu)
        or not np.isfinite(sig)
        or sig <= 0
    ):
        return np.inf

    var = (
        sig * sig
        +
        yerr * yerr
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= TINY)
    ):
        return np.inf

    resid = y - mu

    nll = 0.5 * np.sum(
        LOG2PI
        +
        np.log(var)
        +
        resid * resid / var
    )

    return float(nll)


# ============================================================
# MODEL FITS
# ============================================================

def fit_white(y, yerr, mu_bounds, sig_bounds):

    mu0 = float(
        np.median(y)
    )

    s0 = safe_std(y)

    if not np.isfinite(s0) or s0 <= 0:
        s0 = float(
            np.median(yerr)
        )

    s0 = float(
        np.clip(
            s0,
            sig_bounds[0] * 2.0,
            sig_bounds[1] / 2.0,
        )
    )

    starts = [
        np.array(
            [
                mu0,
                math.log(s0),
            ],
            dtype=float
        ),
        np.array(
            [
                float(np.mean(y)),
                math.log(
                    max(
                        sig_bounds[0] * 2.0,
                        min(
                            sig_bounds[1] / 2.0,
                            0.5 * s0
                        )
                    )
                ),
            ],
            dtype=float
        ),
    ]

    bounds = [
        mu_bounds,
        (
            math.log(sig_bounds[0]),
            math.log(sig_bounds[1]),
        ),
    ]

    best = None

    for start in starts:

        res = minimize(
            white_nll,
            start,
            args=(
                y,
                yerr,
            ),
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": MAXITER,
                "ftol": FTOL,
            },
        )

        if (
            np.isfinite(res.fun)
            and
            (
                best is None
                or
                res.fun < best.fun
            )
        ):
            best = res

    return best


def fit_drw(
    t,
    y,
    yerr,
    mu_bounds,
    sig_bounds,
    tau_bounds,
    cadence,
    baseline,
):

    mu0 = float(
        np.median(y)
    )

    s0 = safe_std(y)

    if not np.isfinite(s0) or s0 <= 0:
        s0 = float(
            np.median(yerr)
        )

    s0 = float(
        np.clip(
            s0,
            sig_bounds[0] * 2.0,
            sig_bounds[1] / 2.0,
        )
    )

    tau_start_values = []

    for frac in TAU_START_BASELINE_FRACTIONS:
        tau_start_values.append(
            frac * baseline
        )

    if np.isfinite(cadence) and cadence > 0:
        for factor in TAU_START_CADENCE_FACTORS:
            tau_start_values.append(
                factor * cadence
            )

    tau_start_values = sorted(
        set(
            float(
                np.clip(
                    v,
                    tau_bounds[0] * 1.01,
                    tau_bounds[1] / 1.01,
                )
            )
            for v in tau_start_values
            if np.isfinite(v) and v > 0
        )
    )

    if not tau_start_values:
        tau_start_values = [
            math.sqrt(
                tau_bounds[0]
                *
                tau_bounds[1]
            )
        ]

    bounds = [
        mu_bounds,
        (
            math.log(
                tau_bounds[0]
            ),
            math.log(
                tau_bounds[1]
            ),
        ),
        (
            math.log(
                sig_bounds[0]
            ),
            math.log(
                sig_bounds[1]
            ),
        ),
    ]

    best = None

    for tau0 in tau_start_values:

        for sig_factor in (
            0.5,
            1.0,
            2.0,
        ):

            sig0 = float(
                np.clip(
                    s0 * sig_factor,
                    sig_bounds[0] * 1.01,
                    sig_bounds[1] / 1.01,
                )
            )

            start = np.array(
                [
                    mu0,
                    math.log(
                        tau0
                    ),
                    math.log(
                        sig0
                    ),
                ],
                dtype=float,
            )

            res = minimize(
                drw_nll,
                start,
                args=(
                    t,
                    y,
                    yerr,
                ),
                method="L-BFGS-B",
                bounds=bounds,
                options={
                    "maxiter": MAXITER,
                    "ftol": FTOL,
                },
            )

            if (
                np.isfinite(
                    res.fun
                )
                and
                (
                    best is None
                    or
                    res.fun < best.fun
                )
            ):
                best = res

    return best


# ============================================================
# HESSIAN-INVERSE APPROXIMATE log(tau) UNCERTAINTY
# ============================================================

def approximate_logtau_se(opt_result):

    if opt_result is None:
        return np.nan

    try:
        h = opt_result.hess_inv

        if hasattr(
            h,
            "todense"
        ):
            mat = np.asarray(
                h.todense(),
                dtype=float
            )
        else:
            mat = np.asarray(
                h,
                dtype=float
            )

        if (
            mat.shape[0] >= 2
            and
            mat.shape[1] >= 2
            and
            np.isfinite(
                mat[1, 1]
            )
            and
            mat[1, 1] > 0
        ):
            return float(
                math.sqrt(
                    mat[1, 1]
                )
            )

    except Exception:
        pass

    return np.nan


# ============================================================
# ANALYZE ONE FILTER
# ============================================================

def analyze_filter(
    blazar_id,
    filt,
    nightly,
    meta,
):

    x = nightly.loc[
        nightly[
            "filter_name"
        ].eq(
            filt
        ),
        [
            "hmjd",
            "mag",
            "magerr",
        ],
    ].copy()

    for col in [
        "hmjd",
        "mag",
        "magerr",
    ]:
        x[col] = pd.to_numeric(
            x[col],
            errors="coerce"
        )

    x = x.loc[
        np.isfinite(
            x["hmjd"]
        )
        &
        np.isfinite(
            x["mag"]
        )
        &
        np.isfinite(
            x["magerr"]
        )
        &
        (
            x["magerr"]
            >
            0
        )
    ].sort_values(
        "hmjd"
    ).reset_index(
        drop=True
    )

    n = len(
        x
    )

    row = {
        "blazar_id": blazar_id,
        "Source_Name": meta.get(
            "Source_Name",
            np.nan
        ),
        "ASSOC1": meta.get(
            "ASSOC1",
            np.nan
        ),
        "blazar_class": meta.get(
            "blazar_class",
            np.nan
        ),
        "sample_tier": meta.get(
            "sample_tier",
            np.nan
        ),
        "redshift_clean": meta.get(
            "redshift_clean",
            np.nan
        ),
        "SED_class_clean": meta.get(
            "SED_class_clean",
            np.nan
        ),
        "filter_name": filt,
        "N_nightly": int(
            n
        ),
        "fit_status": "NOT_RUN",
    }

    if n < MIN_N:
        row[
            "fit_status"
        ] = (
            f"TOO_FEW_POINTS_LT_{MIN_N}"
        )

        return row

    t_abs = x[
        "hmjd"
    ].to_numpy(
        dtype=float
    )

    y = x[
        "mag"
    ].to_numpy(
        dtype=float
    )

    yerr = x[
        "magerr"
    ].to_numpy(
        dtype=float
    )

    # Shift time origin for numerical cleanliness.
    t = (
        t_abs
        -
        t_abs[0]
    )

    baseline = float(
        t[-1]
        -
        t[0]
    )

    cadence = finite_median_positive_dt(
        t
    )

    row[
        "baseline_days"
    ] = baseline

    row[
        "median_cadence_days"
    ] = cadence

    row[
        "median_magerr"
    ] = float(
        np.median(
            yerr
        )
    )

    row[
        "std_mag"
    ] = safe_std(
        y
    )

    if (
        not np.isfinite(
            baseline
        )
        or
        baseline <= 0
        or
        not np.isfinite(
            cadence
        )
        or
        cadence <= 0
    ):
        row[
            "fit_status"
        ] = "INVALID_TIME_BASE"

        return row

    y_med = float(
        np.median(
            y
        )
    )

    y_span = float(
        np.max(
            y
        )
        -
        np.min(
            y
        )
    )

    y_std = safe_std(
        y
    )

    if (
        not np.isfinite(
            y_std
        )
        or
        y_std <= 0
    ):
        row[
            "fit_status"
        ] = "DEGENERATE_MAGNITUDES"

        return row

    mu_pad = max(
        1.0,
        2.0 * y_span,
        5.0 * y_std,
    )

    mu_bounds = (
        y_med
        -
        mu_pad,
        y_med
        +
        mu_pad,
    )

    sig_low = max(
        1.0e-4,
        0.02
        *
        float(
            np.median(
                yerr
            )
        ),
    )

    sig_high = max(
        1.0,
        5.0 * y_std,
        y_span,
    )

    sig_bounds = (
        sig_low,
        sig_high,
    )

    tau_low = max(
        TAU_LOWER_ABS_DAYS,
        0.25 * cadence,
    )

    tau_high = max(
        100.0,
        TAU_UPPER_BASELINE_FACTOR
        *
        baseline,
    )

    tau_bounds = (
        tau_low,
        tau_high,
    )

    row[
        "tau_search_low_days"
    ] = tau_low

    row[
        "tau_search_high_days"
    ] = tau_high

    try:

        white = fit_white(
            y,
            yerr,
            mu_bounds,
            sig_bounds,
        )

        drw = fit_drw(
            t,
            y,
            yerr,
            mu_bounds,
            sig_bounds,
            tau_bounds,
            cadence,
            baseline,
        )

        if (
            white is None
            or
            drw is None
        ):

            row[
                "fit_status"
            ] = "OPTIMIZER_NO_FINITE_SOLUTION"

            return row

        mu_white = float(
            white.x[0]
        )

        sig_white = float(
            math.exp(
                white.x[1]
            )
        )

        mu_drw = float(
            drw.x[0]
        )

        tau = float(
            math.exp(
                drw.x[1]
            )
        )

        sig_drw = float(
            math.exp(
                drw.x[2]
            )
        )

        ll_white = float(
            -white.fun
        )

        ll_drw = float(
            -drw.fun
        )

        # Parameter counts:
        # white = mu + intrinsic scatter = 2
        # DRW   = mu + tau + stationary sigma = 3
        k_white = 2
        k_drw = 3

        bic_white = (
            k_white
            *
            math.log(
                n
            )
            -
            2.0
            *
            ll_white
        )

        bic_drw = (
            k_drw
            *
            math.log(
                n
            )
            -
            2.0
            *
            ll_drw
        )

        aic_white = (
            2.0
            *
            k_white
            -
            2.0
            *
            ll_white
        )

        aic_drw = (
            2.0
            *
            k_drw
            -
            2.0
            *
            ll_drw
        )

        delta_bic = (
            bic_white
            -
            bic_drw
        )

        delta_aic = (
            aic_white
            -
            aic_drw
        )

        logtau_low = math.log(
            tau_low
        )

        logtau_high = math.log(
            tau_high
        )

        logtau = math.log(
            tau
        )

        logrange = (
            logtau_high
            -
            logtau_low
        )

        if logrange > 0:

            frac_from_low = (
                logtau
                -
                logtau_low
            ) / logrange

            frac_from_high = (
                logtau_high
                -
                logtau
            ) / logrange

        else:

            frac_from_low = np.nan
            frac_from_high = np.nan

        near_lower = bool(
            np.isfinite(
                frac_from_low
            )
            and
            frac_from_low
            <=
            BOUNDARY_LOG_FRACTION
        )

        near_upper = bool(
            np.isfinite(
                frac_from_high
            )
            and
            frac_from_high
            <=
            BOUNDARY_LOG_FRACTION
        )

        tau_over_cadence = (
            tau
            /
            cadence
        )

        tau_over_baseline = (
            tau
            /
            baseline
        )

        sf_inf = (
            math.sqrt(
                2.0
            )
            *
            sig_drw
        )

        logtau_se = approximate_logtau_se(
            drw
        )

        if np.isfinite(
            logtau_se
        ):

            tau_lo_approx = (
                tau
                *
                math.exp(
                    -1.96
                    *
                    logtau_se
                )
            )

            tau_hi_approx = (
                tau
                *
                math.exp(
                    1.96
                    *
                    logtau_se
                )
            )

        else:

            tau_lo_approx = np.nan
            tau_hi_approx = np.nan

        z = pd.to_numeric(
            pd.Series(
                [
                    meta.get(
                        "redshift_clean",
                        np.nan
                    )
                ]
            ),
            errors="coerce",
        ).iloc[0]

        if (
            np.isfinite(
                z
            )
            and
            z > 0
        ):

            tau_rest = (
                tau
                /
                (
                    1.0
                    +
                    z
                )
            )

        else:

            tau_rest = np.nan

        interpretable = bool(
            drw.success
            and
            np.isfinite(
                delta_bic
            )
            and
            delta_bic
            >=
            MIN_DELTA_BIC_DRW_VS_WHITE
            and
            tau
            >=
            MIN_TAU_CADENCE_FACTOR
            *
            cadence
            and
            tau
            <=
            MAX_TAU_BASELINE_FRACTION
            *
            baseline
            and
            not near_lower
            and
            not near_upper
        )

        row.update({
            "optimizer_success_drw": bool(
                drw.success
            ),
            "optimizer_message_drw": str(
                drw.message
            ),
            "optimizer_nit_drw": int(
                getattr(
                    drw,
                    "nit",
                    -1
                )
            ),
            "optimizer_success_white": bool(
                white.success
            ),
            "mu_white_mag": mu_white,
            "sigma_white_intrinsic_mag": sig_white,
            "loglike_white": ll_white,
            "aic_white": aic_white,
            "bic_white": bic_white,
            "mu_drw_mag": mu_drw,
            "tau_obs_days": tau,
            "tau_rest_days": tau_rest,
            "sigma_drw_stationary_mag": sig_drw,
            "SF_inf_mag": sf_inf,
            "loglike_drw": ll_drw,
            "aic_drw": aic_drw,
            "bic_drw": bic_drw,
            "delta_bic_white_minus_drw": delta_bic,
            "delta_aic_white_minus_drw": delta_aic,
            "tau_over_median_cadence": tau_over_cadence,
            "tau_over_baseline": tau_over_baseline,
            "tau_near_lower_search_bound": near_lower,
            "tau_near_upper_search_bound": near_upper,
            "logtau_se_hess_approx": logtau_se,
            "tau_obs_p025_hess_approx_days": tau_lo_approx,
            "tau_obs_p975_hess_approx_days": tau_hi_approx,
            "tau_interpretable_primary": interpretable,
            "fit_status": "OK",
        })

    except Exception as exc:

        row[
            "fit_status"
        ] = (
            f"FIT_FAILED:{type(exc).__name__}"
        )

    return row


# ============================================================
# LOAD SAMPLE
# ============================================================

sample = pd.read_csv(
    SAMPLE_FILE
)

required = [
    "blazar_id",
    "sample_tier",
    "blazar_class",
]

missing = [
    c
    for c in required
    if c not in sample.columns
]

if missing:

    raise RuntimeError(
        "Missing sample columns: "
        +
        ", ".join(
            missing
        )
    )

sample[
    "blazar_id"
] = (
    sample[
        "blazar_id"
    ]
    .astype(
        str
    )
)

source_ids = (
    sample[
        "blazar_id"
    ]
    .drop_duplicates()
    .tolist()
)

sample_lookup = (
    sample
    .drop_duplicates(
        "blazar_id"
    )
    .set_index(
        "blazar_id"
    )
)

N_SOURCE = len(
    source_ids
)


# ============================================================
# HEADER
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 03D")
print("DRW / OU STOCHASTIC TIMESCALE ANALYSIS")
print("=" * 78)

print(
    "Analysis sample =",
    N_SOURCE
)

print(
    "Minimum N/filter =",
    MIN_N
)

print(
    "Primary interpretable gate:"
)

print(
    "  DeltaBIC(white-DRW) >=",
    MIN_DELTA_BIC_DRW_VS_WHITE
)

print(
    "  tau >= ",
    MIN_TAU_CADENCE_FACTOR,
    "* median cadence"
)

print(
    "  tau <= ",
    MAX_TAU_BASELINE_FRACTION,
    "* baseline"
)


# ============================================================
# CHECKPOINT STATUS
# ============================================================

def source_complete(
    blazar_id
):

    return (
        result_file(
            blazar_id
        ).exists()
        and
        done_file(
            blazar_id
        ).exists()
    )


complete_before = [
    bid
    for bid in source_ids
    if source_complete(
        bid
    )
]

print()

print(
    "Completed 03D sources on disk =",
    len(
        complete_before
    ),
    "/",
    N_SOURCE
)

print(
    "Remaining 03D sources         =",
    N_SOURCE
    -
    len(
        complete_before
    )
)


# ============================================================
# PER-SOURCE LOOP
# ============================================================

processed_this_run = 0

session_start = time.time()


for source_number, blazar_id in enumerate(
    source_ids,
    start=1
):

    if source_complete(
        blazar_id
    ):
        continue

    if (
        args.limit is not None
        and
        processed_this_run
        >=
        args.limit
    ):

        print()

        print(
            "Pilot limit reached:",
            args.limit
        )

        break

    nightly_path = (
        NIGHTLY_DIR
        /
        f"{blazar_id}_NIGHTLY.parquet"
    )

    if not nightly_path.exists():

        raise FileNotFoundError(
            nightly_path
        )

    if not done_file(
        blazar_id
    ).exists():

        remove_if_exists(
            result_file(
                blazar_id
            )
        )

        remove_if_exists(
            temp_path(
                result_file(
                    blazar_id
                )
            )
        )

        remove_if_exists(
            temp_path(
                done_file(
                    blazar_id
                )
            )
        )

    print()
    print("=" * 78)

    print(
        f"SOURCE "
        f"{source_number}/{N_SOURCE}"
    )

    print(
        "blazar_id =",
        blazar_id
    )

    t0 = time.time()

    try:

        nightly = pd.read_parquet(
            nightly_path
        )

        meta = (
            sample_lookup
            .loc[
                blazar_id
            ]
            .to_dict()
        )

        rows = []

        for filt in [
            "g",
            "r",
        ]:

            rows.append(
                analyze_filter(
                    blazar_id=blazar_id,
                    filt=filt,
                    nightly=nightly,
                    meta=meta,
                )
            )

        result = pd.DataFrame(
            rows
        )

        atomic_csv(
            result,
            result_file(
                blazar_id
            )
        )

        elapsed = (
            time.time()
            -
            t0
        )

        atomic_text(
            (
                "COMPLETE\n"
                f"blazar_id={blazar_id}\n"
                f"elapsed_seconds={elapsed:.6f}\n"
            ),
            done_file(
                blazar_id
            )
        )

        for _, rr in result.iterrows():

            print(
                f"{rr['filter_name']}: "
                f"N={int(rr['N_nightly'])}, "
                f"tau={rr.get('tau_obs_days', np.nan):.2f} d, "
                f"DeltaBIC={rr.get('delta_bic_white_minus_drw', np.nan):.2f}, "
                f"interpretable={bool(rr.get('tau_interpretable_primary', False))}, "
                f"status={rr['fit_status']}"
            )

        print(
            "CHECKPOINT =",
            done_file(
                blazar_id
            ).name
        )

        processed_this_run += 1

    except Exception:

        print()

        print(
            "FAILED SOURCE:",
            blazar_id
        )

        traceback.print_exc()

        fail_path = (
            AUDIT_DIR
            /
            "stage03d_last_failure.txt"
        )

        fail_path.write_text(
            (
                "BLAZAR_I STAGE 03D FAILURE\n"
                f"blazar_id={blazar_id}\n"
                f"source_number="
                f"{source_number}/"
                f"{N_SOURCE}\n"
            ),
            encoding="utf-8"
        )

        sys.exit(
            30
        )


# ============================================================
# CURRENT STATUS
# ============================================================

complete_now = [
    bid
    for bid in source_ids
    if source_complete(
        bid
    )
]

session_elapsed = (
    time.time()
    -
    session_start
)

print()
print("=" * 78)
print("STAGE 03D CURRENT STATUS")
print("=" * 78)

print(
    "Completed sources =",
    len(
        complete_now
    ),
    "/",
    N_SOURCE
)

print(
    "Remaining         =",
    N_SOURCE
    -
    len(
        complete_now
    )
)

print(
    f"Session elapsed   = "
    f"{session_elapsed/60:.2f} min"
)


# ============================================================
# GLOBAL PRODUCTS
# ============================================================

if len(
    complete_now
) == N_SOURCE:

    print()

    print(
        "All STAGE 03D sources complete."
    )

    frames = []

    for bid in source_ids:

        frames.append(
            pd.read_csv(
                result_file(
                    bid
                )
            )
        )

    master = pd.concat(
        frames,
        ignore_index=True
    )

    MASTER_OUT = (
        TABLE_DIR
        /
        "stage03d_drw_master.csv"
    )

    master.to_csv(
        MASTER_OUT,
        index=False
    )

    interpretable = master.loc[
        master[
            "tau_interpretable_primary"
        ]
        .fillna(
            False
        )
        .astype(
            bool
        )
    ].copy()

    INTERP_OUT = (
        TABLE_DIR
        /
        "stage03d_interpretable_timescales.csv"
    )

    interpretable.to_csv(
        INTERP_OUT,
        index=False
    )

    # --------------------------------------------
    # Source-level wide table
    # --------------------------------------------

    keep = [
        "blazar_id",
        "filter_name",
        "N_nightly",
        "baseline_days",
        "median_cadence_days",
        "tau_obs_days",
        "tau_rest_days",
        "sigma_drw_stationary_mag",
        "SF_inf_mag",
        "delta_bic_white_minus_drw",
        "tau_over_median_cadence",
        "tau_over_baseline",
        "tau_near_lower_search_bound",
        "tau_near_upper_search_bound",
        "tau_interpretable_primary",
        "fit_status",
    ]

    wide = master[
        [
            c
            for c in keep
            if c in master.columns
        ]
    ].pivot(
        index="blazar_id",
        columns="filter_name"
    )

    wide.columns = [
        f"{metric}_{filt}"
        for metric, filt in wide.columns
    ]

    wide = wide.reset_index()

    meta_cols = [
        "blazar_id",
        "Source_Name",
        "ASSOC1",
        "blazar_class",
        "sample_tier",
        "redshift_clean",
        "SED_class_clean",
    ]

    meta = (
        master[
            [
                c
                for c in meta_cols
                if c in master.columns
            ]
        ]
        .drop_duplicates(
            "blazar_id"
        )
    )

    source_master = meta.merge(
        wide,
        on="blazar_id",
        how="left",
        validate="one_to_one"
    )

    SOURCE_OUT = (
        TABLE_DIR
        /
        "stage03d_source_master.csv"
    )

    source_master.to_csv(
        SOURCE_OUT,
        index=False
    )

    # --------------------------------------------
    # Cross-band interpretable counts
    # --------------------------------------------

    p = master.pivot(
        index="blazar_id",
        columns="filter_name",
        values="tau_interpretable_primary"
    )

    g_ok = (
        p["g"]
        .fillna(
            False
        )
        .astype(
            bool
        )
        if "g" in p.columns
        else pd.Series(
            False,
            index=p.index
        )
    )

    r_ok = (
        p["r"]
        .fillna(
            False
        )
        .astype(
            bool
        )
        if "r" in p.columns
        else pd.Series(
            False,
            index=p.index
        )
    )

    both_ok = int(
        (
            g_ok
            &
            r_ok
        ).sum()
    )

    either_ok = int(
        (
            g_ok
            |
            r_ok
        ).sum()
    )

    # --------------------------------------------
    # Final summary
    # --------------------------------------------

    ok = master.loc[
        master[
            "fit_status"
        ].eq(
            "OK"
        )
    ]

    lines = [
        "BLAZAR_I - STAGE 03D FINAL SUMMARY",
        "=" * 72,
        "",
        "MODEL:",
        "  Ornstein-Uhlenbeck / damped random walk in magnitude space",
        "  exact irregular-time scalar Kalman likelihood",
        "",
        "PRIMARY INTERPRETABLE-TAU GATE:",
        (
            "  DeltaBIC(white-DRW) >= "
            f"{MIN_DELTA_BIC_DRW_VS_WHITE:.1f}"
        ),
        (
            "  tau >= "
            f"{MIN_TAU_CADENCE_FACTOR:.1f}"
            " * median cadence"
        ),
        (
            "  tau <= "
            f"{MAX_TAU_BASELINE_FRACTION:.2f}"
            " * baseline"
        ),
        "  tau not near numerical search boundary",
        "",
        (
            "Analysis blazars                : "
            f"{N_SOURCE}"
        ),
        (
            "Source-filter rows              : "
            f"{len(master)}"
        ),
        (
            "Successful DRW fits             : "
            f"{len(ok)}"
        ),
        (
            "Interpretable source-filter tau : "
            f"{len(interpretable)}"
        ),
        (
            "Sources interpretable >=1 band  : "
            f"{either_ok}"
        ),
        (
            "Sources interpretable both bands: "
            f"{both_ok}"
        ),
        "",
        "By filter:",
    ]

    for filt in [
        "g",
        "r",
    ]:

        xx = master.loc[
            master[
                "filter_name"
            ].eq(
                filt
            )
        ]

        ii = xx.loc[
            xx[
                "tau_interpretable_primary"
            ]
            .fillna(
                False
            )
            .astype(
                bool
            )
        ]

        med_tau = (
            float(
                ii[
                    "tau_obs_days"
                ].median()
            )
            if len(ii)
            else np.nan
        )

        lines.append(
            f"  {filt}: "
            f"fits={int((xx['fit_status']=='OK').sum())}, "
            f"interpretable={len(ii)}, "
            f"median_tau_obs={med_tau:.2f} d"
        )

    lines += [
        "",
        "By class and filter:",
    ]

    for cls in [
        "BLL",
        "FSRQ",
    ]:

        for filt in [
            "g",
            "r",
        ]:

            xx = master.loc[
                master[
                    "blazar_class"
                ].eq(
                    cls
                )
                &
                master[
                    "filter_name"
                ].eq(
                    filt
                )
            ]

            ii = xx.loc[
                xx[
                    "tau_interpretable_primary"
                ]
                .fillna(
                    False
                )
                .astype(
                    bool
                )
            ]

            med_tau = (
                float(
                    ii[
                        "tau_obs_days"
                    ].median()
                )
                if len(ii)
                else np.nan
            )

            lines.append(
                f"  {cls} {filt}: "
                f"N={len(xx)}, "
                f"interpretable={len(ii)}, "
                f"median_tau_obs={med_tau:.2f} d"
            )

    final_summary = "\n".join(
        lines
    )

    SUMMARY_OUT = (
        AUDIT_DIR
        /
        "stage03d_summary.txt"
    )

    SUMMARY_OUT.write_text(
        final_summary,
        encoding="utf-8"
    )

    print()
    print(
        final_summary
    )

    print()
    print("=" * 78)
    print("GLOBAL FILES SAVED")
    print("=" * 78)

    print(
        MASTER_OUT
    )

    print(
        SOURCE_OUT
    )

    print(
        INTERP_OUT
    )

    print(
        SUMMARY_OUT
    )

    print()
    print(
        "STAGE 03D COMPLETE"
    )
