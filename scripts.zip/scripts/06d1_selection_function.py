# ============================================================
# BLAZAR_I — STAGE 06D1
# FORMAL TWO-STAGE SELECTION-FUNCTION ANALYSIS
#
# Selection flow:
#   1901 clean Fermi FSRQ+BLL parent
#      -> 1456 with any ZTF g/r object coverage
#      -> 1061 GOLD+SILVER analysis sample
#
# Stage 1 outcome:
#   ZTF_ANY = has_g OR has_r
#
# Stage 2 outcome:
#   ANALYSIS = passes_silver_min
#   modelled only among the 1456 ZTF_ANY sources
#
# Parent-level predictors only are used in the primary controlled
# models, so the selection model is not adjusted for variables that
# are created by the downstream quality gate itself.
#
# Controlled model:
#   FSRQ
#   sky footprint:
#       sin(RA), cos(RA), Dec, Dec^2
#   SED class:
#       LSP reference; HSP / ISP / UNKNOWN indicators
#   redshift-known indicator
#   log10(Energy_Flux100_DR4)
#   log1p(Variability_Index_DR4)
#
# Continuous predictors are standardized within each stage model.
# GLM Binomial with HC3 robust standard errors.
#
# Outputs include predicted probabilities from the FULL model so
# a later IPW sensitivity analysis can be performed without refitting
# the selection model.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import fisher_exact

ROOT = Path(__file__).resolve().parents[1]

PARENT_FILE = (
    ROOT / "data" / "interim"
    / "stage01_parent_clean_fsrq_bll.csv"
)

COVERAGE_FILE = (
    ROOT / "outputs" / "audit"
    / "stage02b1_ztf_object_coverage.csv"
)

QUALITY_FILE = (
    ROOT / "outputs" / "tables"
    / "stage02b3_source_quality.csv"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_FLOW = TABLE_DIR / "stage06d1_selection_flow_master.csv"
OUT_RETENTION = TABLE_DIR / "stage06d1_selection_retention.csv"
OUT_MODELS = TABLE_DIR / "stage06d1_selection_models.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06d1_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def bh_qvalues(pvalues):
    p = np.asarray(
        pvalues,
        dtype=float
    )

    q = np.full(
        len(p),
        np.nan,
        dtype=float
    )

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw = (
        ranked
        *
        m
        /
        np.arange(1, m + 1)
    )

    adj = np.minimum.accumulate(
        raw[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0
    )

    qv = np.empty(
        m,
        dtype=float
    )
    qv[order] = adj
    q[valid] = qv

    return q


def standardize_train_apply(
    train_df,
    apply_df,
    cols,
):
    train = train_df.copy()
    apply = apply_df.copy()

    scaling = {}

    for c in cols:
        x = numeric(
            train[c]
        )

        mu = float(
            x.mean()
        )

        sd = float(
            x.std(ddof=1)
        )

        if not (
            np.isfinite(sd)
            and
            sd > 0
        ):
            raise RuntimeError(
                f"Cannot standardize {c}: sd={sd}"
            )

        train[c] = (
            numeric(train[c]) - mu
        ) / sd

        apply[c] = (
            numeric(apply[c]) - mu
        ) / sd

        scaling[c] = (
            mu,
            sd
        )

    return (
        train,
        apply,
        scaling,
    )


def fit_glm_stage(
    train_df,
    apply_df,
    outcome,
    stage_name,
    model_name,
    predictors,
    continuous_predictors,
):
    cols = [
        outcome,
        *predictors,
    ]

    train = train_df[
        cols
    ].copy()

    apply = apply_df[
        predictors
    ].copy()

    for c in cols:
        train[c] = numeric(
            train[c]
        )

    for c in predictors:
        apply[c] = numeric(
            apply[c]
        )

    train = train.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    # Apply rows must remain aligned; FULL models are intentionally
    # specified using complete parent-level variables.
    if apply.replace(
        [np.inf, -np.inf],
        np.nan
    ).isna().any().any():
        raise RuntimeError(
            f"{stage_name} {model_name}: missing predictor values in apply set"
        )

    train, apply, scaling = (
        standardize_train_apply(
            train,
            apply,
            continuous_predictors,
        )
    )

    y = train[
        outcome
    ].astype(float)

    X = sm.add_constant(
        train[
            predictors
        ].astype(float),
        has_constant="add"
    )

    fit = sm.GLM(
        y,
        X,
        family=sm.families.Binomial()
    ).fit(
        cov_type="HC3"
    )

    X_apply = sm.add_constant(
        apply[
            predictors
        ].astype(float),
        has_constant="add"
    )

    pred = np.asarray(
        fit.predict(X_apply),
        dtype=float
    )

    ci = fit.conf_int()

    rows = []

    for term in fit.params.index:
        beta = float(
            fit.params[term]
        )

        lo = float(
            ci.loc[term, 0]
        )

        hi = float(
            ci.loc[term, 1]
        )

        rows.append({
            "stage": stage_name,
            "model": model_name,
            "N_model": int(
                len(train)
            ),
            "N_positive": int(
                y.sum()
            ),
            "term": term,
            "beta": beta,
            "se_robust": float(
                fit.bse[term]
            ),
            "OR": (
                math.exp(beta)
                if term != "const"
                else np.nan
            ),
            "OR_ci95_low": (
                math.exp(lo)
                if term != "const"
                else np.nan
            ),
            "OR_ci95_high": (
                math.exp(hi)
                if term != "const"
                else np.nan
            ),
            "p_value": float(
                fit.pvalues[term]
            ),
            "AIC": float(
                fit.aic
            ),
            "deviance": float(
                fit.deviance
            ),
        })

    return (
        fit,
        pred,
        rows,
        scaling,
    )


def add_retention_rows(
    rows,
    df,
    stage,
    outcome,
    group_type,
    group_col,
):
    for group, x in df.groupby(
        group_col,
        dropna=False
    ):
        n = len(x)
        selected = int(
            x[outcome].sum()
        )

        rows.append({
            "stage": stage,
            "group_type": group_type,
            "group": str(group),
            "N_input": int(n),
            "N_selected": selected,
            "retention_fraction": (
                selected / n
                if n > 0
                else np.nan
            ),
        })


def raw_class_or(
    df,
    outcome,
):
    fsrq = df.loc[
        df["FSRQ"].eq(1),
        outcome
    ]

    bll = df.loc[
        df["FSRQ"].eq(0),
        outcome
    ]

    a = int(
        fsrq.sum()
    )
    b = int(
        len(fsrq) - a
    )
    c = int(
        bll.sum()
    )
    d = int(
        len(bll) - c
    )

    or_raw, p = fisher_exact(
        [
            [a, b],
            [c, d],
        ],
        alternative="two-sided",
    )

    # Wald CI on log OR with 0.5 continuity correction only if needed.
    aa, bb, cc, dd = (
        float(a),
        float(b),
        float(c),
        float(d),
    )

    if min(
        aa,
        bb,
        cc,
        dd
    ) == 0:
        aa += 0.5
        bb += 0.5
        cc += 0.5
        dd += 0.5

    log_or = math.log(
        (aa * dd)
        /
        (bb * cc)
    )

    se = math.sqrt(
        1.0 / aa
        +
        1.0 / bb
        +
        1.0 / cc
        +
        1.0 / dd
    )

    lo = math.exp(
        log_or
        -
        1.96 * se
    )

    hi = math.exp(
        log_or
        +
        1.96 * se
    )

    return {
        "FSRQ_selected": a,
        "FSRQ_not_selected": b,
        "BLL_selected": c,
        "BLL_not_selected": d,
        "OR": float(or_raw),
        "CI_low": float(lo),
        "CI_high": float(hi),
        "p": float(p),
    }


# ============================================================
# LOAD + VALIDATE
# ============================================================

for path in [
    PARENT_FILE,
    COVERAGE_FILE,
    QUALITY_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

parent = pd.read_csv(
    PARENT_FILE
)

coverage = pd.read_csv(
    COVERAGE_FILE
)

quality = pd.read_csv(
    QUALITY_FILE
)

for df in [
    parent,
    coverage,
    quality,
]:
    df["blazar_id"] = (
        df["blazar_id"]
        .astype(str)
    )

if len(parent) != 1901:
    raise RuntimeError(
        f"Expected parent N=1901; got {len(parent)}"
    )

if len(coverage) != 1901:
    raise RuntimeError(
        f"Expected coverage N=1901; got {len(coverage)}"
    )

if len(quality) != 1456:
    raise RuntimeError(
        f"Expected quality N=1456; got {len(quality)}"
    )

if parent["blazar_id"].nunique() != 1901:
    raise RuntimeError(
        "Parent blazar_id is not unique."
    )

if coverage["blazar_id"].nunique() != 1901:
    raise RuntimeError(
        "Coverage blazar_id is not unique."
    )

if quality["blazar_id"].nunique() != 1456:
    raise RuntimeError(
        "Quality blazar_id is not unique."
    )


# ============================================================
# BUILD 1901-SOURCE FLOW MASTER
# ============================================================

cov_keep = coverage[
    [
        "blazar_id",
        "N_objectid_g",
        "N_objectid_r",
        "has_g",
        "has_r",
        "has_gr",
    ]
].copy()

for c in [
    "has_g",
    "has_r",
    "has_gr",
]:
    cov_keep[c] = as_bool_series(
        cov_keep[c]
    )

q_keep = quality[
    [
        "blazar_id",
        "N_raw_epochs",
        "N_clean_epochs",
        "N_clean_g",
        "N_clean_r",
        "N_nights_g",
        "N_nights_r",
        "baseline_g_days",
        "baseline_r_days",
        "N_colour_pairs",
        "passes_gold",
        "passes_silver_min",
        "sample_tier",
    ]
].copy()

q_keep[
    "passes_gold"
] = as_bool_series(
    q_keep[
        "passes_gold"
    ]
)

q_keep[
    "passes_silver_min"
] = as_bool_series(
    q_keep[
        "passes_silver_min"
    ]
)

flow = parent.merge(
    cov_keep,
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

flow = flow.merge(
    q_keep,
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

if flow[
    [
        "has_g",
        "has_r",
        "has_gr",
    ]
].isna().any().any():
    raise RuntimeError(
        "Coverage merge produced missing rows."
    )

flow["ZTF_ANY"] = (
    flow["has_g"]
    |
    flow["has_r"]
)

quality_ids = set(
    quality["blazar_id"]
)

ztf_ids = set(
    flow.loc[
        flow["ZTF_ANY"],
        "blazar_id"
    ]
)

if quality_ids != ztf_ids:
    only_quality = sorted(
        quality_ids - ztf_ids
    )[:10]

    only_cov = sorted(
        ztf_ids - quality_ids
    )[:10]

    raise RuntimeError(
        "1456-source membership mismatch between coverage and quality tables. "
        f"only_quality={only_quality}; only_coverage={only_cov}"
    )

flow[
    "ANALYSIS_SELECTED"
] = (
    flow[
        "passes_silver_min"
    ]
    .fillna(False)
    .astype(bool)
)

flow[
    "GOLD_SELECTED"
] = (
    flow[
        "passes_gold"
    ]
    .fillna(False)
    .astype(bool)
)

# ------------------------------------------------------------
# Parent-level predictors
# ------------------------------------------------------------

flow["FSRQ"] = (
    flow["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

flow["redshift_known"] = (
    numeric(
        flow["redshift_clean"]
    )
    .notna()
    .astype(int)
)

flow["SED4"] = (
    flow["SED_class_clean"]
    .fillna("UNKNOWN")
    .astype(str)
    .str.strip()
    .str.upper()
)

allowed_sed = {
    "LSP",
    "ISP",
    "HSP",
    "UNKNOWN",
}

bad_sed = sorted(
    set(
        flow["SED4"].unique()
    )
    -
    allowed_sed
)

if bad_sed:
    raise RuntimeError(
        f"Unexpected SED categories: {bad_sed}"
    )

flow["SED_HSP"] = (
    flow["SED4"].eq("HSP")
    .astype(int)
)

flow["SED_ISP"] = (
    flow["SED4"].eq("ISP")
    .astype(int)
)

flow["SED_UNKNOWN"] = (
    flow["SED4"].eq("UNKNOWN")
    .astype(int)
)

ra_rad = np.deg2rad(
    numeric(
        flow["ra_opt"]
    )
)

flow["RA_sin"] = np.sin(
    ra_rad
)

flow["RA_cos"] = np.cos(
    ra_rad
)

flow["Dec_deg"] = numeric(
    flow["dec_opt"]
)

flow["Dec2"] = (
    flow["Dec_deg"]
    ** 2
)

energy = numeric(
    flow["Energy_Flux100_DR4"]
)

if (
    energy.isna().any()
    or
    (energy <= 0).any()
):
    raise RuntimeError(
        "Energy_Flux100_DR4 must be finite and >0 for all 1901 parent sources."
    )

varidx = numeric(
    flow["Variability_Index_DR4"]
)

if (
    varidx.isna().any()
    or
    (varidx < 0).any()
):
    raise RuntimeError(
        "Variability_Index_DR4 must be finite and >=0 for all 1901 parent sources."
    )

flow["logEnergyFlux_DR4"] = np.log10(
    energy
)

flow["log1pVarIndex_DR4"] = np.log1p(
    varidx
)

# Keep group labels for descriptive retention.
flow["redshift_status"] = np.where(
    flow["redshift_known"].eq(1),
    "KNOWN",
    "UNKNOWN",
)


# ============================================================
# COUNT VALIDATION
# ============================================================

n_any = int(
    flow["ZTF_ANY"].sum()
)

n_gr = int(
    flow["has_gr"].sum()
)

n_analysis = int(
    flow["ANALYSIS_SELECTED"].sum()
)

n_gold = int(
    flow["GOLD_SELECTED"].sum()
)

if n_any != 1456:
    raise RuntimeError(
        f"Expected ZTF_ANY=1456; got {n_any}"
    )

if n_gr != 1416:
    raise RuntimeError(
        f"Expected has_gr=1416; got {n_gr}"
    )

if n_analysis != 1061:
    raise RuntimeError(
        f"Expected analysis N=1061; got {n_analysis}"
    )

if n_gold != 983:
    raise RuntimeError(
        f"Expected GOLD N=983; got {n_gold}"
    )


# ============================================================
# DESCRIPTIVE RETENTION
# ============================================================

retention_rows = []

# Stage 1: all 1901 parent.
for group_type, group_col in [
    ("CLASS", "blazar_class"),
    ("SED", "SED4"),
    ("REDSHIFT_STATUS", "redshift_status"),
]:
    add_retention_rows(
        retention_rows,
        flow,
        stage="STAGE1_PARENT_TO_ZTF_ANY",
        outcome="ZTF_ANY",
        group_type=group_type,
        group_col=group_col,
    )

# Stage 2: only 1456 with any ZTF coverage.
flow_ztf = flow.loc[
    flow["ZTF_ANY"]
].copy()

for group_type, group_col in [
    ("CLASS", "blazar_class"),
    ("SED", "SED4"),
    ("REDSHIFT_STATUS", "redshift_status"),
]:
    add_retention_rows(
        retention_rows,
        flow_ztf,
        stage="STAGE2_ZTF_ANY_TO_ANALYSIS",
        outcome="ANALYSIS_SELECTED",
        group_type=group_type,
        group_col=group_col,
    )

# Overall 1901 -> 1061 final.
for group_type, group_col in [
    ("CLASS", "blazar_class"),
    ("SED", "SED4"),
    ("REDSHIFT_STATUS", "redshift_status"),
]:
    add_retention_rows(
        retention_rows,
        flow,
        stage="OVERALL_PARENT_TO_ANALYSIS",
        outcome="ANALYSIS_SELECTED",
        group_type=group_type,
        group_col=group_col,
    )

retention = pd.DataFrame(
    retention_rows
)

retention.to_csv(
    OUT_RETENTION,
    index=False
)


# ============================================================
# LOGISTIC SELECTION MODELS
# ============================================================

M0_PRED = [
    "FSRQ",
]

M1_PRED = [
    "FSRQ",
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "Dec2",
]

M2_PRED = [
    "FSRQ",
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "Dec2",
    "SED_HSP",
    "SED_ISP",
    "SED_UNKNOWN",
    "redshift_known",
    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",
]

M0_CONT = []

M1_CONT = [
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "Dec2",
]

M2_CONT = [
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "Dec2",
    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",
]

model_rows = []

# Stage 1 apply to all 1901.
for model_name, preds, cont in [
    ("M0_CLASS", M0_PRED, M0_CONT),
    ("M1_CLASS_SKY", M1_PRED, M1_CONT),
    ("M2_FULL_PARENT", M2_PRED, M2_CONT),
]:
    fit, pred, rows, scaling = fit_glm_stage(
        train_df=flow,
        apply_df=flow,
        outcome="ZTF_ANY",
        stage_name="STAGE1_PARENT_TO_ZTF_ANY",
        model_name=model_name,
        predictors=preds,
        continuous_predictors=cont,
    )

    model_rows.extend(
        rows
    )

    if model_name == "M2_FULL_PARENT":
        flow[
            "p_stage1_ztf_any_full"
        ] = pred

# Stage 2 train/apply only within the 1456 ZTF_ANY sample.
for model_name, preds, cont in [
    ("M0_CLASS", M0_PRED, M0_CONT),
    ("M1_CLASS_SKY", M1_PRED, M1_CONT),
    ("M2_FULL_PARENT", M2_PRED, M2_CONT),
]:
    fit, pred, rows, scaling = fit_glm_stage(
        train_df=flow_ztf,
        apply_df=flow_ztf,
        outcome="ANALYSIS_SELECTED",
        stage_name="STAGE2_ZTF_ANY_TO_ANALYSIS",
        model_name=model_name,
        predictors=preds,
        continuous_predictors=cont,
    )

    model_rows.extend(
        rows
    )

    if model_name == "M2_FULL_PARENT":
        pred_map = dict(
            zip(
                flow_ztf[
                    "blazar_id"
                ],
                pred,
            )
        )

        flow[
            "p_stage2_analysis_given_ztf_full"
        ] = (
            flow["blazar_id"]
            .map(pred_map)
        )

# Product probability is defined for final selection.
flow[
    "p_final_analysis_full"
] = (
    flow[
        "p_stage1_ztf_any_full"
    ]
    *
    flow[
        "p_stage2_analysis_given_ztf_full"
    ]
)

models = pd.DataFrame(
    model_rows
)

# BH within each stage-model family across non-intercept coefficients.
models[
    "q_BH_within_stage_model"
] = np.nan

for (
    stage,
    model_name
), idx in models.groupby(
    [
        "stage",
        "model",
    ]
).groups.items():

    idx = list(idx)

    nonconst = [
        i
        for i in idx
        if models.loc[
            i,
            "term"
        ]
        !=
        "const"
    ]

    models.loc[
        nonconst,
        "q_BH_within_stage_model"
    ] = bh_qvalues(
        models.loc[
            nonconst,
            "p_value"
        ].to_numpy(
            dtype=float
        )
    )

models.to_csv(
    OUT_MODELS,
    index=False
)


# ============================================================
# RAW CLASS ODDS
# ============================================================

raw1 = raw_class_or(
    flow,
    "ZTF_ANY",
)

raw2 = raw_class_or(
    flow_ztf,
    "ANALYSIS_SELECTED",
)

raw_all = raw_class_or(
    flow,
    "ANALYSIS_SELECTED",
)


# ============================================================
# SAVE FLOW MASTER
# ============================================================

flow.to_csv(
    OUT_FLOW,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

def get_full_fsrq(stage):
    x = models.loc[
        models["stage"].eq(stage)
        &
        models["model"].eq("M2_FULL_PARENT")
        &
        models["term"].eq("FSRQ")
    ]

    if len(x) != 1:
        raise RuntimeError(
            f"Cannot locate unique FULL FSRQ coefficient for {stage}"
        )

    return x.iloc[0]


m1 = get_full_fsrq(
    "STAGE1_PARENT_TO_ZTF_ANY"
)

m2 = get_full_fsrq(
    "STAGE2_ZTF_ANY_TO_ANALYSIS"
)

# Descriptive group helper.
def retention_line(
    stage,
    group_type,
):
    x = retention.loc[
        retention["stage"].eq(stage)
        &
        retention["group_type"].eq(group_type)
    ].sort_values(
        "group"
    )

    return "; ".join(
        [
            (
                f"{r['group']} "
                f"{int(r['N_selected'])}/{int(r['N_input'])}="
                f"{r['retention_fraction']:.3f}"
            )
            for _, r in x.iterrows()
        ]
    )


lines = [
    "BLAZAR_I - STAGE 06D1 FINAL SUMMARY",
    "=" * 78,
    "",
    "FLOW COUNTS:",
    f"  Clean Fermi parent                = {len(flow)}",
    f"  ZTF any g/r object coverage       = {n_any}",
    f"  ZTF both g+r object coverage      = {n_gr}",
    f"  GOLD+SILVER analysis sample       = {n_analysis}",
    f"  GOLD sample                       = {n_gold}",
    "",
    "RETENTION FRACTIONS:",
    (
        f"  Parent -> ZTF any                 = "
        f"{n_any}/{len(flow)}={n_any/len(flow):.3f}"
    ),
    (
        f"  ZTF any -> analysis               = "
        f"{n_analysis}/{n_any}={n_analysis/n_any:.3f}"
    ),
    (
        f"  Parent -> analysis                = "
        f"{n_analysis}/{len(flow)}={n_analysis/len(flow):.3f}"
    ),
    "",
    "CLASS RETENTION:",
    (
        "  Stage 1: "
        +
        retention_line(
            "STAGE1_PARENT_TO_ZTF_ANY",
            "CLASS"
        )
    ),
    (
        "  Stage 2: "
        +
        retention_line(
            "STAGE2_ZTF_ANY_TO_ANALYSIS",
            "CLASS"
        )
    ),
    (
        "  Overall: "
        +
        retention_line(
            "OVERALL_PARENT_TO_ANALYSIS",
            "CLASS"
        )
    ),
    "",
    "SED RETENTION:",
    (
        "  Stage 1: "
        +
        retention_line(
            "STAGE1_PARENT_TO_ZTF_ANY",
            "SED"
        )
    ),
    (
        "  Stage 2: "
        +
        retention_line(
            "STAGE2_ZTF_ANY_TO_ANALYSIS",
            "SED"
        )
    ),
    (
        "  Overall: "
        +
        retention_line(
            "OVERALL_PARENT_TO_ANALYSIS",
            "SED"
        )
    ),
    "",
    "RAW FSRQ vs BLL SELECTION ODDS:",
    (
        "  Stage 1 parent->ZTF any: "
        f"OR={raw1['OR']:.3f} "
        f"({raw1['CI_low']:.3f}-{raw1['CI_high']:.3f}), "
        f"p={raw1['p']:.3g}"
    ),
    (
        "  Stage 2 ZTF any->analysis: "
        f"OR={raw2['OR']:.3f} "
        f"({raw2['CI_low']:.3f}-{raw2['CI_high']:.3f}), "
        f"p={raw2['p']:.3g}"
    ),
    (
        "  Overall parent->analysis: "
        f"OR={raw_all['OR']:.3f} "
        f"({raw_all['CI_low']:.3f}-{raw_all['CI_high']:.3f}), "
        f"p={raw_all['p']:.3g}"
    ),
    "",
    "FULL PARENT-LEVEL CONTROLLED FSRQ EFFECT:",
    (
        "  Stage 1 parent->ZTF any: "
        f"OR={m1['OR']:.3f} "
        f"({m1['OR_ci95_low']:.3f}-{m1['OR_ci95_high']:.3f}), "
        f"p={m1['p_value']:.3g}, "
        f"q={m1['q_BH_within_stage_model']:.3g}"
    ),
    (
        "  Stage 2 ZTF any->analysis: "
        f"OR={m2['OR']:.3f} "
        f"({m2['OR_ci95_low']:.3f}-{m2['OR_ci95_high']:.3f}), "
        f"p={m2['p_value']:.3g}, "
        f"q={m2['q_BH_within_stage_model']:.3g}"
    ),
    "",
    "MODEL NOTE:",
    (
        "  The FULL models use only parent-level class, sky position, "
        "SED category, redshift-known status, gamma-ray energy flux, "
        "and gamma-ray variability. Downstream ZTF quality metrics are "
        "not used as controls."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 06D1")
print("FORMAL TWO-STAGE SELECTION-FUNCTION ANALYSIS")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_FLOW)
print(OUT_RETENTION)
print(OUT_MODELS)
print(OUT_SUMMARY)
print()
print("STAGE 06D1 COMPLETE")
