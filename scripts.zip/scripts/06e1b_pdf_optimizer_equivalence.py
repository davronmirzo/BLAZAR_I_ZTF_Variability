# ============================================================
# BLAZAR_I — STAGE 06E1B
# FLUX-PDF OPTIMIZER / REFIT EQUIVALENCE AUDIT
#
# Purpose:
#   Verify that the exact STAGE 03A fitting machinery can be
#   reconstructed from the frozen nightly data before any
#   downsampling sensitivity analysis.
#
# Refit recipe being audited:
#   Gaussian flux MLE:
#       mu = mean(F), sigma = std(F, ddof=0)
#
#   Single lognormal MLE:
#       mu = mean(ln F), sigma = std(ln F, ddof=0)
#
#   Double lognormal:
#       sklearn GaussianMixture on ln F
#       n_components = 2
#       covariance_type = "full"
#       n_init = 10
#       max_iter = 500
#       reg_covar = 1e-4
#       random_state = 20260917
#
#   BICs are evaluated in FLUX SPACE:
#       Gaussian k=2
#       Lognormal k=2
#       Double-lognormal k=5
#
# Robust-double gate:
#   preferred BIC model == DOUBLE_LOGNORMAL
#   DeltaBIC(second-best - best) >= 10
#   smaller component weight >= 0.10
#   Ashman D >= 2
#
# Read-only relative to frozen STAGE 03A.
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.mixture import GaussianMixture
from sklearn.exceptions import ConvergenceWarning

warnings.filterwarnings(
    "ignore",
    category=ConvergenceWarning,
)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

MASTER_FILE = TABLE_DIR / "stage03a_fluxpdf_master.csv"

OUT_TABLE = TABLE_DIR / "stage06e1b_pdf_optimizer_equivalence.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06e1b_summary.txt"

RANDOM_STATE = 20260917
N_INIT = 10
MAX_ITER = 500
REG_COVAR = 1e-4


def normal_logpdf(x, mu, sigma):
    return (
        -0.5 * np.log(2.0 * np.pi)
        - np.log(sigma)
        - 0.5 * ((x - mu) / sigma) ** 2
    )


def abs_stats(x):
    x = np.asarray(x, dtype=float)
    x = np.abs(
        x[np.isfinite(x)]
    )

    if len(x) == 0:
        return (
            np.nan,
            np.nan,
            np.nan,
        )

    return (
        float(np.median(x)),
        float(np.quantile(x, 0.95)),
        float(np.max(x)),
    )


def choose_model(
    bic_g,
    bic_l,
    bic_d,
):
    vals = {
        "GAUSSIAN": float(bic_g),
        "LOGNORMAL": float(bic_l),
        "DOUBLE_LOGNORMAL": float(bic_d),
    }

    ordered = sorted(
        vals.items(),
        key=lambda kv: kv[1],
    )

    return (
        ordered[0][0],
        float(
            ordered[1][1]
            -
            ordered[0][1]
        ),
    )


def fit_one(flux):
    f = np.asarray(
        flux,
        dtype=float
    )

    f = f[
        np.isfinite(f)
        &
        (f > 0)
    ]

    n = len(f)

    if n < 2:
        raise RuntimeError(
            f"Too few flux points: N={n}"
        )

    lnf = np.log(f)

    # Gaussian flux MLE.
    g_mu = float(
        np.mean(f)
    )

    g_sig = float(
        np.std(
            f,
            ddof=0
        )
    )

    ll_g = float(
        normal_logpdf(
            f,
            g_mu,
            g_sig
        ).sum()
    )

    bic_g = (
        2.0 * math.log(n)
        -
        2.0 * ll_g
    )

    # Single lognormal MLE.
    l_mu = float(
        np.mean(lnf)
    )

    l_sig = float(
        np.std(
            lnf,
            ddof=0
        )
    )

    ll_l = float(
        (
            normal_logpdf(
                lnf,
                l_mu,
                l_sig
            )
            -
            lnf
        ).sum()
    )

    bic_l = (
        2.0 * math.log(n)
        -
        2.0 * ll_l
    )

    # Double lognormal GMM in ln F.
    gm = GaussianMixture(
        n_components=2,
        covariance_type="full",
        n_init=N_INIT,
        max_iter=MAX_ITER,
        reg_covar=REG_COVAR,
        random_state=RANDOM_STATE,
    )

    gm.fit(
        lnf.reshape(
            -1,
            1
        )
    )

    means = gm.means_[
        :,
        0
    ].astype(float)

    order = np.argsort(
        means
    )

    means = means[
        order
    ]

    weights = gm.weights_[
        order
    ].astype(float)

    variances = gm.covariances_[
        order,
        0,
        0
    ].astype(float)

    sigmas = np.sqrt(
        variances
    )

    # Re-evaluate mixture LL explicitly in lnF then include Jacobian.
    comp = np.vstack(
        [
            math.log(
                weights[0]
            )
            +
            normal_logpdf(
                lnf,
                means[0],
                sigmas[0]
            ),
            math.log(
                weights[1]
            )
            +
            normal_logpdf(
                lnf,
                means[1],
                sigmas[1]
            ),
        ]
    )

    ll_d = float(
        (
            logsumexp(
                comp,
                axis=0
            )
            -
            lnf
        ).sum()
    )

    bic_d = (
        5.0 * math.log(n)
        -
        2.0 * ll_d
    )

    sep = (
        math.sqrt(2.0)
        *
        abs(
            means[1]
            -
            means[0]
        )
        /
        math.sqrt(
            sigmas[0] ** 2
            +
            sigmas[1] ** 2
        )
    )

    smaller_weight = float(
        min(
            weights[0],
            weights[1]
        )
    )

    pref, delta = choose_model(
        bic_g,
        bic_l,
        bic_d,
    )

    robust = bool(
        pref == "DOUBLE_LOGNORMAL"
        and
        delta >= 10.0
        and
        smaller_weight >= 0.10
        and
        sep >= 2.0
    )

    return {
        "gauss_mu": g_mu,
        "gauss_sigma": g_sig,
        "gauss_bic": bic_g,
        "lnorm_mu": l_mu,
        "lnorm_sigma": l_sig,
        "lnorm_bic": bic_l,
        "weight_low": float(
            weights[0]
        ),
        "weight_high": float(
            weights[1]
        ),
        "mu_low": float(
            means[0]
        ),
        "mu_high": float(
            means[1]
        ),
        "sigma_low": float(
            sigmas[0]
        ),
        "sigma_high": float(
            sigmas[1]
        ),
        "dlnorm_bic": bic_d,
        "separation": float(
            sep
        ),
        "smaller_weight": smaller_weight,
        "preferred": pref,
        "delta_second": float(
            delta
        ),
        "robust_double": robust,
        "gmm_converged": bool(
            gm.converged_
        ),
        "gmm_n_iter": int(
            gm.n_iter_
        ),
    }


if not MASTER_FILE.exists():
    raise FileNotFoundError(
        MASTER_FILE
    )

master = pd.read_csv(
    MASTER_FILE
)

if len(master) != 2122:
    raise RuntimeError(
        f"Expected 2122 frozen rows; got {len(master)}"
    )

master["blazar_id"] = (
    master["blazar_id"]
    .astype(str)
)

rows = []

print("=" * 78)
print("BLAZAR_I — STAGE 06E1B")
print("FLUX-PDF OPTIMIZER / REFIT EQUIVALENCE AUDIT")
print("=" * 78)

for i, (
    bid,
    group
) in enumerate(
    master.groupby(
        "blazar_id",
        sort=True
    ),
    start=1,
):
    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    nightly = pd.read_parquet(
        path
    )

    for _, rr in group.iterrows():
        filt = str(
            rr["filter_name"]
        )

        flux = pd.to_numeric(
            nightly.loc[
                nightly[
                    "filter_name"
                ].astype(str).eq(filt),
                "flux_jy",
            ],
            errors="coerce"
        ).to_numpy(
            dtype=float
        )

        res = fit_one(
            flux
        )

        frozen_weight_low = float(
            rr[
                "dlnorm_weight_low"
            ]
        )

        frozen_weight_high = float(
            rr[
                "dlnorm_weight_high"
            ]
        )

        frozen_smaller = min(
            frozen_weight_low,
            frozen_weight_high
        )

        frozen_robust = bool(
            str(
                rr[
                    "preferred_bic_model"
                ]
            )
            ==
            "DOUBLE_LOGNORMAL"
            and
            float(
                rr[
                    "delta_bic_second_minus_best"
                ]
            )
            >=
            10.0
            and
            frozen_smaller >= 0.10
            and
            float(
                rr[
                    "dlnorm_component_separation"
                ]
            )
            >=
            2.0
        )

        rows.append({
            "blazar_id": bid,
            "blazar_class": rr[
                "blazar_class"
            ],
            "filter_name": filt,
            "N_nightly": int(
                rr[
                    "N_nightly"
                ]
            ),

            "gauss_mu_diff": (
                res[
                    "gauss_mu"
                ]
                -
                float(
                    rr[
                        "gauss_mu_flux"
                    ]
                )
            ),
            "gauss_sigma_diff": (
                res[
                    "gauss_sigma"
                ]
                -
                float(
                    rr[
                        "gauss_sigma_flux"
                    ]
                )
            ),
            "gauss_bic_diff": (
                res[
                    "gauss_bic"
                ]
                -
                float(
                    rr[
                        "gauss_bic"
                    ]
                )
            ),

            "lnorm_mu_diff": (
                res[
                    "lnorm_mu"
                ]
                -
                float(
                    rr[
                        "lnorm_mu_lnflux"
                    ]
                )
            ),
            "lnorm_sigma_diff": (
                res[
                    "lnorm_sigma"
                ]
                -
                float(
                    rr[
                        "lnorm_sigma_lnflux"
                    ]
                )
            ),
            "lnorm_bic_diff": (
                res[
                    "lnorm_bic"
                ]
                -
                float(
                    rr[
                        "lnorm_bic"
                    ]
                )
            ),

            "weight_low_diff": (
                res[
                    "weight_low"
                ]
                -
                frozen_weight_low
            ),
            "weight_high_diff": (
                res[
                    "weight_high"
                ]
                -
                frozen_weight_high
            ),
            "mu_low_diff": (
                res[
                    "mu_low"
                ]
                -
                float(
                    rr[
                        "dlnorm_mu_low_lnflux"
                    ]
                )
            ),
            "mu_high_diff": (
                res[
                    "mu_high"
                ]
                -
                float(
                    rr[
                        "dlnorm_mu_high_lnflux"
                    ]
                )
            ),
            "sigma_low_diff": (
                res[
                    "sigma_low"
                ]
                -
                float(
                    rr[
                        "dlnorm_sigma_low_lnflux"
                    ]
                )
            ),
            "sigma_high_diff": (
                res[
                    "sigma_high"
                ]
                -
                float(
                    rr[
                        "dlnorm_sigma_high_lnflux"
                    ]
                )
            ),
            "dlnorm_bic_diff": (
                res[
                    "dlnorm_bic"
                ]
                -
                float(
                    rr[
                        "dlnorm_bic"
                    ]
                )
            ),
            "separation_diff": (
                res[
                    "separation"
                ]
                -
                float(
                    rr[
                        "dlnorm_component_separation"
                    ]
                )
            ),
            "delta_second_diff": (
                res[
                    "delta_second"
                ]
                -
                float(
                    rr[
                        "delta_bic_second_minus_best"
                    ]
                )
            ),

            "preferred_frozen": str(
                rr[
                    "preferred_bic_model"
                ]
            ),
            "preferred_refit": res[
                "preferred"
            ],
            "preferred_match": bool(
                res[
                    "preferred"
                ]
                ==
                str(
                    rr[
                        "preferred_bic_model"
                    ]
                )
            ),

            "robust_frozen": frozen_robust,
            "robust_refit": res[
                "robust_double"
            ],
            "robust_match": bool(
                frozen_robust
                ==
                res[
                    "robust_double"
                ]
            ),

            "gmm_converged": res[
                "gmm_converged"
            ],
            "gmm_n_iter_refit": res[
                "gmm_n_iter"
            ],
            "gmm_n_iter_frozen": int(
                rr[
                    "dlnorm_n_iter"
                ]
            ),
        })

    if (
        i % 100 == 0
        or
        i == 1061
    ):
        print(
            f"Processed {i}/1061 sources"
        )

out = pd.DataFrame(
    rows
)

out.to_csv(
    OUT_TABLE,
    index=False
)

wide = out.pivot(
    index="blazar_id",
    columns="filter_name",
    values="robust_refit"
)

robust_both = int(
    (
        wide["g"].astype(bool)
        &
        wide["r"].astype(bool)
    ).sum()
)


# ============================================================
# SUMMARY
# ============================================================

fields = [
    "gauss_mu_diff",
    "gauss_sigma_diff",
    "gauss_bic_diff",
    "lnorm_mu_diff",
    "lnorm_sigma_diff",
    "lnorm_bic_diff",
    "weight_low_diff",
    "weight_high_diff",
    "mu_low_diff",
    "mu_high_diff",
    "sigma_low_diff",
    "sigma_high_diff",
    "dlnorm_bic_diff",
    "separation_diff",
    "delta_second_diff",
]

stats = {
    c: abs_stats(
        out[c]
    )
    for c in fields
}

pref_mismatch = int(
    (
        ~out[
            "preferred_match"
        ]
    ).sum()
)

robust_mismatch = int(
    (
        ~out[
            "robust_match"
        ]
    ).sum()
)

not_converged = int(
    (
        ~out[
            "gmm_converged"
        ]
    ).sum()
)

niter_match = int(
    (
        out[
            "gmm_n_iter_refit"
        ]
        ==
        out[
            "gmm_n_iter_frozen"
        ]
    ).sum()
)

lines = [
    "BLAZAR_I - STAGE 06E1B FINAL SUMMARY",
    "=" * 78,
    "",
    f"Rows audited: {len(out)}",
    "",
    "ABSOLUTE PARAMETER / BIC DIFFERENCES",
    "(median, p95, max):",
]

for c in fields:
    med, p95, mx = stats[c]

    lines.append(
        f"  {c}: "
        f"{med:.3e}, "
        f"{p95:.3e}, "
        f"{mx:.3e}"
    )

lines += [
    "",
    "CLASSIFICATION EQUIVALENCE:",
    (
        f"  preferred-model mismatches = "
        f"{pref_mismatch}/{len(out)}"
    ),
    (
        f"  robust-double mismatches   = "
        f"{robust_mismatch}/{len(out)}"
    ),
    (
        f"  reconstructed robust-both  = "
        f"{robust_both}/1061"
    ),
    "",
    "GMM OPTIMIZER:",
    (
        f"  non-converged refits       = "
        f"{not_converged}/{len(out)}"
    ),
    (
        f"  exact n_iter matches       = "
        f"{niter_match}/{len(out)}"
    ),
    "",
    "DECISION RULE:",
    (
        "  Sampling-sensitivity refits are authorized if preferred-model "
        "and robust-double classification reproduce the frozen STAGE 03A "
        "results exactly or to a scientifically negligible numerical "
        "difference, with no systematic optimizer failure."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_TABLE)
print(OUT_SUMMARY)
print()
print("STAGE 06E1B COMPLETE")
