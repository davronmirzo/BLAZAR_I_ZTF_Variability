# ============================================================
# BLAZAR_I — STAGE 02B3
# Resumable per-source ZTF DR24 science preprocessing
# ============================================================

from pathlib import Path
import argparse
import math
import sys
import time
import traceback

import numpy as np
import pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument("--limit", type=int, default=None,
                    help="Process at most this many unfinished sources.")
args = parser.parse_args()

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw" / "ztf" / "stage02b2_sources"
OUT_DIR = ROOT / "data" / "processed" / "stage02b3_sources"
INTERIM_DIR = ROOT / "data" / "interim"
AUDIT_DIR = ROOT / "outputs" / "audit"
TABLE_DIR = ROOT / "outputs" / "tables"
PARENT_FILE = INTERIM_DIR / "stage01_parent_clean_fsrq_bll.csv"
LEDGER_FILE = INTERIM_DIR / "stage02b1_objectid_download_ledger.csv"
DOWNLOAD_MANIFEST = AUDIT_DIR / "stage02b2_object_download_manifest.csv"

OUT_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)

# Frozen primary processing rules
MAGERR_MAX = 0.10
OFFSET_PAIR_TOL_DAYS = 0.02       # 28.8 min
MIN_OFFSET_PAIRS = 5
MIN_OFFSET_TO_APPLY_MAG = 0.005
PAIR_CLIP_NMAD = 5.0
PAIR_CLIP_MIN_MAG = 0.02
NEAR_DUPLICATE_SECONDS = 30.0      # audit only
COLOR_PAIR_MAX_DAYS = 0.25         # 6 h, same MJD night
DAYS_PER_YEAR = 365.25

# Final operational sample criteria use NIGHTLY points
GOLD_N = 100
GOLD_BASELINE_YR = 4.0
GOLD_COLOR_N = 30
SILVER_N = 50
SILVER_BASELINE_YR = 3.0
SILVER_COLOR_N = 15


def clean_file(bid):
    return OUT_DIR / f"{bid}_CLEAN_HOM.parquet"


def nightly_file(bid):
    return OUT_DIR / f"{bid}_NIGHTLY.parquet"


def offsets_file(bid):
    return OUT_DIR / f"{bid}_OFFSETS.csv"


def summary_file(bid):
    return OUT_DIR / f"{bid}_SUMMARY.csv"


def done_file(bid):
    return OUT_DIR / f"{bid}.done"


def temp_path(path):
    return path.with_name(path.name + ".tmp")


def remove_if_exists(path):
    if path.exists():
        path.unlink()


def atomic_parquet(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_parquet(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)


def atomic_csv(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_csv(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)


def atomic_text(text, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    tmp.write_text(text, encoding="utf-8")
    remove_if_exists(path)
    tmp.replace(path)


def robust_median_mad(values):
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return np.nan, np.nan
    med = float(np.median(x))
    mad = float(1.4826 * np.median(np.abs(x - med)))
    return med, mad


def robust_clip_offsets(values):
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return x
    med, mad = robust_median_mad(x)
    if not np.isfinite(mad) or mad <= 0:
        return x
    width = max(PAIR_CLIP_NMAD * mad, PAIR_CLIP_MIN_MAG)
    return x[np.abs(x - med) <= width]


def make_direct_pairs(reference, secondary):
    ref = (reference[["hmjd", "mag", "magerr"]]
           .dropna().sort_values("hmjd").reset_index(drop=True).copy())
    sec = (secondary[["hmjd", "mag", "magerr"]]
           .dropna().sort_values("hmjd").reset_index(drop=True).copy())
    cols = ["t_sec", "t_ref", "dt_days", "mag_sec", "mag_ref",
            "delta_mag", "ref_row", "sec_row"]
    if len(ref) == 0 or len(sec) == 0:
        return pd.DataFrame(columns=cols)

    ref_work = pd.DataFrame({
        "tkey": ref["hmjd"].to_numpy(),
        "t_ref": ref["hmjd"].to_numpy(),
        "mag_ref": ref["mag"].to_numpy(),
        "magerr_ref": ref["magerr"].to_numpy(),
        "ref_row": np.arange(len(ref), dtype=int),
    })
    sec_work = pd.DataFrame({
        "tkey": sec["hmjd"].to_numpy(),
        "t_sec": sec["hmjd"].to_numpy(),
        "mag_sec": sec["mag"].to_numpy(),
        "magerr_sec": sec["magerr"].to_numpy(),
        "sec_row": np.arange(len(sec), dtype=int),
    })
    pairs = pd.merge_asof(
        sec_work.sort_values("tkey"),
        ref_work.sort_values("tkey"),
        on="tkey", direction="nearest", tolerance=OFFSET_PAIR_TOL_DAYS,
    )
    pairs = pairs.dropna(subset=["t_ref", "mag_ref", "mag_sec", "ref_row"]).copy()
    if len(pairs) == 0:
        return pd.DataFrame(columns=cols)
    pairs["ref_row"] = pairs["ref_row"].astype(int)
    pairs["dt_days"] = np.abs(pairs["t_sec"] - pairs["t_ref"])
    pairs["delta_mag"] = pairs["mag_sec"] - pairs["mag_ref"]
    # One-to-one use of reference observations.
    pairs = (pairs.sort_values(["dt_days", "sec_row", "ref_row"])
             .drop_duplicates(subset=["ref_row"], keep="first")
             .sort_values("t_sec").reset_index(drop=True))
    return pairs


def preprocess_source(raw, bid):
    raw = raw.copy()
    required = ["blazar_id", "ztf_objectid", "filter_name", "hmjd",
                "mag", "magerr", "catflags"]
    missing = [c for c in required if c not in raw.columns]
    if len(raw) > 0 and missing:
        raise RuntimeError(f"{bid}: missing RAW columns: " + ", ".join(missing))

    empty_offsets_cols = [
        "blazar_id", "filter_name", "reference_oid", "ztf_objectid",
        "N_clean_object", "N_pairs_raw", "N_pairs_used",
        "median_offset_mag", "mad_offset_mag", "offset_unc_mag",
        "offset_applied_mag", "status",
    ]

    if len(raw) == 0:
        clean = pd.DataFrame(columns=required + [
            "mag_hom", "magerr_hom", "object_offset_mag",
            "object_offset_unc_mag", "night_id",
        ])
        return clean, pd.DataFrame(columns=empty_offsets_cols), 0

    for col in ["ztf_objectid", "filterid", "hmjd", "mag", "magerr", "catflags"]:
        if col in raw.columns:
            raw[col] = pd.to_numeric(raw[col], errors="coerce")
    raw["filter_name"] = raw["filter_name"].fillna("").astype(str).str.strip().str.lower()

    mask = (
        raw["filter_name"].isin(["g", "r"])
        & np.isfinite(raw["hmjd"])
        & np.isfinite(raw["mag"])
        & np.isfinite(raw["magerr"])
        & np.isfinite(raw["catflags"])
        & (raw["catflags"] == 0)
        & (raw["magerr"] > 0)
        & (raw["magerr"] <= MAGERR_MAX)
        & np.isfinite(raw["ztf_objectid"])
    )
    clean = raw.loc[mask].copy()

    if len(clean) == 0:
        clean = pd.DataFrame(columns=list(raw.columns) + [
            "mag_hom", "magerr_hom", "object_offset_mag",
            "object_offset_unc_mag", "night_id",
        ])
        return clean, pd.DataFrame(columns=empty_offsets_cols), 0

    clean["ztf_objectid"] = clean["ztf_objectid"].astype("int64")
    clean = clean.sort_values(["filter_name", "hmjd", "ztf_objectid"]).reset_index(drop=True)
    clean["mag_hom"] = clean["mag"]
    clean["magerr_hom"] = clean["magerr"]
    clean["object_offset_mag"] = 0.0
    clean["object_offset_unc_mag"] = 0.0

    offset_rows = []
    for filt in ["g", "r"]:
        fd = clean.loc[clean["filter_name"] == filt]
        if len(fd) == 0:
            continue
        counts = fd.groupby("ztf_objectid").size()
        max_n = int(counts.max())
        ref_candidates = sorted(int(x) for x in counts.loc[counts == max_n].index)
        ref_oid = ref_candidates[0]
        ref = fd.loc[fd["ztf_objectid"] == ref_oid].copy()

        for oid in sorted(int(x) for x in fd["ztf_objectid"].unique()):
            obj = fd.loc[fd["ztf_objectid"] == oid].copy()
            n_obj = len(obj)
            if oid == ref_oid:
                offset_rows.append({
                    "blazar_id": bid, "filter_name": filt,
                    "reference_oid": ref_oid, "ztf_objectid": oid,
                    "N_clean_object": n_obj, "N_pairs_raw": n_obj,
                    "N_pairs_used": n_obj, "median_offset_mag": 0.0,
                    "mad_offset_mag": 0.0, "offset_unc_mag": 0.0,
                    "offset_applied_mag": 0.0, "status": "REFERENCE",
                })
                continue

            pairs = make_direct_pairs(ref, obj)
            n_pairs_raw = len(pairs)
            if n_pairs_raw > 0:
                clipped = robust_clip_offsets(pairs["delta_mag"].to_numpy())
                n_pairs_used = len(clipped)
                med, mad = robust_median_mad(clipped)
                offset_unc = (float(mad / math.sqrt(n_pairs_used))
                              if n_pairs_used > 0 and np.isfinite(mad) else np.nan)
            else:
                n_pairs_used, med, mad, offset_unc = 0, np.nan, np.nan, np.nan

            applied = 0.0
            if n_pairs_raw == 0:
                status = "NO_OVERLAP"
            elif n_pairs_used < MIN_OFFSET_PAIRS:
                status = "TOO_FEW_PAIRS"
            elif not np.isfinite(med):
                status = "OFFSET_INVALID"
            elif abs(med) < MIN_OFFSET_TO_APPLY_MAG:
                status = "OFFSET_NEGLIGIBLE"
            else:
                status = "CORRECTED"
                applied = float(med)
                idx = ((clean["filter_name"] == filt)
                       & (clean["ztf_objectid"] == oid))
                clean.loc[idx, "mag_hom"] = clean.loc[idx, "mag"] - applied
                clean.loc[idx, "object_offset_mag"] = applied
                if np.isfinite(offset_unc):
                    clean.loc[idx, "object_offset_unc_mag"] = offset_unc
                    clean.loc[idx, "magerr_hom"] = np.sqrt(
                        clean.loc[idx, "magerr"] ** 2 + offset_unc ** 2
                    )

            offset_rows.append({
                "blazar_id": bid, "filter_name": filt,
                "reference_oid": ref_oid, "ztf_objectid": oid,
                "N_clean_object": n_obj, "N_pairs_raw": n_pairs_raw,
                "N_pairs_used": n_pairs_used, "median_offset_mag": med,
                "mad_offset_mag": mad, "offset_unc_mag": offset_unc,
                "offset_applied_mag": applied, "status": status,
            })

    offsets = pd.DataFrame(offset_rows, columns=empty_offsets_cols)

    near_duplicate_pairs = 0
    near_tol_days = NEAR_DUPLICATE_SECONDS / 86400.0
    for filt in ["g", "r"]:
        fd = clean.loc[clean["filter_name"] == filt].sort_values("hmjd")
        if len(fd) >= 2:
            near_duplicate_pairs += int(
                np.sum(np.abs(np.diff(fd["hmjd"].to_numpy())) <= near_tol_days)
            )

    clean["night_id"] = np.floor(clean["hmjd"]).astype("int64")
    return clean, offsets, near_duplicate_pairs


def build_nightly(clean):
    cols = [
        "blazar_id", "fermi_name", "counterpart_name", "blazar_class",
        "filter_name", "night_id", "hmjd", "mag", "magerr",
        "N_epoch", "N_objectid", "intranight_std_mag", "flux_jy", "fluxerr_jy",
    ]
    if len(clean) == 0:
        return pd.DataFrame(columns=cols)

    rows = []
    for (bid, filt, night_id), g in clean.groupby(
        ["blazar_id", "filter_name", "night_id"], sort=False
    ):
        m = g["mag_hom"].to_numpy(dtype=float)
        e = g["magerr_hom"].to_numpy(dtype=float)
        t = g["hmjd"].to_numpy(dtype=float)
        good = np.isfinite(m) & np.isfinite(e) & np.isfinite(t) & (e > 0)
        m, e, t = m[good], e[good], t[good]
        if len(m) == 0:
            continue
        w = 1.0 / (e ** 2)
        mean_mag = float(np.sum(w * m) / np.sum(w))
        formal_err = float(math.sqrt(1.0 / np.sum(w)))
        if len(m) >= 2:
            intranight_std = float(np.std(m, ddof=1))
            scatter_err = float(intranight_std / math.sqrt(len(m)))
            nightly_err = max(formal_err, scatter_err)
        else:
            intranight_std = np.nan
            nightly_err = formal_err

        hmjd = float(np.median(t))
        flux_jy = float(3631.0 * 10.0 ** (-0.4 * mean_mag))
        fluxerr_jy = float((math.log(10.0) / 2.5) * flux_jy * nightly_err)
        first = g.iloc[0]
        rows.append({
            "blazar_id": bid,
            "fermi_name": first.get("fermi_name", np.nan),
            "counterpart_name": first.get("counterpart_name", np.nan),
            "blazar_class": first.get("blazar_class", np.nan),
            "filter_name": filt,
            "night_id": int(night_id),
            "hmjd": hmjd,
            "mag": mean_mag,
            "magerr": nightly_err,
            "N_epoch": int(len(m)),
            "N_objectid": int(g.loc[good, "ztf_objectid"].nunique()),
            "intranight_std_mag": intranight_std,
            "flux_jy": flux_jy,
            "fluxerr_jy": fluxerr_jy,
        })

    nightly = pd.DataFrame(rows, columns=cols)
    if len(nightly) > 0:
        nightly = nightly.sort_values(["filter_name", "hmjd", "night_id"]).reset_index(drop=True)
    return nightly


def build_colour_pairs(nightly):
    cols = [
        "night_id", "hmjd_g", "hmjd_r", "dt_gr_days", "g_mag", "g_magerr",
        "r_mag", "r_magerr", "g_minus_r", "g_minus_r_err",
    ]
    if len(nightly) == 0:
        return pd.DataFrame(columns=cols)

    g = nightly.loc[nightly["filter_name"] == "g", ["night_id", "hmjd", "mag", "magerr"]].rename(
        columns={"hmjd": "hmjd_g", "mag": "g_mag", "magerr": "g_magerr"})
    r = nightly.loc[nightly["filter_name"] == "r", ["night_id", "hmjd", "mag", "magerr"]].rename(
        columns={"hmjd": "hmjd_r", "mag": "r_mag", "magerr": "r_magerr"})
    if len(g) == 0 or len(r) == 0:
        return pd.DataFrame(columns=cols)

    pairs = g.merge(r, on="night_id", how="inner", validate="one_to_one")
    pairs["dt_gr_days"] = np.abs(pairs["hmjd_g"] - pairs["hmjd_r"])
    pairs = pairs.loc[pairs["dt_gr_days"] <= COLOR_PAIR_MAX_DAYS].copy()
    pairs["g_minus_r"] = pairs["g_mag"] - pairs["r_mag"]
    pairs["g_minus_r_err"] = np.sqrt(pairs["g_magerr"] ** 2 + pairs["r_magerr"] ** 2)
    return pairs[cols].sort_values("night_id").reset_index(drop=True)


def summarize_source(bid, raw, clean, offsets, nightly, colour_pairs,
                     near_duplicate_pairs, parent_row):
    def fcount(df, filt):
        return int((df["filter_name"] == filt).sum()) if len(df) else 0

    gnight = nightly.loc[nightly["filter_name"] == "g"] if len(nightly) else nightly.iloc[0:0]
    rnight = nightly.loc[nightly["filter_name"] == "r"] if len(nightly) else nightly.iloc[0:0]

    def baseline_days(df):
        return float(df["hmjd"].max() - df["hmjd"].min()) if len(df) >= 2 else 0.0

    ng_clean, nr_clean = fcount(clean, "g"), fcount(clean, "r")
    ng_night, nr_night = len(gnight), len(rnight)
    tg_days, tr_days = baseline_days(gnight), baseline_days(rnight)
    tg_yr, tr_yr = tg_days / DAYS_PER_YEAR, tr_days / DAYS_PER_YEAR
    n_colour = len(colour_pairs)

    if len(offsets):
        n_corrected = int((offsets["status"] == "CORRECTED").sum())
        n_negligible = int((offsets["status"] == "OFFSET_NEGLIGIBLE").sum())
        n_too_few = int((offsets["status"] == "TOO_FEW_PAIRS").sum())
        n_no_overlap = int((offsets["status"] == "NO_OVERLAP").sum())
    else:
        n_corrected = n_negligible = n_too_few = n_no_overlap = 0

    n_oid_g = int(clean.loc[clean["filter_name"] == "g", "ztf_objectid"].nunique()) if len(clean) else 0
    n_oid_r = int(clean.loc[clean["filter_name"] == "r", "ztf_objectid"].nunique()) if len(clean) else 0

    passes_gold = (
        ng_night >= GOLD_N and nr_night >= GOLD_N
        and tg_yr >= GOLD_BASELINE_YR and tr_yr >= GOLD_BASELINE_YR
        and n_colour >= GOLD_COLOR_N
    )
    passes_silver_min = (
        ng_night >= SILVER_N and nr_night >= SILVER_N
        and tg_yr >= SILVER_BASELINE_YR and tr_yr >= SILVER_BASELINE_YR
        and n_colour >= SILVER_COLOR_N
    )
    tier = "GOLD" if passes_gold else ("SILVER" if passes_silver_min else "NOT_QUALIFIED")

    row = {
        "blazar_id": bid,
        "Source_Name": parent_row.get("Source_Name", np.nan),
        "ASSOC1": parent_row.get("ASSOC1", np.nan),
        "blazar_class": parent_row.get("blazar_class", np.nan),
        "redshift_clean": parent_row.get("redshift_clean", np.nan),
        "SED_class_clean": parent_row.get("SED_class_clean", np.nan),
        "N_raw_epochs": int(len(raw)),
        "N_clean_epochs": int(len(clean)),
        "N_clean_g": ng_clean,
        "N_clean_r": nr_clean,
        "N_nights_g": int(ng_night),
        "N_nights_r": int(nr_night),
        "baseline_g_days": tg_days,
        "baseline_r_days": tr_days,
        "baseline_g_yr": tg_yr,
        "baseline_r_yr": tr_yr,
        "N_colour_pairs": int(n_colour),
        "N_clean_objectid_g": n_oid_g,
        "N_clean_objectid_r": n_oid_r,
        "N_offsets_corrected": n_corrected,
        "N_offsets_negligible": n_negligible,
        "N_offsets_too_few_pairs": n_too_few,
        "N_offsets_no_overlap": n_no_overlap,
        "N_near_duplicate_pairs_30s": int(near_duplicate_pairs),
        "has_g": bool(ng_night > 0),
        "has_r": bool(nr_night > 0),
        "has_gr": bool(ng_night > 0 and nr_night > 0),
        "passes_gold": bool(passes_gold),
        "passes_silver_min": bool(passes_silver_min),
        "sample_tier": tier,
    }
    return pd.DataFrame([row])


# ============================================================
# LOAD MASTER TABLES
# ============================================================

if not RAW_DIR.exists():
    raise FileNotFoundError(RAW_DIR)

parent = pd.read_csv(PARENT_FILE)
ledger = pd.read_csv(LEDGER_FILE)
manifest = pd.read_csv(DOWNLOAD_MANIFEST)

print("=" * 78)
print("BLAZAR_I — STAGE 02B3")
print("CLEANING + HOMOGENIZATION + NIGHTLY + SAMPLE SELECTION")
print("=" * 78)
print("Parent clean Fermi sample =", len(parent))
print("02B1 ledger rows          =", len(ledger))
print("02B2 manifest rows        =", len(manifest))

source_ids = ledger["blazar_id"].dropna().astype(str).drop_duplicates().tolist()
parent_order = {str(bid): i for i, bid in enumerate(parent["blazar_id"].astype(str))}
source_ids = sorted(source_ids, key=lambda x: parent_order.get(x, 10**12))
N_SOURCE = len(source_ids)

n_raw_files = len(list(RAW_DIR.glob("*_RAW.parquet")))
n_done_files = len(list(RAW_DIR.glob("*.done")))
print()
print("02B2 RAW source files =", n_raw_files)
print("02B2 done markers     =", n_done_files)
print("02B3 source universe  =", N_SOURCE)
if n_raw_files < N_SOURCE:
    raise RuntimeError("Fewer STAGE 02B2 RAW files than source IDs.")


def source_complete(bid):
    return (clean_file(bid).exists() and nightly_file(bid).exists()
            and offsets_file(bid).exists() and summary_file(bid).exists()
            and done_file(bid).exists())


complete_before = [bid for bid in source_ids if source_complete(bid)]
print()
print("Completed 02B3 sources on disk =", len(complete_before), "/", N_SOURCE)
print("Remaining 02B3 sources         =", N_SOURCE - len(complete_before))

parent_lookup = parent.drop_duplicates(subset=["blazar_id"]).set_index("blazar_id")
processed_this_run = 0
session_start = time.time()

for source_number, bid in enumerate(source_ids, start=1):
    if source_complete(bid):
        continue
    if args.limit is not None and processed_this_run >= args.limit:
        print()
        print("Pilot limit reached:", args.limit)
        break

    raw_in = RAW_DIR / f"{bid}_RAW.parquet"
    if not raw_in.exists():
        raise FileNotFoundError(raw_in)

    if not done_file(bid).exists():
        for path in [clean_file(bid), nightly_file(bid), offsets_file(bid), summary_file(bid)]:
            remove_if_exists(path)
            remove_if_exists(temp_path(path))

    print()
    print("=" * 78)
    print(f"SOURCE {source_number}/{N_SOURCE}")
    print("blazar_id =", bid)
    t0 = time.time()

    try:
        raw = pd.read_parquet(raw_in)
        print("RAW epochs =", len(raw))
        clean, offsets, near_duplicates = preprocess_source(raw, bid)
        nightly = build_nightly(clean)
        colour_pairs = build_colour_pairs(nightly)
        parent_row = parent_lookup.loc[bid] if bid in parent_lookup.index else pd.Series(dtype=object)
        summary = summarize_source(
            bid, raw, clean, offsets, nightly, colour_pairs,
            near_duplicates, parent_row,
        )

        atomic_parquet(clean, clean_file(bid))
        atomic_parquet(nightly, nightly_file(bid))
        atomic_csv(offsets, offsets_file(bid))
        atomic_csv(summary, summary_file(bid))

        elapsed = time.time() - t0
        atomic_text(
            "COMPLETE\n"
            f"blazar_id={bid}\n"
            f"raw_epochs={len(raw)}\n"
            f"clean_epochs={len(clean)}\n"
            f"nightly_points={len(nightly)}\n"
            f"colour_pairs={len(colour_pairs)}\n"
            f"elapsed_seconds={elapsed:.6f}\n",
            done_file(bid),
        )

        row = summary.iloc[0]
        print("CLEAN epochs =", int(row["N_clean_epochs"]))
        print("Nightly g/r  =", int(row["N_nights_g"]), "/", int(row["N_nights_r"]))
        print("Colour pairs =", int(row["N_colour_pairs"]))
        print("Tier         =", row["sample_tier"])
        print("CHECKPOINT   =", done_file(bid).name)
        processed_this_run += 1

    except Exception:
        print()
        print("FAILED SOURCE:", bid)
        traceback.print_exc()
        (AUDIT_DIR / "stage02b3_last_failure.txt").write_text(
            "BLAZAR_I STAGE 02B3\n"
            "SOURCE PROCESSING FAILURE\n"
            f"blazar_id={bid}\n"
            f"source_number={source_number}/{N_SOURCE}\n",
            encoding="utf-8",
        )
        sys.exit(30)

complete_now = [bid for bid in source_ids if source_complete(bid)]
session_elapsed = time.time() - session_start
print()
print("=" * 78)
print("STAGE 02B3 CURRENT STATUS")
print("=" * 78)
print("Completed sources =", len(complete_now), "/", N_SOURCE)
print("Remaining         =", N_SOURCE - len(complete_now))
print(f"Session elapsed   = {session_elapsed/60:.2f} min")

# ============================================================
# GLOBAL PRODUCTS WHEN ALL SOURCES COMPLETE
# ============================================================

if len(complete_now) == N_SOURCE:
    print()
    print("All STAGE 02B3 sources complete.")

    summary_frames = []
    offset_frames = []
    for bid in source_ids:
        summary_frames.append(pd.read_csv(summary_file(bid)))
        off = pd.read_csv(offsets_file(bid))
        if len(off) > 0:
            offset_frames.append(off)

    quality = pd.concat(summary_frames, ignore_index=True)
    all_offsets = pd.concat(offset_frames, ignore_index=True) if offset_frames else pd.DataFrame()

    gold = quality.loc[quality["sample_tier"] == "GOLD"].copy()
    silver = quality.loc[quality["sample_tier"] == "SILVER"].copy()
    analysis_sample = quality.loc[quality["sample_tier"].isin(["GOLD", "SILVER"])].copy()
    not_qualified = quality.loc[quality["sample_tier"] == "NOT_QUALIFIED"].copy()

    quality_out = TABLE_DIR / "stage02b3_source_quality.csv"
    gold_out = TABLE_DIR / "stage02b3_GOLD_sample.csv"
    silver_out = TABLE_DIR / "stage02b3_SILVER_sample.csv"
    analysis_out = TABLE_DIR / "stage02b3_GOLD_PLUS_SILVER.csv"
    notq_out = TABLE_DIR / "stage02b3_NOT_QUALIFIED.csv"
    offsets_out = AUDIT_DIR / "stage02b3_object_offsets.csv"

    quality.to_csv(quality_out, index=False)
    gold.to_csv(gold_out, index=False)
    silver.to_csv(silver_out, index=False)
    analysis_sample.to_csv(analysis_out, index=False)
    not_qualified.to_csv(notq_out, index=False)
    all_offsets.to_csv(offsets_out, index=False)

    n_with_clean = int((quality["N_clean_epochs"] > 0).sum())
    n_with_g = int(quality["has_g"].sum())
    n_with_r = int(quality["has_r"].sum())
    n_with_gr = int(quality["has_gr"].sum())
    n_gold = len(gold)
    n_silver = len(silver)
    n_analysis = len(analysis_sample)
    n_notq = len(not_qualified)
    n_gold_fsrq = int((gold["blazar_class"] == "FSRQ").sum())
    n_gold_bll = int((gold["blazar_class"] == "BLL").sum())
    n_silver_fsrq = int((silver["blazar_class"] == "FSRQ").sum())
    n_silver_bll = int((silver["blazar_class"] == "BLL").sum())

    if len(all_offsets) > 0:
        n_corrected = int((all_offsets["status"] == "CORRECTED").sum())
        n_no_overlap = int((all_offsets["status"] == "NO_OVERLAP").sum())
        n_too_few = int((all_offsets["status"] == "TOO_FEW_PAIRS").sum())
    else:
        n_corrected = n_no_overlap = n_too_few = 0

    lines = [
        "BLAZAR_I - STAGE 02B3 FINAL SUMMARY",
        "=" * 72,
        "",
        "PRIMARY QUALITY FILTER:",
        "  catflags == 0",
        f"  0 < magerr <= {MAGERR_MAX:.2f} mag",
        "",
        "OBJECT-ID HOMOGENIZATION:",
        f"  pair tolerance = {OFFSET_PAIR_TOL_DAYS:.3f} d",
        f"  minimum pairs  = {MIN_OFFSET_PAIRS}",
        f"  min correction = {MIN_OFFSET_TO_APPLY_MAG:.3f} mag",
        "",
        "COLOUR PAIRING:",
        f"  same night and |dt(g-r)| <= {COLOR_PAIR_MAX_DAYS:.2f} d",
        "",
        "SAMPLE CRITERIA USE NIGHTLY POINTS.",
        "",
        f"Input downloaded blazars    : {N_SOURCE}",
        f"Sources with clean epochs   : {n_with_clean}",
        f"Sources with g              : {n_with_g}",
        f"Sources with r              : {n_with_r}",
        f"Sources with both g+r       : {n_with_gr}",
        "",
        f"GOLD                        : {n_gold}",
        f"  GOLD FSRQ                 : {n_gold_fsrq}",
        f"  GOLD BLL                  : {n_gold_bll}",
        f"SILVER (non-GOLD)           : {n_silver}",
        f"  SILVER FSRQ               : {n_silver_fsrq}",
        f"  SILVER BLL                : {n_silver_bll}",
        f"GOLD + SILVER               : {n_analysis}",
        f"NOT QUALIFIED               : {n_notq}",
        "",
        "OBJECT-ID OFFSET AUDIT:",
        f"  corrected                 : {n_corrected}",
        f"  no direct overlap         : {n_no_overlap}",
        f"  too few pairs             : {n_too_few}",
    ]
    final_summary = "\n".join(lines)
    summary_out = AUDIT_DIR / "stage02b3_summary.txt"
    summary_out.write_text(final_summary, encoding="utf-8")

    print()
    print(final_summary)
    print()
    print("=" * 78)
    print("GLOBAL FILES SAVED")
    print("=" * 78)
    print(quality_out)
    print(gold_out)
    print(silver_out)
    print(analysis_out)
    print(notq_out)
    print(offsets_out)
    print(summary_out)
    print()
    print("STAGE 02B3 COMPLETE")
