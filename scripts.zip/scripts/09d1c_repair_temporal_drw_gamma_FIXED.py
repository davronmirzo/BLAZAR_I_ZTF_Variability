# ============================================================
# BLAZAR_I — STAGE 09D1C
# REPAIR TEMPORAL DRW CONTROLLED INFERENCE WITH GAMMA COVARIATE
#
# Purpose:
#   Stage09D1B completed all expensive EARLY/LATE DRW refits, but its
#   covariate resolver returned:
#
#       gamma = None
#
#   Therefore the printed D1/D2 models did NOT include the intended
#   gamma-ray energy-flux adjustment.
#
#   This stage DOES NOT refit any light curve.  It reuses the frozen
#   Stage09D1B DRW half-master and repairs only the regression layer.
#
# Gamma resolution:
#   Prefer an already-log-transformed energy-flux column if available.
#   Otherwise detect a raw DR4 energy-flux column and construct log10.
#
# Models, separately for EARLY and LATE:
#   D0: log(tau_rest) ~ FSRQ
#   D1: + standardized redshift + standardized gamma energy flux
#   D2: + filter-specific half median magnitude + PS1 host proxy
#
# Covariance:
#   Row-level g/r models use cluster-robust SE by blazar_id.
#
# Robustness:
#   - source-level both-band geometric mean tau
#   - separate g and r models
#   - LSP-only D2
#
# Outputs:
#   outputs/tables/stage09d1c_clustered_models_gamma_repaired.csv
#   outputs/tables/stage09d1c_source_level_models_gamma_repaired.csv
#   outputs/tables/stage09d1c_single_band_models_gamma_repaired.csv
#   outputs/tables/stage09d1c_lsp_only_models_gamma_repaired.csv
#   outputs/tables/stage09d1c_gamma_resolution_audit.csv
#   outputs/audit/stage09d1c_summary.txt
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

MASTER_FILE = TABLE_DIR / "stage09d1b_drw_half_master.csv"
CONF_FILE = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"

OUT_CLUSTER = TABLE_DIR / "stage09d1c_clustered_models_gamma_repaired.csv"
OUT_SOURCE = TABLE_DIR / "stage09d1c_source_level_models_gamma_repaired.csv"
OUT_BAND = TABLE_DIR / "stage09d1c_single_band_models_gamma_repaired.csv"
OUT_LSP = TABLE_DIR / "stage09d1c_lsp_only_models_gamma_repaired.csv"
OUT_GAMMA = TABLE_DIR / "stage09d1c_gamma_resolution_audit.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09d1c_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def parse_bool_series(s):
    num = pd.to_numeric(s, errors="coerce")
    out = pd.Series(False, index=s.index, dtype=bool)

    good = num.notna()
    out.loc[good] = num.loc[good] != 0

    rem = ~good
    if rem.any():
        txt = (
            s.loc[rem]
            .astype(str)
            .str.strip()
            .str.lower()
        )
        out.loc[rem] = txt.isin(
            ["true", "t", "yes", "y"]
        )

    return out


def first_existing(df, candidates):
    lower = {
        c.lower(): c
        for c in df.columns
    }

    for c in candidates:
        if c in df.columns:
            return c

        hit = lower.get(c.lower())
        if hit is not None:
            return hit

    return None


def standardize(s):
    x = numeric(s)
    mu = x.mean()
    sd = x.std(ddof=0)

    if not np.isfinite(sd) or sd <= 0:
        return pd.Series(
            np.nan,
            index=s.index,
            dtype=float,
        )

    return (x - mu) / sd


def cluster_ols(df, predictors, focal="FSRQ"):
    cols = [
        "log_tau_rest",
        "blazar_id",
        *predictors,
    ]

    x = df[cols].copy()

    for c in [
        "log_tau_rest",
        *predictors,
    ]:
        x[c] = numeric(x[c])

    x = x.dropna()

    if len(x) < 30:
        return {
            "N_rows": len(x),
            "N_sources": x["blazar_id"].nunique(),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": "TOO_FEW_COMPLETE_CASES",
        }

    X = sm.add_constant(
        x[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            x["log_tau_rest"].astype(float),
            X,
        ).fit(
            cov_type="cluster",
            cov_kwds={
                "groups": x["blazar_id"],
            },
        )

        beta = float(
            fit.params[focal]
        )
        se = float(
            fit.bse[focal]
        )

        return {
            "N_rows": len(x),
            "N_sources": x["blazar_id"].nunique(),
            "factor": math.exp(beta),
            "ci95_low": math.exp(
                beta
                -
                1.959963984540054
                *
                se
            ),
            "ci95_high": math.exp(
                beta
                +
                1.959963984540054
                *
                se
            ),
            "p": float(
                fit.pvalues[focal]
            ),
            "status": "OK",
        }

    except Exception as exc:
        return {
            "N_rows": len(x),
            "N_sources": x["blazar_id"].nunique(),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": (
                f"FAILED:{type(exc).__name__}"
            ),
        }


def ordinary_ols(df, predictors, focal="FSRQ"):
    cols = [
        "log_tau_rest",
        *predictors,
    ]

    x = df[cols].copy()

    for c in cols:
        x[c] = numeric(x[c])

    x = x.dropna()

    if len(x) < 30:
        return {
            "N_sources": len(x),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": "TOO_FEW_COMPLETE_CASES",
        }

    X = sm.add_constant(
        x[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            x["log_tau_rest"].astype(float),
            X,
        ).fit(
            cov_type="HC3",
        )

        beta = float(
            fit.params[focal]
        )
        se = float(
            fit.bse[focal]
        )

        return {
            "N_sources": len(x),
            "factor": math.exp(beta),
            "ci95_low": math.exp(
                beta
                -
                1.959963984540054
                *
                se
            ),
            "ci95_high": math.exp(
                beta
                +
                1.959963984540054
                *
                se
            ),
            "p": float(
                fit.pvalues[focal]
            ),
            "status": "OK",
        }

    except Exception as exc:
        return {
            "N_sources": len(x),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": (
                f"FAILED:{type(exc).__name__}"
            ),
        }


for path in [
    MASTER_FILE,
    CONF_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

master = pd.read_csv(
    MASTER_FILE,
    low_memory=False,
)

conf = pd.read_csv(
    CONF_FILE,
    low_memory=False,
)

master["blazar_id"] = (
    master["blazar_id"]
    .astype(str)
)

conf["blazar_id"] = (
    conf["blazar_id"]
    .astype(str)
)

conf = conf.drop_duplicates(
    "blazar_id"
)

master["tau_interpretable"] = (
    parse_bool_series(
        master["tau_interpretable"]
    )
)


# ============================================================
# RESOLVE STATIC COVARIATES
# ============================================================

sed_col = first_existing(
    conf,
    [
        "sed_class",
        "SED_class_clean",
        "sed_class_clean",
        "SED_class",
    ],
)

host_col = first_existing(
    conf,
    [
        "ps1_host_proxy_ri",
        "ps1_host_proxy",
        "host_proxy",
        "ps1_extension_proxy",
    ],
)

# Prefer already-log energy-flux variables.
gamma_logged_candidates = [
    "log10_gamma_energy_flux",
    "logEnergyFlux_DR4",
    "log10_Energy_Flux100_DR4",
    "fermi_screen_log_energyflux_dr4",
    "log10_Energy_Flux_DR4",
    "log_energy_flux_dr4",
    "gamma_log_energy_flux",
]

gamma_raw_candidates = [
    "gamma_energy_flux",
    "Energy_Flux100_DR4",
    "Energy_Flux_DR4",
    "Energy_Flux100",
    "Energy_Flux",
]

gamma_col = first_existing(
    conf,
    gamma_logged_candidates,
)

gamma_transform = None

if gamma_col is not None:
    conf["gamma_work"] = numeric(
        conf[gamma_col]
    )
    gamma_transform = "already_log"

else:
    raw_col = first_existing(
        conf,
        gamma_raw_candidates,
    )

    if raw_col is not None:
        raw = numeric(
            conf[raw_col]
        )

        conf["gamma_work"] = np.where(
            raw > 0,
            np.log10(raw),
            np.nan,
        )

        gamma_col = raw_col
        gamma_transform = "log10_from_raw"

    else:
        # Final heuristic: energy + flux + DR4, excluding obvious uncertainty
        # or already unrelated fractional-variability fields.
        candidates = []

        for c in conf.columns:
            cl = c.lower()

            if (
                "energy" in cl
                and
                "flux" in cl
                and
                "dr4" in cl
                and
                "err" not in cl
                and
                "unc" not in cl
            ):
                candidates.append(c)

        if len(candidates) == 1:
            gamma_col = candidates[0]
            raw = numeric(
                conf[gamma_col]
            )

            # Decide whether it is already logged from name/range.
            if (
                "log" in gamma_col.lower()
                or
                (
                    np.isfinite(raw).sum() > 0
                    and
                    raw.dropna().median() < 0
                )
            ):
                conf["gamma_work"] = raw
                gamma_transform = "heuristic_already_log"
            else:
                conf["gamma_work"] = np.where(
                    raw > 0,
                    np.log10(raw),
                    np.nan,
                )
                gamma_transform = "heuristic_log10_from_raw"

        elif len(candidates) > 1:
            raise RuntimeError(
                "Ambiguous gamma energy-flux columns: "
                +
                repr(candidates)
            )

        else:
            raise RuntimeError(
                "Could not resolve a gamma-ray energy-flux column. "
                "Columns containing 'flux': "
                +
                repr(
                    [
                        c
                        for c in conf.columns
                        if "flux" in c.lower()
                    ]
                )
            )


# ============================================================
# RESOLUTION AUDIT
# ============================================================

gamma_vals = numeric(
    conf["gamma_work"]
)

audit = pd.DataFrame(
    [
        {
            "resolved_gamma_column": gamma_col,
            "gamma_transform": gamma_transform,
            "gamma_nonnull": int(
                gamma_vals.notna().sum()
            ),
            "gamma_unique": int(
                gamma_vals.nunique(
                    dropna=True
                )
            ),
            "gamma_p01": float(
                gamma_vals.quantile(0.01)
            ),
            "gamma_median": float(
                gamma_vals.median()
            ),
            "gamma_p99": float(
                gamma_vals.quantile(0.99)
            ),
            "resolved_host_column": host_col,
            "resolved_sed_column": sed_col,
        }
    ]
)

audit.to_csv(
    OUT_GAMMA,
    index=False,
)


# ============================================================
# MERGE
# ============================================================

keep = [
    "blazar_id",
    "gamma_work",
]

if host_col is not None:
    keep.append(host_col)

if sed_col is not None:
    keep.append(sed_col)

cov = conf[
    list(dict.fromkeys(keep))
].copy()

d = master.merge(
    cov,
    on="blazar_id",
    how="left",
    validate="many_to_one",
)

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

d["redshift_work"] = numeric(
    d["redshift"]
)

d["log_tau_rest"] = np.log(
    numeric(
        d["tau_rest_days"]
    )
)

d["mag_half"] = numeric(
    d["median_mag"]
)

if host_col is not None:
    d["host_work"] = numeric(
        d[host_col]
    )
else:
    d["host_work"] = np.nan

if sed_col is not None:
    d["sed_work"] = (
        d[sed_col]
        .astype(str)
        .str.upper()
        .str.strip()
    )
else:
    d["sed_work"] = ""


# ============================================================
# MODELS
# ============================================================

cluster_rows = []
source_rows = []
band_rows = []
lsp_rows = []

for half in [
    "EARLY",
    "LATE",
]:
    x = d.loc[
        d["half"].eq(half)
        &
        d["tau_interpretable"]
        &
        np.isfinite(
            numeric(
                d["tau_rest_days"]
            )
        )
        &
        (
            numeric(
                d["tau_rest_days"]
            )
            >
            0
        )
    ].copy()

    x["z_z"] = standardize(
        x["redshift_work"]
    )

    x["gamma_z"] = standardize(
        x["gamma_work"]
    )

    x["host_z"] = standardize(
        x["host_work"]
    )

    x["mag_z"] = np.nan

    for filt in [
        "g",
        "r",
    ]:
        idx = x.index[
            x["filter_name"].eq(filt)
        ]

        x.loc[
            idx,
            "mag_z",
        ] = standardize(
            x.loc[
                idx,
                "mag_half",
            ]
        ).to_numpy()

    model_specs = {
        "D0_CLASS_ONLY": [
            "FSRQ",
        ],
        "D1_Z_GAMMA": [
            "FSRQ",
            "z_z",
            "gamma_z",
        ],
        "D2_FULL": (
            [
                "FSRQ",
                "z_z",
                "gamma_z",
                "mag_z",
            ]
            +
            (
                ["host_z"]
                if host_col is not None
                else
                []
            )
        ),
    }

    for model_name, predictors in model_specs.items():
        r = cluster_ols(
            x,
            predictors=predictors,
        )

        cluster_rows.append({
            "half": half,
            "model": model_name,
            **r,
        })

    d2_predictors = model_specs[
        "D2_FULL"
    ]

    # Single-band.
    for filt in [
        "g",
        "r",
    ]:
        xb = x.loc[
            x["filter_name"].eq(filt)
        ].copy()

        r = ordinary_ols(
            xb,
            predictors=d2_predictors,
        )

        band_rows.append({
            "half": half,
            "filter_name": filt,
            "model": "D2_FULL",
            **r,
        })

    # Source-level both-band geometric mean tau.
    piv_tau = x.pivot_table(
        index="blazar_id",
        columns="filter_name",
        values="tau_rest_days",
        aggfunc="first",
    )

    common = piv_tau.dropna(
        subset=["g", "r"]
    ).copy()

    common["tau_geom"] = np.sqrt(
        common["g"]
        *
        common["r"]
    )

    src = (
        x.sort_values(
            "filter_name"
        )
        .drop_duplicates(
            "blazar_id"
        )
        .set_index(
            "blazar_id"
        )
    )

    s = src.loc[
        common.index
    ].copy()

    s["log_tau_rest"] = np.log(
        common["tau_geom"]
    )

    piv_magz = x.pivot_table(
        index="blazar_id",
        columns="filter_name",
        values="mag_z",
        aggfunc="first",
    )

    if (
        "g" in piv_magz.columns
        and
        "r" in piv_magz.columns
    ):
        s["mag_z"] = (
            piv_magz.loc[
                s.index,
                ["g", "r"],
            ]
            .mean(axis=1)
        )

    r = ordinary_ols(
        s.reset_index(),
        predictors=d2_predictors,
    )

    source_rows.append({
        "half": half,
        "model": "D2_SOURCE_GEOMEAN",
        **r,
    })

    # LSP-only.
    if sed_col is not None:
        xlsp = x.loc[
            x["sed_work"].eq("LSP")
        ].copy()

        r = cluster_ols(
            xlsp,
            predictors=d2_predictors,
        )

        lsp_rows.append({
            "half": half,
            "model": "D2_LSP_ONLY",
            **r,
        })


cluster = pd.DataFrame(
    cluster_rows
)

source = pd.DataFrame(
    source_rows
)

band = pd.DataFrame(
    band_rows
)

lsp = pd.DataFrame(
    lsp_rows
)

cluster.to_csv(
    OUT_CLUSTER,
    index=False,
)

source.to_csv(
    OUT_SOURCE,
    index=False,
)

band.to_csv(
    OUT_BAND,
    index=False,
)

lsp.to_csv(
    OUT_LSP,
    index=False,
)


# ============================================================
# SUMMARY
# ============================================================

def get_model(df, half, model, filt=None):
    mask = (
        df["half"].eq(half)
        &
        df["model"].eq(model)
    )

    if filt is not None:
        mask = (
            mask
            &
            df["filter_name"].eq(filt)
        )

    hit = df.loc[mask]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


lines = [
    "BLAZAR_I - STAGE 09D1C FINAL SUMMARY",
    "=" * 80,
    "",
    "TEMPORAL DRW CONTROLLED-INFERENCE REPAIR",
    "",
    "No DRW light curve was refit in this stage.",
    "",
    f"Resolved gamma column              : {gamma_col}",
    f"Gamma transform                    : {gamma_transform}",
    f"Gamma non-null                     : {int(gamma_vals.notna().sum())}/{len(conf)}",
    f"Resolved host column               : {host_col}",
    f"Resolved SED column                : {sed_col}",
    "",
]

for half in [
    "EARLY",
    "LATE",
]:
    lines.append(
        f"{half}:"
    )

    for model in [
        "D0_CLASS_ONLY",
        "D1_Z_GAMMA",
        "D2_FULL",
    ]:
        r = get_model(
            cluster,
            half,
            model,
        )

        if r is not None:
            lines.append(
                f"  clustered {model:14s}: "
                f"factor={r['factor']:.3f}, "
                f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
                f"p={r['p']:.3g}, "
                f"rows={int(r['N_rows'])}, "
                f"sources={int(r['N_sources'])}"
            )

    r = get_model(
        source,
        half,
        "D2_SOURCE_GEOMEAN",
    )

    if r is not None:
        lines.append(
            f"  source-level D2 geomean : "
            f"factor={r['factor']:.3f}, "
            f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
            f"p={r['p']:.3g}, "
            f"Nsrc={int(r['N_sources'])}"
        )

    for filt in [
        "g",
        "r",
    ]:
        r = get_model(
            band,
            half,
            "D2_FULL",
            filt=filt,
        )

        if r is not None:
            lines.append(
                f"  single-band {filt} D2       : "
                f"factor={r['factor']:.3f}, "
                f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
                f"p={r['p']:.3g}, "
                f"N={int(r['N_sources'])}"
            )

    if len(lsp):
        r = get_model(
            lsp,
            half,
            "D2_LSP_ONLY",
        )

        if r is not None:
            lines.append(
                f"  LSP-only clustered D2       : "
                f"factor={r['factor']:.3f}, "
                f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
                f"p={r['p']:.3g}, "
                f"rows={int(r['N_rows'])}, "
                f"sources={int(r['N_sources'])}"
            )

    lines.append("")

lines += [
    "Interpretation locks:",
    "  - Use Stage09D1C, not the Stage09D1B D1/D2 printout, for final",
    "    gamma-adjusted temporal inference.",
    "  - A factor <1 means shorter rest-frame tau for FSRQs relative to BLLs.",
    "  - EARLY/LATE are repeated temporal blocks; their p-values are not independent.",
    "  - LSP-only attenuation remains the key composition sensitivity.",
    "",
    "Files saved:",
    f"  {OUT_CLUSTER}",
    f"  {OUT_SOURCE}",
    f"  {OUT_BAND}",
    f"  {OUT_LSP}",
    f"  {OUT_GAMMA}",
    "",
    "STAGE 09D1C COMPLETE",
]

summary = "\n".join(lines)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
