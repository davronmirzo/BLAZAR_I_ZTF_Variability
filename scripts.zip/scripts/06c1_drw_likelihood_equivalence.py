# ============================================================
# BLAZAR_I — STAGE 06C1
# FROZEN DRW LIKELIHOOD + GATE EQUIVALENCE AUDIT
#
# Purpose:
#   Verify that an independently reconstructed exact irregular
#   OU/DRW Kalman likelihood reproduces the frozen STAGE 03D
#   log-likelihoods, AIC/BIC values, and primary interpretability
#   gate for ALL 2122 source-filter rows.
#
# No optimization is performed here.  The frozen best-fit
# parameters are inserted into the reconstructed likelihood.
#
# Model:
#   y_i = mu + x_i + measurement noise
#   Cov[x(t_i), x(t_j)] = sigma^2 exp(-|dt|/tau)
#
# Exact scalar Kalman recursion:
#   stationary prior variance = sigma^2
#   a = exp(-dt/tau)
#   Q = sigma^2 (1-a^2)
#
# White-noise null:
#   y_i ~ Normal(mu, sigma_intrinsic^2 + magerr_i^2)
#
# Information criteria:
#   white k=2
#   DRW   k=3
#
# Primary interpretability gate reconstructed from the frozen
# specification:
#   optimizer_success_drw
#   DeltaBIC(white-DRW) >= 10
#   tau >= 2 * median cadence
#   tau <= baseline / 10
#   tau not within 2% of either log-search boundary
#
# Read-only audit.  No upstream product is modified.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"
DRW_FILE = ROOT / "outputs" / "tables" / "stage03d_drw_master.csv"

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_TABLE = TABLE_DIR / "stage06c1_drw_likelihood_equivalence.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06c1_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool(v):
    if isinstance(v, (bool, np.bool_)):
        return bool(v)

    s = str(v).strip().lower()

    return s in {
        "true",
        "1",
        "yes",
        "y",
    }


def white_loglike(
    y,
    err,
    mu,
    sigma_intrinsic,
):
    var = (
        err ** 2
        +
        sigma_intrinsic ** 2
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= 0)
    ):
        return np.nan

    resid = (
        y - mu
    )

    return -0.5 * float(
        np.sum(
            np.log(
                2.0 * np.pi * var
            )
            +
            resid ** 2 / var
        )
    )


def drw_loglike_exact_kalman(
    t,
    y,
    err,
    mu,
    tau,
    sigma_stationary,
):
    t = np.asarray(
        t,
        dtype=float
    )

    y = np.asarray(
        y,
        dtype=float
    )

    err = np.asarray(
        err,
        dtype=float
    )

    n = len(t)

    if n == 0:
        return np.nan

    if not (
        np.isfinite(mu)
        and
        np.isfinite(tau)
        and
        np.isfinite(sigma_stationary)
        and
        tau > 0
        and
        sigma_stationary > 0
    ):
        return np.nan

    sigma2 = (
        sigma_stationary ** 2
    )

    # Stationary prior for the latent OU process.
    m_pred = 0.0
    p_pred = sigma2

    ll = 0.0

    for i in range(n):

        obs_var = (
            p_pred
            +
            err[i] ** 2
        )

        if not (
            np.isfinite(obs_var)
            and
            obs_var > 0
        ):
            return np.nan

        innovation = (
            y[i]
            -
            mu
            -
            m_pred
        )

        ll += -0.5 * (
            math.log(
                2.0
                *
                math.pi
                *
                obs_var
            )
            +
            innovation ** 2
            /
            obs_var
        )

        kalman_gain = (
            p_pred
            /
            obs_var
        )

        m_post = (
            m_pred
            +
            kalman_gain
            *
            innovation
        )

        p_post = (
            p_pred
            *
            (
                1.0
                -
                kalman_gain
            )
        )

        if i == n - 1:
            break

        dt = (
            t[i + 1]
            -
            t[i]
        )

        if not (
            np.isfinite(dt)
            and
            dt >= 0
        ):
            return np.nan

        a = math.exp(
            -dt / tau
        )

        # Numerically stable stationary process innovation variance:
        # sigma^2 * (1 - exp(-2 dt/tau)).
        q = (
            sigma2
            *
            (
                -math.expm1(
                    -2.0
                    *
                    dt
                    /
                    tau
                )
            )
        )

        m_pred = (
            a
            *
            m_post
        )

        p_pred = (
            a ** 2
            *
            p_post
            +
            q
        )

    return float(ll)


def near_log_bound(
    tau,
    lo,
    hi,
    frac=0.02,
):
    if not (
        np.isfinite(tau)
        and
        np.isfinite(lo)
        and
        np.isfinite(hi)
        and
        tau > 0
        and
        lo > 0
        and
        hi > lo
    ):
        return (
            False,
            False,
            np.nan,
        )

    lt = math.log(tau)
    llo = math.log(lo)
    lhi = math.log(hi)

    pos = (
        (lt - llo)
        /
        (lhi - llo)
    )

    return (
        bool(pos <= frac),
        bool(pos >= 1.0 - frac),
        float(pos),
    )


# ============================================================
# LOAD
# ============================================================

if not DRW_FILE.exists():
    raise FileNotFoundError(
        DRW_FILE
    )

if not NIGHTLY_DIR.exists():
    raise FileNotFoundError(
        NIGHTLY_DIR
    )

master = pd.read_csv(
    DRW_FILE
)

master["blazar_id"] = (
    master["blazar_id"]
    .astype(str)
)

if len(master) != 2122:
    raise RuntimeError(
        f"Expected 2122 frozen rows; got {len(master)}"
    )

source_ids = (
    master["blazar_id"]
    .drop_duplicates()
    .tolist()
)

if len(source_ids) != 1061:
    raise RuntimeError(
        f"Expected 1061 sources; got {len(source_ids)}"
    )


# ============================================================
# RUN
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 06C1")
print("FROZEN DRW LIKELIHOOD + GATE EQUIVALENCE AUDIT")
print("=" * 78)

rows = []

for i, bid in enumerate(
    source_ids,
    start=1
):
    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    nightly = pd.read_parquet(
        path
    )

    for filt in [
        "g",
        "r",
    ]:
        ref = master.loc[
            master["blazar_id"].eq(bid)
            &
            master["filter_name"].astype(str).eq(filt)
        ]

        if len(ref) != 1:
            raise RuntimeError(
                f"{bid} {filt}: expected exactly 1 frozen row; got {len(ref)}"
            )

        rr = ref.iloc[0]

        x = nightly.loc[
            nightly["filter_name"].astype(str).eq(filt),
            [
                "hmjd",
                "mag",
                "magerr",
            ],
        ].copy()

        for c in [
            "hmjd",
            "mag",
            "magerr",
        ]:
            x[c] = pd.to_numeric(
                x[c],
                errors="coerce"
            )

        x = x.replace(
            [np.inf, -np.inf],
            np.nan
        ).dropna().sort_values(
            "hmjd"
        )

        x = x.loc[
            x["magerr"] > 0
        ]

        t = x["hmjd"].to_numpy(dtype=float)
        y = x["mag"].to_numpy(dtype=float)
        e = x["magerr"].to_numpy(dtype=float)

        n = len(x)

        if n != int(rr["N_nightly"]):
            raise RuntimeError(
                f"{bid} {filt}: N mismatch {n} vs {int(rr['N_nightly'])}"
            )

        # Frozen-parameter likelihood reconstruction.
        ll_white_re = white_loglike(
            y=y,
            err=e,
            mu=float(rr["mu_white_mag"]),
            sigma_intrinsic=float(rr["sigma_white_intrinsic_mag"]),
        )

        ll_drw_re = drw_loglike_exact_kalman(
            t=t,
            y=y,
            err=e,
            mu=float(rr["mu_drw_mag"]),
            tau=float(rr["tau_obs_days"]),
            sigma_stationary=float(rr["sigma_drw_stationary_mag"]),
        )

        # Reconstruct information criteria.
        aic_white_re = (
            2.0 * 2
            -
            2.0 * ll_white_re
        )

        bic_white_re = (
            2.0
            *
            math.log(n)
            -
            2.0
            *
            ll_white_re
        )

        aic_drw_re = (
            2.0 * 3
            -
            2.0 * ll_drw_re
        )

        bic_drw_re = (
            3.0
            *
            math.log(n)
            -
            2.0
            *
            ll_drw_re
        )

        delta_bic_re = (
            bic_white_re
            -
            bic_drw_re
        )

        # Reconstruct boundary flags and interpretability gate.
        near_lo_re, near_hi_re, logpos = near_log_bound(
            tau=float(rr["tau_obs_days"]),
            lo=float(rr["tau_search_low_days"]),
            hi=float(rr["tau_search_high_days"]),
            frac=0.02,
        )

        gate_re = (
            as_bool(
                rr["optimizer_success_drw"]
            )
            and
            delta_bic_re >= 10.0
            and
            float(rr["tau_obs_days"])
            >=
            2.0
            *
            float(rr["median_cadence_days"])
            and
            float(rr["tau_obs_days"])
            <=
            float(rr["baseline_days"])
            /
            10.0
            and
            not near_lo_re
            and
            not near_hi_re
        )

        rows.append({
            "blazar_id": bid,
            "filter_name": filt,
            "N_nightly": n,

            "loglike_white_frozen": float(rr["loglike_white"]),
            "loglike_white_reconstructed": ll_white_re,
            "diff_loglike_white": (
                ll_white_re
                -
                float(rr["loglike_white"])
            ),

            "loglike_drw_frozen": float(rr["loglike_drw"]),
            "loglike_drw_reconstructed": ll_drw_re,
            "diff_loglike_drw": (
                ll_drw_re
                -
                float(rr["loglike_drw"])
            ),

            "aic_white_diff": (
                aic_white_re
                -
                float(rr["aic_white"])
            ),
            "bic_white_diff": (
                bic_white_re
                -
                float(rr["bic_white"])
            ),

            "aic_drw_diff": (
                aic_drw_re
                -
                float(rr["aic_drw"])
            ),
            "bic_drw_diff": (
                bic_drw_re
                -
                float(rr["bic_drw"])
            ),

            "delta_bic_frozen": float(
                rr["delta_bic_white_minus_drw"]
            ),
            "delta_bic_reconstructed": delta_bic_re,
            "delta_bic_diff": (
                delta_bic_re
                -
                float(
                    rr["delta_bic_white_minus_drw"]
                )
            ),

            "near_lower_frozen": as_bool(
                rr["tau_near_lower_search_bound"]
            ),
            "near_lower_reconstructed": near_lo_re,

            "near_upper_frozen": as_bool(
                rr["tau_near_upper_search_bound"]
            ),
            "near_upper_reconstructed": near_hi_re,

            "log_search_position": logpos,

            "interpretable_frozen": as_bool(
                rr["tau_interpretable_primary"]
            ),
            "interpretable_reconstructed": bool(
                gate_re
            ),
        })

    if (
        i % 100 == 0
        or
        i == len(source_ids)
    ):
        print(
            f"Processed {i}/{len(source_ids)} sources"
        )

out = pd.DataFrame(
    rows
)

out["boundary_flags_match"] = (
    out["near_lower_frozen"].eq(
        out["near_lower_reconstructed"]
    )
    &
    out["near_upper_frozen"].eq(
        out["near_upper_reconstructed"]
    )
)

out["interpretable_match"] = (
    out["interpretable_frozen"].eq(
        out["interpretable_reconstructed"]
    )
)

out.to_csv(
    OUT_TABLE,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

def abs_stats(col):
    x = np.abs(
        pd.to_numeric(
            out[col],
            errors="coerce"
        ).to_numpy(dtype=float)
    )

    x = x[
        np.isfinite(x)
    ]

    return {
        "median": float(
            np.median(x)
        ),
        "p95": float(
            np.percentile(x, 95)
        ),
        "max": float(
            np.max(x)
        ),
    }


s_w = abs_stats(
    "diff_loglike_white"
)

s_d = abs_stats(
    "diff_loglike_drw"
)

s_db = abs_stats(
    "delta_bic_diff"
)

boundary_mismatch = int(
    (~out["boundary_flags_match"]).sum()
)

gate_mismatch = int(
    (~out["interpretable_match"]).sum()
)

lines = [
    "BLAZAR_I - STAGE 06C1 FINAL SUMMARY",
    "=" * 72,
    "",
    f"Rows audited: {len(out)}",
    "",
    "ABSOLUTE FROZEN-vs-RECONSTRUCTED DIFFERENCES:",
    (
        "  white loglike: "
        f"median={s_w['median']:.3e}, "
        f"p95={s_w['p95']:.3e}, "
        f"max={s_w['max']:.3e}"
    ),
    (
        "  DRW loglike:   "
        f"median={s_d['median']:.3e}, "
        f"p95={s_d['p95']:.3e}, "
        f"max={s_d['max']:.3e}"
    ),
    (
        "  DeltaBIC:      "
        f"median={s_db['median']:.3e}, "
        f"p95={s_db['p95']:.3e}, "
        f"max={s_db['max']:.3e}"
    ),
    "",
    (
        "Boundary-flag mismatches: "
        f"{boundary_mismatch}/{len(out)}"
    ),
    (
        "Interpretability-gate mismatches: "
        f"{gate_mismatch}/{len(out)}"
    ),
    "",
    (
        "Frozen interpretable count: "
        f"{int(out['interpretable_frozen'].sum())}"
    ),
    (
        "Reconstructed interpretable count: "
        f"{int(out['interpretable_reconstructed'].sum())}"
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_TABLE)
print(OUT_SUMMARY)
print()
print("STAGE 06C1 COMPLETE")
