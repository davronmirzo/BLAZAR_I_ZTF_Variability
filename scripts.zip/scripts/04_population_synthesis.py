# ============================================================
# BLAZAR_I — STAGE 04
# POPULATION MASTER + CROSS-DIAGNOSTIC SYNTHESIS
#
# Merges frozen results from:
#   STAGE 02B3 — analysis sample / quality
#   STAGE 03A — flux-PDF diagnostics
#   STAGE 03B — rms–flux diagnostics
#   STAGE 03C — colour–magnitude / broken-line diagnostics
#   STAGE 03D — DRW / OU diagnostics
#
# Also preserves additional Fermi/4LAC/4FGL parent columns when
# available, prefixed with "fermi_".
#
# No raw photometry is modified.
#
# Strict synthesis flags:
#
# 1) PDF robust double-lognormal, per band:
#      preferred model == DOUBLE_LOGNORMAL
#      DeltaBIC(second-best - best) >= 10
#      smaller mixture weight >= 0.10
#      component separation >= 2
#
# 2) rms–flux strict positive:
#      inherited unchanged from STAGE 03B
#
# 3) robust central colour break:
#      DeltaBIC(single - broken) >= 20
#      break fraction in r-magnitude range = 0.15 ... 0.85
#
# 4) DRW interpretable:
#      inherited unchanged from STAGE 03D
#
# "core4_count" is an audit count, NOT a ranking:
#      +1 PDF robust in BOTH bands
#      +1 rms–flux strict in BOTH bands
#      +1 robust central colour break
#      +1 DRW interpretable in BOTH bands
#
# Outputs:
#   outputs/tables/stage04_population_master.csv
#   outputs/tables/stage04_core4_phenotypes.csv
#   outputs/tables/stage04_class_associations.csv
#   outputs/tables/stage04_pairwise_diagnostic_associations.csv
#   outputs/audit/stage04_summary.txt
# ============================================================

from pathlib import Path
import math
import sys

import numpy as np
import pandas as pd

from scipy.stats import fisher_exact, chi2_contingency


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
INTERIM_DIR = ROOT / "data" / "interim"

BASE_FILE = TABLE_DIR / "stage02b3_GOLD_PLUS_SILVER.csv"
PARENT_FILE = INTERIM_DIR / "stage01_parent_clean_fsrq_bll.csv"

PDF_FILE = TABLE_DIR / "stage03a_fluxpdf_master.csv"
RMF_FILE = TABLE_DIR / "stage03b_rmflux_master.csv"
COL_FILE = TABLE_DIR / "stage03c_colour_break_master.csv"
DRW_FILE = TABLE_DIR / "stage03d_drw_master.csv"

OUT_MASTER = TABLE_DIR / "stage04_population_master.csv"
OUT_PHENO = TABLE_DIR / "stage04_core4_phenotypes.csv"
OUT_CLASS = TABLE_DIR / "stage04_class_associations.csv"
OUT_PAIR = TABLE_DIR / "stage04_pairwise_diagnostic_associations.csv"
OUT_SUMMARY = AUDIT_DIR / "stage04_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# FROZEN SYNTHESIS THRESHOLDS
# ============================================================

PDF_DBIC_MIN = 10.0
PDF_SMALL_WEIGHT_MIN = 0.10
PDF_SEPARATION_MIN = 2.0

COLOUR_DBIC_MIN = 20.0
COLOUR_BREAK_FRAC_MIN = 0.15
COLOUR_BREAK_FRAC_MAX = 0.85


# ============================================================
# HELPERS
# ============================================================

def require_file(path):
    if not path.exists():
        raise FileNotFoundError(path)

def to_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    x = (
        s.astype(str)
        .str.strip()
        .str.lower()
    )

    return x.isin(
        ["true", "1", "yes", "y"]
    )

def safe_bool_col(df, col):
    if col not in df.columns:
        raise RuntimeError(
            f"Required boolean column missing: {col}"
        )
    return to_bool_series(df[col])

def assert_unique_source(df, label):
    if "blazar_id" not in df.columns:
        raise RuntimeError(
            f"{label}: blazar_id missing"
        )

    dup = df["blazar_id"].duplicated().sum()

    if dup:
        raise RuntimeError(
            f"{label}: duplicate blazar_id rows = {dup}"
        )

def assert_exact_ids(base_ids, other_ids, label):
    a = set(base_ids)
    b = set(other_ids)

    missing = sorted(a - b)
    extra = sorted(b - a)

    if missing or extra:
        raise RuntimeError(
            f"{label}: ID mismatch; "
            f"missing={len(missing)}, extra={len(extra)}"
        )

def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)

    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw = ranked * m / np.arange(1, m + 1)

    adj = np.minimum.accumulate(
        raw[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0
    )

    qv = np.empty(
        m,
        dtype=float
    )

    qv[order] = adj

    q[valid] = qv

    return q

def two_by_two_stats(flag, cls_fsrq):
    flag = np.asarray(flag, dtype=bool)
    cls_fsrq = np.asarray(cls_fsrq, dtype=bool)

    # Rows: FSRQ, BLL
    # Cols: positive, negative
    a = int(np.sum(cls_fsrq & flag))
    b = int(np.sum(cls_fsrq & ~flag))
    c = int(np.sum(~cls_fsrq & flag))
    d = int(np.sum(~cls_fsrq & ~flag))

    table = np.array(
        [
            [a, b],
            [c, d],
        ],
        dtype=int,
    )

    oddsratio, p_fisher = fisher_exact(
        table,
        alternative="two-sided"
    )

    chi2, p_chi2, dof, expected = chi2_contingency(
        table,
        correction=False
    )

    n = table.sum()

    phi = (
        math.sqrt(chi2 / n)
        if n > 0
        else np.nan
    )

    fsrq_frac = (
        a / (a + b)
        if (a + b) > 0
        else np.nan
    )

    bll_frac = (
        c / (c + d)
        if (c + d) > 0
        else np.nan
    )

    return {
        "FSRQ_positive": a,
        "FSRQ_negative": b,
        "BLL_positive": c,
        "BLL_negative": d,
        "FSRQ_positive_fraction": fsrq_frac,
        "BLL_positive_fraction": bll_frac,
        "odds_ratio_FSRQ_vs_BLL": oddsratio,
        "fisher_p": p_fisher,
        "chi2": chi2,
        "chi2_p": p_chi2,
        "phi_abs": phi,
    }

def binary_pair_stats(a, b):
    a = np.asarray(a, dtype=bool)
    b = np.asarray(b, dtype=bool)

    n11 = int(np.sum(a & b))
    n10 = int(np.sum(a & ~b))
    n01 = int(np.sum(~a & b))
    n00 = int(np.sum(~a & ~b))

    table = np.array(
        [
            [n11, n10],
            [n01, n00],
        ],
        dtype=int,
    )

    oddsratio, p_fisher = fisher_exact(
        table,
        alternative="two-sided"
    )

    chi2, p_chi2, _, _ = chi2_contingency(
        table,
        correction=False
    )

    n = table.sum()

    # Signed phi coefficient.
    denom = math.sqrt(
        (n11 + n10)
        * (n01 + n00)
        * (n11 + n01)
        * (n10 + n00)
    )

    if denom > 0:
        phi = (
            n11 * n00
            -
            n10 * n01
        ) / denom
    else:
        phi = np.nan

    return {
        "both_positive": n11,
        "A_only": n10,
        "B_only": n01,
        "neither": n00,
        "odds_ratio": oddsratio,
        "fisher_p": p_fisher,
        "chi2": chi2,
        "chi2_p": p_chi2,
        "phi": phi,
    }


# ============================================================
# LOAD INPUTS
# ============================================================

for path in [
    BASE_FILE,
    PDF_FILE,
    RMF_FILE,
    COL_FILE,
    DRW_FILE,
]:
    require_file(path)

base = pd.read_csv(BASE_FILE)
pdf = pd.read_csv(PDF_FILE)
rmf = pd.read_csv(RMF_FILE)
col = pd.read_csv(COL_FILE)
drw = pd.read_csv(DRW_FILE)

base["blazar_id"] = base["blazar_id"].astype(str)
pdf["blazar_id"] = pdf["blazar_id"].astype(str)
rmf["blazar_id"] = rmf["blazar_id"].astype(str)
col["blazar_id"] = col["blazar_id"].astype(str)
drw["blazar_id"] = drw["blazar_id"].astype(str)

assert_unique_source(base, "STAGE 02B3 base")
assert_unique_source(col, "STAGE 03C")

N_SOURCE = len(base)

if N_SOURCE != 1061:
    raise RuntimeError(
        f"Expected 1061 analysis sources, got {N_SOURCE}"
    )

base_ids = base["blazar_id"].tolist()

assert_exact_ids(
    base_ids,
    col["blazar_id"].tolist(),
    "STAGE 03C"
)

print("=" * 78)
print("BLAZAR_I — STAGE 04")
print("POPULATION MASTER + CROSS-DIAGNOSTIC SYNTHESIS")
print("=" * 78)

print("Base analysis sample =", N_SOURCE)
print("03A rows =", len(pdf))
print("03B rows =", len(rmf))
print("03C rows =", len(col))
print("03D rows =", len(drw))


# ============================================================
# STAGE 03A — SOURCE-LEVEL PDF FEATURES
# ============================================================

if len(pdf) != 2 * N_SOURCE:
    raise RuntimeError(
        f"03A expected {2*N_SOURCE} rows, got {len(pdf)}"
    )

if pdf.duplicated(
    subset=["blazar_id", "filter_name"]
).any():
    raise RuntimeError(
        "03A duplicate blazar_id/filter rows"
    )

pdf["preferred_bic_model"] = (
    pdf["preferred_bic_model"]
    .astype(str)
)

pdf["pdf_non_gaussian"] = (
    pdf["preferred_bic_model"]
    !=
    "GAUSSIAN"
)

pdf["pdf_double"] = (
    pdf["preferred_bic_model"]
    ==
    "DOUBLE_LOGNORMAL"
)

small_weight = np.minimum(
    pd.to_numeric(
        pdf["dlnorm_weight_low"],
        errors="coerce"
    ),
    pd.to_numeric(
        pdf["dlnorm_weight_high"],
        errors="coerce"
    ),
)

pdf["pdf_smaller_component_weight"] = (
    small_weight
)

pdf["pdf_robust_double"] = (
    pdf["pdf_double"]
    &
    (
        pd.to_numeric(
            pdf["delta_bic_second_minus_best"],
            errors="coerce"
        )
        >=
        PDF_DBIC_MIN
    )
    &
    (
        pdf["pdf_smaller_component_weight"]
        >=
        PDF_SMALL_WEIGHT_MIN
    )
    &
    (
        pd.to_numeric(
            pdf["dlnorm_component_separation"],
            errors="coerce"
        )
        >=
        PDF_SEPARATION_MIN
    )
)

pdf_keep = [
    "blazar_id",
    "filter_name",
    "preferred_bic_model",
    "delta_bic_second_minus_best",
    "delta_bic_gauss_minus_lognorm",
    "delta_bic_lognorm_minus_double",
    "dlnorm_component_separation",
    "pdf_smaller_component_weight",
    "Fvar",
    "robust_amp_mag_p95_p05",
    "pdf_non_gaussian",
    "pdf_double",
    "pdf_robust_double",
]

pdf_wide = (
    pdf[pdf_keep]
    .pivot(
        index="blazar_id",
        columns="filter_name"
    )
)

pdf_wide.columns = [
    f"pdf_{metric}_{filt}"
    for metric, filt in pdf_wide.columns
]

pdf_wide = pdf_wide.reset_index()

assert_unique_source(
    pdf_wide,
    "03A wide"
)

assert_exact_ids(
    base_ids,
    pdf_wide["blazar_id"].tolist(),
    "STAGE 03A"
)


# ============================================================
# STAGE 03B — SOURCE-LEVEL RMS–FLUX FEATURES
# ============================================================

if len(rmf) != 2 * N_SOURCE:
    raise RuntimeError(
        f"03B expected {2*N_SOURCE} rows, got {len(rmf)}"
    )

if rmf.duplicated(
    subset=["blazar_id", "filter_name"]
).any():
    raise RuntimeError(
        "03B duplicate blazar_id/filter rows"
    )

rmf["strict_positive_rmflux"] = safe_bool_col(
    rmf,
    "strict_positive_rmflux"
)

rmf["rmflux_eligible"] = (
    rmf["fit_status"]
    .astype(str)
    .eq("OK")
)

rmf_keep = [
    "blazar_id",
    "filter_name",
    "N_segments",
    "noise_dominated_fraction",
    "segment_span_days_median",
    "segment_span_days_p90",
    "spearman_rho",
    "spearman_q_bh_global",
    "ols_slope",
    "slope_boot_p025",
    "slope_boot_p975",
    "strict_positive_rmflux",
    "rmflux_eligible",
]

rmf_wide = (
    rmf[rmf_keep]
    .pivot(
        index="blazar_id",
        columns="filter_name"
    )
)

rmf_wide.columns = [
    f"rmf_{metric}_{filt}"
    for metric, filt in rmf_wide.columns
]

rmf_wide = rmf_wide.reset_index()

assert_unique_source(
    rmf_wide,
    "03B wide"
)

assert_exact_ids(
    base_ids,
    rmf_wide["blazar_id"].tolist(),
    "STAGE 03B"
)


# ============================================================
# STAGE 03C — COLOUR FEATURES
# ============================================================

col_work = col.copy()

col_work["colour_strong_break_bic10"] = (
    safe_bool_col(
        col_work,
        "strong_break_bic10"
    )
)

col_work["colour_significant_monotonic"] = (
    safe_bool_col(
        col_work,
        "significant_monotonic_colour"
    )
)

denom = (
    pd.to_numeric(
        col_work["r_mag_max"],
        errors="coerce"
    )
    -
    pd.to_numeric(
        col_work["r_mag_min"],
        errors="coerce"
    )
)

col_work["colour_break_fraction"] = (
    (
        pd.to_numeric(
            col_work["break_r_mag"],
            errors="coerce"
        )
        -
        pd.to_numeric(
            col_work["r_mag_min"],
            errors="coerce"
        )
    )
    /
    denom.replace(
        0,
        np.nan
    )
)

col_work["colour_robust_central_break"] = (
    (
        pd.to_numeric(
            col_work[
                "delta_bic_single_minus_broken"
            ],
            errors="coerce"
        )
        >=
        COLOUR_DBIC_MIN
    )
    &
    col_work[
        "colour_break_fraction"
    ].between(
        COLOUR_BREAK_FRAC_MIN,
        COLOUR_BREAK_FRAC_MAX,
        inclusive="both",
    )
)

left = pd.to_numeric(
    col_work["break_slope_left"],
    errors="coerce"
)

right = pd.to_numeric(
    col_work["break_slope_right"],
    errors="coerce"
)

col_work["colour_break_morphology"] = np.select(
    [
        (left > 0) & (right > 0),
        (left < 0) & (right < 0),
        (left > 0) & (right < 0),
        (left < 0) & (right > 0),
    ],
    [
        "BWB->BWB",
        "RWB->RWB",
        "BWB->RWB",
        "RWB->BWB",
    ],
    default="OTHER",
)

col_keep = [
    "blazar_id",
    "N_colour_pairs",
    "r_mag_range",
    "pair_dt_hours_median",
    "spearman_rho",
    "spearman_q_bh_global",
    "single_slope_dcolor_dr",
    "single_trend_direction",
    "break_r_mag",
    "break_slope_left",
    "break_slope_right",
    "delta_bic_single_minus_broken",
    "colour_break_fraction",
    "colour_break_morphology",
    "colour_strong_break_bic10",
    "colour_robust_central_break",
    "colour_significant_monotonic",
]

col_src = col_work[col_keep].copy()

col_src = col_src.rename(
    columns={
        c: (
            c
            if c == "blazar_id"
            else f"col_{c}"
        )
        for c in col_src.columns
    }
)


# ============================================================
# STAGE 03D — SOURCE-LEVEL DRW FEATURES
# ============================================================

if len(drw) != 2 * N_SOURCE:
    raise RuntimeError(
        f"03D expected {2*N_SOURCE} rows, got {len(drw)}"
    )

if drw.duplicated(
    subset=["blazar_id", "filter_name"]
).any():
    raise RuntimeError(
        "03D duplicate blazar_id/filter rows"
    )

drw["tau_interpretable_primary"] = safe_bool_col(
    drw,
    "tau_interpretable_primary"
)

drw_keep = [
    "blazar_id",
    "filter_name",
    "N_nightly",
    "baseline_days",
    "median_cadence_days",
    "tau_obs_days",
    "tau_rest_days",
    "sigma_drw_stationary_mag",
    "SF_inf_mag",
    "delta_bic_white_minus_drw",
    "tau_over_median_cadence",
    "tau_over_baseline",
    "tau_interpretable_primary",
]

drw_wide = (
    drw[drw_keep]
    .pivot(
        index="blazar_id",
        columns="filter_name"
    )
)

drw_wide.columns = [
    f"drw_{metric}_{filt}"
    for metric, filt in drw_wide.columns
]

drw_wide = drw_wide.reset_index()

assert_unique_source(
    drw_wide,
    "03D wide"
)

assert_exact_ids(
    base_ids,
    drw_wide["blazar_id"].tolist(),
    "STAGE 03D"
)


# ============================================================
# MERGE FROZEN DIAGNOSTICS
# ============================================================

master = base.copy()

master = master.merge(
    pdf_wide,
    on="blazar_id",
    how="left",
    validate="one_to_one"
)

master = master.merge(
    rmf_wide,
    on="blazar_id",
    how="left",
    validate="one_to_one"
)

master = master.merge(
    col_src,
    on="blazar_id",
    how="left",
    validate="one_to_one"
)

master = master.merge(
    drw_wide,
    on="blazar_id",
    how="left",
    validate="one_to_one"
)

if len(master) != N_SOURCE:
    raise RuntimeError(
        "Master row count changed during merge."
    )


# ============================================================
# PRESERVE EXTRA FERMI PARENT COLUMNS
# ============================================================

if PARENT_FILE.exists():

    parent = pd.read_csv(
        PARENT_FILE
    )

    parent["blazar_id"] = (
        parent["blazar_id"]
        .astype(str)
    )

    parent = (
        parent
        .drop_duplicates(
            "blazar_id"
        )
    )

    parent = parent.loc[
        parent[
            "blazar_id"
        ].isin(
            set(
                base_ids
            )
        )
    ].copy()

    # Keep only columns that are not already in the master,
    # and prefix them to make provenance explicit.
    extra_cols = [
        c
        for c in parent.columns
        if c != "blazar_id"
        and c not in master.columns
    ]

    parent_extra = parent[
        ["blazar_id"] + extra_cols
    ].copy()

    parent_extra = parent_extra.rename(
        columns={
            c: f"fermi_{c}"
            for c in extra_cols
        }
    )

    master = master.merge(
        parent_extra,
        on="blazar_id",
        how="left",
        validate="one_to_one"
    )


# ============================================================
# DERIVED SOURCE-LEVEL FLAGS
# ============================================================

# PDF
master["pdf_non_gaussian_both"] = (
    to_bool_series(
        master["pdf_pdf_non_gaussian_g"]
    )
    &
    to_bool_series(
        master["pdf_pdf_non_gaussian_r"]
    )
)

master["pdf_double_any"] = (
    to_bool_series(
        master["pdf_pdf_double_g"]
    )
    |
    to_bool_series(
        master["pdf_pdf_double_r"]
    )
)

master["pdf_double_both"] = (
    to_bool_series(
        master["pdf_pdf_double_g"]
    )
    &
    to_bool_series(
        master["pdf_pdf_double_r"]
    )
)

master["pdf_robust_double_any"] = (
    to_bool_series(
        master["pdf_pdf_robust_double_g"]
    )
    |
    to_bool_series(
        master["pdf_pdf_robust_double_r"]
    )
)

master["pdf_robust_double_both"] = (
    to_bool_series(
        master["pdf_pdf_robust_double_g"]
    )
    &
    to_bool_series(
        master["pdf_pdf_robust_double_r"]
    )
)

# rms–flux
master["rmflux_strict_any"] = (
    to_bool_series(
        master[
            "rmf_strict_positive_rmflux_g"
        ]
    )
    |
    to_bool_series(
        master[
            "rmf_strict_positive_rmflux_r"
        ]
    )
)

master["rmflux_strict_both"] = (
    to_bool_series(
        master[
            "rmf_strict_positive_rmflux_g"
        ]
    )
    &
    to_bool_series(
        master[
            "rmf_strict_positive_rmflux_r"
        ]
    )
)

# Colour
master["colour_strong_break"] = (
    to_bool_series(
        master[
            "col_colour_strong_break_bic10"
        ]
    )
)

master["colour_robust_central_break"] = (
    to_bool_series(
        master[
            "col_colour_robust_central_break"
        ]
    )
)

# DRW
master["drw_interpretable_any"] = (
    to_bool_series(
        master[
            "drw_tau_interpretable_primary_g"
        ]
    )
    |
    to_bool_series(
        master[
            "drw_tau_interpretable_primary_r"
        ]
    )
)

master["drw_interpretable_both"] = (
    to_bool_series(
        master[
            "drw_tau_interpretable_primary_g"
        ]
    )
    &
    to_bool_series(
        master[
            "drw_tau_interpretable_primary_r"
        ]
    )
)

# Four stringent source-level synthesis flags.
core_flags = [
    "pdf_robust_double_both",
    "rmflux_strict_both",
    "colour_robust_central_break",
    "drw_interpretable_both",
]

master["core4_count"] = (
    master[
        core_flags
    ]
    .astype(int)
    .sum(
        axis=1
    )
)

master["core4_all"] = (
    master[
        "core4_count"
    ]
    ==
    4
)

master["core4_at_least3"] = (
    master[
        "core4_count"
    ]
    >=
    3
)


# ============================================================
# CORE PHENOTYPE STRING
# ============================================================

def phenotype_row(row):
    tokens = []

    if row["pdf_robust_double_both"]:
        tokens.append("PDF")

    if row["rmflux_strict_both"]:
        tokens.append("RMS")

    if row["colour_robust_central_break"]:
        tokens.append("COL")

    if row["drw_interpretable_both"]:
        tokens.append("DRW")

    if not tokens:
        return "NONE"

    return "+".join(tokens)

master["core4_phenotype"] = master.apply(
    phenotype_row,
    axis=1
)


# ============================================================
# SAVE POPULATION MASTER
# ============================================================

master.to_csv(
    OUT_MASTER,
    index=False
)


# ============================================================
# PHENOTYPE COUNTS
# ============================================================

pheno = (
    master.groupby(
        [
            "core4_phenotype",
            "blazar_class",
        ],
        dropna=False
    )
    .size()
    .rename("N")
    .reset_index()
)

tot = (
    master.groupby(
        "blazar_class"
    )
    .size()
    .rename(
        "class_N"
    )
    .reset_index()
)

pheno = pheno.merge(
    tot,
    on="blazar_class",
    how="left"
)

pheno[
    "within_class_fraction"
] = (
    pheno["N"]
    /
    pheno["class_N"]
)

pheno = pheno.sort_values(
    [
        "N",
        "core4_phenotype",
    ],
    ascending=[
        False,
        True,
    ]
)

pheno.to_csv(
    OUT_PHENO,
    index=False
)


# ============================================================
# CLASS ASSOCIATIONS
# ============================================================

class_flags = [
    "pdf_double_both",
    "pdf_robust_double_both",
    "rmflux_strict_any",
    "rmflux_strict_both",
    "colour_strong_break",
    "colour_robust_central_break",
    "drw_interpretable_any",
    "drw_interpretable_both",
    "core4_at_least3",
    "core4_all",
]

class_rows = []

cls_fsrq = (
    master[
        "blazar_class"
    ]
    .astype(str)
    .eq("FSRQ")
    .to_numpy()
)

for flag in class_flags:

    stats = two_by_two_stats(
        master[
            flag
        ].to_numpy(
            dtype=bool
        ),
        cls_fsrq
    )

    class_rows.append(
        {
            "diagnostic": flag,
            **stats,
        }
    )

class_assoc = pd.DataFrame(
    class_rows
)

class_assoc[
    "fisher_q_bh"
] = bh_qvalues(
    class_assoc[
        "fisher_p"
    ].to_numpy(
        dtype=float
    )
)

class_assoc.to_csv(
    OUT_CLASS,
    index=False
)


# ============================================================
# PAIRWISE ASSOCIATIONS AMONG FOUR STRICT DIAGNOSTICS
# ============================================================

pair_rows = []

for i in range(
    len(core_flags)
):
    for j in range(
        i + 1,
        len(core_flags)
    ):

        a = core_flags[i]
        b = core_flags[j]

        stats = binary_pair_stats(
            master[
                a
            ].to_numpy(
                dtype=bool
            ),
            master[
                b
            ].to_numpy(
                dtype=bool
            ),
        )

        pair_rows.append(
            {
                "diagnostic_A": a,
                "diagnostic_B": b,
                **stats,
            }
        )

pair_assoc = pd.DataFrame(
    pair_rows
)

pair_assoc[
    "fisher_q_bh"
] = bh_qvalues(
    pair_assoc[
        "fisher_p"
    ].to_numpy(
        dtype=float
    )
)

pair_assoc.to_csv(
    OUT_PAIR,
    index=False
)


# ============================================================
# FINAL SUMMARY
# ============================================================

n_bll = int(
    (
        master[
            "blazar_class"
        ]
        ==
        "BLL"
    ).sum()
)

n_fsrq = int(
    (
        master[
            "blazar_class"
        ]
        ==
        "FSRQ"
    ).sum()
)

lines = [
    "BLAZAR_I - STAGE 04 FINAL SUMMARY",
    "=" * 72,
    "",
    f"Population master rows : {len(master)}",
    f"BLL                    : {n_bll}",
    f"FSRQ                   : {n_fsrq}",
    "",
    "STRICT SOURCE-LEVEL DIAGNOSTICS:",
]

for flag in core_flags:

    n = int(
        master[
            flag
        ].sum()
    )

    pct = (
        100.0
        *
        n
        /
        len(master)
    )

    lines.append(
        f"  {flag:<31s}: "
        f"{n:4d} ({pct:6.2f}%)"
    )

lines += [
    "",
    "CORE4 COUNT:",
]

for k in range(
    5
):

    n = int(
        (
            master[
                "core4_count"
            ]
            ==
            k
        ).sum()
    )

    pct = (
        100.0
        *
        n
        /
        len(master)
    )

    lines.append(
        f"  count={k}: "
        f"{n:4d} ({pct:6.2f}%)"
    )

n3 = int(
    master[
        "core4_at_least3"
    ].sum()
)

n4 = int(
    master[
        "core4_all"
    ].sum()
)

lines += [
    "",
    (
        "Sources with >=3 strict diagnostics : "
        f"{n3}"
    ),
    (
        "Sources with all 4 strict diagnostics: "
        f"{n4}"
    ),
    "",
    "CLASS ASSOCIATIONS:",
]

for _, rr in class_assoc.iterrows():

    lines.append(
        f"  {rr['diagnostic']}: "
        f"FSRQ={100*rr['FSRQ_positive_fraction']:.2f}%, "
        f"BLL={100*rr['BLL_positive_fraction']:.2f}%, "
        f"OR={rr['odds_ratio_FSRQ_vs_BLL']:.3f}, "
        f"q={rr['fisher_q_bh']:.3g}"
    )

lines += [
    "",
    "PAIRWISE STRICT-DIAGNOSTIC ASSOCIATIONS:",
]

for _, rr in pair_assoc.iterrows():

    lines.append(
        f"  {rr['diagnostic_A']} vs "
        f"{rr['diagnostic_B']}: "
        f"phi={rr['phi']:.3f}, "
        f"OR={rr['odds_ratio']:.3f}, "
        f"q={rr['fisher_q_bh']:.3g}"
    )

final_summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    final_summary,
    encoding="utf-8"
)

print()
print(final_summary)

print()
print("=" * 78)
print("GLOBAL FILES SAVED")
print("=" * 78)

print(OUT_MASTER)
print(OUT_PHENO)
print(OUT_CLASS)
print(OUT_PAIR)
print(OUT_SUMMARY)

print()
print("STAGE 04 COMPLETE")
