# ============================================================
# BLAZAR_I — STAGE 06E2
# FLUX-PDF TEMPORAL-SAMPLING / EQUAL-N SENSITIVITY
#
# Frozen fitting recipe validated exactly in STAGE 06E1 / 06E1B:
#   Gaussian flux MLE
#   Lognormal flux-space likelihood
#   2-component GaussianMixture on ln(F)
#       n_init=10
#       max_iter=500
#       reg_covar=1e-4
#       random_state=20260917
#   BIC parameter counts: 2, 2, 5
#   Ashman separation:
#       D = sqrt(2)|mu2-mu1| / sqrt(s1^2+s2^2)
#
# Frozen robust-double gate:
#   preferred == DOUBLE_LOGNORMAL
#   DeltaBIC(second-best - best) >= 10
#   smaller component weight >= 0.10
#   D >= 2
#
# Sensitivity schemes:
#
#   THIN_HALF
#       Chronological deterministic thinning: keep every other
#       nightly point. Tests reduced sample size and serial redundancy.
#
#   EQUAL_N50
#       Exactly 50 nightly points per source/filter, sampled without
#       replacement using a stable source/filter-specific deterministic
#       seed. Tests BIC/sample-size dependence while equalizing N.
#
#   MINSEP_7D
#       Chronological greedy thinning requiring >=7 days between
#       retained observations. Tests sensitivity to dense temporal
#       clustering / short-lag correlation.
#
# Minimum transformed N for fitting:
#   25 for THIN_HALF and MINSEP_7D
#   exactly 50 for EQUAL_N50
#
# Outputs:
#   per-source-filter sensitivity fits
#   row-level agreement table
#   source-level robust-both stability table
#   class-specific robust-both table
#   final summary
#
# Resumable:
#   one CSV per blazar is written only after all 6 fits
#   (3 schemes x 2 filters) are complete.
# ============================================================

from pathlib import Path
import hashlib
import math
import warnings

import numpy as np
import pandas as pd
from scipy.special import logsumexp
from scipy.stats import fisher_exact
from sklearn.mixture import GaussianMixture
from sklearn.exceptions import ConvergenceWarning

warnings.filterwarnings(
    "ignore",
    category=ConvergenceWarning,
)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
MODEL_DIR = ROOT / "outputs" / "models" / "stage06e2_sources"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

MASTER_FILE = TABLE_DIR / "stage03a_fluxpdf_master.csv"

OUT_MASTER = TABLE_DIR / "stage06e2_pdf_sampling_sensitivity_master.csv"
OUT_ROW_AGREE = TABLE_DIR / "stage06e2_pdf_row_agreement.csv"
OUT_SOURCE_AGREE = TABLE_DIR / "stage06e2_pdf_source_robustboth_stability.csv"
OUT_CLASS = TABLE_DIR / "stage06e2_pdf_class_robustboth.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06e2_summary.txt"

MODEL_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

SCHEMA_VERSION = "06E2_v1"

RANDOM_STATE_GMM = 20260917
N_INIT = 10
MAX_ITER = 500
REG_COVAR = 1e-4

SCHEMES = [
    "THIN_HALF",
    "EQUAL_N50",
    "MINSEP_7D",
]


# ============================================================
# HELPERS
# ============================================================

def stable_seed(*parts):
    key = "||".join(
        str(x)
        for x in parts
    ).encode(
        "utf-8"
    )

    h = hashlib.sha256(
        key
    ).digest()

    return int.from_bytes(
        h[:8],
        byteorder="little",
        signed=False
    ) % (2**32 - 1)


def normal_logpdf(x, mu, sigma):
    return (
        -0.5 * np.log(2.0 * np.pi)
        - np.log(sigma)
        - 0.5 * ((x - mu) / sigma) ** 2
    )


def choose_model(
    bic_g,
    bic_l,
    bic_d,
):
    vals = {
        "GAUSSIAN": float(
            bic_g
        ),
        "LOGNORMAL": float(
            bic_l
        ),
        "DOUBLE_LOGNORMAL": float(
            bic_d
        ),
    }

    ordered = sorted(
        vals.items(),
        key=lambda kv: kv[1],
    )

    return (
        ordered[0][0],
        float(
            ordered[1][1]
            -
            ordered[0][1]
        ),
    )


def fit_pdf(flux):
    f = np.asarray(
        flux,
        dtype=float
    )

    f = f[
        np.isfinite(f)
        &
        (f > 0)
    ]

    n = len(f)

    if n < 2:
        raise RuntimeError(
            f"Too few points: N={n}"
        )

    lnf = np.log(f)

    # Gaussian in flux.
    g_mu = float(
        np.mean(f)
    )

    g_sig = float(
        np.std(
            f,
            ddof=0
        )
    )

    if not (
        np.isfinite(g_sig)
        and
        g_sig > 0
    ):
        raise RuntimeError(
            "Invalid Gaussian sigma."
        )

    ll_g = float(
        normal_logpdf(
            f,
            g_mu,
            g_sig
        ).sum()
    )

    bic_g = (
        2.0 * math.log(n)
        -
        2.0 * ll_g
    )

    # Single lognormal in flux space.
    l_mu = float(
        np.mean(lnf)
    )

    l_sig = float(
        np.std(
            lnf,
            ddof=0
        )
    )

    if not (
        np.isfinite(l_sig)
        and
        l_sig > 0
    ):
        raise RuntimeError(
            "Invalid lognormal sigma."
        )

    ll_l = float(
        (
            normal_logpdf(
                lnf,
                l_mu,
                l_sig
            )
            -
            lnf
        ).sum()
    )

    bic_l = (
        2.0 * math.log(n)
        -
        2.0 * ll_l
    )

    # Double lognormal mixture.
    gm = GaussianMixture(
        n_components=2,
        covariance_type="full",
        n_init=N_INIT,
        max_iter=MAX_ITER,
        reg_covar=REG_COVAR,
        random_state=RANDOM_STATE_GMM,
    )

    gm.fit(
        lnf.reshape(
            -1,
            1
        )
    )

    means = gm.means_[
        :,
        0
    ].astype(float)

    order = np.argsort(
        means
    )

    means = means[
        order
    ]

    weights = gm.weights_[
        order
    ].astype(float)

    variances = gm.covariances_[
        order,
        0,
        0
    ].astype(float)

    sigmas = np.sqrt(
        variances
    )

    comp = np.vstack(
        [
            math.log(
                weights[0]
            )
            +
            normal_logpdf(
                lnf,
                means[0],
                sigmas[0]
            ),
            math.log(
                weights[1]
            )
            +
            normal_logpdf(
                lnf,
                means[1],
                sigmas[1]
            ),
        ]
    )

    ll_d = float(
        (
            logsumexp(
                comp,
                axis=0
            )
            -
            lnf
        ).sum()
    )

    bic_d = (
        5.0 * math.log(n)
        -
        2.0 * ll_d
    )

    sep = (
        math.sqrt(2.0)
        *
        abs(
            means[1]
            -
            means[0]
        )
        /
        math.sqrt(
            sigmas[0] ** 2
            +
            sigmas[1] ** 2
        )
    )

    smaller_weight = float(
        min(
            weights[0],
            weights[1]
        )
    )

    pref, delta = choose_model(
        bic_g,
        bic_l,
        bic_d,
    )

    robust = bool(
        pref
        ==
        "DOUBLE_LOGNORMAL"
        and
        delta >= 10.0
        and
        smaller_weight >= 0.10
        and
        sep >= 2.0
    )

    return {
        "N_used": int(
            n
        ),
        "gauss_bic": float(
            bic_g
        ),
        "lnorm_bic": float(
            bic_l
        ),
        "dlnorm_bic": float(
            bic_d
        ),
        "preferred_bic_model": pref,
        "delta_bic_second_minus_best": float(
            delta
        ),
        "dlnorm_weight_low": float(
            weights[0]
        ),
        "dlnorm_weight_high": float(
            weights[1]
        ),
        "dlnorm_smaller_weight": smaller_weight,
        "dlnorm_mu_low_lnflux": float(
            means[0]
        ),
        "dlnorm_mu_high_lnflux": float(
            means[1]
        ),
        "dlnorm_sigma_low_lnflux": float(
            sigmas[0]
        ),
        "dlnorm_sigma_high_lnflux": float(
            sigmas[1]
        ),
        "dlnorm_component_separation": float(
            sep
        ),
        "robust_double": robust,
        "gmm_converged": bool(
            gm.converged_
        ),
        "gmm_n_iter": int(
            gm.n_iter_
        ),
    }


def scheme_subset(
    df,
    scheme,
    bid,
    filt,
):
    x = df.sort_values(
        "hmjd"
    ).reset_index(
        drop=True
    )

    n = len(x)

    if scheme == "THIN_HALF":
        y = x.iloc[
            np.arange(
                0,
                n,
                2,
                dtype=int
            )
        ].copy()

        eligible = (
            len(y) >= 25
        )

        return (
            y,
            eligible,
        )

    if scheme == "EQUAL_N50":
        if n < 50:
            return (
                x.iloc[
                    0:0
                ].copy(),
                False,
            )

        rng = np.random.default_rng(
            stable_seed(
                SCHEMA_VERSION,
                scheme,
                bid,
                filt,
            )
        )

        idx = np.sort(
            rng.choice(
                n,
                size=50,
                replace=False,
            )
        )

        y = x.iloc[
            idx
        ].copy()

        return (
            y,
            True,
        )

    if scheme == "MINSEP_7D":
        times = pd.to_numeric(
            x[
                "hmjd"
            ],
            errors="coerce"
        ).to_numpy(
            dtype=float
        )

        keep = []

        last = -np.inf

        for j, t in enumerate(
            times
        ):
            if not np.isfinite(t):
                continue

            if (
                len(keep) == 0
                or
                t - last >= 7.0
            ):
                keep.append(
                    j
                )
                last = t

        y = x.iloc[
            keep
        ].copy()

        eligible = (
            len(y) >= 25
        )

        return (
            y,
            eligible,
        )

    raise ValueError(
        f"Unknown scheme: {scheme}"
    )


def frozen_robust(rr):
    smaller = min(
        float(
            rr[
                "dlnorm_weight_low"
            ]
        ),
        float(
            rr[
                "dlnorm_weight_high"
            ]
        ),
    )

    return bool(
        str(
            rr[
                "preferred_bic_model"
            ]
        )
        ==
        "DOUBLE_LOGNORMAL"
        and
        float(
            rr[
                "delta_bic_second_minus_best"
            ]
        )
        >=
        10.0
        and
        smaller >= 0.10
        and
        float(
            rr[
                "dlnorm_component_separation"
            ]
        )
        >=
        2.0
    )


def safe_jaccard(a, b):
    a = np.asarray(
        a,
        dtype=bool
    )

    b = np.asarray(
        b,
        dtype=bool
    )

    union = int(
        np.logical_or(
            a,
            b
        ).sum()
    )

    inter = int(
        np.logical_and(
            a,
            b
        ).sum()
    )

    if union == 0:
        return np.nan

    return (
        inter / union
    )


def class_or(
    source_df,
):
    x = source_df.copy()

    fs = x.loc[
        x[
            "blazar_class"
        ].eq(
            "FSRQ"
        ),
        "robust_both_sensitivity",
    ].astype(bool)

    bl = x.loc[
        x[
            "blazar_class"
        ].eq(
            "BLL"
        ),
        "robust_both_sensitivity",
    ].astype(bool)

    a = int(
        fs.sum()
    )
    b = int(
        len(fs) - a
    )
    c = int(
        bl.sum()
    )
    d = int(
        len(bl) - c
    )

    OR, p = fisher_exact(
        [
            [a, b],
            [c, d],
        ],
        alternative="two-sided",
    )

    return {
        "FSRQ_positive": a,
        "FSRQ_total": len(fs),
        "BLL_positive": c,
        "BLL_total": len(bl),
        "raw_OR_FSRQ_vs_BLL": float(
            OR
        ),
        "fisher_p": float(
            p
        ),
    }


# ============================================================
# LOAD FROZEN MASTER
# ============================================================

if not MASTER_FILE.exists():
    raise FileNotFoundError(
        MASTER_FILE
    )

master = pd.read_csv(
    MASTER_FILE
)

if len(master) != 2122:
    raise RuntimeError(
        f"Expected 2122 frozen rows; got {len(master)}"
    )

master[
    "blazar_id"
] = master[
    "blazar_id"
].astype(str)

master[
    "frozen_robust_double"
] = master.apply(
    frozen_robust,
    axis=1,
)

# Source class lookup.
class_map = (
    master[
        [
            "blazar_id",
            "blazar_class",
        ]
    ]
    .drop_duplicates()
    .set_index(
        "blazar_id"
    )[
        "blazar_class"
    ]
    .to_dict()
)


# ============================================================
# RESUMABLE SOURCE-BY-SOURCE FITS
# ============================================================

source_ids = sorted(
    master[
        "blazar_id"
    ].unique()
)

print("=" * 78)
print("BLAZAR_I — STAGE 06E2")
print("FLUX-PDF TEMPORAL-SAMPLING / EQUAL-N SENSITIVITY")
print("=" * 78)

n_done = 0
n_run = 0

for i, bid in enumerate(
    source_ids,
    start=1,
):
    out_path = (
        MODEL_DIR
        /
        f"{bid}_stage06e2.csv"
    )

    valid_cached = False

    if out_path.exists():
        try:
            old = pd.read_csv(
                out_path
            )

            valid_cached = bool(
                len(old) == 6
                and
                "schema_version" in old.columns
                and
                old[
                    "schema_version"
                ].astype(str).eq(
                    SCHEMA_VERSION
                ).all()
                and
                set(
                    old[
                        "scheme"
                    ].astype(str)
                )
                ==
                set(
                    SCHEMES
                )
                and
                set(
                    old[
                        "filter_name"
                    ].astype(str)
                )
                ==
                {
                    "g",
                    "r",
                }
            )
        except Exception:
            valid_cached = False

    if valid_cached:
        n_done += 1

        if (
            i % 100 == 0
            or
            i == len(
                source_ids
            )
        ):
            print(
                f"{i}/{len(source_ids)} sources checked; "
                f"cached={n_done}, newly_run={n_run}"
            )

        continue

    nightly_path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not nightly_path.exists():
        raise FileNotFoundError(
            nightly_path
        )

    nightly = pd.read_parquet(
        nightly_path
    )

    frozen_rows = master.loc[
        master[
            "blazar_id"
        ].eq(
            bid
        )
    ]

    if len(
        frozen_rows
    ) != 2:
        raise RuntimeError(
            f"{bid}: expected 2 frozen filter rows; got {len(frozen_rows)}"
        )

    result_rows = []

    for _, fr in frozen_rows.iterrows():
        filt = str(
            fr[
                "filter_name"
            ]
        )

        x = nightly.loc[
            nightly[
                "filter_name"
            ].astype(str).eq(
                filt
            )
        ].copy()

        x["flux_jy"] = pd.to_numeric(
            x[
                "flux_jy"
            ],
            errors="coerce"
        )

        x["hmjd"] = pd.to_numeric(
            x[
                "hmjd"
            ],
            errors="coerce"
        )

        x = x.loc[
            np.isfinite(
                x[
                    "flux_jy"
                ]
            )
            &
            (
                x[
                    "flux_jy"
                ]
                >
                0
            )
            &
            np.isfinite(
                x[
                    "hmjd"
                ]
            )
        ].copy()

        n_input = len(
            x
        )

        if n_input != int(
            fr[
                "N_nightly"
            ]
        ):
            raise RuntimeError(
                f"{bid} {filt}: nightly N={n_input} "
                f"vs frozen N={int(fr['N_nightly'])}"
            )

        for scheme in SCHEMES:
            sub, eligible = scheme_subset(
                x,
                scheme,
                bid,
                filt,
            )

            base = {
                "schema_version": SCHEMA_VERSION,
                "blazar_id": bid,
                "blazar_class": str(
                    fr[
                        "blazar_class"
                    ]
                ),
                "filter_name": filt,
                "scheme": scheme,
                "N_input": int(
                    n_input
                ),
                "N_used": int(
                    len(sub)
                ),
                "retained_fraction": float(
                    len(sub)
                    /
                    n_input
                ),
                "eligible": bool(
                    eligible
                ),
                "frozen_preferred_bic_model": str(
                    fr[
                        "preferred_bic_model"
                    ]
                ),
                "frozen_robust_double": bool(
                    fr[
                        "frozen_robust_double"
                    ]
                ),
            }

            if not eligible:
                base.update({
                    "fit_status": "INELIGIBLE",
                    "preferred_bic_model": np.nan,
                    "delta_bic_second_minus_best": np.nan,
                    "dlnorm_smaller_weight": np.nan,
                    "dlnorm_component_separation": np.nan,
                    "robust_double": False,
                    "gmm_converged": False,
                    "gmm_n_iter": np.nan,
                })

                result_rows.append(
                    base
                )

                continue

            try:
                fit = fit_pdf(
                    sub[
                        "flux_jy"
                    ].to_numpy(
                        dtype=float
                    )
                )

                base.update(
                    fit
                )

                base[
                    "fit_status"
                ] = (
                    "OK"
                    if fit[
                        "gmm_converged"
                    ]
                    else
                    "GMM_NOT_CONVERGED"
                )

            except Exception as exc:
                base.update({
                    "fit_status": (
                        f"FAILED:{type(exc).__name__}"
                    ),
                    "preferred_bic_model": np.nan,
                    "delta_bic_second_minus_best": np.nan,
                    "dlnorm_smaller_weight": np.nan,
                    "dlnorm_component_separation": np.nan,
                    "robust_double": False,
                    "gmm_converged": False,
                    "gmm_n_iter": np.nan,
                })

            result_rows.append(
                base
            )

    res = pd.DataFrame(
        result_rows
    )

    if len(res) != 6:
        raise RuntimeError(
            f"{bid}: expected 6 result rows; got {len(res)}"
        )

    tmp = out_path.with_suffix(
        ".tmp"
    )

    res.to_csv(
        tmp,
        index=False
    )

    tmp.replace(
        out_path
    )

    n_run += 1

    if (
        i % 25 == 0
        or
        i == len(
            source_ids
        )
    ):
        print(
            f"{i}/{len(source_ids)} sources checked; "
            f"cached={n_done}, newly_run={n_run}"
        )


# ============================================================
# COMBINE
# ============================================================

parts = []

for bid in source_ids:
    path = (
        MODEL_DIR
        /
        f"{bid}_stage06e2.csv"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    x = pd.read_csv(
        path
    )

    if len(
        x
    ) != 6:
        raise RuntimeError(
            f"{path.name}: expected 6 rows"
        )

    parts.append(
        x
    )

sens = pd.concat(
    parts,
    ignore_index=True
)

if len(
    sens
) != (
    1061
    *
    2
    *
    3
):
    raise RuntimeError(
        f"Expected 6366 combined rows; got {len(sens)}"
    )

# Normalize booleans after CSV reload.
for c in [
    "eligible",
    "frozen_robust_double",
    "robust_double",
    "gmm_converged",
]:
    sens[c] = (
        sens[c]
        .astype(str)
        .str.strip()
        .str.lower()
        .isin(
            [
                "true",
                "1",
                "yes",
                "y",
            ]
        )
    )

sens.to_csv(
    OUT_MASTER,
    index=False
)


# ============================================================
# ROW-LEVEL AGREEMENT
# ============================================================

row_rows = []

for scheme in SCHEMES:
    x = sens.loc[
        sens[
            "scheme"
        ].eq(
            scheme
        )
        &
        sens[
            "eligible"
        ]
        &
        sens[
            "fit_status"
        ].eq(
            "OK"
        )
    ].copy()

    frozen = x[
        "frozen_robust_double"
    ].astype(bool).to_numpy()

    new = x[
        "robust_double"
    ].astype(bool).to_numpy()

    both = int(
        np.logical_and(
            frozen,
            new
        ).sum()
    )

    frozen_pos = int(
        frozen.sum()
    )

    new_pos = int(
        new.sum()
    )

    agreement = float(
        (
            frozen
            ==
            new
        ).mean()
    )

    preferred_agreement = float(
        (
            x[
                "frozen_preferred_bic_model"
            ].astype(str)
            ==
            x[
                "preferred_bic_model"
            ].astype(str)
        ).mean()
    )

    row_rows.append({
        "scheme": scheme,
        "N_eligible_fit_ok": len(
            x
        ),
        "preferred_model_agreement": preferred_agreement,
        "robust_gate_agreement": agreement,
        "frozen_robust_positive": frozen_pos,
        "sensitivity_robust_positive": new_pos,
        "both_robust_positive": both,
        "robust_jaccard": safe_jaccard(
            frozen,
            new
        ),
        "frozen_positive_retention": (
            both
            /
            frozen_pos
            if frozen_pos > 0
            else np.nan
        ),
        "sensitivity_positive_overlap_fraction": (
            both
            /
            new_pos
            if new_pos > 0
            else np.nan
        ),
        "median_N_used": float(
            x[
                "N_used"
            ].median()
        ),
        "median_retained_fraction": float(
            x[
                "retained_fraction"
            ].median()
        ),
    })

row_agree = pd.DataFrame(
    row_rows
)

row_agree.to_csv(
    OUT_ROW_AGREE,
    index=False
)


# ============================================================
# SOURCE-LEVEL ROBUST-BOTH STABILITY
# ============================================================

source_rows = []
class_rows = []

# Frozen source-level flags from 2122 rows.
frozen_wide = (
    master.pivot(
        index="blazar_id",
        columns="filter_name",
        values="frozen_robust_double",
    )
)

frozen_both_map = (
    frozen_wide[
        "g"
    ].astype(bool)
    &
    frozen_wide[
        "r"
    ].astype(bool)
).to_dict()

for scheme in SCHEMES:
    x = sens.loc[
        sens[
            "scheme"
        ].eq(
            scheme
        )
    ].copy()

    piv_eligible = x.pivot(
        index="blazar_id",
        columns="filter_name",
        values="eligible",
    )

    piv_ok = x.assign(
        fit_ok=x[
            "fit_status"
        ].eq(
            "OK"
        )
    ).pivot(
        index="blazar_id",
        columns="filter_name",
        values="fit_ok",
    )

    piv_robust = x.pivot(
        index="blazar_id",
        columns="filter_name",
        values="robust_double",
    )

    source = pd.DataFrame(
        index=piv_robust.index
    )

    source[
        "both_eligible"
    ] = (
        piv_eligible[
            "g"
        ].astype(bool)
        &
        piv_eligible[
            "r"
        ].astype(bool)
    )

    source[
        "both_fit_ok"
    ] = (
        piv_ok[
            "g"
        ].astype(bool)
        &
        piv_ok[
            "r"
        ].astype(bool)
    )

    source[
        "robust_both_sensitivity"
    ] = (
        piv_robust[
            "g"
        ].astype(bool)
        &
        piv_robust[
            "r"
        ].astype(bool)
    )

    source[
        "robust_both_frozen"
    ] = [
        bool(
            frozen_both_map[
                bid
            ]
        )
        for bid in source.index
    ]

    source[
        "blazar_class"
    ] = [
        class_map[
            bid
        ]
        for bid in source.index
    ]

    source = source.loc[
        source[
            "both_eligible"
        ]
        &
        source[
            "both_fit_ok"
        ]
    ].copy()

    frozen = source[
        "robust_both_frozen"
    ].astype(bool).to_numpy()

    new = source[
        "robust_both_sensitivity"
    ].astype(bool).to_numpy()

    both = int(
        np.logical_and(
            frozen,
            new
        ).sum()
    )

    frozen_pos = int(
        frozen.sum()
    )

    new_pos = int(
        new.sum()
    )

    source_rows.append({
        "scheme": scheme,
        "N_sources_both_eligible_fit_ok": len(
            source
        ),
        "frozen_robust_both_on_common": frozen_pos,
        "sensitivity_robust_both": new_pos,
        "both_positive": both,
        "agreement": float(
            (
                frozen
                ==
                new
            ).mean()
        ),
        "jaccard": safe_jaccard(
            frozen,
            new
        ),
        "frozen_positive_retention": (
            both
            /
            frozen_pos
            if frozen_pos > 0
            else np.nan
        ),
        "sensitivity_positive_overlap_fraction": (
            both
            /
            new_pos
            if new_pos > 0
            else np.nan
        ),
    })

    cls = class_or(
        source
    )

    cls[
        "scheme"
    ] = scheme

    class_rows.append(
        cls
    )

source_agree = pd.DataFrame(
    source_rows
)

source_agree.to_csv(
    OUT_SOURCE_AGREE,
    index=False
)

class_table = pd.DataFrame(
    class_rows
)

class_table.to_csv(
    OUT_CLASS,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06E2 FINAL SUMMARY",
    "=" * 78,
    "",
    "SENSITIVITY SCHEMES:",
    (
        "  THIN_HALF: chronological every-other-night thinning"
    ),
    (
        "  EQUAL_N50: deterministic source/filter-specific random "
        "subsample to exactly 50 nights"
    ),
    (
        "  MINSEP_7D: greedy chronological thinning with >=7 d "
        "between retained nights"
    ),
    "",
    "ROW-LEVEL ROBUST-DOUBLE STABILITY:",
]

for _, rr in row_agree.iterrows():
    lines.append(
        f"  {rr['scheme']}: "
        f"N={int(rr['N_eligible_fit_ok'])}, "
        f"median Nused={rr['median_N_used']:.1f}, "
        f"preferred agreement={rr['preferred_model_agreement']:.3f}, "
        f"robust agreement={rr['robust_gate_agreement']:.3f}, "
        f"Jaccard={rr['robust_jaccard']:.3f}, "
        f"frozen-positive retention={rr['frozen_positive_retention']:.3f}, "
        f"robust positives {int(rr['frozen_robust_positive'])}"
        f"->{int(rr['sensitivity_robust_positive'])}"
    )

lines += [
    "",
    "SOURCE-LEVEL ROBUST-DOUBLE-BOTH STABILITY:",
]

for _, rr in source_agree.iterrows():
    lines.append(
        f"  {rr['scheme']}: "
        f"N={int(rr['N_sources_both_eligible_fit_ok'])}, "
        f"frozen both={int(rr['frozen_robust_both_on_common'])}, "
        f"sensitivity both={int(rr['sensitivity_robust_both'])}, "
        f"both-positive={int(rr['both_positive'])}, "
        f"agreement={rr['agreement']:.3f}, "
        f"Jaccard={rr['jaccard']:.3f}, "
        f"frozen-positive retention={rr['frozen_positive_retention']:.3f}"
    )

lines += [
    "",
    "RAW FSRQ vs BLL ROBUST-BOTH ODDS UNDER EACH SCHEME:",
]

for _, rr in class_table.iterrows():
    lines.append(
        f"  {rr['scheme']}: "
        f"FSRQ={int(rr['FSRQ_positive'])}/{int(rr['FSRQ_total'])}, "
        f"BLL={int(rr['BLL_positive'])}/{int(rr['BLL_total'])}, "
        f"OR={rr['raw_OR_FSRQ_vs_BLL']:.3f}, "
        f"p={rr['fisher_p']:.3g}"
    )

lines += [
    "",
    "INTERPRETATION GUIDE:",
    (
        "  Prevalence is expected to fall when N is reduced because "
        "BIC evidence scales with information content. Therefore the "
        "main robustness quantities are classification agreement, "
        "positive-set retention/Jaccard, and whether the class "
        "contrast remains directionally similar."
    ),
    (
        "  EQUAL_N50 is particularly informative for class comparisons "
        "because it removes source-to-source BIC advantage from larger "
        "nightly sample sizes."
    ),
    (
        "  MINSEP_7D tests whether dense short-lag sampling is driving "
        "the inferred two-component flux distributions."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_MASTER)
print(OUT_ROW_AGREE)
print(OUT_SOURCE_AGREE)
print(OUT_CLASS)
print(OUT_SUMMARY)
print()
print("STAGE 06E2 COMPLETE")
