# ============================================================
# BLAZAR_I — STAGE 05B
# ROBUSTNESS / DIAGNOSTIC QA FOR STAGE 05
#
# Purpose:
#   1) Explain why the controlled FSRQ effect for strict rms–flux
#      is much larger than the raw full-sample association.
#   2) Track attenuation of the rms–flux -> colour-break association
#      as controls are added.
#   3) Audit SED-class overlap with optical class.
#   4) Report FDR-adjusted primary FSRQ coefficients.
#   5) Translate log10 continuous-class coefficients into
#      multiplicative factors.
#
# This stage does not modify any frozen Stage 03–05 products.
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm

from statsmodels.stats.outliers_influence import variance_inflation_factor

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

MASTER_FILE = TABLE_DIR / "stage04_population_master.csv"
PRIMARY_FILE = TABLE_DIR / "stage05_controlled_primary_models.csv"
CONT_FILE = TABLE_DIR / "stage05_continuous_class_models.csv"

OUT_RMF_CLASS = TABLE_DIR / "stage05b_rmflux_class_stepwise.csv"
OUT_RMF_COL = TABLE_DIR / "stage05b_rmflux_colour_stepwise.csv"
OUT_VIF = TABLE_DIR / "stage05b_rmflux_fullmodel_vif.csv"
OUT_SED = TABLE_DIR / "stage05b_sed_overlap.csv"
OUT_PRIMARY_Q = TABLE_DIR / "stage05b_primary_fsrq_q_audit.csv"
OUT_CONT_FACTORS = TABLE_DIR / "stage05b_continuous_effect_factors.csv"
OUT_SUMMARY = AUDIT_DIR / "stage05b_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )

def numeric(s):
    return pd.to_numeric(s, errors="coerce")

def safe_log1p(s):
    x = numeric(s)
    out = pd.Series(np.nan, index=x.index, dtype=float)
    good = np.isfinite(x) & (x >= 0)
    out.loc[good] = np.log1p(x.loc[good])
    return out

def zscore_inplace(work, cols):
    for c in cols:
        x = numeric(work[c])
        sd = x.std(ddof=1)
        mu = x.mean()

        if np.isfinite(sd) and sd > 0:
            work[c] = (x - mu) / sd
        else:
            work[c] = np.nan

def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[valid] = qv

    return q

def fit_logit_row(
    df,
    outcome,
    predictors,
    model_name,
    key_predictor,
    subset=None,
    standardize=None,
):
    if standardize is None:
        standardize = []

    if subset is None:
        subset = pd.Series(True, index=df.index)

    cols = [outcome] + predictors

    w = df.loc[subset, cols].copy()

    w[outcome] = as_bool(w[outcome]).astype(int)

    for c in predictors:
        w[c] = numeric(w[c])

    w = w.replace([np.inf, -np.inf], np.nan).dropna()

    zscore_inplace(
        w,
        [c for c in standardize if c in w.columns]
    )

    w = w.dropna()

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add"
    )

    y = w[outcome].astype(float)

    fit = sm.GLM(
        y,
        X,
        family=sm.families.Binomial(),
    ).fit(
        cov_type="HC3",
        maxiter=300,
    )

    ci = fit.conf_int()

    beta = float(fit.params[key_predictor])
    p = float(fit.pvalues[key_predictor])

    return {
        "model_name": model_name,
        "outcome": outcome,
        "key_predictor": key_predictor,
        "N": len(w),
        "N_event": int(y.sum()),
        "event_fraction": float(y.mean()),
        "coef_log_odds": beta,
        "odds_ratio": math.exp(beta),
        "or_ci95_low": math.exp(float(ci.loc[key_predictor, 0])),
        "or_ci95_high": math.exp(float(ci.loc[key_predictor, 1])),
        "p_value": p,
        "aic": float(fit.aic),
    }


# ============================================================
# LOAD
# ============================================================

for path in [
    MASTER_FILE,
    PRIMARY_FILE,
    CONT_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

d = pd.read_csv(MASTER_FILE)
primary = pd.read_csv(PRIMARY_FILE)
cont = pd.read_csv(CONT_FILE)

if len(d) != 1061:
    raise RuntimeError(
        f"Expected 1061 master rows; got {len(d)}"
    )

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

for c in [
    "rmflux_strict_both",
    "colour_robust_central_break",
    "rmf_rmflux_eligible_g",
    "rmf_rmflux_eligible_r",
]:
    d[c] = as_bool(d[c])

d["rmflux_eligible_both"] = (
    d["rmf_rmflux_eligible_g"]
    &
    d["rmf_rmflux_eligible_r"]
)

d["logNseg_g"] = safe_log1p(
    d["rmf_N_segments_g"]
)

d["logNseg_r"] = safe_log1p(
    d["rmf_N_segments_r"]
)

d["logNcolour"] = safe_log1p(
    d["col_N_colour_pairs"]
)


# ============================================================
# 1) RMS-FLUX CLASS EFFECT — STEPWISE
# ============================================================

rmf_rows = []

# M0: exact raw full-sample association.
rmf_rows.append(
    fit_logit_row(
        d,
        outcome="rmflux_strict_both",
        predictors=["FSRQ"],
        model_name="M0_FULL_UNADJUSTED",
        key_predictor="FSRQ",
    )
)

# M1: selection restriction only.
rmf_rows.append(
    fit_logit_row(
        d,
        outcome="rmflux_strict_both",
        predictors=["FSRQ"],
        model_name="M1_ELIGIBLE_UNADJUSTED",
        key_predictor="FSRQ",
        subset=d["rmflux_eligible_both"],
    )
)

# M2: add available segment count.
rmf_rows.append(
    fit_logit_row(
        d,
        outcome="rmflux_strict_both",
        predictors=[
            "FSRQ",
            "logNseg_g",
            "logNseg_r",
        ],
        model_name="M2_ELIGIBLE_PLUS_NSEG",
        key_predictor="FSRQ",
        subset=d["rmflux_eligible_both"],
        standardize=[
            "logNseg_g",
            "logNseg_r",
        ],
    )
)

# M3: add noise-dominated fractions.
rmf_rows.append(
    fit_logit_row(
        d,
        outcome="rmflux_strict_both",
        predictors=[
            "FSRQ",
            "logNseg_g",
            "logNseg_r",
            "rmf_noise_dominated_fraction_g",
            "rmf_noise_dominated_fraction_r",
        ],
        model_name="M3_PLUS_NOISE_FRACTIONS",
        key_predictor="FSRQ",
        subset=d["rmflux_eligible_both"],
        standardize=[
            "logNseg_g",
            "logNseg_r",
            "rmf_noise_dominated_fraction_g",
            "rmf_noise_dominated_fraction_r",
        ],
    )
)

# M4: reproduce Stage 05 full rms-flux controlled model.
full_rmf_predictors = [
    "FSRQ",
    "logNseg_g",
    "logNseg_r",
    "rmf_noise_dominated_fraction_g",
    "rmf_noise_dominated_fraction_r",
    "rmf_segment_span_days_median_g",
    "rmf_segment_span_days_median_r",
]

full_rmf_std = [
    c
    for c in full_rmf_predictors
    if c != "FSRQ"
]

rmf_rows.append(
    fit_logit_row(
        d,
        outcome="rmflux_strict_both",
        predictors=full_rmf_predictors,
        model_name="M4_PLUS_SEGMENT_SPAN_FULL",
        key_predictor="FSRQ",
        subset=d["rmflux_eligible_both"],
        standardize=full_rmf_std,
    )
)

rmf_class = pd.DataFrame(rmf_rows)

rmf_class.to_csv(
    OUT_RMF_CLASS,
    index=False
)


# ============================================================
# VIF FOR FULL RMS-FLUX MODEL
# ============================================================

vif_cols = [
    "logNseg_g",
    "logNseg_r",
    "rmf_noise_dominated_fraction_g",
    "rmf_noise_dominated_fraction_r",
    "rmf_segment_span_days_median_g",
    "rmf_segment_span_days_median_r",
]

vw = d.loc[
    d["rmflux_eligible_both"],
    vif_cols
].copy()

vw = vw.replace(
    [np.inf, -np.inf],
    np.nan
).dropna()

zscore_inplace(
    vw,
    vif_cols
)

Xv = sm.add_constant(
    vw[vif_cols].astype(float),
    has_constant="add"
)

vif_rows = []

for i, c in enumerate(Xv.columns):
    if c == "const":
        continue

    vif_rows.append({
        "predictor": c,
        "VIF": float(
            variance_inflation_factor(
                Xv.values,
                i
            )
        ),
        "N": len(Xv),
    })

vif_table = pd.DataFrame(
    vif_rows
)

vif_table.to_csv(
    OUT_VIF,
    index=False
)


# ============================================================
# 2) RMS-FLUX -> COLOUR BREAK — STEPWISE
# ============================================================

rc_rows = []

# C0: raw full-sample association.
rc_rows.append(
    fit_logit_row(
        d,
        outcome="colour_robust_central_break",
        predictors=["rmflux_strict_both"],
        model_name="C0_FULL_UNADJUSTED",
        key_predictor="rmflux_strict_both",
    )
)

# C1: restriction to both-band rms-flux eligible.
rc_rows.append(
    fit_logit_row(
        d,
        outcome="colour_robust_central_break",
        predictors=["rmflux_strict_both"],
        model_name="C1_ELIGIBLE_UNADJUSTED",
        key_predictor="rmflux_strict_both",
        subset=d["rmflux_eligible_both"],
    )
)

# C2: class adjustment.
rc_rows.append(
    fit_logit_row(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
        ],
        model_name="C2_PLUS_CLASS",
        key_predictor="rmflux_strict_both",
        subset=d["rmflux_eligible_both"],
    )
)

# C3: colour detectability controls.
rc_rows.append(
    fit_logit_row(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
            "logNcolour",
            "col_r_mag_range",
            "col_pair_dt_hours_median",
        ],
        model_name="C3_PLUS_COLOUR_DETECTABILITY",
        key_predictor="rmflux_strict_both",
        subset=d["rmflux_eligible_both"],
        standardize=[
            "logNcolour",
            "col_r_mag_range",
            "col_pair_dt_hours_median",
        ],
    )
)

# C4: reproduce Stage 05 focused model.
rc_rows.append(
    fit_logit_row(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
            "logNcolour",
            "col_r_mag_range",
            "col_pair_dt_hours_median",
            "logNseg_g",
            "logNseg_r",
            "rmf_noise_dominated_fraction_g",
            "rmf_noise_dominated_fraction_r",
        ],
        model_name="C4_PLUS_RMS_DETECTABILITY_STAGE05",
        key_predictor="rmflux_strict_both",
        subset=d["rmflux_eligible_both"],
        standardize=[
            "logNcolour",
            "col_r_mag_range",
            "col_pair_dt_hours_median",
            "logNseg_g",
            "logNseg_r",
            "rmf_noise_dominated_fraction_g",
            "rmf_noise_dominated_fraction_r",
        ],
    )
)

# C5: extra sensitivity with segment-span controls.
rc_rows.append(
    fit_logit_row(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
            "logNcolour",
            "col_r_mag_range",
            "col_pair_dt_hours_median",
            "logNseg_g",
            "logNseg_r",
            "rmf_noise_dominated_fraction_g",
            "rmf_noise_dominated_fraction_r",
            "rmf_segment_span_days_median_g",
            "rmf_segment_span_days_median_r",
        ],
        model_name="C5_PLUS_SEGMENT_SPAN_SENSITIVITY",
        key_predictor="rmflux_strict_both",
        subset=d["rmflux_eligible_both"],
        standardize=[
            "logNcolour",
            "col_r_mag_range",
            "col_pair_dt_hours_median",
            "logNseg_g",
            "logNseg_r",
            "rmf_noise_dominated_fraction_g",
            "rmf_noise_dominated_fraction_r",
            "rmf_segment_span_days_median_g",
            "rmf_segment_span_days_median_r",
        ],
    )
)

rmf_colour = pd.DataFrame(
    rc_rows
)

rmf_colour.to_csv(
    OUT_RMF_COL,
    index=False
)


# ============================================================
# 3) SED-CLASS OVERLAP
# ============================================================

if "SED_class_clean" in d.columns:
    sed = (
        d["SED_class_clean"]
        .astype(str)
        .str.strip()
        .str.upper()
    )

    valid = (
        d["SED_class_clean"].notna()
        &
        sed.isin(["LSP", "ISP", "HSP"])
    )

    sed_tab = pd.crosstab(
        d.loc[valid, "blazar_class"],
        sed.loc[valid],
        margins=True,
    )

    sed_long = (
        sed_tab
        .rename_axis(index="blazar_class", columns="SED_class")
        .stack()
        .rename("N")
        .reset_index()
    )

else:
    sed_long = pd.DataFrame(
        columns=[
            "blazar_class",
            "SED_class",
            "N",
        ]
    )

sed_long.to_csv(
    OUT_SED,
    index=False
)


# ============================================================
# 4) PRIMARY FSRQ q-VALUE AUDIT
# ============================================================

pfs = primary.loc[
    primary["predictor"].eq("FSRQ")
].copy()

if len(pfs) > 0:
    pfs["q_BH_FSRQ_effects_only"] = bh_qvalues(
        numeric(pfs["p_value"]).to_numpy(dtype=float)
    )

pfs.to_csv(
    OUT_PRIMARY_Q,
    index=False
)


# ============================================================
# 5) CONTINUOUS EFFECTS -> MULTIPLICATIVE FACTORS
# ============================================================

cf = cont.loc[
    cont["predictor"].eq("FSRQ")
].copy()

factor_rows = []

for _, rr in cf.iterrows():
    if rr.get("outcome_transform", "") == "log10_positive":
        beta = float(rr["coef"])
        lo = float(rr["ci95_low"])
        hi = float(rr["ci95_high"])

        factor_rows.append({
            "model_name": rr["model_name"],
            "outcome": rr["outcome"],
            "N": int(rr["N"]),
            "beta_log10": beta,
            "factor_FSRQ_vs_BLL": 10.0 ** beta,
            "factor_ci95_low": 10.0 ** lo,
            "factor_ci95_high": 10.0 ** hi,
            "p_value": float(rr["p_value"]),
        })

factors = pd.DataFrame(
    factor_rows
)

if len(factors) > 0:
    factors["q_BH"] = bh_qvalues(
        factors["p_value"].to_numpy(dtype=float)
    )

factors.to_csv(
    OUT_CONT_FACTORS,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 05B ROBUSTNESS SUMMARY",
    "=" * 72,
    "",
    "RMS-FLUX CLASS EFFECT — STEPWISE FSRQ OR:",
]

for _, rr in rmf_class.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['odds_ratio']:.3f}, "
        f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
        f"p={rr['p_value']:.3g}"
    )

lines += [
    "",
    "FULL RMS-FLUX MODEL VIF:",
]

for _, rr in vif_table.sort_values("VIF", ascending=False).iterrows():
    lines.append(
        f"  {rr['predictor']}: VIF={rr['VIF']:.3f}"
    )

lines += [
    "",
    "RMS-FLUX -> COLOUR BREAK — STEPWISE OR:",
]

for _, rr in rmf_colour.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['odds_ratio']:.3f}, "
        f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
        f"p={rr['p_value']:.3g}"
    )

lines += [
    "",
    "SED OVERLAP (class x SED):",
]

if len(sed_long) > 0:
    for _, rr in sed_long.iterrows():
        lines.append(
            f"  {rr['blazar_class']} / {rr['SED_class']}: "
            f"N={int(rr['N'])}"
        )

lines += [
    "",
    "PRIMARY FSRQ EFFECTS WITH FSRQ-ONLY BH q:",
]

for _, rr in pfs.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"OR={rr['odds_ratio']:.3f}, "
        f"p={rr['p_value']:.3g}, "
        f"q4={rr['q_BH_FSRQ_effects_only']:.3g}"
    )

lines += [
    "",
    "CONTINUOUS FSRQ/BLL MULTIPLICATIVE FACTORS:",
]

for _, rr in factors.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"factor={rr['factor_FSRQ_vs_BLL']:.3f}, "
        f"95%CI={rr['factor_ci95_low']:.3f}-{rr['factor_ci95_high']:.3f}, "
        f"q={rr['q_BH']:.3g}"
    )

summary = "\n".join(lines)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 05B")
print("ROBUSTNESS / DIAGNOSTIC QA")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_RMF_CLASS)
print(OUT_RMF_COL)
print(OUT_VIF)
print(OUT_SED)
print(OUT_PRIMARY_Q)
print(OUT_CONT_FACTORS)
print(OUT_SUMMARY)
print()
print("STAGE 05B COMPLETE")
