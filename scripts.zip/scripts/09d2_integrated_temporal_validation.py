# ============================================================
# BLAZAR_I — STAGE 09D2
# INTEGRATED TEMPORAL-VALIDATION LEDGER + CLAIM HIERARCHY
#
# Purpose:
#   Freeze the interpretation of Stage09D temporal validation before
#   manuscript reconstruction.
#
# Inputs:
#   stage09d1a_association_summary.csv
#   stage09d1a_crosshalf_stability.csv
#   stage09d1c_clustered_models_gamma_repaired.csv
#   stage09d1c_source_level_models_gamma_repaired.csv
#   stage09d1c_single_band_models_gamma_repaired.csv
#   stage09d1c_lsp_only_models_gamma_repaired.csv
#   stage09c5_primary_calibration_table.csv
#
# Outputs:
#   outputs/tables/stage09d2_temporal_validation_ledger.csv
#   outputs/tables/stage09d2_claim_hierarchy.csv
#   outputs/tables/stage09d2_q1_temporal_table.tex
#   outputs/audit/stage09d2_summary.txt
#
# No upstream result is modified.
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

A_ASSOC = TABLE_DIR / "stage09d1a_association_summary.csv"
A_STAB = TABLE_DIR / "stage09d1a_crosshalf_stability.csv"

D_CLUSTER = TABLE_DIR / "stage09d1c_clustered_models_gamma_repaired.csv"
D_SOURCE = TABLE_DIR / "stage09d1c_source_level_models_gamma_repaired.csv"
D_BAND = TABLE_DIR / "stage09d1c_single_band_models_gamma_repaired.csv"
D_LSP = TABLE_DIR / "stage09d1c_lsp_only_models_gamma_repaired.csv"

CAL = TABLE_DIR / "stage09c5_primary_calibration_table.csv"

OUT_LEDGER = TABLE_DIR / "stage09d2_temporal_validation_ledger.csv"
OUT_HIER = TABLE_DIR / "stage09d2_claim_hierarchy.csv"
OUT_TEX = TABLE_DIR / "stage09d2_q1_temporal_table.tex"
OUT_SUMMARY = AUDIT_DIR / "stage09d2_summary.txt"

for p in [
    A_ASSOC,
    A_STAB,
    D_CLUSTER,
    D_SOURCE,
    D_BAND,
    D_LSP,
    CAL,
]:
    if not p.exists():
        raise FileNotFoundError(p)

assoc = pd.read_csv(A_ASSOC, low_memory=False)
stab = pd.read_csv(A_STAB, low_memory=False)
drw = pd.read_csv(D_CLUSTER, low_memory=False)
src = pd.read_csv(D_SOURCE, low_memory=False)
band = pd.read_csv(D_BAND, low_memory=False)
lsp = pd.read_csv(D_LSP, low_memory=False)
cal = pd.read_csv(CAL, low_memory=False)


def one(df, **conds):
    mask = pd.Series(True, index=df.index)
    for c, v in conds.items():
        mask = mask & df[c].astype(str).eq(str(v))
    hit = df.loc[mask]
    if len(hit) != 1:
        raise RuntimeError(
            f"Expected one row for {conds}; found {len(hit)}"
        )
    return hit.iloc[0]


rows = []

# ============================================================
# RMS-FLUX -> COLOUR TEMPORAL ASSOCIATION
# ============================================================

for half in ["EARLY", "LATE"]:
    for model in [
        "UNADJUSTED_2X2",
        "MINIMAL_CLASS",
        "PLUS_DYNAMIC_RANGE",
    ]:
        r = one(
            assoc,
            half=half,
            model=model,
        )

        rows.append({
            "domain": "RMS_FLUX_TO_COLOUR",
            "half": half,
            "analysis": model,
            "effect_type": "odds_ratio",
            "estimate": r["OR"],
            "ci95_low": r["ci95_low"],
            "ci95_high": r["ci95_high"],
            "p": r["p"],
            "N": r["N"],
            "interpretation": (
                "Positive raw association"
                if model != "PLUS_DYNAMIC_RANGE"
                else
                "Association attenuated after half-specific optical dynamic-range adjustment"
            ),
        })


# ============================================================
# DRW TEMPORAL CLASS ASSOCIATION
# ============================================================

for half in ["EARLY", "LATE"]:
    for model in [
        "D0_CLASS_ONLY",
        "D1_Z_GAMMA",
        "D2_FULL",
    ]:
        r = one(
            drw,
            half=half,
            model=model,
        )

        rows.append({
            "domain": "DRW_CLASS_ASSOCIATION",
            "half": half,
            "analysis": model,
            "effect_type": "FSRQ_to_BLL_tau_factor",
            "estimate": r["factor"],
            "ci95_low": r["ci95_low"],
            "ci95_high": r["ci95_high"],
            "p": r["p"],
            "N": r["N_sources"],
            "interpretation": (
                "Factor <1 means shorter rest-frame DRW timescale in FSRQs"
            ),
        })

    r = one(
        src,
        half=half,
        model="D2_SOURCE_GEOMEAN",
    )

    rows.append({
        "domain": "DRW_CLASS_ASSOCIATION",
        "half": half,
        "analysis": "D2_SOURCE_GEOMEAN",
        "effect_type": "FSRQ_to_BLL_tau_factor",
        "estimate": r["factor"],
        "ci95_low": r["ci95_low"],
        "ci95_high": r["ci95_high"],
        "p": r["p"],
        "N": r["N_sources"],
        "interpretation": (
            "One-row-per-source both-band geometric-mean sensitivity"
        ),
    })

    for filt in ["g", "r"]:
        r = one(
            band,
            half=half,
            model="D2_FULL",
            filter_name=filt,
        )

        rows.append({
            "domain": "DRW_CLASS_ASSOCIATION",
            "half": half,
            "analysis": f"D2_SINGLE_{filt.upper()}",
            "effect_type": "FSRQ_to_BLL_tau_factor",
            "estimate": r["factor"],
            "ci95_low": r["ci95_low"],
            "ci95_high": r["ci95_high"],
            "p": r["p"],
            "N": r["N_sources"],
            "interpretation": (
                f"Single-band {filt}-band sensitivity"
            ),
        })

    if len(lsp):
        r = one(
            lsp,
            half=half,
            model="D2_LSP_ONLY",
        )

        rows.append({
            "domain": "DRW_CLASS_ASSOCIATION",
            "half": half,
            "analysis": "D2_LSP_ONLY",
            "effect_type": "FSRQ_to_BLL_tau_factor",
            "estimate": r["factor"],
            "ci95_low": r["ci95_low"],
            "ci95_high": r["ci95_high"],
            "p": r["p"],
            "N": r["N_sources"],
            "interpretation": (
                "SED-overlap sensitivity; attenuation toward unity tests compositional contribution"
            ),
        })


ledger = pd.DataFrame(rows)
ledger.to_csv(OUT_LEDGER, index=False)


# ============================================================
# CLAIM HIERARCHY
# ============================================================

early_dyn = one(
    assoc,
    half="EARLY",
    model="PLUS_DYNAMIC_RANGE",
)

late_dyn = one(
    assoc,
    half="LATE",
    model="PLUS_DYNAMIC_RANGE",
)

early_drw = one(
    drw,
    half="EARLY",
    model="D2_FULL",
)

late_drw = one(
    drw,
    half="LATE",
    model="D2_FULL",
)

early_lsp = one(
    lsp,
    half="EARLY",
    model="D2_LSP_ONLY",
)

late_lsp = one(
    lsp,
    half="LATE",
    model="D2_LSP_ONLY",
)

rmf_stab = one(
    stab,
    endpoint="rmflux_strict_both",
)

col_stab = one(
    stab,
    endpoint="colour_robust_central_break",
)

hier = pd.DataFrame([
    {
        "rank": 1,
        "claim_id": "FINAL-DRW-01",
        "role": "PRIMARY_HEADLINE",
        "claim": (
            "FSRQs show shorter rest-frame DRW timescales than BLLs at the "
            "population level, with the direction reproduced in both temporal halves."
        ),
        "evidence": (
            f"EARLY D2 factor={early_drw['factor']:.3f} "
            f"[{early_drw['ci95_low']:.3f},{early_drw['ci95_high']:.3f}]; "
            f"LATE D2 factor={late_drw['factor']:.3f} "
            f"[{late_drw['ci95_low']:.3f},{late_drw['ci95_high']:.3f}]."
        ),
        "required_caveat": (
            "This is an observational population association, not a causal class effect. "
            "LSP-only estimates attenuate toward unity, especially in the late half, "
            "so SED/population composition contributes materially."
        ),
    },
    {
        "rank": 2,
        "claim_id": "FINAL-RMF-COL-01",
        "role": "CONDITIONAL_SUPPORTING",
        "claim": (
            "Strict rms-flux detections and robust colour curvature co-occur in raw "
            "temporal analyses."
        ),
        "evidence": (
            "Unadjusted ORs are >1 in both temporal halves, but the association is "
            "not retained after half-specific optical dynamic-range adjustment."
        ),
        "required_caveat": (
            f"EARLY dynamic-range-adjusted OR={early_dyn['OR']:.3f}, "
            f"p={early_dyn['p']:.3g}; LATE OR={late_dyn['OR']:.3f}, "
            f"p={late_dyn['p']:.3g}. Do not present this as an independent "
            "physical coupling."
        ),
    },
    {
        "rank": 3,
        "claim_id": "FINAL-ENDPOINT-01",
        "role": "SECONDARY",
        "claim": (
            "Endpoint incidence differences by optical class are descriptive "
            "population contrasts."
        ),
        "evidence": (
            "Stage09A overlap/confounder analyses showed substantial attenuation "
            "after gamma-ray, brightness, host, and SED-related adjustment."
        ),
        "required_caveat": (
            "Do not describe endpoint differences as intrinsic class properties."
        ),
    },
    {
        "rank": 4,
        "claim_id": "FINAL-PDF-01",
        "role": "DESCRIPTIVE_ONLY",
        "claim": (
            "Double-lognormal labels describe mixture-like flux-distribution shape."
        ),
        "evidence": (
            "Stage09C correlated-lognormal null produced a non-negligible robust-double "
            "false-positive rate and Stage06E showed strong sampling sensitivity."
        ),
        "required_caveat": (
            "Never interpret robust-double incidence as a physical two-state or "
            "bimodal fraction."
        ),
    },
])

hier.to_csv(OUT_HIER, index=False)


# ============================================================
# LATEX TABLE
# ============================================================

def ff(x):
    return f"{float(x):.3f}"

tex = [
    r"\begin{table*}",
    r"\centering",
    r"\caption{Temporal validation of the principal population-level associations. "
    r"EARLY and LATE blocks contain repeated measurements of the same sources and "
    r"therefore are not statistically independent samples.}",
    r"\label{tab:temporal_validation}",
    r"\begin{tabular}{lllll}",
    r"\hline",
    r"Result & EARLY & LATE & Adjustment & Interpretation \\",
    r"\hline",
    (
        r"DRW FSRQ/BLL $\tau_{\rm rest}$ factor & "
        f"{ff(early_drw['factor'])} "
        f"({ff(early_drw['ci95_low'])}--{ff(early_drw['ci95_high'])}) & "
        f"{ff(late_drw['factor'])} "
        f"({ff(late_drw['ci95_low'])}--{ff(late_drw['ci95_high'])}) & "
        r"$z+\gamma+$ brightness + host & "
        r"\parbox[t]{5.2cm}{Direction reproduced in both halves; "
        r"LSP-only estimates are attenuated toward unity.} \\"
    ),
    (
        r"rms--flux $\rightarrow$ colour OR & "
        f"{ff(early_dyn['OR'])} "
        f"({ff(early_dyn['ci95_low'])}--{ff(early_dyn['ci95_high'])}) & "
        f"{ff(late_dyn['OR'])} "
        f"({ff(late_dyn['ci95_low'])}--{ff(late_dyn['ci95_high'])}) & "
        r"class + optical dynamic range & "
        r"\parbox[t]{5.2cm}{Raw association is not retained after "
        r"dynamic-range adjustment in either half.} \\"
    ),
    r"\hline",
    r"\end{tabular}",
    r"\end{table*}",
]

OUT_TEX.write_text(
    "\n".join(tex),
    encoding="utf-8",
)


# ============================================================
# FINAL SUMMARY
# ============================================================

summary = f"""BLAZAR_I - STAGE 09D2 FINAL SUMMARY
================================================================================

INTEGRATED TEMPORAL VALIDATION

1) DRW — NEW PRIMARY HEADLINE
  EARLY gamma/brightness/host-adjusted factor : {early_drw['factor']:.3f} [{early_drw['ci95_low']:.3f}, {early_drw['ci95_high']:.3f}], p={early_drw['p']:.3g}
  LATE  gamma/brightness/host-adjusted factor : {late_drw['factor']:.3f} [{late_drw['ci95_low']:.3f}, {late_drw['ci95_high']:.3f}], p={late_drw['p']:.3g}

  LSP-only:
    EARLY factor                              : {early_lsp['factor']:.3f} [{early_lsp['ci95_low']:.3f}, {early_lsp['ci95_high']:.3f}], p={early_lsp['p']:.3g}
    LATE factor                               : {late_lsp['factor']:.3f} [{late_lsp['ci95_low']:.3f}, {late_lsp['ci95_high']:.3f}], p={late_lsp['p']:.3g}

  INTERPRETATION:
    The full supported population shows a temporally reproducible FSRQ/BLL
    rest-frame DRW timescale contrast.  The contrast attenuates toward unity
    within LSP-only overlap, especially in the late half, so it must be framed
    as a population-level association partly related to SED/population composition,
    not as an intrinsic causal class property.

2) RMS-FLUX -> COLOUR — DOWNGRADE FROM FLAGSHIP
  EARLY dynamic-range-adjusted OR             : {early_dyn['OR']:.3f} [{early_dyn['ci95_low']:.3f}, {early_dyn['ci95_high']:.3f}], p={early_dyn['p']:.3g}
  LATE  dynamic-range-adjusted OR             : {late_dyn['OR']:.3f} [{late_dyn['ci95_low']:.3f}, {late_dyn['ci95_high']:.3f}], p={late_dyn['p']:.3g}

  Endpoint cross-half stability:
    rms-flux Cohen kappa                      : {rmf_stab['cohen_kappa']:.3f}
    colour-break Cohen kappa                  : {col_stab['cohen_kappa']:.3f}

  INTERPRETATION:
    Raw rms-flux/colour co-occurrence reproduces directionally in both halves,
    but the association disappears after optical dynamic-range adjustment in
    both halves.  It is therefore a conditional/detectability-linked association,
    not the main independent physical result.

3) FINAL Q1 CLAIM HIERARCHY
  A. PRIMARY:
     Temporally reproducible population-level FSRQ/BLL DRW timescale contrast.
  B. CONDITIONAL SUPPORTING:
     Raw rms-flux/colour-curvature co-occurrence, strongly dependent on
     optical dynamic range/detectability.
  C. SECONDARY:
     Class-specific binary endpoint incidence after overlap/confounder audits.
  D. DESCRIPTIVE ONLY:
     Double-lognormal PDF incidence / mixture-like flux-distribution shape.

MANUSCRIPT LOCKS
  - Do not call the DRW contrast causal or intrinsic to optical class.
  - Explicitly report LSP-only attenuation.
  - Do not retain rms-flux -> colour as the principal independent headline.
  - Do not infer physical two-state incidence from double-lognormal labels.
  - EARLY and LATE p-values are not independent replications.
  - Stage09C calibration caveats remain active.

Files saved:
  {OUT_LEDGER}
  {OUT_HIER}
  {OUT_TEX}

STAGE 09D2 COMPLETE
"""

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
