# ============================================================
# BLAZAR_I — STAGE 06B3
# BOOTSTRAP STABILITY OF ERROR-AWARE COLOUR BREAKS
#
# Purpose:
#   Quantify whether the break magnitudes detected in STAGE 06B1
#   are stable under resampling of the paired colour-magnitude data.
#
# Target set:
#   Sources with a robust-central error-aware break at T6H
#   (DeltaBIC >= 20 and central break fraction 0.15..0.85).
#
# For each target:
#   * use T6H pairs only
#   * bootstrap paired rows with replacement
#   * refit single + continuous broken error-aware likelihood
#   * record break recovery, DeltaBIC, break magnitude
#
# Primary stability summaries:
#   recovery fraction with robust-central break
#   recovery fraction with DeltaBIC >= 10
#   median bootstrap break magnitude
#   16/84 and 2.5/97.5 percentiles
#   median |bootstrap break - original break|
#
# This is a robustness stage only; upstream frozen products are
# read-only and are NOT replaced.
# ============================================================

from pathlib import Path
import argparse
import math
import zlib
import warnings

import numpy as np
import pandas as pd
from scipy.optimize import minimize

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

PAIR_FILE = (
    ROOT / "outputs" / "tables"
    / "stage03c_colour_pairs_master.parquet"
)

MASTER06B1 = (
    ROOT / "outputs" / "tables"
    / "stage06b1_colour_erroraware_master.csv"
)

MODEL_DIR = (
    ROOT / "outputs" / "models"
    / "stage06b3_break_bootstrap"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_SUMMARY_TABLE = (
    TABLE_DIR / "stage06b3_break_bootstrap_summary.csv"
)

OUT_GLOBAL_BOOT = (
    TABLE_DIR / "stage06b3_break_bootstrap_draws.parquet"
)

OUT_AUDIT = (
    AUDIT_DIR / "stage06b3_summary.txt"
)

MODEL_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# CONFIG
# ============================================================

TIMING_HOURS = 6.0

BOOT_N = 300
BASE_SEED = 20260917

MIN_N = 30
MIN_SIDE = 10

STRONG_DBIC = 10.0
ROBUST_DBIC = 20.0
CENTRAL_MIN = 0.15
CENTRAL_MAX = 0.85

SLOPE_BOUND = 10.0
DELTA_SLOPE_BOUND = 20.0

SIGMA_INT_MIN = 1.0e-4
SIGMA_INT_MAX = 2.0

BREAK_START_QUANTILES = [
    0.20,
    0.35,
    0.50,
    0.65,
    0.80,
]


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def stable_seed(blazar_id):
    token = (
        f"{BASE_SEED}|{blazar_id}|06B3"
    ).encode("utf-8")

    return int(
        zlib.crc32(token)
        &
        0xFFFFFFFF
    )


def robust_scale(y):
    y = np.asarray(y, dtype=float)

    med = np.median(y)
    mad = np.median(
        np.abs(y - med)
    )

    if np.isfinite(mad) and mad > 0:
        return 1.4826 * mad

    sd = np.std(y, ddof=1)

    if np.isfinite(sd) and sd > 0:
        return sd

    return 0.05


def single_nll(
    pars,
    x,
    y,
    sg,
    sr,
    x0,
):
    c, b, log_sint = pars

    sint = math.exp(log_sint)

    mu = (
        c
        +
        b * (x - x0)
    )

    var = (
        sg ** 2
        +
        (1.0 + b) ** 2 * sr ** 2
        +
        sint ** 2
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= 0)
    ):
        return 1.0e100

    resid = y - mu

    return 0.5 * float(
        np.sum(
            np.log(
                2.0 * np.pi * var
            )
            +
            resid ** 2 / var
        )
    )


def broken_nll(
    pars,
    x,
    y,
    sg,
    sr,
):
    c, b_left, db, xb, log_sint = pars

    left = x <= xb
    right = ~left

    if (
        int(left.sum()) < MIN_SIDE
        or
        int(right.sum()) < MIN_SIDE
    ):
        return 1.0e100

    b_right = (
        b_left + db
    )

    sint = math.exp(
        log_sint
    )

    dx = (
        x - xb
    )

    mu = (
        c
        +
        b_left * dx
        +
        db * np.maximum(
            dx,
            0.0
        )
    )

    local_b = np.where(
        left,
        b_left,
        b_right
    )

    var = (
        sg ** 2
        +
        (1.0 + local_b) ** 2 * sr ** 2
        +
        sint ** 2
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= 0)
    ):
        return 1.0e100

    resid = (
        y - mu
    )

    return 0.5 * float(
        np.sum(
            np.log(
                2.0 * np.pi * var
            )
            +
            resid ** 2 / var
        )
    )


def initial_ols(x, y):
    x0 = float(
        np.median(x)
    )

    A = np.column_stack(
        [
            np.ones(len(x)),
            x - x0,
        ]
    )

    beta, *_ = np.linalg.lstsq(
        A,
        y,
        rcond=None
    )

    c = float(
        beta[0]
    )

    b = float(
        np.clip(
            beta[1],
            -SLOPE_BOUND,
            SLOPE_BOUND
        )
    )

    return x0, c, b


def fit_single(
    x,
    y,
    sg,
    sr,
):
    x0, c0, b0 = initial_ols(
        x,
        y
    )

    s0 = max(
        SIGMA_INT_MIN * 10.0,
        min(
            robust_scale(y) * 0.5,
            0.5
        )
    )

    starts = [
        [c0, b0, math.log(s0)],
        [float(np.median(y)), 0.0, math.log(s0)],
        [c0, b0, math.log(0.02)],
        [c0, b0, math.log(0.10)],
    ]

    c_pad = max(
        1.0,
        4.0 * robust_scale(y)
    )

    c_med = float(
        np.median(y)
    )

    bounds = [
        (
            c_med - c_pad,
            c_med + c_pad
        ),
        (
            -SLOPE_BOUND,
            SLOPE_BOUND
        ),
        (
            math.log(SIGMA_INT_MIN),
            math.log(SIGMA_INT_MAX)
        ),
    ]

    best = None

    for start in starts:
        res = minimize(
            single_nll,
            x0=np.asarray(
                start,
                dtype=float
            ),
            args=(x, y, sg, sr, x0),
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 500,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(
            res.fun
        ):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    c, b, log_sint = (
        best.x
    )

    return {
        "success": bool(
            best.success
        ),
        "nll": float(
            best.fun
        ),
        "c": float(c),
        "slope": float(b),
        "sigma_int": float(
            math.exp(
                log_sint
            )
        ),
        "x0": float(x0),
    }


def fit_broken(
    x,
    y,
    sg,
    sr,
    single,
):
    xs = np.sort(x)

    if len(xs) < MIN_N:
        return None

    x_lo = float(
        xs[MIN_SIDE - 1]
    )

    x_hi = float(
        xs[-MIN_SIDE]
    )

    if not (
        np.isfinite(x_lo)
        and
        np.isfinite(x_hi)
        and
        x_hi > x_lo
    ):
        return None

    starts = []

    for q in BREAK_START_QUANTILES:
        xb0 = float(
            np.clip(
                np.quantile(x, q),
                x_lo,
                x_hi
            )
        )

        c0 = (
            single["c"]
            +
            single["slope"]
            *
            (
                xb0
                -
                single["x0"]
            )
        )

        starts.append(
            [
                c0,
                single["slope"],
                0.0,
                xb0,
                math.log(
                    max(
                        single["sigma_int"],
                        SIGMA_INT_MIN
                    )
                ),
            ]
        )

    # Match the STAGE 06B1 optimizer starts as closely as possible:
    # add left/right OLS-informed starts at three trial breaks.
    for q in [0.35, 0.50, 0.65]:
        xb0 = float(
            np.clip(
                np.quantile(x, q),
                x_lo,
                x_hi
            )
        )

        left = x <= xb0
        right = x > xb0

        if (
            left.sum() < MIN_SIDE
            or
            right.sum() < MIN_SIDE
        ):
            continue

        def slope_only(xx, yy):
            if len(xx) < 2:
                return 0.0

            xx0 = xx - np.mean(xx)
            den = float(
                np.sum(xx0 ** 2)
            )

            if den <= 0:
                return 0.0

            return float(
                np.sum(
                    xx0
                    *
                    (yy - np.mean(yy))
                )
                /
                den
            )

        bl = np.clip(
            slope_only(
                x[left],
                y[left]
            ),
            -SLOPE_BOUND,
            SLOPE_BOUND
        )

        br = np.clip(
            slope_only(
                x[right],
                y[right]
            ),
            -SLOPE_BOUND,
            SLOPE_BOUND
        )

        db0 = float(
            np.clip(
                br - bl,
                -DELTA_SLOPE_BOUND,
                DELTA_SLOPE_BOUND
            )
        )

        near = np.argsort(
            np.abs(
                x - xb0
            )
        )[
            :max(
                5,
                min(
                    20,
                    len(x)
                )
            )
        ]

        c0 = float(
            np.median(
                y[near]
            )
        )

        starts.append(
            [
                c0,
                float(bl),
                db0,
                xb0,
                math.log(
                    max(
                        single["sigma_int"],
                        SIGMA_INT_MIN
                    )
                ),
            ]
        )

    c_med = float(
        np.median(y)
    )

    c_pad = max(
        1.0,
        4.0 * robust_scale(y)
    )

    bounds = [
        (
            c_med - c_pad,
            c_med + c_pad
        ),
        (
            -SLOPE_BOUND,
            SLOPE_BOUND
        ),
        (
            -DELTA_SLOPE_BOUND,
            DELTA_SLOPE_BOUND
        ),
        (
            x_lo,
            x_hi
        ),
        (
            math.log(SIGMA_INT_MIN),
            math.log(SIGMA_INT_MAX)
        ),
    ]

    best = None

    for start in starts:
        res = minimize(
            broken_nll,
            x0=np.asarray(
                start,
                dtype=float
            ),
            args=(x, y, sg, sr),
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 700,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(
            res.fun
        ):
            continue

        c, b_left, db, xb, log_sint = (
            res.x
        )

        if (
            int((x <= xb).sum()) < MIN_SIDE
            or
            int((x > xb).sum()) < MIN_SIDE
        ):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    c, b_left, db, xb, log_sint = (
        best.x
    )

    return {
        "success": bool(
            best.success
        ),
        "nll": float(
            best.fun
        ),
        "break_r_mag": float(
            xb
        ),
        "slope_left": float(
            b_left
        ),
        "slope_right": float(
            b_left + db
        ),
        "sigma_int": float(
            math.exp(
                log_sint
            )
        ),
    }


def fit_one_bootstrap(
    x,
    y,
    sg,
    sr,
):
    if len(x) < MIN_N:
        return None

    rmin = float(
        np.min(x)
    )

    rmax = float(
        np.max(x)
    )

    rrange = (
        rmax - rmin
    )

    if not (
        np.isfinite(rrange)
        and
        rrange > 0
    ):
        return None

    single = fit_single(
        x,
        y,
        sg,
        sr
    )

    if single is None:
        return None

    broken = fit_broken(
        x,
        y,
        sg,
        sr,
        single
    )

    if broken is None:
        return None

    n = len(x)

    bic_single = (
        2.0 * single["nll"]
        +
        3.0 * math.log(n)
    )

    bic_broken = (
        2.0 * broken["nll"]
        +
        5.0 * math.log(n)
    )

    delta_bic = (
        bic_single
        -
        bic_broken
    )

    break_frac = (
        (
            broken["break_r_mag"]
            -
            rmin
        )
        /
        rrange
    )

    strong = (
        single["success"]
        and
        broken["success"]
        and
        delta_bic >= STRONG_DBIC
    )

    robust = (
        strong
        and
        delta_bic >= ROBUST_DBIC
        and
        CENTRAL_MIN
        <=
        break_frac
        <=
        CENTRAL_MAX
    )

    return {
        "single_success": bool(
            single["success"]
        ),
        "broken_success": bool(
            broken["success"]
        ),
        "delta_bic": float(
            delta_bic
        ),
        "break_r_mag": float(
            broken["break_r_mag"]
        ),
        "break_fraction": float(
            break_frac
        ),
        "strong_break": bool(
            strong
        ),
        "robust_central_break": bool(
            robust
        ),
    }


# ============================================================
# MAIN
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="Process only first N not-yet-complete robust T6H sources.",
)

args = parser.parse_args()

for path in [
    PAIR_FILE,
    MASTER06B1,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

pairs = pd.read_parquet(
    PAIR_FILE
)

m = pd.read_csv(
    MASTER06B1
)

pairs["blazar_id"] = (
    pairs["blazar_id"]
    .astype(str)
)

m["blazar_id"] = (
    m["blazar_id"]
    .astype(str)
)

m["robust_flag"] = as_bool(
    m["robust_central_break_bic20_ea"]
)

targets = (
    m.loc[
        m["timing_cut"].eq("T6H")
        &
        m["fit_status"].eq("OK")
        &
        m["robust_flag"]
    ]
    .sort_values("blazar_id")
    .reset_index(drop=True)
)

target_ids = (
    targets["blazar_id"]
    .tolist()
)

grouped = {
    bid: g.copy()
    for bid, g in pairs.groupby(
        "blazar_id",
        sort=False
    )
    if bid in set(target_ids)
}

done = set(
    p.stem
    for p in MODEL_DIR.glob(
        "*.done"
    )
)

todo = [
    bid
    for bid in target_ids
    if bid not in done
]

if args.limit is not None:
    todo = todo[
        :args.limit
    ]

print("=" * 78)
print("BLAZAR_I — STAGE 06B3")
print("BOOTSTRAP STABILITY OF ERROR-AWARE T6H COLOUR BREAKS")
print("=" * 78)
print(
    f"Robust T6H targets = {len(target_ids)}"
)
print(
    f"Already complete   = {len(done)}"
)
print(
    f"This run            = {len(todo)}"
)
print(
    f"Bootstrap draws     = {BOOT_N} per source"
)
print()

for i, bid in enumerate(
    todo,
    start=1
):
    src = grouped[
        bid
    ]

    src = src.loc[
        pd.to_numeric(
            src["dt_gr_hours"],
            errors="coerce"
        ).abs()
        <=
        TIMING_HOURS
    ].copy()

    cols = [
        "r_mag",
        "g_minus_r",
        "g_magerr",
        "r_magerr",
    ]

    for c in cols:
        src[c] = pd.to_numeric(
            src[c],
            errors="coerce"
        )

    src = src.dropna(
        subset=cols
    )

    src = src.loc[
        (src["g_magerr"] > 0)
        &
        (src["r_magerr"] > 0)
    ].reset_index(
        drop=True
    )

    if len(src) < MIN_N:
        raise RuntimeError(
            f"{bid}: fewer than {MIN_N} valid T6H pairs"
        )

    original = targets.loc[
        targets["blazar_id"].eq(bid)
    ].iloc[0]

    original_break = float(
        original["break_r_mag"]
    )

    rng = np.random.default_rng(
        stable_seed(bid)
    )

    draw_rows = []

    n = len(src)

    for b in range(
        BOOT_N
    ):
        idx = rng.integers(
            0,
            n,
            size=n
        )

        boot = src.iloc[
            idx
        ]

        result = fit_one_bootstrap(
            boot["r_mag"].to_numpy(dtype=float),
            boot["g_minus_r"].to_numpy(dtype=float),
            boot["g_magerr"].to_numpy(dtype=float),
            boot["r_magerr"].to_numpy(dtype=float),
        )

        if result is None:
            draw_rows.append({
                "blazar_id": bid,
                "draw": b + 1,
                "fit_ok": False,
            })
            continue

        draw_rows.append({
            "blazar_id": bid,
            "draw": b + 1,
            "fit_ok": True,
            **result,
            "abs_break_shift_mag": abs(
                result["break_r_mag"]
                -
                original_break
            ),
        })

    draw_df = pd.DataFrame(
        draw_rows
    )

    draw_path = (
        MODEL_DIR
        /
        f"{bid}_06B3_boot.csv"
    )

    draw_df.to_csv(
        draw_path,
        index=False
    )

    done_path = (
        MODEL_DIR
        /
        f"{bid}.done"
    )

    done_path.write_text(
        "OK\n",
        encoding="utf-8"
    )

    ok = draw_df.loc[
        draw_df["fit_ok"]
        .fillna(False)
        .astype(bool)
    ]

    robust_frac = (
        float(
            ok[
                "robust_central_break"
            ]
            .fillna(False)
            .astype(bool)
            .mean()
        )
        if len(ok) > 0
        else np.nan
    )

    if (
        i <= 5
        or
        i % 10 == 0
        or
        i == len(todo)
    ):
        print(
            f"{i}/{len(todo)} {bid}: "
            f"Npairs={n}, "
            f"fitOK={len(ok)}/{BOOT_N}, "
            f"robust_recovery={robust_frac:.3f}"
        )


# ============================================================
# STATUS
# ============================================================

n_done = len(
    list(
        MODEL_DIR.glob(
            "*.done"
        )
    )
)

remaining = (
    len(target_ids)
    -
    n_done
)

print()
print("=" * 78)
print("STAGE 06B3 CURRENT STATUS")
print("=" * 78)
print(
    f"Completed = {n_done} / {len(target_ids)}"
)
print(
    f"Remaining = {remaining}"
)

if remaining > 0:
    print()
    print(
        "Partial run complete. Re-run same command to resume."
    )
    raise SystemExit(0)


# ============================================================
# GLOBAL ASSEMBLY
# ============================================================

draw_files = sorted(
    MODEL_DIR.glob(
        "BZI_*_06B3_boot.csv"
    )
)

draws = pd.concat(
    [
        pd.read_csv(f)
        for f in draw_files
    ],
    ignore_index=True
)

draws.to_parquet(
    OUT_GLOBAL_BOOT,
    index=False
)

summary_rows = []

for _, original in targets.iterrows():
    bid = original["blazar_id"]

    x = draws.loc[
        draws["blazar_id"].eq(bid)
    ].copy()

    x["fit_ok"] = as_bool(
        x["fit_ok"]
    )

    ok = x.loc[
        x["fit_ok"]
    ]

    strong = (
        as_bool(
            ok["strong_break"]
        )
        if len(ok)
        else pd.Series(
            dtype=bool
        )
    )

    robust = (
        as_bool(
            ok["robust_central_break"]
        )
        if len(ok)
        else pd.Series(
            dtype=bool
        )
    )

    br = pd.to_numeric(
        ok["break_r_mag"],
        errors="coerce"
    ).dropna()

    shift = pd.to_numeric(
        ok["abs_break_shift_mag"],
        errors="coerce"
    ).dropna()

    row = {
        "blazar_id": bid,
        "blazar_class": original["blazar_class"],
        "N_pairs_original": int(original["N_pairs"]),
        "original_break_r_mag": float(original["break_r_mag"]),
        "original_delta_bic": float(original["delta_bic_single_minus_broken"]),
        "bootstrap_N": BOOT_N,
        "bootstrap_fit_ok_N": int(len(ok)),
        "bootstrap_fit_ok_fraction": float(len(ok) / BOOT_N),
        "strong_break_recovery_fraction": (
            float(strong.mean())
            if len(strong)
            else np.nan
        ),
        "robust_central_recovery_fraction": (
            float(robust.mean())
            if len(robust)
            else np.nan
        ),
        "break_boot_median": (
            float(br.median())
            if len(br)
            else np.nan
        ),
        "break_boot_p16": (
            float(br.quantile(0.16))
            if len(br)
            else np.nan
        ),
        "break_boot_p84": (
            float(br.quantile(0.84))
            if len(br)
            else np.nan
        ),
        "break_boot_p025": (
            float(br.quantile(0.025))
            if len(br)
            else np.nan
        ),
        "break_boot_p975": (
            float(br.quantile(0.975))
            if len(br)
            else np.nan
        ),
        "median_abs_break_shift_mag": (
            float(shift.median())
            if len(shift)
            else np.nan
        ),
        "p90_abs_break_shift_mag": (
            float(shift.quantile(0.90))
            if len(shift)
            else np.nan
        ),
    }

    summary_rows.append(
        row
    )

summary_table = pd.DataFrame(
    summary_rows
)

summary_table.to_csv(
    OUT_SUMMARY_TABLE,
    index=False
)


# ============================================================
# GLOBAL SUMMARY
# ============================================================

stable50 = (
    summary_table[
        "robust_central_recovery_fraction"
    ]
    >=
    0.50
)

stable80 = (
    summary_table[
        "robust_central_recovery_fraction"
    ]
    >=
    0.80
)

stable90 = (
    summary_table[
        "robust_central_recovery_fraction"
    ]
    >=
    0.90
)

lines = [
    "BLAZAR_I - STAGE 06B3 FINAL SUMMARY",
    "=" * 72,
    "",
    f"Robust T6H targets             : {len(summary_table)}",
    (
        "Median bootstrap fit-OK frac  : "
        f"{summary_table['bootstrap_fit_ok_fraction'].median():.3f}"
    ),
    (
        "Median strong-break recovery  : "
        f"{summary_table['strong_break_recovery_fraction'].median():.3f}"
    ),
    (
        "Median robust-break recovery  : "
        f"{summary_table['robust_central_recovery_fraction'].median():.3f}"
    ),
    (
        "Sources robust recovery >=0.50: "
        f"{int(stable50.sum())}/{len(summary_table)}"
    ),
    (
        "Sources robust recovery >=0.80: "
        f"{int(stable80.sum())}/{len(summary_table)}"
    ),
    (
        "Sources robust recovery >=0.90: "
        f"{int(stable90.sum())}/{len(summary_table)}"
    ),
    (
        "Median |bootstrap-break - original|: "
        f"{summary_table['median_abs_break_shift_mag'].median():.4f} mag"
    ),
    (
        "Median source p90 |break shift|     : "
        f"{summary_table['p90_abs_break_shift_mag'].median():.4f} mag"
    ),
    "",
    "BY CLASS:",
]

for cls in [
    "BLL",
    "FSRQ",
]:
    x = summary_table.loc[
        summary_table["blazar_class"].eq(cls)
    ]

    if len(x) == 0:
        continue

    lines += [
        (
            f"  {cls}: N={len(x)}, "
            f"median robust recovery="
            f"{x['robust_central_recovery_fraction'].median():.3f}, "
            f">=0.80="
            f"{int((x['robust_central_recovery_fraction']>=0.80).sum())}"
        )
    ]

text = "\n".join(
    lines
)

OUT_AUDIT.write_text(
    text,
    encoding="utf-8"
)

print()
print(text)
print()
print("=" * 78)
print("GLOBAL FILES SAVED")
print("=" * 78)
print(OUT_SUMMARY_TABLE)
print(OUT_GLOBAL_BOOT)
print(OUT_AUDIT)
print()
print("STAGE 06B3 COMPLETE")
