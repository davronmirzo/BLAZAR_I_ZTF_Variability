# ============================================================
# BLAZAR_I — STAGE 06C0
# DRW ROBUSTNESS INPUT / SCHEMA AUDIT — FIXED
#
# Fix:
#   Boolean columns are summarized as counts rather than passed
#   to numeric quantile calculations.
#
# Read-only audit. No upstream files are modified.
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
OUT = AUDIT_DIR / "stage06c0_drw_schema_audit.txt"

patterns = [
    "stage03d*.csv",
    "stage03d*.parquet",
    "stage04_population_master.csv",
]

files = []
for pat in patterns:
    files.extend(sorted(TABLE_DIR.glob(pat)))

# De-duplicate, preserve order.
seen = set()
uniq = []
for f in files:
    if f not in seen:
        uniq.append(f)
        seen.add(f)
files = uniq

if not files:
    raise FileNotFoundError(
        "No STAGE 03D / STAGE 04 table products found in outputs/tables."
    )

lines = []
lines.append("BLAZAR_I - STAGE 06C0 DRW SCHEMA AUDIT")
lines.append("=" * 78)

for path in files:
    lines.append("")
    lines.append(f"FILE: {path.name}")

    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
    elif path.suffix.lower() == ".parquet":
        df = pd.read_parquet(path)
    else:
        continue

    lines.append(f"  rows={len(df)} columns={len(df.columns)}")

    lines.append("  COLUMNS:")
    for c in df.columns:
        lines.append(f"    {c}    dtype={df[c].dtype}")

    keys = [
        "tau", "sigma", "cadence", "baseline", "bic", "lik",
        "success", "status", "bound", "rest", "redshift",
        "filter", "night", "n_", "nnight", "delta",
    ]

    cand = [
        c for c in df.columns
        if any(k in c.lower() for k in keys)
    ]

    lines.append("  CANDIDATE DRW COLUMNS:")

    for c in cand:
        s = df[c]

        lines.append(
            f"    {c}: nonnull={int(s.notna().sum())}, "
            f"unique={int(s.nunique(dropna=True))}"
        )

        # Boolean columns: counts only.
        if pd.api.types.is_bool_dtype(s.dtype):
            vc = s.value_counts(dropna=False).to_dict()
            lines.append(f"      boolean_counts={vc}")
            continue

        # Try numeric conversion.
        x = pd.to_numeric(
            s,
            errors="coerce"
        )

        # pd.to_numeric may preserve bool in unusual extension dtypes.
        if pd.api.types.is_bool_dtype(x.dtype):
            vc = x.value_counts(dropna=False).to_dict()
            lines.append(f"      boolean_counts={vc}")
            continue

        # Force floating dtype before quantiles to avoid bool arithmetic.
        x = x.astype(float)

        finite = np.isfinite(
            x.to_numpy(dtype=float)
        )

        nfinite = int(finite.sum())

        if nfinite > 0:
            xf = x.loc[finite]

            q = xf.quantile(
                [0.01, 0.05, 0.50, 0.95, 0.99]
            )

            lines.append(
                "      "
                + ", ".join(
                    [
                        f"finite={nfinite}",
                        f"p01={q.loc[0.01]:.6g}",
                        f"p05={q.loc[0.05]:.6g}",
                        f"p50={q.loc[0.50]:.6g}",
                        f"p95={q.loc[0.95]:.6g}",
                        f"p99={q.loc[0.99]:.6g}",
                    ]
                )
            )

    if "filter_name" in df.columns:
        lines.append(
            "  FILTER COUNTS: "
            + str(
                df["filter_name"]
                .value_counts(dropna=False)
                .to_dict()
            )
        )

    if "fit_status" in df.columns:
        lines.append(
            "  FIT STATUS COUNTS: "
            + str(
                df["fit_status"]
                .value_counts(dropna=False)
                .to_dict()
            )
        )

text = "\n".join(lines)

OUT.write_text(
    text,
    encoding="utf-8"
)

print(text)
print()
print("AUDIT SAVED:")
print(OUT)
print()
print("STAGE 06C0 COMPLETE")
