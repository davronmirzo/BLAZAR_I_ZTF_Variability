# ============================================================
# BLAZAR_I — STAGE 09C5
# INTEGRATED REVIEWER-FACING CALIBRATION LEDGER
#
# Purpose:
#   Integrate the four Stage09C calibration families into one compact,
#   auditable table for manuscript revision and reviewer response.
#
# Inputs:
#   stage09c1b_drw_scenario_summary_repaired.csv
#   stage09c2_colour_scenario_summary.csv
#   stage09c3_pdf_scenario_summary.csv
#   stage09c4_rmflux_scenario_summary.csv
#   stage09c0_template_coverage.csv
#
# Outputs:
#   outputs/tables/stage09c5_calibration_ledger.csv
#   outputs/tables/stage09c5_primary_calibration_table.csv
#   outputs/tables/stage09c5_reviewer_claims.csv
#   outputs/tables/stage09c5_q1_calibration_table.tex
#   outputs/audit/stage09c5_summary.txt
#
# No upstream file is modified.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

DRW_FILE = TABLE_DIR / "stage09c1b_drw_scenario_summary_repaired.csv"
COL_FILE = TABLE_DIR / "stage09c2_colour_scenario_summary.csv"
PDF_FILE = TABLE_DIR / "stage09c3_pdf_scenario_summary.csv"
RMF_FILE = TABLE_DIR / "stage09c4_rmflux_scenario_summary.csv"
COVER_FILE = TABLE_DIR / "stage09c0_template_coverage.csv"

OUT_LEDGER = TABLE_DIR / "stage09c5_calibration_ledger.csv"
OUT_PRIMARY = TABLE_DIR / "stage09c5_primary_calibration_table.csv"
OUT_CLAIMS = TABLE_DIR / "stage09c5_reviewer_claims.csv"
OUT_TEX = TABLE_DIR / "stage09c5_q1_calibration_table.tex"
OUT_SUMMARY = AUDIT_DIR / "stage09c5_summary.txt"

for p in [TABLE_DIR, AUDIT_DIR]:
    p.mkdir(parents=True, exist_ok=True)


def req(path):
    if not path.exists():
        raise FileNotFoundError(path)


for p in [DRW_FILE, COL_FILE, PDF_FILE, RMF_FILE, COVER_FILE]:
    req(p)


def getrow(df, col, value):
    hit = df.loc[df[col].astype(str).eq(str(value))]
    if len(hit) != 1:
        raise RuntimeError(
            f"Expected exactly one row where {col}={value}; got {len(hit)}"
        )
    return hit.iloc[0]


def fmt_ci(est, lo, hi, digits=3):
    if not (
        np.isfinite(est)
        and np.isfinite(lo)
        and np.isfinite(hi)
    ):
        return "NA"
    return f"{est:.{digits}f} [{lo:.{digits}f}, {hi:.{digits}f}]"


drw = pd.read_csv(DRW_FILE, low_memory=False)
col = pd.read_csv(COL_FILE, low_memory=False)
pdf = pd.read_csv(PDF_FILE, low_memory=False)
rmf = pd.read_csv(RMF_FILE, low_memory=False)
cover = pd.read_csv(COVER_FILE, low_memory=False)


# ============================================================
# LONG CALIBRATION LEDGER
# ============================================================

rows = []

def add(
    diagnostic,
    scenario,
    scenario_type,
    metric,
    estimate,
    ci_low=np.nan,
    ci_high=np.nan,
    support_metric=np.nan,
    support_metric_name="",
    reviewer_interpretation="",
    manuscript_role="",
):
    rows.append({
        "diagnostic": diagnostic,
        "scenario": scenario,
        "scenario_type": scenario_type,
        "metric": metric,
        "estimate": float(estimate) if pd.notna(estimate) else np.nan,
        "ci95_low": float(ci_low) if pd.notna(ci_low) else np.nan,
        "ci95_high": float(ci_high) if pd.notna(ci_high) else np.nan,
        "support_metric_name": support_metric_name,
        "support_metric": float(support_metric) if pd.notna(support_metric) else np.nan,
        "reviewer_interpretation": reviewer_interpretation,
        "manuscript_role": manuscript_role,
    })


# DRW
r = getrow(drw, "scenario", "WHITE_NULL")
add(
    "DRW",
    "WHITE_NULL",
    "NULL",
    "interpretable_gate_rate",
    r["gate_positive_fraction"],
    r["gate_positive_ci95_low"],
    r["gate_positive_ci95_high"],
    r["median_delta_bic"],
    "median_DeltaBIC",
    "Very low observation-conditioned false-positive rate for the frozen DRW gate.",
    "PRIMARY calibrated stochastic-timescale diagnostic",
)

for scen in ["OU_SHORT", "OU_MID", "OU_LONG"]:
    r = getrow(drw, "scenario", scen)
    add(
        "DRW",
        scen,
        "INJECTION",
        "gate_recovery",
        r["gate_positive_fraction"],
        r["gate_positive_ci95_low"],
        r["gate_positive_ci95_high"],
        r["tau_ratio_median"],
        "median_tau_hat_over_tau_true",
        "Recovery is high for short/mid timescales and lower near the long-timescale interpretability boundary.",
        "PRIMARY calibrated stochastic-timescale diagnostic",
    )
    add(
        "DRW",
        scen,
        "INJECTION",
        "within_factor2_recovery",
        r["within_factor2_fraction"],
        r["within_factor2_ci95_low"],
        r["within_factor2_ci95_high"],
        r["tau_ratio_median"],
        "median_tau_hat_over_tau_true",
        "Quantifies timescale-estimation accuracy conditional on the actual cadence/error patterns.",
        "PRIMARY calibrated stochastic-timescale diagnostic",
    )


# COLOUR
r = getrow(col, "scenario", "LINEAR_NULL")
add(
    "COLOUR",
    "LINEAR_NULL",
    "NULL",
    "robust_central_false_positive",
    r["robust_break_fraction"],
    r["robust_break_ci95_low"],
    r["robust_break_ci95_high"],
    r["median_delta_bic"],
    "median_DeltaBIC",
    "The robust-central break gate is highly specific under a linear colour-magnitude null.",
    "PRIMARY empirical curvature diagnostic; not a literal physical transition fraction",
)
add(
    "COLOUR",
    "LINEAR_NULL",
    "NULL",
    "strong_break_false_positive",
    r["strong_break_fraction"],
    r["strong_break_ci95_low"],
    r["strong_break_ci95_high"],
    r["median_delta_bic"],
    "median_DeltaBIC",
    "The weaker DeltaBIC>=10 gate is also conservative but less specific than the robust-central gate.",
    "SUPPORTING calibration",
)

for scen in ["BREAK_MODERATE", "BREAK_STRONG"]:
    r = getrow(col, "scenario", scen)
    add(
        "COLOUR",
        scen,
        "INJECTION",
        "robust_central_recovery",
        r["robust_break_fraction"],
        r["robust_break_ci95_low"],
        r["robust_break_ci95_high"],
        r["median_break_error_fraction"],
        "median_break_error_fraction_of_range",
        "The robust gate has non-negligible false negatives; observed incidence is therefore not the intrinsic break fraction.",
        "PRIMARY empirical curvature diagnostic",
    )
    add(
        "COLOUR",
        scen,
        "INJECTION",
        "robust_and_localized_recovery",
        r["robust_and_localized_fraction"],
        r["robust_and_localized_ci95_low"],
        r["robust_and_localized_ci95_high"],
        r["median_break_error_fraction"],
        "median_break_error_fraction_of_range",
        "When recovered, break location is usually well constrained, especially for stronger injected curvature.",
        "SUPPORTING localization calibration",
    )


# PDF
r = getrow(pdf, "scenario", "CORRELATED_LOGNORMAL_NULL")
add(
    "PDF",
    "CORRELATED_LOGNORMAL_NULL",
    "NULL",
    "robust_double_false_positive",
    r["robust_double_fraction"],
    r["robust_double_ci95_low"],
    r["robust_double_ci95_high"],
    r["median_fitted_D"],
    "median_fitted_Ashman_D",
    "Serial correlation alone can create substantial robust-double classifications; ordinary BIC is anti-conservative for this use.",
    "SECONDARY / supportive only",
)
add(
    "PDF",
    "CORRELATED_LOGNORMAL_NULL",
    "NULL",
    "double_preferred_false_positive",
    r["double_preferred_fraction"],
    r["double_preferred_ci95_low"],
    r["double_preferred_ci95_high"],
    r["median_delta_bic_second"],
    "median_DeltaBIC_second_best",
    "Uncorrected double-lognormal preference is strongly vulnerable to temporal dependence.",
    "CAUTIONARY",
)

for scen in ["MIXTURE_D2P5", "MIXTURE_D3P5"]:
    r = getrow(pdf, "scenario", scen)
    add(
        "PDF",
        scen,
        "INJECTION",
        "robust_double_recovery",
        r["robust_double_fraction"],
        r["robust_double_ci95_low"],
        r["robust_double_ci95_high"],
        r["median_fitted_D_over_true"],
        "median_fitted_D_over_true_D",
        "Recovery is incomplete even for separated mixtures, reinforcing that robust-double incidence is not a physical state fraction.",
        "SECONDARY / supportive only",
    )


# RMS-FLUX
r = getrow(rmf, "scenario", "ADDITIVE_OU_NULL")
add(
    "RMS_FLUX",
    "ADDITIVE_OU_NULL",
    "NULL",
    "frozen_global_false_positive",
    r["frozen_global_positive_fraction"],
    r["frozen_global_ci95_low"],
    r["frozen_global_ci95_high"],
    r["median_spearman_rho"],
    "median_Spearman_rho",
    "The frozen primary gate has a low false-positive rate under correlated additive variability.",
    "PRIMARY multiplicative-variability diagnostic",
)
add(
    "RMS_FLUX",
    "ADDITIVE_OU_NULL",
    "NULL",
    "bank_BH_false_positive",
    r["bank_bh_positive_fraction"],
    r["bank_bh_ci95_low"],
    r["bank_bh_ci95_high"],
    r["median_spearman_rho"],
    "median_Spearman_rho",
    "Template-bank BH is even more conservative; it is a sensitivity analysis rather than the original global FDR.",
    "SUPPORTING calibration",
)

for scen in ["MULTIPLICATIVE_FROZEN", "MULTIPLICATIVE_STRONG"]:
    r = getrow(rmf, "scenario", scen)
    add(
        "RMS_FLUX",
        scen,
        "INJECTION",
        "frozen_global_recovery",
        r["frozen_global_positive_fraction"],
        r["frozen_global_ci95_low"],
        r["frozen_global_ci95_high"],
        r["median_spearman_rho"],
        "median_Spearman_rho",
        "The gate is specific but has moderate power, so strict-positive incidence is a lower-sensitivity diagnostic rather than the intrinsic multiplicative fraction.",
        "PRIMARY multiplicative-variability diagnostic",
    )
    add(
        "RMS_FLUX",
        scen,
        "INJECTION",
        "bank_BH_recovery",
        r["bank_bh_positive_fraction"],
        r["bank_bh_ci95_low"],
        r["bank_bh_ci95_high"],
        r["median_spearman_rho"],
        "median_Spearman_rho",
        "Bank-level BH confirms the same qualitative power limitation.",
        "SUPPORTING calibration",
    )

ledger = pd.DataFrame(rows)
ledger.to_csv(OUT_LEDGER, index=False)


# ============================================================
# COMPACT PRIMARY CALIBRATION TABLE
# ============================================================

primary_rows = []

def add_primary(
    diagnostic,
    null_description,
    null_rate,
    null_lo,
    null_hi,
    injection_description,
    recovery_rate,
    recovery_lo,
    recovery_hi,
    interpretation,
):
    primary_rows.append({
        "diagnostic": diagnostic,
        "null_model": null_description,
        "null_false_positive_rate": null_rate,
        "null_ci95_low": null_lo,
        "null_ci95_high": null_hi,
        "representative_injection": injection_description,
        "representative_recovery_rate": recovery_rate,
        "recovery_ci95_low": recovery_lo,
        "recovery_ci95_high": recovery_hi,
        "interpretation": interpretation,
    })


# DRW: use OU_MID as representative injection.
n = getrow(drw, "scenario", "WHITE_NULL")
i = getrow(drw, "scenario", "OU_MID")
add_primary(
    "DRW interpretability",
    "uncorrelated intrinsic variability + actual errors",
    n["gate_positive_fraction"],
    n["gate_positive_ci95_low"],
    n["gate_positive_ci95_high"],
    "OU_MID",
    i["gate_positive_fraction"],
    i["gate_positive_ci95_low"],
    i["gate_positive_ci95_high"],
    "High specificity and high central-timescale recovery; long-timescale recovery is weaker and biased low.",
)

# Colour: use strong break as representative injection; also moderate is in long ledger.
n = getrow(col, "scenario", "LINEAR_NULL")
i = getrow(col, "scenario", "BREAK_STRONG")
add_primary(
    "Robust-central colour break",
    "single linear colour-magnitude relation",
    n["robust_break_fraction"],
    n["robust_break_ci95_low"],
    n["robust_break_ci95_high"],
    "BREAK_STRONG",
    i["robust_break_fraction"],
    i["robust_break_ci95_low"],
    i["robust_break_ci95_high"],
    "Very low false-positive rate but incomplete recovery; observed incidence is not an intrinsic transition fraction.",
)

# PDF: use D3.5 strong mixture.
n = getrow(pdf, "scenario", "CORRELATED_LOGNORMAL_NULL")
i = getrow(pdf, "scenario", "MIXTURE_D3P5")
add_primary(
    "Robust double-lognormal",
    "single correlated lognormal process",
    n["robust_double_fraction"],
    n["robust_double_ci95_low"],
    n["robust_double_ci95_high"],
    "MIXTURE_D3P5",
    i["robust_double_fraction"],
    i["robust_double_ci95_low"],
    i["robust_double_ci95_high"],
    "Temporal correlation substantially inflates the robust-double gate; PDF classification is secondary/supportive.",
)

# RMS: frozen global p threshold, strong injection.
n = getrow(rmf, "scenario", "ADDITIVE_OU_NULL")
i = getrow(rmf, "scenario", "MULTIPLICATIVE_STRONG")
add_primary(
    "Strict rms-flux",
    "additive OU + actual errors",
    n["frozen_global_positive_fraction"],
    n["frozen_global_ci95_low"],
    n["frozen_global_ci95_high"],
    "MULTIPLICATIVE_STRONG",
    i["frozen_global_positive_fraction"],
    i["frozen_global_ci95_low"],
    i["frozen_global_ci95_high"],
    "Low false-positive rate but moderate power; strict-positive incidence is a conservative empirical diagnostic.",
)

primary = pd.DataFrame(primary_rows)
primary.to_csv(OUT_PRIMARY, index=False)


# ============================================================
# REVIEWER-FACING CLAIM LOCKS
# ============================================================

claims = pd.DataFrame([
    {
        "claim_id": "CAL-DRW-01",
        "status": "SUPPORTED",
        "claim": (
            "The frozen DRW interpretability gate has a very low calibrated "
            "false-positive rate and high recovery for short-to-intermediate "
            "timescales under actual ZTF sampling/error patterns."
        ),
        "required_caveat": (
            "Recovery weakens and tau is biased low near the long-timescale "
            "interpretability boundary."
        ),
    },
    {
        "claim_id": "CAL-COL-01",
        "status": "SUPPORTED_WITH_CAUTION",
        "claim": (
            "The robust-central colour-curvature gate is highly specific under "
            "a linear null."
        ),
        "required_caveat": (
            "Moderate/strong injected breaks are not recovered with unit "
            "probability, so observed robust-break incidence is not an "
            "intrinsic physical transition fraction."
        ),
    },
    {
        "claim_id": "CAL-PDF-01",
        "status": "DOWNGRADE",
        "claim": (
            "Double-lognormal PDF labels provide an empirical description of "
            "flux-distribution shape."
        ),
        "required_caveat": (
            "A correlated single-lognormal null yields a substantial robust-"
            "double false-positive rate; no literal two-state interpretation "
            "or physical incidence fraction is supported."
        ),
    },
    {
        "claim_id": "CAL-RMF-01",
        "status": "SUPPORTED_WITH_CAUTION",
        "claim": (
            "The strict rms-flux gate is specific against correlated additive "
            "variability and therefore provides evidence for multiplicative-"
            "like variability structure when detected."
        ),
        "required_caveat": (
            "Recovery is only moderate for injected multiplicative processes, "
            "so non-detections do not imply absence of multiplicative variability."
        ),
    },
    {
        "claim_id": "CAL-XDIAG-01",
        "status": "PRIORITY",
        "claim": (
            "The rms-flux to colour-curvature association remains the most "
            "defensible cross-diagnostic headline because both component "
            "diagnostics have low calibrated null false-positive rates."
        ),
        "required_caveat": (
            "The association remains observational/associative, and conditioning "
            "on optical dynamic range attenuates its magnitude."
        ),
    },
])

claims.to_csv(OUT_CLAIMS, index=False)


# ============================================================
# LATEX TABLE
# ============================================================

def pct(x):
    return f"{100.0 * float(x):.1f}\\%"

tex_lines = [
    r"\begin{table*}",
    r"\centering",
    r"\caption{Observation-conditioned injection--recovery calibration of the four variability diagnostics. False-positive and recovery rates are evaluated using real ZTF sampling/error templates.}",
    r"\label{tab:diagnostic_calibration}",
    r"\begin{tabular}{lllll}",
    r"\hline",
    r"Diagnostic & Null false positive & Representative injection & Recovery & Interpretation \\",
    r"\hline",
]

for _, rr in primary.iterrows():
    null_txt = (
        f"{pct(rr['null_false_positive_rate'])} "
        f"({pct(rr['null_ci95_low'])}--{pct(rr['null_ci95_high'])})"
    )
    rec_txt = (
        f"{pct(rr['representative_recovery_rate'])} "
        f"({pct(rr['recovery_ci95_low'])}--{pct(rr['recovery_ci95_high'])})"
    )

    interp = str(rr["interpretation"]).replace("%", r"\%")
    diag = str(rr["diagnostic"]).replace("_", r"\_")
    inj = str(rr["representative_injection"]).replace("_", r"\_")

    tex_lines.append(
        f"{diag} & {null_txt} & {inj} & {rec_txt} & "
        + r"\parbox[t]{5.4cm}{"
        + interp
        + r"} \\"
    )

tex_lines += [
    r"\hline",
    r"\end{tabular}",
    r"\end{table*}",
]

OUT_TEX.write_text(
    "\n".join(tex_lines),
    encoding="utf-8",
)


# ============================================================
# COVERAGE SUMMARY
# ============================================================

def parse_bool_series(s):
    num = pd.to_numeric(
        s,
        errors="coerce",
    )

    out = pd.Series(
        False,
        index=s.index,
        dtype=bool,
    )

    num_good = num.notna()

    out.loc[num_good] = (
        num.loc[num_good]
        !=
        0
    )

    rem = ~num_good

    if rem.any():
        txt = (
            s.loc[rem]
            .astype(str)
            .str.strip()
            .str.lower()
        )

        out.loc[rem] = txt.isin(
            [
                "true",
                "t",
                "yes",
                "y",
            ]
        )

    return out


cover_bool = (
    parse_bool_series(
        cover["covers_population_p05"]
    )
    &
    parse_bool_series(
        cover["covers_population_p95"]
    )
)

coverage_pass = int(cover_bool.sum())
coverage_total = int(len(cover))


# ============================================================
# FINAL SUMMARY
# ============================================================

drw_null = getrow(drw, "scenario", "WHITE_NULL")
drw_mid = getrow(drw, "scenario", "OU_MID")
drw_long = getrow(drw, "scenario", "OU_LONG")

col_null = getrow(col, "scenario", "LINEAR_NULL")
col_mod = getrow(col, "scenario", "BREAK_MODERATE")
col_str = getrow(col, "scenario", "BREAK_STRONG")

pdf_null = getrow(pdf, "scenario", "CORRELATED_LOGNORMAL_NULL")
pdf_d25 = getrow(pdf, "scenario", "MIXTURE_D2P5")
pdf_d35 = getrow(pdf, "scenario", "MIXTURE_D3P5")

rmf_null = getrow(rmf, "scenario", "ADDITIVE_OU_NULL")
rmf_fr = getrow(rmf, "scenario", "MULTIPLICATIVE_FROZEN")
rmf_st = getrow(rmf, "scenario", "MULTIPLICATIVE_STRONG")

summary = f"""BLAZAR_I - STAGE 09C5 FINAL SUMMARY
================================================================================

INTEGRATED OBSERVATION-CONDITIONED CALIBRATION

Template coverage:
  population p05--p95 spanned on both ends : {coverage_pass}/{coverage_total} audited variables

1) DRW
  WHITE_NULL false-positive gate rate       : {fmt_ci(drw_null['gate_positive_fraction'], drw_null['gate_positive_ci95_low'], drw_null['gate_positive_ci95_high'])}
  OU_MID gate recovery                      : {fmt_ci(drw_mid['gate_positive_fraction'], drw_mid['gate_positive_ci95_low'], drw_mid['gate_positive_ci95_high'])}
  OU_MID factor-2 tau recovery              : {fmt_ci(drw_mid['within_factor2_fraction'], drw_mid['within_factor2_ci95_low'], drw_mid['within_factor2_ci95_high'])}
  OU_LONG gate recovery                     : {fmt_ci(drw_long['gate_positive_fraction'], drw_long['gate_positive_ci95_low'], drw_long['gate_positive_ci95_high'])}
  OU_LONG median tau_hat/tau_true           : {drw_long['tau_ratio_median']:.3f}
  verdict                                   : PRIMARY / well calibrated

2) COLOUR CURVATURE
  robust-central null false-positive rate   : {fmt_ci(col_null['robust_break_fraction'], col_null['robust_break_ci95_low'], col_null['robust_break_ci95_high'])}
  moderate-break robust recovery            : {fmt_ci(col_mod['robust_break_fraction'], col_mod['robust_break_ci95_low'], col_mod['robust_break_ci95_high'])}
  strong-break robust recovery              : {fmt_ci(col_str['robust_break_fraction'], col_str['robust_break_ci95_low'], col_str['robust_break_ci95_high'])}
  strong-break localization <=0.10 range    : {fmt_ci(col_str['localized_fraction'], col_str['localized_ci95_low'], col_str['localized_ci95_high'])}
  verdict                                   : PRIMARY empirical diagnostic; incidence != physical fraction

3) FLUX PDF
  correlated-lognormal robust-double FPR    : {fmt_ci(pdf_null['robust_double_fraction'], pdf_null['robust_double_ci95_low'], pdf_null['robust_double_ci95_high'])}
  D=2.5 robust-double recovery              : {fmt_ci(pdf_d25['robust_double_fraction'], pdf_d25['robust_double_ci95_low'], pdf_d25['robust_double_ci95_high'])}
  D=3.5 robust-double recovery              : {fmt_ci(pdf_d35['robust_double_fraction'], pdf_d35['robust_double_ci95_low'], pdf_d35['robust_double_ci95_high'])}
  verdict                                   : DOWNGRADE to secondary/supportive

4) RMS-FLUX
  additive-OU frozen-threshold FPR          : {fmt_ci(rmf_null['frozen_global_positive_fraction'], rmf_null['frozen_global_ci95_low'], rmf_null['frozen_global_ci95_high'])}
  multiplicative-frozen recovery            : {fmt_ci(rmf_fr['frozen_global_positive_fraction'], rmf_fr['frozen_global_ci95_low'], rmf_fr['frozen_global_ci95_high'])}
  multiplicative-strong recovery            : {fmt_ci(rmf_st['frozen_global_positive_fraction'], rmf_st['frozen_global_ci95_low'], rmf_st['frozen_global_ci95_high'])}
  verdict                                   : PRIMARY / specific but moderate sensitivity

Q1 CLAIM HIERARCHY AFTER CALIBRATION
  A. Flagship:
     rms-flux -> colour-curvature cross-diagnostic association.
  B. Strong supporting result:
     continuous DRW rest-frame timescale difference, with Stage09B
     source-clustered inference and Stage09C1 calibration.
  C. Secondary:
     class-specific endpoint incidence after Stage09A overlap/confounder audits.
  D. Downgraded / descriptive:
     robust-double-lognormal incidence and any literal two-state interpretation.

MANUSCRIPT LOCKS
  - Never call robust-double incidence a physical bimodal/two-state fraction.
  - Never convert robust colour-break incidence into an intrinsic transition fraction.
  - State that rms-flux strict positives are highly specific but incomplete detections.
  - State that long DRW timescales are recovered less efficiently and are biased low.
  - Preserve the Stage09A4 SED-overlap caveat for global FSRQ/BLL endpoint effects.
  - Preserve the Stage09B LSP-only attenuation caveat for the DRW class contrast.
  - Keep the rms-flux -> colour result associative rather than causal.

Files saved:
  {OUT_LEDGER}
  {OUT_PRIMARY}
  {OUT_CLAIMS}
  {OUT_TEX}

STAGE 09C5 COMPLETE
"""

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
