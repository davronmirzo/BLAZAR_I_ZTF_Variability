from pathlib import Path
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT=Path(__file__).resolve().parent/'figures'
OUT.mkdir(exist_ok=True)

plt.rcParams.update({
    'text.usetex': True,
    'text.latex.preamble': r'\usepackage{lmodern}\usepackage[T1]{fontenc}',
    'font.family': 'serif',
    'font.size': 11,
    'axes.labelsize': 11,
    'axes.titlesize': 11,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 9.5,
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

def save(fig,name):
    fig.savefig(OUT/name, bbox_inches='tight', pad_inches=0.04)
    plt.close(fig)

# Figure 1: analysis workflow. The caption carries the explanatory title;
# the graphic itself intentionally has no redundant top heading.
fig,ax=plt.subplots(figsize=(7.2,4.7), constrained_layout=True)
ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')

def box(x,y,w,h,text,fs=10.2):
    patch=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.018,rounding_size=0.018',
                        linewidth=1.0,facecolor='white',edgecolor='black')
    ax.add_patch(patch)
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,linespacing=1.18)
    return patch

def arrow(x1,y1,x2,y2):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',
                                 mutation_scale=12,linewidth=1.0,color='black',
                                 shrinkA=2,shrinkB=2))

# Main analysis chain
box(.04,.71,.24,.17,r'Fermi parent sample\\4LAC-DR3 + 4FGL-DR4')
box(.38,.71,.24,.17,r'ZTF DR24 cross-match\\cleaning + nightly binning')
box(.72,.71,.24,.17,r'Analysis sample\\GOLD + SILVER')
arrow(.28,.795,.38,.795); arrow(.62,.795,.72,.795)

# Diagnostics
box(.04,.37,.20,.18,r'Flux PDF\\shape')
box(.285,.37,.20,.18,r'rms--flux\\relation')
box(.53,.37,.20,.18,r'Colour--magnitude\\curvature')
box(.775,.37,.18,.18,r'DRW\\timescale')
for xc in [.14,.385,.63,.865]:
    arrow(.84,.71,xc,.555) if xc==.865 else None
# use one split node for clean geometry
ax.plot([.84,.84],[.71,.625],color='black',lw=1.0)
ax.plot([.14,.865],[.625,.625],color='black',lw=1.0)
for xc in [.14,.385,.63,.865]:
    arrow(xc,.625,xc,.555)

# Validation layer
box(.06,.08,.25,.17,r'Sampling + selection\\sensitivity')
box(.375,.08,.25,.17,r'Injection--recovery\\calibration')
box(.69,.08,.25,.17,r'Confounder + temporal\\validation')
# connectors from diagnostics to validation backbone
ax.plot([.14,.865],[.31,.31],color='black',lw=1.0)
for xc in [.14,.385,.63,.865]:
    arrow(xc,.37,xc,.31)
for xc in [.185,.50,.815]:
    arrow(xc,.31,xc,.25)

save(fig,'Figure01_workflow.pdf')

# Figure 2: sample selection
labels=['Clean Fermi parent','ZTF-matched','GOLD+SILVER sample']
counts=np.array([1901,1456,1061])
fig,ax=plt.subplots(figsize=(6.7,3.4), constrained_layout=True)
y=np.arange(3)
bars=ax.barh(y,counts)
ax.set_yticks(y,labels)
ax.invert_yaxis(); ax.set_xlabel('Number of sources')
ax.set_xlim(0,2050)
for yy,b,n in zip(y,bars,counts):
    ax.text(n+25,yy,f'{n}',va='center',ha='left')
save(fig,'Figure02_sample_selection.pdf')

# Figure 3: diagnostic incidence
classes=['BLL','FSRQ']
ns={'BLL':727,'FSRQ':334}
fracs={
    'BLL':[0.2834,0.3356,0.1100,0.7400],
    'FSRQ':[0.3473,0.4281,0.2425,0.7335],
}
labels=['Double-lognormal\n(both bands)','Strict rms--flux\n(both bands)','Robust colour\ncurvature','Interpretable DRW\n(both bands)']

def wilson(p,n,z=1.95996398454):
    den=1+z*z/n
    cen=(p+z*z/(2*n))/den
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return max(0,cen-half),min(1,cen+half)
fig,ax=plt.subplots(figsize=(7.2,3.9), constrained_layout=True)
x=np.arange(4); width=.34
for j,c in enumerate(classes):
    vals=np.array(fracs[c])
    cis=[wilson(v,ns[c]) for v in vals]
    errs=np.vstack([vals-np.array([a for a,b in cis]), np.array([b for a,b in cis])-vals])
    shift=(-width/2 if j==0 else width/2)
    ax.bar(x+shift,vals,width,label=c,yerr=errs,capsize=3)
ax.set_xticks(x,labels)
ax.set_ylabel('Observed source fraction')
ax.set_ylim(0,0.85)
ax.legend(frameon=False,ncol=2,loc='upper left')
save(fig,'Figure03_diagnostic_incidence.pdf')

# Figure 4: DRW temporal validation
rows=['Fully adjusted','Source geometric mean','$g$ only','$r$ only','LSP-only']
early=np.array([.540,.550,.568,.511,.671]); elo=np.array([.457,.460,.470,.422,.543]); ehi=np.array([.638,.659,.686,.618,.829])
late=np.array([.676,.728,.637,.736,.872]); llo=np.array([.572,.610,.528,.610,.713]); lhi=np.array([.798,.869,.768,.889,1.066])
y=np.arange(len(rows)); off=.12
fig,ax=plt.subplots(figsize=(7.0,4.0), constrained_layout=True)
ax.errorbar(early,y-off,xerr=np.vstack([early-elo,ehi-early]),fmt='o',capsize=3,label='Early interval')
ax.errorbar(late,y+off,xerr=np.vstack([late-llo,lhi-late]),fmt='s',capsize=3,label='Late interval')
ax.axvline(1,ls='--',lw=1)
ax.set_yticks(y,rows); ax.invert_yaxis(); ax.set_xlim(.35,1.12)
ax.set_xlabel('FSRQ/BLL factor in rest-frame DRW timescale')
ax.legend(frameon=False,loc='upper right')
save(fig,'Figure04_drw_temporal_validation.pdf')

# Figure 5: cross-diagnostic temporal models
rows=['Unadjusted','+ optical class','+ magnitude range']
e=np.array([2.972,2.241,.869]); elo=np.array([1.569,1.147,.347]); ehi=np.array([5.533,4.375,2.176])
l=np.array([3.169,1.942,.609]); llo=np.array([1.526,.885,.233]); lhi=np.array([6.670,4.261,1.594])
y=np.arange(3); off=.11
fig,ax=plt.subplots(figsize=(7.0,3.4), constrained_layout=True)
ax.errorbar(e,y-off,xerr=np.vstack([e-elo,ehi-e]),fmt='o',capsize=3,label='Early interval')
ax.errorbar(l,y+off,xerr=np.vstack([l-llo,lhi-l]),fmt='s',capsize=3,label='Late interval')
ax.axvline(1,ls='--',lw=1)
ax.set_xscale('log'); ax.set_xlim(.18,8.0)
ax.set_yticks(y,rows); ax.invert_yaxis()
ax.set_xlabel('Odds ratio: strict rms--flux vs. robust colour curvature')
ax.legend(frameon=False,loc='lower right')
save(fig,'Figure05_rmflux_colour_temporal.pdf')

# Figure 6: diagnostic calibration
rows=['DRW','Colour curvature','rms--flux','Double-lognormal PDF']
null=np.array([0.0,.0022,.0144,.1146]); nlo=np.array([0.0,.0009,.0089,.0991]); nhi=np.array([.0066,.0057,.0233,.1321])
rec=np.array([.9740,.6222,.5243,.6146]); rlo=np.array([.9575,.5996,.4949,.5892]); rhi=np.array([.9842,.6443,.5536,.6394])
y=np.arange(4); off=.10
fig,ax=plt.subplots(figsize=(7.0,3.9), constrained_layout=True)
ax.errorbar(null,y-off,xerr=np.vstack([null-nlo,nhi-null]),fmt='o',capsize=3,label='Null false-positive rate')
ax.errorbar(rec,y+off,xerr=np.vstack([rec-rlo,rhi-rec]),fmt='s',capsize=3,label='Representative recovery')
ax.set_yticks(y,rows); ax.invert_yaxis(); ax.set_xlim(-.02,1.02)
ax.set_xlabel('Fraction of simulations')
ax.legend(frameon=False,loc='lower right')
save(fig,'Figure06_diagnostic_calibration.pdf')

# Figure 7: PDF sampling sensitivity
labels=['Full light curve','Half-thinned','Minimum separation 7 d','Equal $N=50$','Repeated equal $N=50$']
counts=np.array([322,198,152,45,41.5])
y=np.arange(5)
fig,ax=plt.subplots(figsize=(7.0,4.0), constrained_layout=True)
bars=ax.barh(y[:4],counts[:4])
ax.errorbar([counts[4]],[y[4]],xerr=np.array([[counts[4]-31],[53-counts[4]]]),fmt='o',capsize=3)
ax.set_yticks(y,labels); ax.invert_yaxis(); ax.set_xlim(0,350)
ax.set_xlabel('Sources classified robust double-lognormal in both bands')
for yy,b,n in zip(y[:4],bars,counts[:4]):
    ax.text(n+6,yy,f'{int(n)}',va='center',ha='left')
ax.text(58,y[4],r'median 41.5; range 31--53',va='center',ha='left')
save(fig,'Figure07_pdf_sampling_sensitivity.pdf')

print('generated', len(list(OUT.glob('Figure*.pdf'))), 'figures in', OUT)
