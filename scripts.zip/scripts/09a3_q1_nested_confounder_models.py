# ============================================================
# BLAZAR_I — STAGE 09A3
# Q1 NESTED CONFOUNDER MODELS + HOST SENSITIVITY
#
# Purpose:
#   Quantify how the principal population effects change after adding
#   increasingly strong Q1-reviewer confounder controls:
#
#     M0  coverage
#     M1  M0 + redshift + SED + gamma-ray covariates
#     M2  M1 + optical brightness
#     M3  M2 + PS1 continuous host/extension proxy
#
#   Crucially, M0--M3 are also fit on the SAME endpoint-specific M3
#   complete-case sample, so coefficient movement cannot be confused
#   with changing sample composition.
#
# Additional reviewer-critical tests:
#   - near-full-sample NO-Z host-adjusted model
#   - colour M4 = M3 + optical dynamic range sensitivity
#   - rms-flux -> colour nested confounder/host models
#   - g/r Fvar nested class models
#   - BLL redshift-missingness audit
#
# Scientific locks:
#   - primary frozen Stage05C models are not overwritten
#   - PS1 proxy is a sensitivity covariate, not host decomposition
#   - dynamic range is a sensitivity covariate, not part of the main
#     confounder sequence
#   - no DRW continuous-tau source/filter model is fit here; that is
#     reserved for Stage 09B with source-clustered inference
#
# Outputs:
#   outputs/tables/stage09a3_nested_binary_class_models.csv
#   outputs/tables/stage09a3_class_effect_trajectory.csv
#   outputs/tables/stage09a3_rmflux_colour_nested_models.csv
#   outputs/tables/stage09a3_fvar_nested_models.csv
#   outputs/tables/stage09a3_bll_redshift_missingness_models.csv
#   outputs/tables/stage09a3_bll_redshift_known_rates.csv
#   outputs/audit/stage09a3_summary.txt
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings(
    "ignore",
    category=RuntimeWarning,
)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

MASTER_FILE = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"
STAGE04_FILE = TABLE_DIR / "stage04_population_master.csv"
FROZEN05C_FILE = TABLE_DIR / "stage05c_clean_class_models.csv"

OUT_BINARY = TABLE_DIR / "stage09a3_nested_binary_class_models.csv"
OUT_TRAJ = TABLE_DIR / "stage09a3_class_effect_trajectory.csv"
OUT_XDIAG = TABLE_DIR / "stage09a3_rmflux_colour_nested_models.csv"
OUT_FVAR = TABLE_DIR / "stage09a3_fvar_nested_models.csv"
OUT_ZMISS = TABLE_DIR / "stage09a3_bll_redshift_missingness_models.csv"
OUT_ZRATES = TABLE_DIR / "stage09a3_bll_redshift_known_rates.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09a3_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce",
    )


def zscore_columns(
    w,
    columns,
):
    for c in columns:
        x = numeric(
            w[c]
        )

        mu = x.mean()
        sd = x.std(
            ddof=1
        )

        if (
            np.isfinite(sd)
            and
            sd > 0
        ):
            w[c] = (
                x - mu
            ) / sd
        else:
            w[c] = np.nan


def bh_qvalues(pvalues):
    p = np.asarray(
        pvalues,
        dtype=float,
    )

    out = np.full(
        len(p),
        np.nan,
        dtype=float,
    )

    good = np.isfinite(
        p
    )

    if good.sum() == 0:
        return out

    pv = p[good]
    order = np.argsort(
        pv
    )
    ranked = pv[
        order
    ]

    m = len(ranked)

    raw = (
        ranked
        *
        m
        /
        np.arange(
            1,
            m + 1,
        )
    )

    adj = np.minimum.accumulate(
        raw[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0,
    )

    qv = np.empty(
        m,
        dtype=float,
    )
    qv[order] = adj

    out[good] = qv

    return out


def complete_mask(
    df,
    columns,
):
    mask = pd.Series(
        True,
        index=df.index,
    )

    for c in columns:
        if c not in df.columns:
            raise RuntimeError(
                f"Required column missing: {c}"
            )

        mask &= (
            numeric(df[c])
            .replace(
                [np.inf, -np.inf],
                np.nan,
            )
            .notna()
        )

    return mask


def fit_logistic(
    df,
    outcome,
    predictors,
    key_predictor,
    model_name,
    sample_name,
    subset_mask=None,
    standardize=None,
):
    if standardize is None:
        standardize = []

    if subset_mask is None:
        subset_mask = pd.Series(
            True,
            index=df.index,
        )

    cols = [
        outcome,
        *predictors,
    ]

    w = df.loc[
        subset_mask,
        cols,
    ].copy()

    w[outcome] = (
        as_bool(
            w[outcome]
        )
        .astype(int)
    )

    for c in predictors:
        w[c] = numeric(
            w[c]
        )

    w = (
        w.replace(
            [np.inf, -np.inf],
            np.nan,
        )
        .dropna()
    )

    zscore_columns(
        w,
        standardize,
    )

    w = w.dropna()

    if len(w) < 50:
        return {
            "model_name": model_name,
            "sample_name": sample_name,
            "outcome": outcome,
            "key_predictor": key_predictor,
            "N": len(w),
            "N_BLL": np.nan,
            "N_FSRQ": np.nan,
            "N_event": np.nan,
            "event_fraction": np.nan,
            "coef_log_odds": np.nan,
            "odds_ratio": np.nan,
            "or_ci95_low": np.nan,
            "or_ci95_high": np.nan,
            "p_value": np.nan,
            "aic": np.nan,
            "status": "TOO_FEW_ROWS",
        }

    y = w[
        outcome
    ].astype(float)

    if y.nunique() < 2:
        return {
            "model_name": model_name,
            "sample_name": sample_name,
            "outcome": outcome,
            "key_predictor": key_predictor,
            "N": len(w),
            "N_BLL": np.nan,
            "N_FSRQ": np.nan,
            "N_event": int(
                y.sum()
            ),
            "event_fraction": float(
                y.mean()
            ),
            "coef_log_odds": np.nan,
            "odds_ratio": np.nan,
            "or_ci95_low": np.nan,
            "or_ci95_high": np.nan,
            "p_value": np.nan,
            "aic": np.nan,
            "status": "DEGENERATE_OUTCOME",
        }

    X = sm.add_constant(
        w[
            predictors
        ].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.GLM(
            y,
            X,
            family=sm.families.Binomial(),
        ).fit(
            cov_type="HC3",
            maxiter=500,
        )

        ci = fit.conf_int()

        beta = float(
            fit.params[
                key_predictor
            ]
        )

        lo = float(
            ci.loc[
                key_predictor,
                0,
            ]
        )

        hi = float(
            ci.loc[
                key_predictor,
                1,
            ]
        )

        result = {
            "model_name": model_name,
            "sample_name": sample_name,
            "outcome": outcome,
            "key_predictor": key_predictor,
            "N": int(
                len(w)
            ),
            "N_BLL": (
                int(
                    (
                        w["FSRQ"]
                        ==
                        0
                    ).sum()
                )
                if "FSRQ" in w.columns
                else np.nan
            ),
            "N_FSRQ": (
                int(
                    (
                        w["FSRQ"]
                        ==
                        1
                    ).sum()
                )
                if "FSRQ" in w.columns
                else np.nan
            ),
            "N_event": int(
                y.sum()
            ),
            "event_fraction": float(
                y.mean()
            ),
            "coef_log_odds": beta,
            "odds_ratio": math.exp(
                beta
            ),
            "or_ci95_low": math.exp(
                lo
            ),
            "or_ci95_high": math.exp(
                hi
            ),
            "p_value": float(
                fit.pvalues[
                    key_predictor
                ]
            ),
            "aic": float(
                fit.aic
            ),
            "status": "OK",
        }

        return result

    except Exception as exc:
        return {
            "model_name": model_name,
            "sample_name": sample_name,
            "outcome": outcome,
            "key_predictor": key_predictor,
            "N": int(
                len(w)
            ),
            "N_BLL": np.nan,
            "N_FSRQ": np.nan,
            "N_event": int(
                y.sum()
            ),
            "event_fraction": float(
                y.mean()
            ),
            "coef_log_odds": np.nan,
            "odds_ratio": np.nan,
            "or_ci95_low": np.nan,
            "or_ci95_high": np.nan,
            "p_value": np.nan,
            "aic": np.nan,
            "status": (
                f"FIT_FAILED:{type(exc).__name__}"
            ),
        }


def fit_logcontinuous(
    df,
    outcome,
    predictors,
    key_predictor,
    model_name,
    sample_name,
    subset_mask=None,
    standardize=None,
):
    if standardize is None:
        standardize = []

    if subset_mask is None:
        subset_mask = pd.Series(
            True,
            index=df.index,
        )

    cols = [
        outcome,
        *predictors,
    ]

    w = df.loc[
        subset_mask,
        cols,
    ].copy()

    for c in cols:
        w[c] = numeric(
            w[c]
        )

    w = (
        w.replace(
            [np.inf, -np.inf],
            np.nan,
        )
        .dropna()
    )

    w = w.loc[
        w[outcome] > 0
    ].copy()

    zscore_columns(
        w,
        standardize,
    )

    w = w.dropna()

    if len(w) < 50:
        return {
            "model_name": model_name,
            "sample_name": sample_name,
            "outcome": outcome,
            "key_predictor": key_predictor,
            "N": len(w),
            "N_BLL": np.nan,
            "N_FSRQ": np.nan,
            "beta_ln": np.nan,
            "factor": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": "TOO_FEW_ROWS",
        }

    w["ln_outcome"] = np.log(
        w[outcome]
    )

    y = w[
        "ln_outcome"
    ].astype(float)

    X = sm.add_constant(
        w[
            predictors
        ].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            y,
            X,
        ).fit(
            cov_type="HC3"
        )

        ci = fit.conf_int()

        beta = float(
            fit.params[
                key_predictor
            ]
        )

        lo = float(
            ci.loc[
                key_predictor,
                0,
            ]
        )

        hi = float(
            ci.loc[
                key_predictor,
                1,
            ]
        )

        return {
            "model_name": model_name,
            "sample_name": sample_name,
            "outcome": outcome,
            "key_predictor": key_predictor,
            "N": int(
                len(w)
            ),
            "N_BLL": (
                int(
                    (
                        w["FSRQ"]
                        ==
                        0
                    ).sum()
                )
                if "FSRQ" in w.columns
                else np.nan
            ),
            "N_FSRQ": (
                int(
                    (
                        w["FSRQ"]
                        ==
                        1
                    ).sum()
                )
                if "FSRQ" in w.columns
                else np.nan
            ),
            "beta_ln": beta,
            "factor": math.exp(
                beta
            ),
            "factor_ci95_low": math.exp(
                lo
            ),
            "factor_ci95_high": math.exp(
                hi
            ),
            "p_value": float(
                fit.pvalues[
                    key_predictor
                ]
            ),
            "r2": float(
                fit.rsquared
            ),
            "status": "OK",
        }

    except Exception as exc:
        return {
            "model_name": model_name,
            "sample_name": sample_name,
            "outcome": outcome,
            "key_predictor": key_predictor,
            "N": int(
                len(w)
            ),
            "N_BLL": np.nan,
            "N_FSRQ": np.nan,
            "beta_ln": np.nan,
            "factor": np.nan,
            "factor_ci95_low": np.nan,
            "factor_ci95_high": np.nan,
            "p_value": np.nan,
            "r2": np.nan,
            "status": (
                f"FIT_FAILED:{type(exc).__name__}"
            ),
        }


# ============================================================
# LOAD / VALIDATE
# ============================================================

for p in [
    MASTER_FILE,
    STAGE04_FILE,
]:
    if not p.exists():
        raise FileNotFoundError(
            p
        )

d = pd.read_csv(
    MASTER_FILE,
    low_memory=False,
)

s04 = pd.read_csv(
    STAGE04_FILE,
    low_memory=False,
)

if len(d) != 1061:
    raise RuntimeError(
        f"Expected 1061 Stage09A2 rows, got {len(d)}"
    )

if d[
    "blazar_id"
].astype(str).duplicated().any():
    raise RuntimeError(
        "Duplicate blazar_id in Stage09A2 master."
    )

d["blazar_id"] = (
    d["blazar_id"]
    .astype(str)
)

s04["blazar_id"] = (
    s04["blazar_id"]
    .astype(str)
)

# Bring exact colour detectability N from Stage04 for the flagship
# rms-flux -> colour models.
if (
    "col_N_colour_pairs"
    not in s04.columns
):
    raise RuntimeError(
        "stage04 master lacks col_N_colour_pairs."
    )

extra = s04[
    [
        "blazar_id",
        "col_N_colour_pairs",
    ]
].drop_duplicates(
    "blazar_id"
)

d = d.merge(
    extra,
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

d[
    "colour_logN"
] = np.log1p(
    numeric(
        d[
            "col_N_colour_pairs"
        ]
    )
)

# Core booleans.
for c in [
    "endpoint_pdf_robust_double_both",
    "endpoint_rmflux_strict_both",
    "endpoint_rmflux_eligible_both",
    "endpoint_colour_robust_central",
    "endpoint_drw_interpretable_both",
    "ps1_host_proxy_hq_available",
]:
    if c not in d.columns:
        raise RuntimeError(
            f"Missing required column: {c}"
        )

    d[c] = as_bool(
        d[c]
    )

# Numeric variables.
numeric_cols = [
    "FSRQ",
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
    "redshift",
    "SED_ISP",
    "SED_HSP",
    "SED_UNKNOWN",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
    "colour_r_mag_range",
    "colour_pair_dt_hours_median",
    "colour_logN",
    "fvar_g",
    "fvar_r",
]

for c in numeric_cols:
    if c not in d.columns:
        raise RuntimeError(
            f"Missing required numeric column: {c}"
        )

    d[c] = numeric(
        d[c]
    )


# ============================================================
# MODEL DEFINITIONS
# ============================================================

M0 = [
    "FSRQ",
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
]

M1 = [
    *M0,
    "redshift",
    "SED_ISP",
    "SED_HSP",
    "SED_UNKNOWN",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
]

M2 = [
    *M1,
    "median_mag_g",
    "median_mag_r",
]

M3 = [
    *M2,
    "ps1_host_proxy_ri",
]

# Full/near-full host-adjusted model without redshift so that missing BLL
# redshifts do not force sample restriction.
M3_NO_Z = [
    "FSRQ",
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
    "SED_ISP",
    "SED_HSP",
    "SED_UNKNOWN",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
]

continuous_controls = [
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
    "redshift",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
]

continuous_controls_noz = [
    c
    for c in continuous_controls
    if c != "redshift"
]

endpoint_map = {
    "PDF": "endpoint_pdf_robust_double_both",
    "RMF": "endpoint_rmflux_strict_both",
    "COLOUR": "endpoint_colour_robust_central",
    "DRW_GATE": "endpoint_drw_interpretable_both",
}


# ============================================================
# BINARY CLASS EFFECTS
# ============================================================

binary_rows = []

for short, outcome in endpoint_map.items():

    base_subset = pd.Series(
        True,
        index=d.index,
    )

    if short == "RMF":
        base_subset &= d[
            "endpoint_rmflux_eligible_both"
        ]

    # Full-sample M0 context.
    binary_rows.append(
        fit_logistic(
            d,
            outcome=outcome,
            predictors=M0,
            key_predictor="FSRQ",
            model_name=f"{short}_FULL_M0",
            sample_name="full_endpoint_eligible",
            subset_mask=base_subset,
            standardize=[
                c
                for c in M0
                if c != "FSRQ"
            ],
        )
    )

    # Near-full host-adjusted model excluding redshift.
    host_noz_subset = (
        base_subset
        &
        d[
            "ps1_host_proxy_hq_available"
        ]
    )

    binary_rows.append(
        fit_logistic(
            d,
            outcome=outcome,
            predictors=M3_NO_Z,
            key_predictor="FSRQ",
            model_name=f"{short}_HOST_NO_Z",
            sample_name="hq_host_near_full_without_redshift",
            subset_mask=host_noz_subset,
            standardize=continuous_controls_noz,
        )
    )

    # Common exact sample for M0--M3 trajectory.
    required_m3 = [
        c
        for c in M3
        if c != "FSRQ"
    ]

    common = (
        base_subset
        &
        d[
            "ps1_host_proxy_hq_available"
        ]
        &
        complete_mask(
            d,
            required_m3,
        )
    )

    for tag, predictors in [
        ("CC_M0", M0),
        ("CC_M1", M1),
        ("CC_M2", M2),
        ("CC_M3", M3),
    ]:
        binary_rows.append(
            fit_logistic(
                d,
                outcome=outcome,
                predictors=predictors,
                key_predictor="FSRQ",
                model_name=f"{short}_{tag}",
                sample_name="same_m3_complete_case",
                subset_mask=common,
                standardize=[
                    c
                    for c in predictors
                    if (
                        c
                        not in {
                            "FSRQ",
                            "SED_ISP",
                            "SED_HSP",
                            "SED_UNKNOWN",
                        }
                    )
                ],
            )
        )

    # Colour-specific dynamic-range sensitivity after all confounders.
    if short == "COLOUR":
        predictors = [
            *M3,
            "colour_r_mag_range",
        ]

        binary_rows.append(
            fit_logistic(
                d,
                outcome=outcome,
                predictors=predictors,
                key_predictor="FSRQ",
                model_name="COLOUR_CC_M4_HOST_PLUS_RANGE",
                sample_name="same_m3_complete_case",
                subset_mask=common,
                standardize=[
                    c
                    for c in predictors
                    if (
                        c
                        not in {
                            "FSRQ",
                            "SED_ISP",
                            "SED_HSP",
                            "SED_UNKNOWN",
                        }
                    )
                ],
            )
        )

binary = pd.DataFrame(
    binary_rows
)

binary[
    "q_BH_all_class_effects"
] = bh_qvalues(
    binary[
        "p_value"
    ].to_numpy(
        dtype=float
    )
)

# BH within the same model-depth family across endpoints.
binary["model_family"] = (
    binary["model_name"]
    .str.replace(
        r"^(PDF|RMF|COLOUR|DRW_GATE)_",
        "",
        regex=True,
    )
)

binary[
    "q_BH_within_model_family"
] = np.nan

for fam in binary[
    "model_family"
].dropna().unique():
    mask = binary[
        "model_family"
    ].eq(
        fam
    )

    binary.loc[
        mask,
        "q_BH_within_model_family"
    ] = bh_qvalues(
        binary.loc[
            mask,
            "p_value",
        ].to_numpy(
            dtype=float
        )
    )

binary.to_csv(
    OUT_BINARY,
    index=False,
)


# ============================================================
# CLASS-EFFECT TRAJECTORY TABLE
# ============================================================

traj_rows = []

for short in endpoint_map:
    for suffix in [
        "FULL_M0",
        "HOST_NO_Z",
        "CC_M0",
        "CC_M1",
        "CC_M2",
        "CC_M3",
    ]:
        name = (
            f"{short}_{suffix}"
        )

        hit = binary.loc[
            binary[
                "model_name"
            ]
            .eq(name)
        ]

        if len(hit) != 1:
            continue

        r = hit.iloc[0]

        traj_rows.append({
            "diagnostic": short,
            "model_stage": suffix,
            "N": r["N"],
            "N_BLL": r["N_BLL"],
            "N_FSRQ": r["N_FSRQ"],
            "odds_ratio": r["odds_ratio"],
            "or_ci95_low": r["or_ci95_low"],
            "or_ci95_high": r["or_ci95_high"],
            "p_value": r["p_value"],
            "q_BH_within_model_family": r[
                "q_BH_within_model_family"
            ],
            "status": r["status"],
        })

traj = pd.DataFrame(
    traj_rows
)

# Optional frozen Stage05C reference rows.
if FROZEN05C_FILE.exists():
    frozen = pd.read_csv(
        FROZEN05C_FILE
    )

    frozen_map = {
        "PDF": "PDF_CLASS_PRE_DIAGNOSTIC_CONTROLS",
        "RMF": "RMFLUX_CLASS_ELIGIBLE_PRE_DIAGNOSTIC_CONTROLS",
        "COLOUR": "COLOUR_CLASS_MINIMAL_DETECTABILITY_CONTROLS",
        "DRW_GATE": "DRW_CLASS_PRE_DIAGNOSTIC_CONTROLS",
    }

    extra_rows = []

    for short, model_name in frozen_map.items():
        hit = frozen.loc[
            frozen[
                "model_name"
            ]
            .astype(str)
            .eq(
                model_name
            )
        ]

        if len(hit) != 1:
            continue

        r = hit.iloc[0]

        extra_rows.append({
            "diagnostic": short,
            "model_stage": "FROZEN_STAGE05C_PRIMARY",
            "N": r.get(
                "N",
                np.nan,
            ),
            "N_BLL": np.nan,
            "N_FSRQ": np.nan,
            "odds_ratio": r.get(
                "odds_ratio",
                np.nan,
            ),
            "or_ci95_low": r.get(
                "or_ci95_low",
                np.nan,
            ),
            "or_ci95_high": r.get(
                "or_ci95_high",
                np.nan,
            ),
            "p_value": r.get(
                "p_value",
                np.nan,
            ),
            "q_BH_within_model_family": r.get(
                "q_BH_all_models",
                np.nan,
            ),
            "status": "REFERENCE_ONLY",
        })

    if extra_rows:
        traj = pd.concat(
            [
                pd.DataFrame(
                    extra_rows
                ),
                traj,
            ],
            ignore_index=True,
        )

traj.to_csv(
    OUT_TRAJ,
    index=False,
)


# ============================================================
# FLAGSHIP RMS-FLUX -> COLOUR ASSOCIATION
# ============================================================

# Use exact colour detectability controls from the primary Stage05C logic,
# then add the Q1 confounders. Keep FSRQ in every model.
X0 = [
    "endpoint_rmflux_strict_both",
    "FSRQ",
    "colour_logN",
    "colour_pair_dt_hours_median",
]

X1 = [
    *X0,
    "redshift",
    "SED_ISP",
    "SED_HSP",
    "SED_UNKNOWN",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
]

X2 = [
    *X1,
    "median_mag_g",
    "median_mag_r",
]

X3 = [
    *X2,
    "ps1_host_proxy_ri",
]

X4 = [
    *X3,
    "colour_r_mag_range",
]

x_base = d[
    "endpoint_rmflux_eligible_both"
]

x_common = (
    x_base
    &
    d[
        "ps1_host_proxy_hq_available"
    ]
    &
    complete_mask(
        d,
        [
            c
            for c in X4
            if c
            not in {
                "endpoint_rmflux_strict_both",
                "FSRQ",
                "SED_ISP",
                "SED_HSP",
                "SED_UNKNOWN",
            }
        ],
    )
)

x_rows = []

for tag, predictors in [
    ("X0_DETECTABILITY", X0),
    ("X1_Z_SED_GAMMA", X1),
    ("X2_PLUS_BRIGHTNESS", X2),
    ("X3_PLUS_HOST", X3),
    ("X4_PLUS_DYNAMIC_RANGE", X4),
]:
    x_rows.append(
        fit_logistic(
            d,
            outcome="endpoint_colour_robust_central",
            predictors=predictors,
            key_predictor="endpoint_rmflux_strict_both",
            model_name=tag,
            sample_name="same_x4_complete_case",
            subset_mask=x_common,
            standardize=[
                c
                for c in predictors
                if (
                    c
                    not in {
                        "endpoint_rmflux_strict_both",
                        "FSRQ",
                        "SED_ISP",
                        "SED_HSP",
                        "SED_UNKNOWN",
                    }
                )
            ],
        )
    )

xdiag = pd.DataFrame(
    x_rows
)

xdiag[
    "q_BH_nested_models"
] = bh_qvalues(
    xdiag[
        "p_value"
    ].to_numpy(
        dtype=float
    )
)

xdiag.to_csv(
    OUT_XDIAG,
    index=False,
)


# ============================================================
# FVAR CONTINUOUS CLASS EFFECTS
# ============================================================

fvar_rows = []

for band in [
    "g",
    "r",
]:
    outcome = (
        f"fvar_{band}"
    )

    # Common M3 complete-case sample for clean trajectory.
    common = (
        d[
            "ps1_host_proxy_hq_available"
        ]
        &
        complete_mask(
            d,
            [
                outcome,
                *[
                    c
                    for c in M3
                    if c != "FSRQ"
                ],
            ],
        )
    )

    for tag, predictors in [
        ("CC_M0", M0),
        ("CC_M1", M1),
        ("CC_M2", M2),
        ("CC_M3", M3),
    ]:
        fvar_rows.append(
            fit_logcontinuous(
                d,
                outcome=outcome,
                predictors=predictors,
                key_predictor="FSRQ",
                model_name=(
                    f"FVAR_{band.upper()}_{tag}"
                ),
                sample_name="same_m3_complete_case",
                subset_mask=common,
                standardize=[
                    c
                    for c in predictors
                    if (
                        c
                        not in {
                            "FSRQ",
                            "SED_ISP",
                            "SED_HSP",
                            "SED_UNKNOWN",
                        }
                    )
                ],
            )
        )

fvar = pd.DataFrame(
    fvar_rows
)

fvar[
    "q_BH_all_models"
] = bh_qvalues(
    fvar[
        "p_value"
    ].to_numpy(
        dtype=float
    )
)

fvar.to_csv(
    OUT_FVAR,
    index=False,
)


# ============================================================
# BLL REDSHIFT-MISSINGNESS AUDIT
# ============================================================

bll = d.loc[
    d[
        "blazar_class"
    ]
    .astype(str)
    .eq("BLL")
].copy()

bll[
    "redshift_known_int"
] = (
    bll[
        "redshift"
    ]
    .notna()
    .astype(int)
)

zrate_rows = []

for short, outcome in endpoint_map.items():
    for known in [
        0,
        1,
    ]:
        w = bll.loc[
            bll[
                "redshift_known_int"
            ]
            .eq(
                known
            )
        ]

        if short == "RMF":
            w = w.loc[
                w[
                    "endpoint_rmflux_eligible_both"
                ]
            ]

        y = as_bool(
            w[outcome]
        )

        zrate_rows.append({
            "diagnostic": short,
            "redshift_known": known,
            "N": len(w),
            "N_event": int(
                y.sum()
            ),
            "event_fraction": (
                float(
                    y.mean()
                )
                if len(w)
                else np.nan
            ),
        })

zrates = pd.DataFrame(
    zrate_rows
)

zrates.to_csv(
    OUT_ZRATES,
    index=False,
)

# Does redshift-known status predict each endpoint among BLLs after
# observed non-redshift covariates? This is an audit of complete-case risk.
ZMISS_PRED = [
    "redshift_known_int",
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
    "SED_ISP",
    "SED_HSP",
    "SED_UNKNOWN",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
    "median_mag_g",
    "median_mag_r",
    "ps1_host_proxy_ri",
]

zmiss_rows = []

for short, outcome in endpoint_map.items():
    subset = (
        bll[
            "ps1_host_proxy_hq_available"
        ]
    )

    if short == "RMF":
        subset &= bll[
            "endpoint_rmflux_eligible_both"
        ]

    zmiss_rows.append(
        fit_logistic(
            bll,
            outcome=outcome,
            predictors=ZMISS_PRED,
            key_predictor="redshift_known_int",
            model_name=(
                f"BLL_ZKNOWN_TO_{short}"
            ),
            sample_name="BLL_hq_host_observed_covariates",
            subset_mask=subset,
            standardize=[
                "log1p_N_nightly_mean_gr",
                "log10_baseline_mean_gr",
                "log10_cadence_mean_gr",
                "median_magerr_mean_gr",
                "log10_gamma_energy_flux",
                "log1p_gamma_variability_index",
                "median_mag_g",
                "median_mag_r",
                "ps1_host_proxy_ri",
            ],
        )
    )

zmiss = pd.DataFrame(
    zmiss_rows
)

zmiss[
    "q_BH_endpoints"
] = bh_qvalues(
    zmiss[
        "p_value"
    ].to_numpy(
        dtype=float
    )
)

zmiss.to_csv(
    OUT_ZMISS,
    index=False,
)


# ============================================================
# SUMMARY
# ============================================================

def get_model(
    frame,
    name,
):
    hit = frame.loc[
        frame[
            "model_name"
        ]
        .eq(name)
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


def fmt_or(r):
    if r is None:
        return "NA"

    if (
        r["status"] != "OK"
        or
        not np.isfinite(
            r["odds_ratio"]
        )
    ):
        return (
            f"{r['status']}"
        )

    return (
        f"OR={r['odds_ratio']:.3f} "
        f"[{r['or_ci95_low']:.3f},"
        f"{r['or_ci95_high']:.3f}], "
        f"p={r['p_value']:.3g}, "
        f"N={int(r['N'])}"
    )


def fmt_factor(r):
    if r is None:
        return "NA"

    if (
        r["status"] != "OK"
        or
        not np.isfinite(
            r["factor"]
        )
    ):
        return (
            f"{r['status']}"
        )

    return (
        f"factor={r['factor']:.3f} "
        f"[{r['factor_ci95_low']:.3f},"
        f"{r['factor_ci95_high']:.3f}], "
        f"p={r['p_value']:.3g}, "
        f"N={int(r['N'])}"
    )


lines = [
    "BLAZAR_I - STAGE 09A3 FINAL SUMMARY",
    "=" * 80,
    "",
    "Q1 nested confounder / host-sensitivity models",
    "",
    "Binary FSRQ/BLL class effects:",
]

for short in [
    "PDF",
    "RMF",
    "COLOUR",
    "DRW_GATE",
]:
    lines += [
        f"  {short}:",
        "    full M0        : "
        + fmt_or(
            get_model(
                binary,
                f"{short}_FULL_M0",
            )
        ),
        "    host no-z      : "
        + fmt_or(
            get_model(
                binary,
                f"{short}_HOST_NO_Z",
            )
        ),
        "    common CC M0   : "
        + fmt_or(
            get_model(
                binary,
                f"{short}_CC_M0",
            )
        ),
        "    common CC M1   : "
        + fmt_or(
            get_model(
                binary,
                f"{short}_CC_M1",
            )
        ),
        "    common CC M2   : "
        + fmt_or(
            get_model(
                binary,
                f"{short}_CC_M2",
            )
        ),
        "    common CC M3   : "
        + fmt_or(
            get_model(
                binary,
                f"{short}_CC_M3",
            )
        ),
    ]

colour_m4 = get_model(
    binary,
    "COLOUR_CC_M4_HOST_PLUS_RANGE",
)

lines += [
    "",
    "Colour host + dynamic-range sensitivity:",
    "  "
    + fmt_or(
        colour_m4
    ),
    "",
    "Flagship rms-flux -> colour association:",
]

for name in [
    "X0_DETECTABILITY",
    "X1_Z_SED_GAMMA",
    "X2_PLUS_BRIGHTNESS",
    "X3_PLUS_HOST",
    "X4_PLUS_DYNAMIC_RANGE",
]:
    lines.append(
        f"  {name:24s}: "
        +
        fmt_or(
            get_model(
                xdiag,
                name,
            )
        )
    )

lines += [
    "",
    "Fvar FSRQ/BLL multiplicative factors on common M3 samples:",
]

for band in [
    "G",
    "R",
]:
    for tag in [
        "CC_M0",
        "CC_M1",
        "CC_M2",
        "CC_M3",
    ]:
        name = (
            f"FVAR_{band}_{tag}"
        )

        lines.append(
            f"  {name:18s}: "
            +
            fmt_factor(
                get_model(
                    fvar,
                    name,
                )
            )
        )

lines += [
    "",
    "BLL redshift-missingness audit:",
]

for short in [
    "PDF",
    "RMF",
    "COLOUR",
    "DRW_GATE",
]:
    name = (
        f"BLL_ZKNOWN_TO_{short}"
    )

    lines.append(
        f"  {short:10s}: "
        +
        fmt_or(
            get_model(
                zmiss,
                name,
            )
        )
    )

lines += [
    "",
    "Interpretation locks:",
    "  - M0--M3 common-case trajectories use the SAME endpoint-specific sample.",
    "  - M3 host proxy is a sensitivity adjustment, not a host decomposition.",
    "  - HOST_NO_Z preserves near-full coverage and tests whether redshift",
    "    complete-case restriction is driving the class contrast.",
    "  - colour M4 additionally conditions on dynamic range as a separate",
    "    detectability/mediation sensitivity.",
    "  - continuous DRW tau is NOT analysed here; Stage 09B will use",
    "    blazar-clustered inference to remove source/filter pseudo-replication.",
    "",
    "Files saved:",
    f"  {OUT_BINARY}",
    f"  {OUT_TRAJ}",
    f"  {OUT_XDIAG}",
    f"  {OUT_FVAR}",
    f"  {OUT_ZMISS}",
    f"  {OUT_ZRATES}",
    "",
    "Next:",
    "  STAGE 09B — source-clustered / mixed-effects DRW rest-frame timescale",
    "  rebuild, using the same Q1 confounder set and all sampling perturbations.",
    "",
    "STAGE 09A3 COMPLETE",
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(
    summary
)
