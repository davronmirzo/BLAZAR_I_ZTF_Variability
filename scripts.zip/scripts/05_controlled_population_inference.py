# ============================================================
# BLAZAR_I — STAGE 05
# CONTROLLED POPULATION INFERENCE
#
# Input:
#   outputs/tables/stage04_population_master.csv
#
# Goals:
#   1) Test class associations after diagnostic-specific
#      detectability/sampling controls.
#   2) Test the key rms–flux <-> robust colour-break association
#      after class + sampling controls.
#   3) Screen selected Fermi/SED predictors one at a time on top of
#      each controlled base model.
#   4) Compare continuous Fvar and rest-frame DRW tau between
#      classes with basic observation-quality controls.
#
# IMPORTANT:
#   * Continuous predictors are standardized within each fitted model.
#   * Reported ORs for continuous predictors are therefore per 1 SD.
#   * FSRQ is binary (FSRQ=1, BLL=0) and is NOT standardized.
#   * rms–flux controlled models are restricted to sources eligible
#     in BOTH g and r bands, so "False" does not mix non-detections
#     with cadence ineligibility.
#   * Fermi predictor screens add ONE predictor at a time to reduce
#     collinearity and preserve interpretability.
#   * redshift_clean is used for redshift; the raw fermi_Redshift
#     column is not substituted for missing clean values.
#   * This stage is associative, not causal.
#
# Outputs:
#   outputs/tables/stage05_controlled_primary_models.csv
#   outputs/tables/stage05_rmflux_colour_model.csv
#   outputs/tables/stage05_fermi_predictor_screen.csv
#   outputs/tables/stage05_sed_class_models.csv
#   outputs/tables/stage05_continuous_class_models.csv
#   outputs/tables/stage05_predictor_audit.csv
#   outputs/audit/stage05_summary.txt
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

MASTER_FILE = (
    ROOT / "outputs" / "tables"
    / "stage04_population_master.csv"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_PRIMARY = TABLE_DIR / "stage05_controlled_primary_models.csv"
OUT_RMSCOLOR = TABLE_DIR / "stage05_rmflux_colour_model.csv"
OUT_FERMI = TABLE_DIR / "stage05_fermi_predictor_screen.csv"
OUT_SED = TABLE_DIR / "stage05_sed_class_models.csv"
OUT_CONT = TABLE_DIR / "stage05_continuous_class_models.csv"
OUT_AUDIT = TABLE_DIR / "stage05_predictor_audit.csv"
OUT_SUMMARY = AUDIT_DIR / "stage05_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def require_columns(df, cols, label):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise RuntimeError(
            f"{label}: missing columns: " + ", ".join(missing)
        )

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    x = (
        s.astype(str)
        .str.strip()
        .str.lower()
    )

    return x.isin(["true", "1", "yes", "y"])

def numeric(s):
    return pd.to_numeric(s, errors="coerce")

def zscore_series(s):
    s = numeric(s)

    mean = s.mean()
    std = s.std(ddof=1)

    if (
        not np.isfinite(mean)
        or not np.isfinite(std)
        or std <= 0
    ):
        return pd.Series(
            np.nan,
            index=s.index,
            dtype=float,
        )

    return (s - mean) / std

def safe_log1p(s):
    x = numeric(s)
    out = pd.Series(np.nan, index=x.index, dtype=float)

    good = np.isfinite(x) & (x >= 0)

    out.loc[good] = np.log1p(x.loc[good])

    return out

def safe_log10_positive(s):
    x = numeric(s)
    out = pd.Series(np.nan, index=x.index, dtype=float)

    good = np.isfinite(x) & (x > 0)

    out.loc[good] = np.log10(x.loc[good])

    return out

def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)

    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw = ranked * m / np.arange(1, m + 1)

    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    qv = np.empty(m, dtype=float)
    qv[order] = adj

    q[valid] = qv

    return q


# ============================================================
# MODEL FITTERS
# ============================================================

def fit_logistic(
    data,
    outcome,
    predictors,
    model_name,
    standardize_predictors=None,
    subset=None,
):
    """
    Fit GLM Binomial with HC3 covariance.
    Returns one coefficient-table row per predictor.
    """
    if standardize_predictors is None:
        standardize_predictors = []

    cols = [outcome] + predictors

    work = data.loc[
        subset if subset is not None else data.index == data.index,
        cols,
    ].copy()

    work[outcome] = as_bool(work[outcome]).astype(int)

    # Numeric normalization.
    for p in predictors:
        if p == "FSRQ":
            work[p] = numeric(work[p])
        else:
            work[p] = numeric(work[p])

    work = work.replace([np.inf, -np.inf], np.nan).dropna()

    n = len(work)
    n_event = int(work[outcome].sum())
    n_nonevent = n - n_event

    if n < 30:
        return pd.DataFrame([{
            "model_name": model_name,
            "outcome": outcome,
            "predictor": "__MODEL__",
            "N": n,
            "N_event": n_event,
            "N_nonevent": n_nonevent,
            "status": "TOO_FEW_ROWS",
        }])

    if n_event == 0 or n_nonevent == 0:
        return pd.DataFrame([{
            "model_name": model_name,
            "outcome": outcome,
            "predictor": "__MODEL__",
            "N": n,
            "N_event": n_event,
            "N_nonevent": n_nonevent,
            "status": "DEGENERATE_OUTCOME",
        }])

    # Standardize only selected continuous predictors.
    for p in standardize_predictors:
        if p in work.columns:
            z = zscore_series(work[p])

            if z.notna().sum() != len(work):
                return pd.DataFrame([{
                    "model_name": model_name,
                    "outcome": outcome,
                    "predictor": p,
                    "N": n,
                    "N_event": n_event,
                    "N_nonevent": n_nonevent,
                    "status": "STANDARDIZATION_FAILED",
                }])

            work[p] = z

    # Remove zero-variance predictors.
    keep_predictors = []

    for p in predictors:
        vals = work[p]

        if vals.nunique(dropna=True) > 1:
            keep_predictors.append(p)

    if len(keep_predictors) == 0:
        return pd.DataFrame([{
            "model_name": model_name,
            "outcome": outcome,
            "predictor": "__MODEL__",
            "N": n,
            "N_event": n_event,
            "N_nonevent": n_nonevent,
            "status": "NO_VARIABLE_PREDICTORS",
        }])

    X = sm.add_constant(
        work[keep_predictors].astype(float),
        has_constant="add",
    )

    y = work[outcome].astype(float)

    try:
        fit = sm.GLM(
            y,
            X,
            family=sm.families.Binomial(),
        ).fit(
            cov_type="HC3",
            maxiter=300,
        )

        ci = fit.conf_int()

        rows = []

        for p in keep_predictors:
            beta = float(fit.params[p])
            se = float(fit.bse[p])
            pval = float(fit.pvalues[p])
            lo = float(ci.loc[p, 0])
            hi = float(ci.loc[p, 1])

            rows.append({
                "model_name": model_name,
                "outcome": outcome,
                "predictor": p,
                "N": n,
                "N_event": n_event,
                "N_nonevent": n_nonevent,
                "coef_log_odds": beta,
                "robust_se": se,
                "odds_ratio": math.exp(beta),
                "or_ci95_low": math.exp(lo),
                "or_ci95_high": math.exp(hi),
                "p_value": pval,
                "aic": float(fit.aic),
                "deviance": float(fit.deviance),
                "standardized": bool(
                    p in standardize_predictors
                ),
                "status": "OK",
            })

        return pd.DataFrame(rows)

    except Exception as exc:
        return pd.DataFrame([{
            "model_name": model_name,
            "outcome": outcome,
            "predictor": "__MODEL__",
            "N": n,
            "N_event": n_event,
            "N_nonevent": n_nonevent,
            "status": f"FIT_FAILED:{type(exc).__name__}",
        }])


def fit_ols(
    data,
    outcome,
    predictors,
    model_name,
    standardize_predictors=None,
    subset=None,
    transform_outcome=None,
):
    """
    HC3 OLS for continuous outcomes.
    """
    if standardize_predictors is None:
        standardize_predictors = []

    cols = [outcome] + predictors

    work = data.loc[
        subset if subset is not None else data.index == data.index,
        cols,
    ].copy()

    work[outcome] = numeric(work[outcome])

    for p in predictors:
        work[p] = numeric(work[p])

    if transform_outcome == "log10_positive":
        work[outcome] = safe_log10_positive(work[outcome])

    work = work.replace([np.inf, -np.inf], np.nan).dropna()

    n = len(work)

    if n < 30:
        return pd.DataFrame([{
            "model_name": model_name,
            "outcome": outcome,
            "predictor": "__MODEL__",
            "N": n,
            "status": "TOO_FEW_ROWS",
        }])

    for p in standardize_predictors:
        if p in work.columns:
            work[p] = zscore_series(work[p])

    keep_predictors = [
        p
        for p in predictors
        if work[p].nunique(dropna=True) > 1
    ]

    X = sm.add_constant(
        work[keep_predictors].astype(float),
        has_constant="add",
    )

    y = work[outcome].astype(float)

    try:
        fit = sm.OLS(
            y,
            X,
        ).fit(
            cov_type="HC3"
        )

        ci = fit.conf_int()

        rows = []

        for p in keep_predictors:
            beta = float(fit.params[p])
            se = float(fit.bse[p])
            pval = float(fit.pvalues[p])
            lo = float(ci.loc[p, 0])
            hi = float(ci.loc[p, 1])

            rows.append({
                "model_name": model_name,
                "outcome": outcome,
                "predictor": p,
                "N": n,
                "coef": beta,
                "robust_se": se,
                "ci95_low": lo,
                "ci95_high": hi,
                "p_value": pval,
                "r_squared": float(fit.rsquared),
                "standardized": bool(
                    p in standardize_predictors
                ),
                "outcome_transform": transform_outcome or "none",
                "status": "OK",
            })

        return pd.DataFrame(rows)

    except Exception as exc:
        return pd.DataFrame([{
            "model_name": model_name,
            "outcome": outcome,
            "predictor": "__MODEL__",
            "N": n,
            "status": f"FIT_FAILED:{type(exc).__name__}",
        }])


# ============================================================
# LOAD MASTER
# ============================================================

if not MASTER_FILE.exists():
    raise FileNotFoundError(MASTER_FILE)

d = pd.read_csv(MASTER_FILE)

if len(d) != 1061:
    raise RuntimeError(
        f"Expected 1061 rows, got {len(d)}"
    )

require_columns(
    d,
    [
        "blazar_id",
        "blazar_class",
        "pdf_robust_double_both",
        "rmflux_strict_both",
        "colour_robust_central_break",
        "drw_interpretable_both",
        "rmf_rmflux_eligible_g",
        "rmf_rmflux_eligible_r",
        "N_nights_g",
        "N_nights_r",
        "baseline_g_yr",
        "baseline_r_yr",
        "rmf_N_segments_g",
        "rmf_N_segments_r",
        "rmf_noise_dominated_fraction_g",
        "rmf_noise_dominated_fraction_r",
        "rmf_segment_span_days_median_g",
        "rmf_segment_span_days_median_r",
        "col_N_colour_pairs",
        "col_r_mag_range",
        "col_pair_dt_hours_median",
        "drw_N_nightly_g",
        "drw_N_nightly_r",
        "drw_baseline_days_g",
        "drw_baseline_days_r",
        "drw_median_cadence_days_g",
        "drw_median_cadence_days_r",
    ],
    "STAGE 05 master",
)

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

# Stable booleans.
for c in [
    "pdf_robust_double_both",
    "rmflux_strict_both",
    "colour_robust_central_break",
    "drw_interpretable_both",
    "rmf_rmflux_eligible_g",
    "rmf_rmflux_eligible_r",
]:
    d[c] = as_bool(d[c])

d["rmflux_eligible_both"] = (
    d["rmf_rmflux_eligible_g"]
    &
    d["rmf_rmflux_eligible_r"]
)


# ============================================================
# DERIVED CONTROL VARIABLES
# ============================================================

# Stage 02B3 general observation counts.
d["ctrl_logNnight_g"] = safe_log1p(d["N_nights_g"])
d["ctrl_logNnight_r"] = safe_log1p(d["N_nights_r"])

# rms–flux detectability.
d["ctrl_logNseg_g"] = safe_log1p(d["rmf_N_segments_g"])
d["ctrl_logNseg_r"] = safe_log1p(d["rmf_N_segments_r"])

# Colour detectability.
d["ctrl_logNcolour"] = safe_log1p(d["col_N_colour_pairs"])

# DRW detectability.
d["ctrl_drw_logN_g"] = safe_log1p(d["drw_N_nightly_g"])
d["ctrl_drw_logN_r"] = safe_log1p(d["drw_N_nightly_r"])


# ============================================================
# PRIMARY CONTROLLED MODELS
# ============================================================

primary_frames = []

# 1) Robust double-lognormal BOTH.
pred_pdf = [
    "FSRQ",
    "ctrl_logNnight_g",
    "ctrl_logNnight_r",
    "baseline_g_yr",
    "baseline_r_yr",
]

std_pdf = [
    p for p in pred_pdf
    if p != "FSRQ"
]

primary_frames.append(
    fit_logistic(
        d,
        outcome="pdf_robust_double_both",
        predictors=pred_pdf,
        model_name="PDF_ROBUST_DOUBLE_BOTH_CONTROLLED",
        standardize_predictors=std_pdf,
    )
)

# 2) Strict rms–flux BOTH, restricted to both-band eligible sources.
pred_rmf = [
    "FSRQ",
    "ctrl_logNseg_g",
    "ctrl_logNseg_r",
    "rmf_noise_dominated_fraction_g",
    "rmf_noise_dominated_fraction_r",
    "rmf_segment_span_days_median_g",
    "rmf_segment_span_days_median_r",
]

std_rmf = [
    p for p in pred_rmf
    if p != "FSRQ"
]

primary_frames.append(
    fit_logistic(
        d,
        outcome="rmflux_strict_both",
        predictors=pred_rmf,
        model_name="RMFLUX_STRICT_BOTH_ELIGIBLE_CONTROLLED",
        standardize_predictors=std_rmf,
        subset=d["rmflux_eligible_both"],
    )
)

# 3) Robust central colour break.
pred_col = [
    "FSRQ",
    "ctrl_logNcolour",
    "col_r_mag_range",
    "col_pair_dt_hours_median",
]

std_col = [
    p for p in pred_col
    if p != "FSRQ"
]

primary_frames.append(
    fit_logistic(
        d,
        outcome="colour_robust_central_break",
        predictors=pred_col,
        model_name="COLOUR_ROBUST_CENTRAL_BREAK_CONTROLLED",
        standardize_predictors=std_col,
    )
)

# 4) DRW interpretable BOTH.
pred_drw = [
    "FSRQ",
    "ctrl_drw_logN_g",
    "ctrl_drw_logN_r",
    "drw_baseline_days_g",
    "drw_baseline_days_r",
    "drw_median_cadence_days_g",
    "drw_median_cadence_days_r",
]

std_drw = [
    p for p in pred_drw
    if p != "FSRQ"
]

primary_frames.append(
    fit_logistic(
        d,
        outcome="drw_interpretable_both",
        predictors=pred_drw,
        model_name="DRW_INTERPRETABLE_BOTH_CONTROLLED",
        standardize_predictors=std_drw,
    )
)

primary = pd.concat(
    primary_frames,
    ignore_index=True
)

if "p_value" in primary.columns:
    primary["p_q_bh_all_primary_coefficients"] = bh_qvalues(
        primary["p_value"].to_numpy(dtype=float)
    )

primary.to_csv(
    OUT_PRIMARY,
    index=False
)


# ============================================================
# FOCUSED RMS–FLUX -> COLOUR BREAK MODEL
# ============================================================

pred_rmcolor = [
    "rmflux_strict_both",
    "FSRQ",
    "ctrl_logNcolour",
    "col_r_mag_range",
    "col_pair_dt_hours_median",
    "ctrl_logNseg_g",
    "ctrl_logNseg_r",
    "rmf_noise_dominated_fraction_g",
    "rmf_noise_dominated_fraction_r",
]

std_rmcolor = [
    p for p in pred_rmcolor
    if p not in [
        "rmflux_strict_both",
        "FSRQ",
    ]
]

rmcolor = fit_logistic(
    d,
    outcome="colour_robust_central_break",
    predictors=pred_rmcolor,
    model_name="COLOUR_BREAK_GIVEN_RMFLUX_BOTH_ELIGIBLE",
    standardize_predictors=std_rmcolor,
    subset=d["rmflux_eligible_both"],
)

rmcolor.to_csv(
    OUT_RMSCOLOR,
    index=False
)


# ============================================================
# FERMI / SED PREDICTOR SCREEN
#
# One predictor at a time, on top of each controlled base model.
# ============================================================

# Build transformed Fermi predictors only if source columns exist.
fermi_specs = []

if "redshift_clean" in d.columns:
    d["fermi_screen_redshift"] = numeric(d["redshift_clean"])
    fermi_specs.append(
        ("redshift_clean", "fermi_screen_redshift")
    )

if "fermi_nu_syn_clean" in d.columns:
    # Do NOT assume whether the stored value is log10(Hz) or Hz.
    # Use the catalog value as supplied and standardize it.
    # Restrict to rows with a defined SED class so unknown/placeholder
    # synchrotron-peak values do not enter the model.
    d["fermi_screen_nu_syn"] = numeric(d["fermi_nu_syn_clean"])

    if "SED_class_clean" in d.columns:
        sed_defined = d["SED_class_clean"].notna()
        d.loc[~sed_defined, "fermi_screen_nu_syn"] = np.nan

    fermi_specs.append(
        ("nu_syn_clean_catalog_value", "fermi_screen_nu_syn")
    )

if "fermi_Variability_Index_DR4" in d.columns:
    d["fermi_screen_log1p_varindex_dr4"] = safe_log1p(
        d["fermi_Variability_Index_DR4"]
    )
    fermi_specs.append(
        (
            "log1p_Variability_Index_DR4",
            "fermi_screen_log1p_varindex_dr4",
        )
    )

if "fermi_Frac_Variability_DR4" in d.columns:
    d["fermi_screen_fracvar_dr4"] = numeric(
        d["fermi_Frac_Variability_DR4"]
    )
    fermi_specs.append(
        (
            "Frac_Variability_DR4",
            "fermi_screen_fracvar_dr4",
        )
    )

if "fermi_Energy_Flux100_DR4" in d.columns:
    d["fermi_screen_log_energyflux_dr4"] = safe_log10_positive(
        d["fermi_Energy_Flux100_DR4"]
    )
    fermi_specs.append(
        (
            "log10_Energy_Flux100_DR4",
            "fermi_screen_log_energyflux_dr4",
        )
    )

if "fermi_PL_Index_DR4" in d.columns:
    d["fermi_screen_plindex_dr4"] = numeric(
        d["fermi_PL_Index_DR4"]
    )
    fermi_specs.append(
        (
            "PL_Index_DR4",
            "fermi_screen_plindex_dr4",
        )
    )

if "fermi_Signif_Avg_DR4" in d.columns:
    d["fermi_screen_log1p_signif_dr4"] = safe_log1p(
        d["fermi_Signif_Avg_DR4"]
    )
    fermi_specs.append(
        (
            "log1p_Signif_Avg_DR4",
            "fermi_screen_log1p_signif_dr4",
        )
    )


base_models = [
    {
        "outcome": "pdf_robust_double_both",
        "base_predictors": pred_pdf,
        "base_std": std_pdf,
        "subset": None,
        "label": "PDF",
    },
    {
        "outcome": "rmflux_strict_both",
        "base_predictors": pred_rmf,
        "base_std": std_rmf,
        "subset": d["rmflux_eligible_both"],
        "label": "RMS",
    },
    {
        "outcome": "colour_robust_central_break",
        "base_predictors": pred_col,
        "base_std": std_col,
        "subset": None,
        "label": "COLOUR",
    },
    {
        "outcome": "drw_interpretable_both",
        "base_predictors": pred_drw,
        "base_std": std_drw,
        "subset": None,
        "label": "DRW",
    },
]

screen_rows = []

for spec_label, spec_col in fermi_specs:
    for bm in base_models:
        predictors = bm["base_predictors"] + [spec_col]
        stds = bm["base_std"] + [spec_col]

        fit_table = fit_logistic(
            d,
            outcome=bm["outcome"],
            predictors=predictors,
            model_name=f"{bm['label']}_PLUS_{spec_label}",
            standardize_predictors=stds,
            subset=bm["subset"],
        )

        target = fit_table.loc[
            fit_table["predictor"].eq(spec_col)
        ].copy()

        if len(target) == 1:
            rr = target.iloc[0].to_dict()

            rr["screen_predictor_label"] = spec_label
            rr["screen_predictor_column"] = spec_col
            rr["diagnostic_family"] = bm["label"]

            screen_rows.append(rr)
        else:
            screen_rows.append({
                "model_name": f"{bm['label']}_PLUS_{spec_label}",
                "outcome": bm["outcome"],
                "predictor": spec_col,
                "screen_predictor_label": spec_label,
                "screen_predictor_column": spec_col,
                "diagnostic_family": bm["label"],
                "status": "TARGET_COEFFICIENT_NOT_RETURNED",
            })

fermi_screen = pd.DataFrame(
    screen_rows
)

if len(fermi_screen) > 0 and "p_value" in fermi_screen.columns:
    fermi_screen["p_q_bh_global_screen"] = bh_qvalues(
        fermi_screen["p_value"].to_numpy(dtype=float)
    )

    # Also FDR within each diagnostic family.
    fermi_screen["p_q_bh_within_diagnostic"] = np.nan

    for fam, idx in fermi_screen.groupby(
        "diagnostic_family"
    ).groups.items():
        idx = list(idx)

        fermi_screen.loc[
            idx,
            "p_q_bh_within_diagnostic"
        ] = bh_qvalues(
            fermi_screen.loc[
                idx,
                "p_value"
            ].to_numpy(dtype=float)
        )

fermi_screen.to_csv(
    OUT_FERMI,
    index=False
)


# ============================================================
# CATEGORICAL SED-CLASS MODELS
#
# LSP is the reference category. Models are fit only where
# SED_class_clean is defined.
# ============================================================

sed_frames = []

if "SED_class_clean" in d.columns:

    sed = (
        d["SED_class_clean"]
        .astype(str)
        .str.strip()
        .str.upper()
    )

    sed_valid = (
        d["SED_class_clean"].notna()
        &
        sed.isin(["LSP", "ISP", "HSP"])
    )

    d["SED_ISP"] = (sed == "ISP").astype(int)
    d["SED_HSP"] = (sed == "HSP").astype(int)

    for bm in base_models:

        base_subset = (
            bm["subset"]
            if bm["subset"] is not None
            else pd.Series(True, index=d.index)
        )

        subset = (
            pd.Series(base_subset, index=d.index).astype(bool)
            &
            sed_valid
        )

        predictors = (
            bm["base_predictors"]
            +
            ["SED_ISP", "SED_HSP"]
        )

        stds = list(
            bm["base_std"]
        )

        tab = fit_logistic(
            d,
            outcome=bm["outcome"],
            predictors=predictors,
            model_name=f"{bm['label']}_PLUS_SED_CLASS",
            standardize_predictors=stds,
            subset=subset,
        )

        target = tab.loc[
            tab["predictor"].isin(
                ["SED_ISP", "SED_HSP"]
            )
        ].copy()

        if len(target) > 0:
            target["diagnostic_family"] = bm["label"]
            target["reference_SED_class"] = "LSP"
            sed_frames.append(target)

if sed_frames:
    sed_models = pd.concat(
        sed_frames,
        ignore_index=True
    )

    sed_models["p_q_bh_global_sed"] = bh_qvalues(
        sed_models["p_value"].to_numpy(dtype=float)
    )

    sed_models["p_q_bh_within_diagnostic"] = np.nan

    for fam, idx in sed_models.groupby(
        "diagnostic_family"
    ).groups.items():
        idx = list(idx)

        sed_models.loc[
            idx,
            "p_q_bh_within_diagnostic"
        ] = bh_qvalues(
            sed_models.loc[
                idx,
                "p_value"
            ].to_numpy(dtype=float)
        )
else:
    sed_models = pd.DataFrame()

sed_models.to_csv(
    OUT_SED,
    index=False
)


# ============================================================
# CONTINUOUS CLASS MODELS
# ============================================================

continuous_frames = []

# Fvar by band.
for filt in ["g", "r"]:
    outcome = f"pdf_Fvar_{filt}"

    if outcome in d.columns:
        predictors = [
            "FSRQ",
            f"ctrl_logNnight_{filt}",
            f"baseline_{filt}_yr",
        ]

        continuous_frames.append(
            fit_ols(
                d,
                outcome=outcome,
                predictors=predictors,
                model_name=f"FVAR_{filt}_CLASS_CONTROLLED",
                standardize_predictors=[
                    f"ctrl_logNnight_{filt}",
                    f"baseline_{filt}_yr",
                ],
                transform_outcome="log10_positive",
            )
        )

# Rest-frame tau by band: interpretable tau + known clean redshift only.
for filt in ["g", "r"]:
    outcome = f"drw_tau_rest_days_{filt}"
    gate_col = f"drw_tau_interpretable_primary_{filt}"

    if outcome in d.columns and gate_col in d.columns:
        gate = as_bool(d[gate_col])

        predictors = [
            "FSRQ",
            "redshift_clean",
            f"ctrl_drw_logN_{filt}",
            f"drw_baseline_days_{filt}",
            f"drw_median_cadence_days_{filt}",
        ]

        continuous_frames.append(
            fit_ols(
                d,
                outcome=outcome,
                predictors=predictors,
                model_name=f"REST_TAU_{filt}_CLASS_CONTROLLED",
                standardize_predictors=[
                    "redshift_clean",
                    f"ctrl_drw_logN_{filt}",
                    f"drw_baseline_days_{filt}",
                    f"drw_median_cadence_days_{filt}",
                ],
                subset=gate,
                transform_outcome="log10_positive",
            )
        )

continuous = pd.concat(
    continuous_frames,
    ignore_index=True
)

if "p_value" in continuous.columns:
    continuous["p_q_bh_all_continuous_coefficients"] = bh_qvalues(
        continuous["p_value"].to_numpy(dtype=float)
    )

continuous.to_csv(
    OUT_CONT,
    index=False
)


# ============================================================
# PREDICTOR AUDIT
# ============================================================

audit_cols = [
    "redshift_clean",
    "SED_class_clean",
    "fermi_nu_syn_clean",
    "fermi_Variability_Index_DR4",
    "fermi_Frac_Variability_DR4",
    "fermi_Energy_Flux100_DR4",
    "fermi_PL_Index_DR4",
    "fermi_Signif_Avg_DR4",
    "N_nights_g",
    "N_nights_r",
    "col_N_colour_pairs",
    "col_r_mag_range",
]

audit_rows = []

for c in audit_cols:
    if c not in d.columns:
        continue

    s = d[c]

    row = {
        "column": c,
        "N_total": len(s),
        "N_nonnull": int(s.notna().sum()),
        "N_missing": int(s.isna().sum()),
        "N_unique": int(s.nunique(dropna=True)),
    }

    sn = numeric(s)

    if sn.notna().sum() > 0:
        row.update({
            "numeric_min": float(sn.min()),
            "numeric_median": float(sn.median()),
            "numeric_mean": float(sn.mean()),
            "numeric_max": float(sn.max()),
        })

    audit_rows.append(row)

predictor_audit = pd.DataFrame(
    audit_rows
)

predictor_audit.to_csv(
    OUT_AUDIT,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

def extract_row(table, model_name, predictor):
    x = table.loc[
        table["model_name"].eq(model_name)
        &
        table["predictor"].eq(predictor)
    ]

    if len(x) != 1:
        return None

    return x.iloc[0]

lines = [
    "BLAZAR_I - STAGE 05 FINAL SUMMARY",
    "=" * 72,
    "",
    f"Population rows: {len(d)}",
    f"BLL: {int((d['blazar_class']=='BLL').sum())}",
    f"FSRQ: {int((d['blazar_class']=='FSRQ').sum())}",
    f"rms-flux BOTH-band eligible subset: {int(d['rmflux_eligible_both'].sum())}",
    "",
    "CONTROLLED FSRQ CLASS EFFECTS:",
]

primary_models = [
    "PDF_ROBUST_DOUBLE_BOTH_CONTROLLED",
    "RMFLUX_STRICT_BOTH_ELIGIBLE_CONTROLLED",
    "COLOUR_ROBUST_CENTRAL_BREAK_CONTROLLED",
    "DRW_INTERPRETABLE_BOTH_CONTROLLED",
]

for mname in primary_models:
    rr = extract_row(
        primary,
        mname,
        "FSRQ"
    )

    if rr is None:
        lines.append(
            f"  {mname}: FSRQ coefficient unavailable"
        )
    else:
        lines.append(
            f"  {mname}: "
            f"N={int(rr['N'])}, "
            f"OR={rr['odds_ratio']:.3f}, "
            f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
            f"p={rr['p_value']:.3g}"
        )

lines += [
    "",
    "FOCUSED RMS-FLUX -> COLOUR BREAK MODEL:",
]

rr = extract_row(
    rmcolor,
    "COLOUR_BREAK_GIVEN_RMFLUX_BOTH_ELIGIBLE",
    "rmflux_strict_both"
)

if rr is not None:
    lines.append(
        f"  rmsflux_strict_both: "
        f"N={int(rr['N'])}, "
        f"adjusted OR={rr['odds_ratio']:.3f}, "
        f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
        f"p={rr['p_value']:.3g}"
    )

rr_cls = extract_row(
    rmcolor,
    "COLOUR_BREAK_GIVEN_RMFLUX_BOTH_ELIGIBLE",
    "FSRQ"
)

if rr_cls is not None:
    lines.append(
        f"  FSRQ in same model: "
        f"OR={rr_cls['odds_ratio']:.3f}, "
        f"95%CI={rr_cls['or_ci95_low']:.3f}-{rr_cls['or_ci95_high']:.3f}, "
        f"p={rr_cls['p_value']:.3g}"
    )

lines += [
    "",
    "FERMI / SED SCREEN (q_BH_global <= 0.05):",
]

if len(fermi_screen) > 0:
    sig = fermi_screen.loc[
        pd.to_numeric(
            fermi_screen.get(
                "p_q_bh_global_screen",
                np.nan
            ),
            errors="coerce"
        )
        <=
        0.05
    ].copy()

    if len(sig) == 0:
        lines.append(
            "  none"
        )
    else:
        for _, rr in sig.sort_values(
            "p_q_bh_global_screen"
        ).iterrows():
            lines.append(
                f"  {rr['diagnostic_family']} <- "
                f"{rr['screen_predictor_label']}: "
                f"OR/SD={rr['odds_ratio']:.3f}, "
                f"q={rr['p_q_bh_global_screen']:.3g}, "
                f"N={int(rr['N'])}"
            )

lines += [
    "",
    "SED-CLASS SCREEN (LSP reference; q_BH_global <= 0.05):",
]

if len(sed_models) > 0:
    sed_sig = sed_models.loc[
        pd.to_numeric(
            sed_models["p_q_bh_global_sed"],
            errors="coerce"
        )
        <=
        0.05
    ].copy()

    if len(sed_sig) == 0:
        lines.append("  none")
    else:
        for _, rr in sed_sig.sort_values(
            "p_q_bh_global_sed"
        ).iterrows():
            lines.append(
                f"  {rr['diagnostic_family']} <- "
                f"{rr['predictor']} vs LSP: "
                f"OR={rr['odds_ratio']:.3f}, "
                f"q={rr['p_q_bh_global_sed']:.3g}, "
                f"N={int(rr['N'])}"
            )

lines += [
    "",
    "CONTINUOUS CLASS EFFECTS (FSRQ coefficient):",
]

for mname in continuous["model_name"].dropna().unique():
    rr = extract_row(
        continuous,
        mname,
        "FSRQ"
    )

    if rr is not None:
        lines.append(
            f"  {mname}: "
            f"N={int(rr['N'])}, "
            f"beta={rr['coef']:.4f}, "
            f"95%CI={rr['ci95_low']:.4f}-{rr['ci95_high']:.4f}, "
            f"p={rr['p_value']:.3g}"
        )

final_summary = "\n".join(lines)

OUT_SUMMARY.write_text(
    final_summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 05")
print("CONTROLLED POPULATION INFERENCE")
print("=" * 78)
print()
print(final_summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_PRIMARY)
print(OUT_RMSCOLOR)
print(OUT_FERMI)
print(OUT_SED)
print(OUT_CONT)
print(OUT_AUDIT)
print(OUT_SUMMARY)
print()
print("STAGE 05 COMPLETE")
