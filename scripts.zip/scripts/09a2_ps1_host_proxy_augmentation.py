# ============================================================
# BLAZAR_I — STAGE 09A2
# PAN-STARRS1 DR2 HOST / EXTENSION-PROXY AUGMENTATION
#
# Purpose:
#   Add an external, empirical host/extension sensitivity proxy to the
#   1061-source Q1 confounder master using PS1 DR2 MeanObject photometry.
#
# Scientific intent:
#   rMeanPSFMag - rMeanKronMag and iMeanPSFMag - iMeanKronMag are used
#   as CONTINUOUS extension/host-contamination sensitivity proxies.
#   They are NOT treated as exact host-galaxy decompositions.
#
# Matching:
#   - query radius: 2.0 arcsec
#   - nearest PS1 MeanObject selected
#   - high-confidence positional match: <= 1.0 arcsec
#   - all candidate rows are retained in per-source raw CSV files
#
# Photometric quality:
#   BASIC:
#     finite positive PSF/Kron magnitudes and finite errors,
#     at least one PSF and Kron contributing measurement.
#   HQ:
#     BASIC + QfPerfect >= 0.85 + both magnitude errors <= 0.20 mag.
#
# Host proxy:
#   delta_r = rMeanPSFMag - rMeanKronMag
#   delta_i = iMeanPSFMag - iMeanKronMag
#   host_proxy_ri = median of available HQ delta_r/delta_i
#
# An auxiliary >=0.05 mag "extended-like" flag is written because this
# threshold is used in PS1 documentation/sample queries for galaxy
# selection, but the continuous proxy is the primary sensitivity variable.
#
# Reproducibility / resilience:
#   - read-only relative to Stage 09A1
#   - resumable per-source raw CSV + done JSON
#   - failed network requests are NOT marked done
#   - rerun the same command to resume
#   - no endpoint model is fit here
#
# Official service:
#   https://catalogs.mast.stsci.edu/api/v0.1/panstarrs/dr2/mean.csv
#
# Outputs:
#   data/interim/stage09a2_ps1_mean/raw/*.csv
#   data/interim/stage09a2_ps1_mean/done/*.json
#   outputs/tables/stage09a2_ps1_host_proxy.csv
#   outputs/tables/stage09a2_q1_confounder_master_ps1.csv
#   outputs/audit/stage09a2_match_audit.csv
#   outputs/audit/stage09a2_summary.txt
# ============================================================

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import StringIO
import argparse
import json
import math
import time
import urllib.parse
import urllib.request
import urllib.error

import numpy as np
import pandas as pd


# ============================================================
# CONFIG
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
INTERIM_DIR = ROOT / "data" / "interim"

IN_MASTER = TABLE_DIR / "stage09a1_q1_confounder_master.csv"

WORK_DIR = INTERIM_DIR / "stage09a2_ps1_mean"
RAW_DIR = WORK_DIR / "raw"
DONE_DIR = WORK_DIR / "done"

OUT_PROXY = TABLE_DIR / "stage09a2_ps1_host_proxy.csv"
OUT_MASTER = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"
OUT_AUDIT = AUDIT_DIR / "stage09a2_match_audit.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09a2_summary.txt"

API = (
    "https://catalogs.mast.stsci.edu/"
    "api/v0.1/panstarrs/dr2/mean.csv"
)

META_API = (
    "https://catalogs.mast.stsci.edu/"
    "api/v0.1/panstarrs/dr2/mean/metadata.json"
)

QUERY_RADIUS_ARCSEC = 2.0
HIGHCONF_SEP_ARCSEC = 1.0

# The documented MeanObject columns we need.
COLUMNS = [
    "objID",
    "objName",
    "raMean",
    "decMean",
    "nDetections",
    "ng",
    "nr",
    "ni",
    "rQfPerfect",
    "iQfPerfect",
    "rMeanPSFMag",
    "rMeanPSFMagErr",
    "rMeanPSFMagNpt",
    "rMeanKronMag",
    "rMeanKronMagErr",
    "rMeanKronMagNpt",
    "iMeanPSFMag",
    "iMeanPSFMagErr",
    "iMeanPSFMagNpt",
    "iMeanKronMag",
    "iMeanKronMagErr",
    "iMeanKronMagNpt",
]

for p in [
    TABLE_DIR,
    AUDIT_DIR,
    RAW_DIR,
    DONE_DIR,
]:
    p.mkdir(
        parents=True,
        exist_ok=True,
    )


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--workers",
    type=int,
    default=4,
    help="Concurrent MAST cone queries. Default=4.",
)

parser.add_argument(
    "--timeout",
    type=int,
    default=45,
    help="Per-request network timeout in seconds. Default=45.",
)

parser.add_argument(
    "--max-retries",
    type=int,
    default=5,
    help="Retries per source before leaving it unfinished. Default=5.",
)

args = parser.parse_args()

if args.workers < 1 or args.workers > 8:
    raise RuntimeError(
        "--workers must be between 1 and 8."
    )


# ============================================================
# HELPERS
# ============================================================

def finite_float(x):
    try:
        v = float(x)
    except Exception:
        return np.nan

    if not np.isfinite(v):
        return np.nan

    # PS1 commonly uses -999 sentinel values.
    if v <= -900:
        return np.nan

    return v


def clean_numeric_series(s):
    x = pd.to_numeric(
        s,
        errors="coerce",
    )

    x = x.mask(
        x <= -900,
        np.nan,
    )

    return x


def angular_sep_arcsec(
    ra1_deg,
    dec1_deg,
    ra2_deg,
    dec2_deg,
):
    ra1 = math.radians(
        float(ra1_deg)
    )
    de1 = math.radians(
        float(dec1_deg)
    )
    ra2 = math.radians(
        float(ra2_deg)
    )
    de2 = math.radians(
        float(dec2_deg)
    )

    s1 = math.sin(
        (de2 - de1) / 2.0
    )
    s2 = math.sin(
        (ra2 - ra1) / 2.0
    )

    a = (
        s1 * s1
        +
        math.cos(de1)
        *
        math.cos(de2)
        *
        s2 * s2
    )

    a = min(
        1.0,
        max(
            0.0,
            a,
        ),
    )

    c = 2.0 * math.asin(
        math.sqrt(a)
    )

    return math.degrees(c) * 3600.0


def json_safe_value(x):
    if x is None:
        return None

    if isinstance(
        x,
        (
            np.integer,
            int,
        ),
    ):
        return int(x)

    if isinstance(
        x,
        (
            np.floating,
            float,
        ),
    ):
        return (
            float(x)
            if np.isfinite(x)
            else None
        )

    if pd.isna(x):
        return None

    return str(x)


def write_json_atomic(
    path,
    obj,
):
    tmp = path.with_suffix(
        path.suffix + ".tmp"
    )

    tmp.write_text(
        json.dumps(
            obj,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    tmp.replace(
        path
    )


def request_text(
    url,
    timeout,
):
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": (
                "BLAZAR_I-Q1-Rebuild/"
                "Stage09A2"
            )
        },
    )

    with urllib.request.urlopen(
        req,
        timeout=timeout,
    ) as resp:
        return resp.read().decode(
            "utf-8",
            errors="replace",
        )


def validate_metadata(
    timeout,
):
    print(
        "Validating PS1 DR2 MeanObject metadata..."
    )

    txt = request_text(
        META_API,
        timeout=timeout,
    )

    meta = json.loads(
        txt
    )

    names = {
        str(x.get("name", "")).lower()
        for x in meta
    }

    missing = [
        c
        for c in COLUMNS
        if c.lower() not in names
    ]

    if missing:
        raise RuntimeError(
            "Required PS1 columns absent from metadata:\n  "
            +
            "\n  ".join(
                missing
            )
        )

    print(
        "PS1 metadata validation: PASS"
    )


def build_url(
    ra,
    dec,
):
    params = {
        "ra": f"{float(ra):.10f}",
        "dec": f"{float(dec):.10f}",
        "radius": (
            f"{QUERY_RADIUS_ARCSEC / 3600.0:.10f}"
        ),
        "pagesize": "25",
        "columns": (
            "["
            +
            ",".join(
                COLUMNS
            )
            +
            "]"
        ),
    }

    return (
        API
        +
        "?"
        +
        urllib.parse.urlencode(
            params,
            safe="[],",
        )
    )


def select_nearest(
    df,
    ra,
    dec,
):
    if len(df) == 0:
        return (
            None,
            np.nan,
            np.nan,
        )

    lower = {
        str(c).lower(): c
        for c in df.columns
    }

    ra_col = lower.get(
        "ramean"
    )
    dec_col = lower.get(
        "decmean"
    )

    if (
        ra_col is None
        or
        dec_col is None
    ):
        raise RuntimeError(
            "PS1 response lacks raMean/decMean."
        )

    seps = []

    for _, row in df.iterrows():
        r = finite_float(
            row[ra_col]
        )
        d = finite_float(
            row[dec_col]
        )

        if (
            not np.isfinite(r)
            or
            not np.isfinite(d)
        ):
            seps.append(
                np.nan
            )
            continue

        seps.append(
            angular_sep_arcsec(
                ra,
                dec,
                r,
                d,
            )
        )

    seps = np.asarray(
        seps,
        dtype=float,
    )

    good = np.isfinite(
        seps
    )

    if not good.any():
        return (
            None,
            np.nan,
            np.nan,
        )

    indices = np.where(
        good
    )[0]

    order = indices[
        np.argsort(
            seps[good]
        )
    ]

    best_i = int(
        order[0]
    )

    second_sep = (
        float(
            seps[
                int(order[1])
            ]
        )
        if len(order) >= 2
        else np.nan
    )

    return (
        df.iloc[
            best_i
        ],
        float(
            seps[best_i]
        ),
        second_sep,
    )


def query_one(
    row,
    timeout,
    max_retries,
):
    bid = str(
        row.blazar_id
    )
    ra = float(
        row.ra_counterpart_deg
    )
    dec = float(
        row.dec_counterpart_deg
    )

    safe_id = (
        bid.replace(
            "/",
            "_",
        )
        .replace(
            "\\",
            "_",
        )
        .replace(
            ":",
            "_",
        )
    )

    raw_path = (
        RAW_DIR
        /
        f"{safe_id}.csv"
    )

    done_path = (
        DONE_DIR
        /
        f"{safe_id}.json"
    )

    if done_path.exists():
        return {
            "blazar_id": bid,
            "status": "ALREADY_DONE",
        }

    if (
        not np.isfinite(ra)
        or
        not np.isfinite(dec)
    ):
        return {
            "blazar_id": bid,
            "status": "INVALID_COORDINATES",
        }

    url = build_url(
        ra,
        dec,
    )

    delays = [
        2,
        5,
        15,
        30,
        60,
        90,
    ]

    last_error = None

    for attempt in range(
        1,
        max_retries + 1,
    ):
        try:
            txt = request_text(
                url,
                timeout=timeout,
            )

            # Write raw response first.
            tmp_raw = raw_path.with_suffix(
                ".csv.tmp"
            )

            tmp_raw.write_text(
                txt,
                encoding="utf-8",
            )

            tmp_raw.replace(
                raw_path
            )

            # Parse.
            try:
                df = pd.read_csv(
                    StringIO(txt)
                )
            except pd.errors.EmptyDataError:
                df = pd.DataFrame(
                    columns=COLUMNS
                )

            best, best_sep, second_sep = (
                select_nearest(
                    df,
                    ra,
                    dec,
                )
            )

            if best is None:
                payload = {
                    "blazar_id": bid,
                    "status": "NO_MATCH",
                    "ra_query": ra,
                    "dec_query": dec,
                    "within_nominal_ps1_footprint": (
                        dec >= -30.0
                    ),
                    "query_radius_arcsec": (
                        QUERY_RADIUS_ARCSEC
                    ),
                    "n_candidates": int(
                        len(df)
                    ),
                    "best_sep_arcsec": None,
                    "second_sep_arcsec": None,
                    "best_row": None,
                }

            else:
                payload = {
                    "blazar_id": bid,
                    "status": "MATCH",
                    "ra_query": ra,
                    "dec_query": dec,
                    "within_nominal_ps1_footprint": (
                        dec >= -30.0
                    ),
                    "query_radius_arcsec": (
                        QUERY_RADIUS_ARCSEC
                    ),
                    "n_candidates": int(
                        len(df)
                    ),
                    "best_sep_arcsec": (
                        best_sep
                    ),
                    "second_sep_arcsec": (
                        second_sep
                        if np.isfinite(
                            second_sep
                        )
                        else None
                    ),
                    "best_row": {
                        str(k): json_safe_value(v)
                        for k, v in best.to_dict().items()
                    },
                }

            write_json_atomic(
                done_path,
                payload,
            )

            return {
                "blazar_id": bid,
                "status": payload[
                    "status"
                ],
            }

        except Exception as exc:
            last_error = (
                f"{type(exc).__name__}: "
                f"{exc}"
            )

            if (
                attempt
                <
                max_retries
            ):
                delay = delays[
                    min(
                        attempt - 1,
                        len(delays) - 1,
                    )
                ]

                time.sleep(
                    delay
                )

    return {
        "blazar_id": bid,
        "status": "QUERY_FAILED",
        "error": last_error,
    }


def get_case(
    d,
    name,
):
    lower = {
        str(k).lower(): k
        for k in d.keys()
    }

    k = lower.get(
        name.lower()
    )

    if k is None:
        return np.nan

    return finite_float(
        d[k]
    )


def get_text_case(
    d,
    name,
):
    lower = {
        str(k).lower(): k
        for k in d.keys()
    }

    k = lower.get(
        name.lower()
    )

    if k is None:
        return None

    v = d[k]

    if v is None:
        return None

    return str(v)


def band_proxy(
    best,
    band,
):
    psf = get_case(
        best,
        f"{band}MeanPSFMag",
    )
    psfe = get_case(
        best,
        f"{band}MeanPSFMagErr",
    )
    psfn = get_case(
        best,
        f"{band}MeanPSFMagNpt",
    )

    kron = get_case(
        best,
        f"{band}MeanKronMag",
    )
    krone = get_case(
        best,
        f"{band}MeanKronMagErr",
    )
    kronn = get_case(
        best,
        f"{band}MeanKronMagNpt",
    )

    qf = get_case(
        best,
        f"{band}QfPerfect",
    )

    basic = (
        np.isfinite(psf)
        and
        np.isfinite(kron)
        and
        np.isfinite(psfe)
        and
        np.isfinite(krone)
        and
        np.isfinite(psfn)
        and
        np.isfinite(kronn)
        and
        psf > 0
        and
        kron > 0
        and
        psf < 35
        and
        kron < 35
        and
        psfe >= 0
        and
        krone >= 0
        and
        psfn >= 1
        and
        kronn >= 1
    )

    hq = (
        basic
        and
        np.isfinite(qf)
        and
        qf >= 0.85
        and
        psfe <= 0.20
        and
        krone <= 0.20
    )

    delta = (
        psf - kron
        if basic
        else np.nan
    )

    delta_hq = (
        delta
        if hq
        else np.nan
    )

    return {
        f"ps1_{band}_psf_mag": psf,
        f"ps1_{band}_psf_magerr": psfe,
        f"ps1_{band}_psf_npt": psfn,
        f"ps1_{band}_kron_mag": kron,
        f"ps1_{band}_kron_magerr": krone,
        f"ps1_{band}_kron_npt": kronn,
        f"ps1_{band}_qfperfect": qf,
        f"ps1_{band}_proxy_basic": bool(
            basic
        ),
        f"ps1_{band}_proxy_hq": bool(
            hq
        ),
        f"ps1_{band}_psf_minus_kron": (
            delta
        ),
        f"ps1_{band}_psf_minus_kron_hq": (
            delta_hq
        ),
    }


# ============================================================
# LOAD MASTER / VALIDATE
# ============================================================

if not IN_MASTER.exists():
    raise FileNotFoundError(
        IN_MASTER
    )

master = pd.read_csv(
    IN_MASTER,
    low_memory=False,
)

if len(master) != 1061:
    raise RuntimeError(
        f"Expected 1061 Stage09A1 rows; "
        f"got {len(master)}"
    )

required_cols = [
    "blazar_id",
    "blazar_class",
    "ra_counterpart_deg",
    "dec_counterpart_deg",
]

missing = [
    c
    for c in required_cols
    if c not in master.columns
]

if missing:
    raise RuntimeError(
        "Missing required Stage09A1 columns: "
        +
        repr(
            missing
        )
    )

if master[
    "blazar_id"
].astype(str).duplicated().any():
    raise RuntimeError(
        "Duplicate blazar_id in Stage09A1 master."
    )

master["blazar_id"] = (
    master["blazar_id"]
    .astype(str)
)


# ============================================================
# NETWORK PREFLIGHT
# ============================================================

validate_metadata(
    timeout=args.timeout,
)


# ============================================================
# RESUMABLE DOWNLOAD
# ============================================================

done_existing = len(
    list(
        DONE_DIR.glob(
            "*.json"
        )
    )
)

print(
    "=" * 78
)
print(
    "BLAZAR_I — STAGE 09A2 PS1 HOST-PROXY AUGMENTATION"
)
print(
    "=" * 78
)
print(
    f"Sources                 = {len(master)}"
)
print(
    f"Existing done markers   = {done_existing}"
)
print(
    f"Query radius            = {QUERY_RADIUS_ARCSEC:.1f} arcsec"
)
print(
    f"Workers                 = {args.workers}"
)
print(
    f"Timeout                 = {args.timeout} s"
)

jobs = [
    row
    for row in master[
        [
            "blazar_id",
            "ra_counterpart_deg",
            "dec_counterpart_deg",
        ]
    ].itertuples(
        index=False
    )
]

results = []

with ThreadPoolExecutor(
    max_workers=args.workers
) as ex:
    futures = {
        ex.submit(
            query_one,
            row,
            args.timeout,
            args.max_retries,
        ): row.blazar_id
        for row in jobs
    }

    n = 0

    for fut in as_completed(
        futures
    ):
        n += 1

        try:
            res = fut.result()
        except Exception as exc:
            res = {
                "blazar_id": (
                    futures[fut]
                ),
                "status": (
                    "UNHANDLED_FAILURE"
                ),
                "error": (
                    f"{type(exc).__name__}: "
                    f"{exc}"
                ),
            }

        results.append(
            res
        )

        if (
            n % 50 == 0
            or
            n == len(jobs)
        ):
            done_now = len(
                list(
                    DONE_DIR.glob(
                        "*.json"
                    )
                )
            )

            print(
                f"Progress {n}/{len(jobs)}; "
                f"done markers={done_now}"
            )


# ============================================================
# AGGREGATE DONE PRODUCTS
# ============================================================

proxy_rows = []
audit_rows = []

for row in master[
    [
        "blazar_id",
        "blazar_class",
        "ra_counterpart_deg",
        "dec_counterpart_deg",
    ]
].itertuples(
    index=False
):
    bid = str(
        row.blazar_id
    )

    safe_id = (
        bid.replace(
            "/",
            "_",
        )
        .replace(
            "\\",
            "_",
        )
        .replace(
            ":",
            "_",
        )
    )

    done_path = (
        DONE_DIR
        /
        f"{safe_id}.json"
    )

    base = {
        "blazar_id": bid,
        "blazar_class": (
            row.blazar_class
        ),
        "ra_counterpart_deg": (
            float(
                row.ra_counterpart_deg
            )
        ),
        "dec_counterpart_deg": (
            float(
                row.dec_counterpart_deg
            )
        ),
        "within_nominal_ps1_footprint": (
            float(
                row.dec_counterpart_deg
            )
            >=
            -30.0
        ),
    }

    if not done_path.exists():
        pr = dict(
            base
        )
        pr.update({
            "ps1_query_status": (
                "UNFINISHED"
            ),
            "ps1_match": False,
            "ps1_match_highconf": False,
            "ps1_match_sep_arcsec": np.nan,
            "ps1_n_candidates": np.nan,
            "ps1_host_proxy_hq_available": False,
            "ps1_host_proxy_ri": np.nan,
            "ps1_extended_like_005": np.nan,
        })

        proxy_rows.append(
            pr
        )

        audit_rows.append({
            **base,
            "status": "UNFINISHED",
            "n_candidates": np.nan,
            "best_sep_arcsec": np.nan,
            "second_sep_arcsec": np.nan,
        })

        continue

    payload = json.loads(
        done_path.read_text(
            encoding="utf-8"
        )
    )

    status = payload.get(
        "status",
        "UNKNOWN",
    )

    best = payload.get(
        "best_row"
    )

    pr = dict(
        base
    )

    pr["ps1_query_status"] = (
        status
    )

    pr["ps1_match"] = (
        status == "MATCH"
    )

    best_sep = payload.get(
        "best_sep_arcsec"
    )

    best_sep = (
        float(
            best_sep
        )
        if best_sep is not None
        else np.nan
    )

    second_sep = payload.get(
        "second_sep_arcsec"
    )

    second_sep = (
        float(
            second_sep
        )
        if second_sep is not None
        else np.nan
    )

    pr[
        "ps1_match_sep_arcsec"
    ] = best_sep

    pr[
        "ps1_match_highconf"
    ] = (
        status == "MATCH"
        and
        np.isfinite(
            best_sep
        )
        and
        best_sep
        <=
        HIGHCONF_SEP_ARCSEC
    )

    pr[
        "ps1_n_candidates"
    ] = payload.get(
        "n_candidates",
        np.nan,
    )

    ambiguous = (
        status == "MATCH"
        and
        np.isfinite(
            second_sep
        )
        and
        np.isfinite(
            best_sep
        )
        and
        (
            second_sep
            -
            best_sep
        )
        <
        0.5
    )

    pr[
        "ps1_match_ambiguous"
    ] = bool(
        ambiguous
    )

    if (
        status != "MATCH"
        or
        best is None
    ):
        pr[
            "ps1_host_proxy_hq_available"
        ] = False

        pr[
            "ps1_host_proxy_ri"
        ] = np.nan

        pr[
            "ps1_extended_like_005"
        ] = np.nan

        proxy_rows.append(
            pr
        )

        audit_rows.append({
            **base,
            "status": status,
            "n_candidates": payload.get(
                "n_candidates",
                np.nan,
            ),
            "best_sep_arcsec": (
                best_sep
            ),
            "second_sep_arcsec": (
                second_sep
            ),
        })

        continue

    pr[
        "ps1_objid"
    ] = get_text_case(
        best,
        "objID",
    )

    pr[
        "ps1_objname"
    ] = get_text_case(
        best,
        "objName",
    )

    pr[
        "ps1_ra_mean_deg"
    ] = get_case(
        best,
        "raMean",
    )

    pr[
        "ps1_dec_mean_deg"
    ] = get_case(
        best,
        "decMean",
    )

    pr[
        "ps1_n_detections"
    ] = get_case(
        best,
        "nDetections",
    )

    for c in [
        "ng",
        "nr",
        "ni",
    ]:
        pr[
            f"ps1_{c}"
        ] = get_case(
            best,
            c,
        )

    r_proxy = band_proxy(
        best,
        "r",
    )

    i_proxy = band_proxy(
        best,
        "i",
    )

    pr.update(
        r_proxy
    )
    pr.update(
        i_proxy
    )

    hq_values = [
        pr[
            "ps1_r_psf_minus_kron_hq"
        ],
        pr[
            "ps1_i_psf_minus_kron_hq"
        ],
    ]

    hq_values = [
        x
        for x in hq_values
        if np.isfinite(x)
    ]

    # Require a high-confidence positional match for the primary proxy.
    pr[
        "ps1_host_proxy_hq_available"
    ] = bool(
        pr[
            "ps1_match_highconf"
        ]
        and
        not pr[
            "ps1_match_ambiguous"
        ]
        and
        len(
            hq_values
        )
        >=
        1
    )

    pr[
        "ps1_host_proxy_ri"
    ] = (
        float(
            np.median(
                hq_values
            )
        )
        if pr[
            "ps1_host_proxy_hq_available"
        ]
        else np.nan
    )

    pr[
        "ps1_extended_like_005"
    ] = (
        bool(
            pr[
                "ps1_host_proxy_ri"
            ]
            >=
            0.05
        )
        if np.isfinite(
            pr[
                "ps1_host_proxy_ri"
            ]
        )
        else np.nan
    )

    proxy_rows.append(
        pr
    )

    audit_rows.append({
        **base,
        "status": status,
        "n_candidates": payload.get(
            "n_candidates",
            np.nan,
        ),
        "best_sep_arcsec": (
            best_sep
        ),
        "second_sep_arcsec": (
            second_sep
        ),
        "highconf": pr[
            "ps1_match_highconf"
        ],
        "ambiguous": pr[
            "ps1_match_ambiguous"
        ],
        "host_proxy_hq_available": pr[
            "ps1_host_proxy_hq_available"
        ],
    })


proxy = pd.DataFrame(
    proxy_rows
)

audit = pd.DataFrame(
    audit_rows
)

if len(proxy) != 1061:
    raise RuntimeError(
        f"Proxy table should have 1061 rows, got {len(proxy)}"
    )

if proxy[
    "blazar_id"
].duplicated().any():
    raise RuntimeError(
        "Duplicate blazar_id in PS1 proxy table."
    )

proxy.to_csv(
    OUT_PROXY,
    index=False,
)

audit.to_csv(
    OUT_AUDIT,
    index=False,
)


# ============================================================
# MERGE INTO Q1 MASTER
# ============================================================

merge_cols = [
    c
    for c in proxy.columns
    if c not in {
        "blazar_class",
        "ra_counterpart_deg",
        "dec_counterpart_deg",
    }
]

master_aug = master.merge(
    proxy[
        merge_cols
    ],
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

if len(master_aug) != 1061:
    raise RuntimeError(
        "Augmented master row count changed."
    )

master_aug.to_csv(
    OUT_MASTER,
    index=False,
)


# ============================================================
# SUMMARY
# ============================================================

n_done = int(
    proxy[
        "ps1_query_status"
    ]
    .isin(
        [
            "MATCH",
            "NO_MATCH",
        ]
    )
    .sum()
)

n_unfinished = int(
    proxy[
        "ps1_query_status"
    ]
    .eq(
        "UNFINISHED"
    )
    .sum()
)

n_match = int(
    proxy[
        "ps1_match"
    ]
    .fillna(False)
    .sum()
)

n_highconf = int(
    proxy[
        "ps1_match_highconf"
    ]
    .fillna(False)
    .sum()
)

n_proxy = int(
    proxy[
        "ps1_host_proxy_hq_available"
    ]
    .fillna(False)
    .sum()
)

n_extended = int(
    (
        pd.to_numeric(
            proxy[
                "ps1_host_proxy_ri"
            ],
            errors="coerce",
        )
        >=
        0.05
    )
    .sum()
)

def class_counts(cls):
    w = proxy.loc[
        proxy[
            "blazar_class"
        ]
        .astype(str)
        .eq(cls)
    ]

    return {
        "N": len(w),
        "match": int(
            w[
                "ps1_match"
            ]
            .fillna(False)
            .sum()
        ),
        "highconf": int(
            w[
                "ps1_match_highconf"
            ]
            .fillna(False)
            .sum()
        ),
        "proxy": int(
            w[
                "ps1_host_proxy_hq_available"
            ]
            .fillna(False)
            .sum()
        ),
        "extended": int(
            (
                pd.to_numeric(
                    w[
                        "ps1_host_proxy_ri"
                    ],
                    errors="coerce",
                )
                >=
                0.05
            )
            .sum()
        ),
    }

bll = class_counts(
    "BLL"
)
fsrq = class_counts(
    "FSRQ"
)

status = (
    "COMPLETE"
    if n_unfinished == 0
    else "PARTIAL_RERUN_REQUIRED"
)

summary = f"""BLAZAR_I - STAGE 09A2 FINAL SUMMARY
================================================================================

Pan-STARRS1 DR2 host/extension-proxy augmentation

Query configuration:
  catalogue                      : PS1 DR2 MeanObject
  radius                         : {QUERY_RADIUS_ARCSEC:.1f} arcsec
  high-confidence match          : <= {HIGHCONF_SEP_ARCSEC:.1f} arcsec
  concurrency                    : {args.workers}
  per-source checkpoints         : YES

Query completion:
  source rows                    : {len(proxy)}
  completed MATCH/NO_MATCH       : {n_done}
  unfinished                    : {n_unfinished}
  status                         : {status}

PS1 positional coverage:
  any match                      : {n_match}/{len(proxy)}
  high-confidence <=1 arcsec     : {n_highconf}/{len(proxy)}

HQ continuous host proxy:
  available                      : {n_proxy}/{len(proxy)}
  proxy >= 0.05 mag              : {n_extended}/{len(proxy)}

By optical class:
  BLL:
    N                            : {bll['N']}
    PS1 match                    : {bll['match']}
    high-confidence              : {bll['highconf']}
    HQ host proxy                : {bll['proxy']}
    proxy >= 0.05 mag            : {bll['extended']}

  FSRQ:
    N                            : {fsrq['N']}
    PS1 match                    : {fsrq['match']}
    high-confidence              : {fsrq['highconf']}
    HQ host proxy                : {fsrq['proxy']}
    proxy >= 0.05 mag            : {fsrq['extended']}

Scientific interpretation lock:
  - ps1_host_proxy_ri is a CONTINUOUS extension/host-contamination
    sensitivity proxy, not a physical host-galaxy decomposition.
  - the >=0.05 mag flag is auxiliary only.
  - host adjustment will be a sensitivity model, not a replacement
    for the frozen primary pre-diagnostic model.

Files saved:
  {OUT_PROXY}
  {OUT_MASTER}
  {OUT_AUDIT}

Checkpoint directories:
  {RAW_DIR}
  {DONE_DIR}

Next:
  If status = PARTIAL_RERUN_REQUIRED:
    rerun the SAME Stage 09A2 command; completed sources will be skipped.

  If status = COMPLETE:
    STAGE 09A3 — nested Q1 confounder models:
      M0 coverage
      M1 + redshift/SED/gamma
      M2 + optical brightness
      M3 + PS1 host proxy
    with explicit complete-case / missing-redshift sensitivity.

No endpoint model was fit in STAGE 09A2.

STAGE 09A2 {status}
"""

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(
    summary
)
