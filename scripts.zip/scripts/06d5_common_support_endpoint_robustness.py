# ============================================================
# BLAZAR_I — STAGE 06D5
# FINAL COMMON-SUPPORT SELECTION-WEIGHTED ENDPOINT ROBUSTNESS
#
# Target population:
#   Clean Fermi FSRQ+BLL sources within the empirically supported
#   ZTF/final declination overlap:
#
#       -31.289 deg <= Dec <= +86.206 deg
#
#   Common-support parent N = 1548
#   Final GOLD+SILVER analysis N = 1061
#
# Weights:
#   outputs/tables/stage06d4b_common_support_weights.csv
#
# Weight schemes:
#   UNWEIGHTED
#   COMMON_RAW
#   COMMON_TRIM_1_99
#   COMMON_TRIM_2P5_97P5
#
# Binary class endpoints:
#   PDF robust double BOTH
#   rms-flux strict BOTH among both-band eligible sources
#   colour robust central break
#   DRW interpretable BOTH
#   core4 >= 3 (audit/synthesis only)
#
# Cross-diagnostic endpoint:
#   colour robust central break ~ rmflux strict both + FSRQ
#   among both-band rms-flux eligible sources
#
# Continuous class contrasts:
#   Fvar_g
#   Fvar_r
#   tau_rest_g among g-band primary interpretable DRW rows
#   tau_rest_r among r-band primary interpretable DRW rows
#
# Interpretation:
#   These are selection-weighted sensitivity estimates for the
#   common-support population. They are not generalized to the
#   unsupported southern sky excluded in STAGE 06D4B.
#
# Note:
#   Selection-model uncertainty is not propagated into endpoint
#   confidence intervals; treat this as a robustness analysis,
#   not a causal estimator.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

POP_FILE = TABLE_DIR / "stage04_population_master.csv"
WEIGHT_FILE = TABLE_DIR / "stage06d4b_common_support_weights.csv"

OUT_BINARY = TABLE_DIR / "stage06d5_common_support_ipw_binary_models.csv"
OUT_CROSS = TABLE_DIR / "stage06d5_common_support_ipw_rmflux_colour.csv"
OUT_CONT = TABLE_DIR / "stage06d5_common_support_ipw_continuous_models.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06d5_summary.txt"


def as_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def kish_ess(w):
    w = np.asarray(w, dtype=float)

    mask = (
        np.isfinite(w)
        &
        (w > 0)
    )

    w = w[mask]

    if len(w) == 0:
        return np.nan

    return float(
        (w.sum() ** 2)
        /
        np.sum(w ** 2)
    )


def normalize_weights(w):
    w = np.asarray(w, dtype=float)

    m = np.mean(w)

    if not (
        np.isfinite(m)
        and
        m > 0
    ):
        raise RuntimeError(
            "Invalid mean analysis weight."
        )

    return w / m


def fit_logit(
    df,
    outcome,
    predictors,
    weight_col,
    model_name,
    endpoint,
):
    cols = [
        outcome,
        *predictors,
    ]

    if weight_col is not None:
        cols.append(
            weight_col
        )

    x = df[
        cols
    ].copy()

    for c in [
        outcome,
        *predictors,
    ]:
        x[c] = numeric(
            x[c]
        )

    if weight_col is not None:
        x[weight_col] = numeric(
            x[weight_col]
        )

    x = x.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    if len(x) < 30:
        raise RuntimeError(
            f"{endpoint} {model_name}: too few rows ({len(x)})"
        )

    y = x[
        outcome
    ].astype(float)

    X = sm.add_constant(
        x[
            predictors
        ].astype(float),
        has_constant="add"
    )

    if weight_col is None:
        fit = sm.GLM(
            y,
            X,
            family=sm.families.Binomial()
        ).fit(
            cov_type="HC3"
        )

        w_used = np.ones(
            len(x),
            dtype=float
        )

    else:
        w_used = normalize_weights(
            x[
                weight_col
            ].to_numpy(
                dtype=float
            )
        )

        fit = sm.GLM(
            y,
            X,
            family=sm.families.Binomial(),
            freq_weights=w_used,
        ).fit(
            cov_type="HC3"
        )

    ci = fit.conf_int()

    rows = []

    for term in predictors:
        beta = float(
            fit.params[term]
        )

        lo = float(
            ci.loc[term, 0]
        )

        hi = float(
            ci.loc[term, 1]
        )

        rows.append({
            "endpoint": endpoint,
            "model": model_name,
            "N": int(
                len(x)
            ),
            "N_positive": int(
                y.sum()
            ),
            "term": term,
            "beta": beta,
            "OR": math.exp(beta),
            "OR_ci95_low": math.exp(lo),
            "OR_ci95_high": math.exp(hi),
            "p_value": float(
                fit.pvalues[term]
            ),
            "weight_ESS": kish_ess(
                w_used
            ),
        })

    return rows


def fit_continuous(
    df,
    outcome,
    weight_col,
    model_name,
    endpoint,
):
    cols = [
        outcome,
        "FSRQ",
    ]

    if weight_col is not None:
        cols.append(
            weight_col
        )

    x = df[
        cols
    ].copy()

    x[outcome] = numeric(
        x[outcome]
    )

    x["FSRQ"] = numeric(
        x["FSRQ"]
    )

    if weight_col is not None:
        x[weight_col] = numeric(
            x[weight_col]
        )

    x = x.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    x = x.loc[
        x[outcome] > 0
    ].copy()

    if len(x) < 30:
        raise RuntimeError(
            f"{endpoint} {model_name}: too few rows ({len(x)})"
        )

    y = np.log10(
        x[outcome].astype(float)
    )

    X = sm.add_constant(
        x[
            ["FSRQ"]
        ].astype(float),
        has_constant="add"
    )

    if weight_col is None:
        fit = sm.OLS(
            y,
            X
        ).fit(
            cov_type="HC3"
        )

        w_used = np.ones(
            len(x),
            dtype=float
        )

    else:
        w_used = normalize_weights(
            x[
                weight_col
            ].to_numpy(
                dtype=float
            )
        )

        fit = sm.WLS(
            y,
            X,
            weights=w_used
        ).fit(
            cov_type="HC3"
        )

    ci = fit.conf_int()

    beta = float(
        fit.params["FSRQ"]
    )

    lo = float(
        ci.loc["FSRQ", 0]
    )

    hi = float(
        ci.loc["FSRQ", 1]
    )

    return {
        "endpoint": endpoint,
        "model": model_name,
        "N": int(
            len(x)
        ),
        "N_FSRQ": int(
            x["FSRQ"].sum()
        ),
        "N_BLL": int(
            len(x) - x["FSRQ"].sum()
        ),
        "beta_log10_FSRQ": beta,
        "factor_FSRQ_vs_BLL": 10.0 ** beta,
        "factor_ci95_low": 10.0 ** lo,
        "factor_ci95_high": 10.0 ** hi,
        "p_value": float(
            fit.pvalues["FSRQ"]
        ),
        "weight_ESS": kish_ess(
            w_used
        ),
    }


# ============================================================
# LOAD + MERGE
# ============================================================

for path in [
    POP_FILE,
    WEIGHT_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

pop = pd.read_csv(
    POP_FILE
)

weights = pd.read_csv(
    WEIGHT_FILE
)

for df in [
    pop,
    weights,
]:
    df["blazar_id"] = (
        df["blazar_id"]
        .astype(str)
    )

if len(pop) != 1061:
    raise RuntimeError(
        f"Expected population N=1061; got {len(pop)}"
    )

if len(weights) != 1061:
    raise RuntimeError(
        f"Expected common-support weight N=1061; got {len(weights)}"
    )

if set(
    pop["blazar_id"]
) != set(
    weights["blazar_id"]
):
    raise RuntimeError(
        "Population and common-support weight IDs do not match."
    )

d = pop.merge(
    weights,
    on="blazar_id",
    how="left",
    validate="one_to_one"
)

for c in [
    "SW_COMMON_RAW",
    "SW_COMMON_TRIM_1_99",
    "SW_COMMON_TRIM_2P5_97P5",
]:
    if d[c].isna().any():
        raise RuntimeError(
            f"Missing common-support weight values in {c}"
        )

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

bool_cols = [
    "pdf_robust_double_both",
    "rmflux_strict_both",
    "colour_robust_central_break",
    "drw_interpretable_both",
    "core4_at_least3",
    "rmf_rmflux_eligible_g",
    "rmf_rmflux_eligible_r",
    "drw_tau_interpretable_primary_g",
    "drw_tau_interpretable_primary_r",
]

for c in bool_cols:
    if c not in d.columns:
        raise RuntimeError(
            f"Missing expected stage04 column: {c}"
        )

    d[c] = as_bool_series(
        d[c]
    )

d["RMF_BOTH_ELIGIBLE"] = (
    d["rmf_rmflux_eligible_g"]
    &
    d["rmf_rmflux_eligible_r"]
)

if int(
    d["RMF_BOTH_ELIGIBLE"].sum()
) != 899:
    raise RuntimeError(
        f"Expected RMF both-eligible N=899; got {int(d['RMF_BOTH_ELIGIBLE'].sum())}"
    )


# ============================================================
# WEIGHT SCHEMES
# ============================================================

WEIGHT_SCHEMES = [
    (
        "UNWEIGHTED",
        None
    ),
    (
        "COMMON_RAW",
        "SW_COMMON_RAW"
    ),
    (
        "COMMON_TRIM_1_99",
        "SW_COMMON_TRIM_1_99"
    ),
    (
        "COMMON_TRIM_2P5_97P5",
        "SW_COMMON_TRIM_2P5_97P5"
    ),
]


# ============================================================
# BINARY ENDPOINTS
# ============================================================

binary_specs = [
    (
        "PDF_ROBUST_DOUBLE_BOTH",
        "pdf_robust_double_both",
        d
    ),
    (
        "RMFLUX_STRICT_BOTH_ELIGIBLE",
        "rmflux_strict_both",
        d.loc[
            d["RMF_BOTH_ELIGIBLE"]
        ].copy()
    ),
    (
        "COLOUR_ROBUST_CENTRAL_BREAK",
        "colour_robust_central_break",
        d
    ),
    (
        "DRW_INTERPRETABLE_BOTH",
        "drw_interpretable_both",
        d
    ),
    (
        "CORE4_AT_LEAST3_AUDIT",
        "core4_at_least3",
        d
    ),
]

binary_rows = []

for endpoint, outcome, sample in binary_specs:
    for label, wcol in WEIGHT_SCHEMES:
        binary_rows.extend(
            fit_logit(
                df=sample,
                outcome=outcome,
                predictors=[
                    "FSRQ"
                ],
                weight_col=wcol,
                model_name=label,
                endpoint=endpoint,
            )
        )

binary_models = pd.DataFrame(
    binary_rows
)

binary_models.to_csv(
    OUT_BINARY,
    index=False
)


# ============================================================
# RMS -> COLOUR
# ============================================================

cross_sample = d.loc[
    d["RMF_BOTH_ELIGIBLE"]
].copy()

cross_rows = []

for label, wcol in WEIGHT_SCHEMES:
    cross_rows.extend(
        fit_logit(
            df=cross_sample,
            outcome="colour_robust_central_break",
            predictors=[
                "rmflux_strict_both",
                "FSRQ",
            ],
            weight_col=wcol,
            model_name=label,
            endpoint="RMFLUX_TO_COLOUR_ROBUST",
        )
    )

cross_models = pd.DataFrame(
    cross_rows
)

cross_models.to_csv(
    OUT_CROSS,
    index=False
)


# ============================================================
# CONTINUOUS FVAR + CORRECT INTERPRETABLE TAU
# ============================================================

for col in [
    "pdf_Fvar_g",
    "pdf_Fvar_r",
    "drw_tau_rest_days_g",
    "drw_tau_rest_days_r",
]:
    if col not in d.columns:
        raise RuntimeError(
            f"Missing expected stage04 column: {col}"
        )

continuous_specs = [
    (
        "FVAR_G",
        "pdf_Fvar_g",
        d
    ),
    (
        "FVAR_R",
        "pdf_Fvar_r",
        d
    ),
    (
        "TAU_REST_G_INTERPRETABLE",
        "drw_tau_rest_days_g",
        d.loc[
            d["drw_tau_interpretable_primary_g"]
        ].copy()
    ),
    (
        "TAU_REST_R_INTERPRETABLE",
        "drw_tau_rest_days_r",
        d.loc[
            d["drw_tau_interpretable_primary_r"]
        ].copy()
    ),
]

continuous_rows = []

for endpoint, outcome, sample in continuous_specs:
    for label, wcol in WEIGHT_SCHEMES:
        continuous_rows.append(
            fit_continuous(
                df=sample,
                outcome=outcome,
                weight_col=wcol,
                model_name=label,
                endpoint=endpoint,
            )
        )

continuous_models = pd.DataFrame(
    continuous_rows
)

continuous_models.to_csv(
    OUT_CONT,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06D5 FINAL SUMMARY",
    "=" * 78,
    "",
    "TARGET:",
    (
        "  Common-support Fermi population within the empirically "
        "supported ZTF/final declination overlap."
    ),
    (
        "  Endpoint sample remains the 1061 GOLD+SILVER sources; "
        "weights target the N=1548 common-support parent."
    ),
    "",
    "PRIMARY BINARY FSRQ EFFECTS:",
]

for endpoint in [
    "PDF_ROBUST_DOUBLE_BOTH",
    "RMFLUX_STRICT_BOTH_ELIGIBLE",
    "COLOUR_ROBUST_CENTRAL_BREAK",
    "DRW_INTERPRETABLE_BOTH",
    "CORE4_AT_LEAST3_AUDIT",
]:
    lines.append(
        f"  {endpoint}:"
    )

    x = binary_models.loc[
        binary_models["endpoint"].eq(endpoint)
        &
        binary_models["term"].eq("FSRQ")
    ]

    for _, rr in x.iterrows():
        lines.append(
            f"    {rr['model']}: "
            f"N={int(rr['N'])}, "
            f"OR={rr['OR']:.3f} "
            f"({rr['OR_ci95_low']:.3f}-{rr['OR_ci95_high']:.3f}), "
            f"p={rr['p_value']:.3g}, "
            f"ESS={rr['weight_ESS']:.1f}"
        )

lines += [
    "",
    "RMS -> COLOUR ASSOCIATION (RMF both-eligible sample):",
]

x = cross_models.loc[
    cross_models["term"].eq(
        "rmflux_strict_both"
    )
]

for _, rr in x.iterrows():
    lines.append(
        f"  {rr['model']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['OR']:.3f} "
        f"({rr['OR_ci95_low']:.3f}-{rr['OR_ci95_high']:.3f}), "
        f"p={rr['p_value']:.3g}, "
        f"ESS={rr['weight_ESS']:.1f}"
    )

lines += [
    "",
    "CONTINUOUS FSRQ/BLL FACTORS:",
]

for endpoint in [
    "FVAR_G",
    "FVAR_R",
    "TAU_REST_G_INTERPRETABLE",
    "TAU_REST_R_INTERPRETABLE",
]:
    lines.append(
        f"  {endpoint}:"
    )

    x = continuous_models.loc[
        continuous_models["endpoint"].eq(endpoint)
    ]

    for _, rr in x.iterrows():
        lines.append(
            f"    {rr['model']}: "
            f"N={int(rr['N'])} "
            f"(FSRQ={int(rr['N_FSRQ'])}, BLL={int(rr['N_BLL'])}), "
            f"factor={rr['factor_FSRQ_vs_BLL']:.3f} "
            f"({rr['factor_ci95_low']:.3f}-{rr['factor_ci95_high']:.3f}), "
            f"p={rr['p_value']:.3g}, "
            f"ESS={rr['weight_ESS']:.1f}"
        )

lines += [
    "",
    "INTERPRETATION NOTE:",
    (
        "  These weighted estimates address observed selection "
        "differences only within the common-support sky region. "
        "They do not identify the unsupported southern parent "
        "population excluded by the ZTF footprint."
    ),
    (
        "  Selection-model uncertainty is not propagated into the "
        "endpoint confidence intervals, so this block is used as a "
        "robustness analysis rather than a causal estimator."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 06D5")
print("FINAL COMMON-SUPPORT SELECTION-WEIGHTED ENDPOINT ROBUSTNESS")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_BINARY)
print(OUT_CROSS)
print(OUT_CONT)
print(OUT_SUMMARY)
print()
print("STAGE 06D5 COMPLETE")
