# ============================================================
# BLAZAR_I — STAGE 06D0B
# LOCATE CLEAN FERMI PARENT + PRE-QUALITY ZTF MATCH PRODUCTS
#
# Purpose:
#   Find the actual source-level files needed to model the FULL
#   selection flow:
#
#       1901 clean Fermi parent
#          -> 1456 with usable ZTF g/r coverage
#          -> 1061 GOLD+SILVER analysis sample
#
# The previous 06D0 audit found the 1456 and 1061 tables, but not
# the 1901-row clean parent table in outputs/tables.
#
# This script searches likely project folders for CSV/parquet
# products whose filenames suggest:
#   stage01 / Fermi parent / 4LAC clean sample
#   stage02b1 / crossmatch
#   stage02b2 / ledger / per-source extraction
#
# It reports row counts and relevant columns only.
# Read-only.  No upstream file is modified.
# ============================================================

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

SEARCH_DIRS = [
    ROOT / "data" / "interim",
    ROOT / "data" / "processed",
    ROOT / "outputs" / "tables",
    ROOT / "outputs" / "audit",
]

OUT = (
    ROOT / "outputs" / "audit"
    / "stage06d0b_parent_locator_audit.txt"
)

NAME_KEYS = [
    "stage01",
    "fermi",
    "parent",
    "4lac",
    "clean",
    "stage02b1",
    "02b1",
    "crossmatch",
    "stage02b2",
    "02b2",
    "ledger",
    "object",
    "source",
]

COLUMN_KEYS = [
    "blazar_id",
    "source_name",
    "assoc1",
    "class",
    "redshift",
    "sed",
    "flag",
    "clean",
    "ra_opt",
    "dec_opt",
    "signif",
    "flux1000",
    "energy_flux",
    "variability",
    "frac_variability",
    "objectid",
    "distance",
    "match",
    "has_g",
    "has_r",
]

candidates = []

for d in SEARCH_DIRS:
    if not d.exists():
        continue

    for ext in ("*.csv", "*.parquet"):
        for path in d.rglob(ext):
            # Avoid model/checkpoint forests.
            lowparts = [p.lower() for p in path.parts]
            if ".venv" in lowparts or "models" in lowparts:
                continue

            name = path.name.lower()

            if any(k in name for k in NAME_KEYS):
                candidates.append(path)

# De-duplicate, deterministic order.
candidates = sorted(set(candidates))

lines = [
    "BLAZAR_I - STAGE 06D0B PARENT / PRE-QUALITY PRODUCT LOCATOR",
    "=" * 78,
    "",
    f"Candidate files found: {len(candidates)}",
]

for path in candidates:
    rel = path.relative_to(ROOT)

    lines.append("")
    lines.append("-" * 78)
    lines.append(f"FILE: {rel}")

    try:
        if path.suffix.lower() == ".csv":
            df = pd.read_csv(path)
        elif path.suffix.lower() == ".parquet":
            df = pd.read_parquet(path)
        else:
            continue

        lines.append(
            f"  rows={len(df)} columns={len(df.columns)}"
        )

        # Highlight likely key population sizes.
        if len(df) in {1901, 1456, 1416, 2134, 5298, 6635}:
            lines.append(
                f"  *** KEY-SIZE CANDIDATE: rows={len(df)} ***"
            )

        relevant = [
            c for c in df.columns
            if any(k in c.lower() for k in COLUMN_KEYS)
        ]

        lines.append("  RELEVANT COLUMNS:")

        for c in relevant:
            s = df[c]

            line = (
                f"    {c}: dtype={s.dtype}, "
                f"nonnull={int(s.notna().sum())}, "
                f"unique={int(s.nunique(dropna=True))}"
            )

            if s.nunique(dropna=True) <= 12:
                try:
                    counts = (
                        s.value_counts(dropna=False)
                        .head(20)
                        .to_dict()
                    )
                    line += f", counts={counts}"
                except Exception:
                    pass

            lines.append(line)

    except Exception as exc:
        lines.append(
            f"  READ FAILED: {type(exc).__name__}: {exc}"
        )

text = "\n".join(lines)

OUT.write_text(
    text,
    encoding="utf-8"
)

print(text)
print()
print("AUDIT SAVED:")
print(OUT)
print()
print("STAGE 06D0B COMPLETE")
