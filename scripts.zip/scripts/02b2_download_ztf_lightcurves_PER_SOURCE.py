# ============================================================
# BLAZAR_I
# STAGE 02B2 v2
# PER-SOURCE RESUMABLE ZTF DR24 LIGHTCURVE DOWNLOAD
# ============================================================

from pathlib import Path
import argparse
import gc
import socket
import sys
import time
import traceback

import pandas as pd
import lsdb
from dask.distributed import Client

parser = argparse.ArgumentParser()
parser.add_argument("--limit", type=int, default=None)
args = parser.parse_args()

ROOT = Path(__file__).resolve().parents[1]

LEDGER_FILE = ROOT / "data" / "interim" / "stage02b1_objectid_download_ledger.csv"
PARENT_FILE = ROOT / "data" / "interim" / "stage01_parent_clean_fsrq_bll.csv"
SOURCE_DIR = ROOT / "data" / "raw" / "ztf" / "stage02b2_sources"
AUDIT_DIR = ROOT / "outputs" / "audit"

SOURCE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

ZTF_LIGHTCURVES = "s3://ipac-irsa-ztf/ztf/enhanced/dr24/lc/hats"
AWS_HOST = "ipac-irsa-ztf.s3.amazonaws.com"

MAX_ATTEMPTS = 8
DNS_ATTEMPTS = 10
DNS_WAIT_SECONDS = 30
BASE_RETRY_SECONDS = 60

FILTER_MAP = {1: "g", 2: "r", 3: "i"}
EXPECTED_FILTERID = {"zg": 1, "zr": 2, "zi": 3}

def raw_file(blazar_id):
    return SOURCE_DIR / f"{blazar_id}_RAW.parquet"

def audit_file(blazar_id):
    return SOURCE_DIR / f"{blazar_id}_objects.csv"

def done_file(blazar_id):
    return SOURCE_DIR / f"{blazar_id}.done"

def dns_is_ok():
    try:
        socket.getaddrinfo(AWS_HOST, 443, type=socket.SOCK_STREAM)
        return True
    except OSError:
        return False

def wait_for_dns():
    for attempt in range(1, DNS_ATTEMPTS + 1):
        if dns_is_ok():
            print(f"DNS OK ({attempt}/{DNS_ATTEMPTS})")
            return True
        print(f"DNS unavailable ({attempt}/{DNS_ATTEMPTS}); waiting {DNS_WAIT_SECONDS}s...")
        time.sleep(DNS_WAIT_SECONDS)
    return False

def looks_network_related(exc):
    text = (f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}").lower()
    tokens = [
        "getaddrinfo", "endpointconnection", "clientconnector",
        "could not connect", "connection reset", "connection aborted",
        "connection refused", "timed out", "timeout", "temporary failure",
        "temporarily unavailable", "ssl", "s3.amazonaws", "aiobotocore", "aiohttp",
    ]
    return any(token in text for token in tokens)

ledger = pd.read_csv(LEDGER_FILE)
parent = pd.read_csv(PARENT_FILE)

print("=" * 78)
print("BLAZAR_I — STAGE 02B2 v2")
print("PER-SOURCE RESUMABLE ZTF DR24 DOWNLOAD")
print("=" * 78)

ledger["oid"] = pd.to_numeric(ledger["oid"], errors="coerce")
ledger = ledger.dropna(subset=["blazar_id", "oid"]).copy()
ledger["oid"] = ledger["oid"].astype("int64")
ledger["filtercode"] = ledger["filtercode"].fillna("").astype(str).str.strip().str.lower()
ledger = ledger.loc[ledger["filtercode"].isin(["zg", "zr"])].copy()

parent_small = parent[["blazar_id", "ra_opt", "dec_opt"]].copy()
ledger = ledger.merge(parent_small, on="blazar_id", how="left", validate="many_to_one")

N_LEDGER = len(ledger)
N_OID = ledger["oid"].nunique()
N_SOURCE = ledger["blazar_id"].nunique()

print("Ledger rows       =", N_LEDGER)
print("Unique object IDs =", N_OID)
print("Unique blazars    =", N_SOURCE)

if N_LEDGER != N_OID:
    raise RuntimeError("Download ledger contains duplicate ZTF object IDs.")

sources = (
    ledger[["blazar_id", "ra_opt", "dec_opt"]]
    .drop_duplicates(subset=["blazar_id"])
    .sort_values(["ra_opt", "dec_opt", "blazar_id"])
    .reset_index(drop=True)
)
source_ids = sources["blazar_id"].tolist()

complete_ids = [
    bid for bid in source_ids
    if raw_file(bid).exists() and audit_file(bid).exists() and done_file(bid).exists()
]

print()
print("Completed sources on disk =", len(complete_ids), "/", len(source_ids))
print("Remaining sources         =", len(source_ids) - len(complete_ids))

print()
print("Checking ZTF/AWS DNS...")
if not wait_for_dns():
    print("DNS unavailable.")
    sys.exit(20)

print()
print("Opening ZTF DR24 Lightcurve HATS catalog...")
ztf_lc = lsdb.open_catalog(
    ZTF_LIGHTCURVES,
    columns=["objectid", "objra", "objdec", "filterid", "nepochs", "lightcurve"],
)
print("Catalog opened.")
print("Partitions =", ztf_lc.npartitions)

indexes = ztf_lc.hc_collection.all_indexes
print("Available indexes =", list(indexes.keys()))
if "objectid" not in indexes:
    raise RuntimeError("objectid index not available.")

processed_this_run = 0
session_start = time.time()

for source_number, blazar_id in enumerate(source_ids, start=1):
    RAW_OUT = raw_file(blazar_id)
    AUDIT_OUT = audit_file(blazar_id)
    DONE_OUT = done_file(blazar_id)

    if RAW_OUT.exists() and AUDIT_OUT.exists() and DONE_OUT.exists():
        continue

    if args.limit is not None and processed_this_run >= args.limit:
        print()
        print(f"Pilot limit reached: {args.limit}")
        break

    if not DONE_OUT.exists():
        if RAW_OUT.exists():
            print("Removing incomplete:", RAW_OUT.name)
            RAW_OUT.unlink()
        if AUDIT_OUT.exists():
            print("Removing incomplete:", AUDIT_OUT.name)
            AUDIT_OUT.unlink()

    src = (
        ledger.loc[ledger["blazar_id"] == blazar_id]
        .copy()
        .sort_values(["filtercode", "oid"])
        .reset_index(drop=True)
    )
    object_ids = src["oid"].astype("int64").tolist()

    print()
    print("=" * 78)
    print(f"SOURCE {source_number}/{len(source_ids)}")
    print("blazar_id        =", blazar_id)
    print("counterpart      =", src.iloc[0]["ASSOC1"])
    print("class            =", src.iloc[0]["blazar_class"])
    print("object IDs       =", len(object_ids))
    print("filters          =", ",".join(sorted(src["filtercode"].unique())))

    source_success = False

    for attempt in range(1, MAX_ATTEMPTS + 1):
        print()
        print(f"Attempt {attempt}/{MAX_ATTEMPTS}")

        if not wait_for_dns():
            if attempt == MAX_ATTEMPTS:
                break
            delay = min(BASE_RETRY_SECONDS * (2 ** (attempt - 1)), 900)
            print(f"Waiting {delay}s...")
            time.sleep(delay)
            continue

        try:
            print("Searching objectid index...")
            query = ztf_lc.id_search(values={"objectid": object_ids})
            print("Relevant LC partitions =", query.npartitions)

            t0 = time.time()
            with Client(
                n_workers=1,
                threads_per_worker=1,
                processes=False,
                memory_limit=None,
            ) as client:
                print("Dask dashboard:", client.dashboard_link)
                result = query.compute()

            elapsed = time.time() - t0
            result = result.reset_index(drop=True)

            print("LC rows returned =", len(result))
            print(f"Compute elapsed = {elapsed/60:.2f} min")

            result["objectid"] = pd.to_numeric(result["objectid"], errors="coerce")
            result = result.dropna(subset=["objectid"]).copy()
            result["objectid"] = result["objectid"].astype("int64")

            requested_set = set(object_ids)
            returned_set = set(result["objectid"].tolist())
            missing_ids = requested_set - returned_set
            extra_ids = returned_set - requested_set
            duplicate_rows = int(result["objectid"].duplicated().sum())

            print("Requested IDs    =", len(requested_set))
            print("Returned IDs     =", len(returned_set))
            print("Missing IDs      =", len(missing_ids))
            print("Duplicate rows   =", duplicate_rows)

            if extra_ids:
                raise RuntimeError("Index search returned unexpected object IDs.")
            if duplicate_rows:
                raise RuntimeError("Duplicate LC rows for an objectid.")

            object_audit = src[
                [
                    "blazar_id", "Source_Name", "ASSOC1", "blazar_class",
                    "oid", "filtercode", "ngoodobsrel", "_dist_arcsec",
                ]
            ].copy()

            object_audit["returned_lc"] = object_audit["oid"].isin(returned_set)

            result_meta = (
                result[["objectid", "filterid", "nepochs", "objra", "objdec"]]
                .copy()
                .rename(columns={"objectid": "oid"})
            )

            object_audit = object_audit.merge(
                result_meta,
                on="oid",
                how="left",
                validate="one_to_one",
            )

            object_audit["expected_filterid"] = object_audit["filtercode"].map(EXPECTED_FILTERID)
            object_audit["filter_consistent"] = (
                object_audit["filterid"] == object_audit["expected_filterid"]
            )

            bad_filter = object_audit.loc[
                object_audit["returned_lc"] & ~object_audit["filter_consistent"]
            ]
            if len(bad_filter):
                raise RuntimeError("filtercode/filterid mismatch.")

            lookup = src.drop_duplicates(subset=["oid"]).set_index("oid")
            frames = []

            for _, row in result.iterrows():
                oid = int(row["objectid"])
                nested = row["lightcurve"]

                if isinstance(nested, pd.DataFrame):
                    lc = nested.copy()
                else:
                    lc = pd.DataFrame(nested).copy()

                if len(lc) == 0:
                    continue

                info = lookup.loc[oid]
                fid = int(row["filterid"])

                lc.insert(0, "blazar_id", blazar_id)
                lc.insert(1, "fermi_name", info["Source_Name"])
                lc.insert(2, "counterpart_name", info["ASSOC1"])
                lc.insert(3, "blazar_class", info["blazar_class"])
                lc.insert(4, "ztf_objectid", oid)
                lc.insert(5, "filterid", fid)
                lc.insert(6, "filter_name", FILTER_MAP.get(fid, f"fid{fid}"))
                lc.insert(7, "match_sep_arcsec", float(info["_dist_arcsec"]))
                frames.append(lc)

            if len(frames) == 0:
                raw = pd.DataFrame(
                    columns=[
                        "blazar_id", "fermi_name", "counterpart_name", "blazar_class",
                        "ztf_objectid", "filterid", "filter_name", "match_sep_arcsec",
                        "hmjd", "mag", "magerr", "clrcoeff", "catflags",
                    ]
                )
            else:
                raw = pd.concat(frames, ignore_index=True)

            for col in ["hmjd", "mag", "magerr", "clrcoeff", "catflags"]:
                if col in raw.columns:
                    raw[col] = pd.to_numeric(raw[col], errors="coerce")

            if len(raw):
                counts = raw.groupby("ztf_objectid").size()
            else:
                counts = pd.Series(dtype="int64")

            object_audit["flattened_epochs"] = (
                object_audit["oid"].map(counts).fillna(0).astype(int)
            )

            # .done marker is deliberately written LAST.
            raw.to_parquet(RAW_OUT, index=False)
            object_audit.to_csv(AUDIT_OUT, index=False)

            DONE_OUT.write_text(
                (
                    "COMPLETE\n"
                    f"blazar_id={blazar_id}\n"
                    f"requested_oids={len(requested_set)}\n"
                    f"returned_oids={len(returned_set)}\n"
                    f"missing_oids={len(missing_ids)}\n"
                    f"raw_epochs={len(raw)}\n"
                    f"elapsed_seconds={elapsed:.3f}\n"
                ),
                encoding="utf-8",
            )

            print()
            print("RAW epochs        =", len(raw))
            print("CHECKPOINT SAVED  =", blazar_id)
            print("DONE marker       =", DONE_OUT.name)

            source_success = True
            processed_this_run += 1

            del query, result, frames, raw, object_audit
            gc.collect()
            break

        except Exception as exc:
            print()
            print("EXCEPTION:")
            print(f"{type(exc).__name__}: {exc}")

            if not looks_network_related(exc):
                traceback.print_exc()
                print()
                print("Non-network failure.")
                print("Stopping rather than silently corrupting data.")
                raise

            if attempt < MAX_ATTEMPTS:
                delay = min(BASE_RETRY_SECONDS * (2 ** (attempt - 1)), 900)
                print("Network-type error.")
                print(f"Retrying ONLY {blazar_id} after {delay}s...")
                time.sleep(delay)

    if not source_success:
        fail_path = AUDIT_DIR / "stage02b2_last_failure.txt"
        fail_path.write_text(
            (
                "BLAZAR_I STAGE 02B2 v2\n"
                "SOURCE DOWNLOAD FAILURE\n"
                f"blazar_id={blazar_id}\n"
                f"source_number={source_number}/{len(source_ids)}\n"
                "\n"
                "All previous .done sources remain safe.\n"
                "Re-run the same script to resume.\n"
            ),
            encoding="utf-8",
        )

        print()
        print("=" * 78)
        print(f"FAILED SOURCE: {blazar_id}")
        print("ALL EARLIER SOURCE CHECKPOINTS ARE SAFE.")
        print("Re-run the same script to resume.")
        sys.exit(30)

complete_now = [
    bid for bid in source_ids
    if raw_file(bid).exists() and audit_file(bid).exists() and done_file(bid).exists()
]

session_elapsed = time.time() - session_start

print()
print("=" * 78)
print("STAGE 02B2 v2 CURRENT STATUS")
print("=" * 78)
print("Completed sources =", len(complete_now), "/", len(source_ids))
print("Remaining         =", len(source_ids) - len(complete_now))
print(f"Session elapsed   = {session_elapsed/60:.2f} min")

if len(complete_now) == len(source_ids):
    print()
    print("All sources complete.")

    audit_frames = []
    total_epochs = 0

    for bid in source_ids:
        a = pd.read_csv(audit_file(bid))
        audit_frames.append(a)

        r = pd.read_parquet(
            raw_file(bid),
            columns=["ztf_objectid"],
        )
        total_epochs += len(r)

    manifest = pd.concat(audit_frames, ignore_index=True)

    MANIFEST_OUT = AUDIT_DIR / "stage02b2_object_download_manifest.csv"
    manifest.to_csv(MANIFEST_OUT, index=False)

    n_returned = int(manifest["returned_lc"].sum())
    n_missing = int((~manifest["returned_lc"]).sum())

    summary_lines = [
        "BLAZAR_I - STAGE 02B2 v2 FINAL SUMMARY",
        "=" * 72,
        f"Blazars complete        : {len(source_ids)}",
        f"Object IDs requested    : {len(manifest)}",
        f"Object IDs returned     : {n_returned}",
        f"Object IDs missing      : {n_missing}",
        f"Total RAW epochs        : {total_epochs}",
        "",
        "FLATTENED EPOCHS PER OBJECT:",
        f"  median = {manifest['flattened_epochs'].median():.1f}",
        f"  p10    = {manifest['flattened_epochs'].quantile(0.10):.1f}",
        f"  p90    = {manifest['flattened_epochs'].quantile(0.90):.1f}",
        f"  max    = {manifest['flattened_epochs'].max():.0f}",
    ]

    summary = "\n".join(summary_lines)
    SUMMARY_OUT = AUDIT_DIR / "stage02b2_summary.txt"
    SUMMARY_OUT.write_text(summary, encoding="utf-8")

    print()
    print(summary)
    print()
    print("STAGE 02B2 v2 COMPLETE")
