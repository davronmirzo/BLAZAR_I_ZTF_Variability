# ============================================================
# BLAZAR_I — STAGE 06D4A
# SKY-SUPPORT / POSITIVITY AUDIT FOR SELECTION WEIGHTING
#
# Purpose:
#   Diagnose why STAGE 06D1/06D2 IPW left residual declination
#   imbalance and why the more flexible STAGE 06D3 propensity
#   did not improve it.
#
# Questions:
#   1) Is the issue model misfit, or limited sky support?
#   2) Are there parent-sky regions with zero final selected sources?
#   3) How strongly does final retention vary with declination?
#   4) How much does the original STAGE 06D1 IPW improve the
#      declination CDF relative to the parent?
#
# Read-only. No upstream products are modified.
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

FLOW_FILE = TABLE_DIR / "stage06d1_selection_flow_master.csv"
WEIGHT_FILE = TABLE_DIR / "stage06d2_selection_weights.csv"

OUT_DEC = TABLE_DIR / "stage06d4a_decile_support.csv"
OUT_RA = TABLE_DIR / "stage06d4a_ra_support.csv"
OUT_CELL = TABLE_DIR / "stage06d4a_sky_cell_support.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06d4a_summary.txt"


def as_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def weighted_cdf_ks(parent_x, selected_x, selected_w):
    p = np.asarray(
        parent_x,
        dtype=float
    )

    s = np.asarray(
        selected_x,
        dtype=float
    )

    w = np.asarray(
        selected_w,
        dtype=float
    )

    p = p[
        np.isfinite(p)
    ]

    mask = (
        np.isfinite(s)
        &
        np.isfinite(w)
        &
        (w > 0)
    )

    s = s[mask]
    w = w[mask]

    if len(p) == 0 or len(s) == 0:
        return np.nan

    grid = np.unique(
        np.concatenate(
            [p, s]
        )
    )

    p_sorted = np.sort(p)

    s_order = np.argsort(s)
    s_sorted = s[s_order]
    w_sorted = w[s_order]

    cw = np.cumsum(w_sorted)
    total_w = cw[-1]

    p_cdf = (
        np.searchsorted(
            p_sorted,
            grid,
            side="right"
        )
        /
        len(p_sorted)
    )

    idx = (
        np.searchsorted(
            s_sorted,
            grid,
            side="right"
        )
        -
        1
    )

    s_cdf = np.zeros(
        len(grid),
        dtype=float
    )

    good = idx >= 0

    s_cdf[good] = (
        cw[idx[good]]
        /
        total_w
    )

    return float(
        np.max(
            np.abs(
                p_cdf
                -
                s_cdf
            )
        )
    )


for path in [
    FLOW_FILE,
    WEIGHT_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

flow = pd.read_csv(
    FLOW_FILE
)

weights = pd.read_csv(
    WEIGHT_FILE
)

flow[
    "blazar_id"
] = flow[
    "blazar_id"
].astype(str)

weights[
    "blazar_id"
] = weights[
    "blazar_id"
].astype(str)

flow[
    "ZTF_ANY"
] = as_bool_series(
    flow[
        "ZTF_ANY"
    ]
)

flow[
    "ANALYSIS_SELECTED"
] = as_bool_series(
    flow[
        "ANALYSIS_SELECTED"
    ]
)

if len(flow) != 1901:
    raise RuntimeError(
        f"Expected parent N=1901; got {len(flow)}"
    )

if int(
    flow[
        "ANALYSIS_SELECTED"
    ].sum()
) != 1061:
    raise RuntimeError(
        "Expected 1061 final selected sources."
    )

selected = flow.loc[
    flow[
        "ANALYSIS_SELECTED"
    ]
].copy()

selected = selected.merge(
    weights[
        [
            "blazar_id",
            "SW_RAW",
            "SW_TRIM_1_99",
            "SW_TRIM_2P5_97P5",
        ]
    ],
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

if selected[
    [
        "SW_RAW",
        "SW_TRIM_1_99",
        "SW_TRIM_2P5_97P5",
    ]
].isna().any().any():
    raise RuntimeError(
        "Weight merge produced missing values."
    )

flow[
    "ra_deg"
] = numeric(
    flow[
        "ra_opt"
    ]
)

flow[
    "dec_deg"
] = numeric(
    flow[
        "dec_opt"
    ]
)

selected[
    "ra_deg"
] = numeric(
    selected[
        "ra_opt"
    ]
)

selected[
    "dec_deg"
] = numeric(
    selected[
        "dec_opt"
    ]
)

if flow[
    [
        "ra_deg",
        "dec_deg",
    ]
].isna().any().any():
    raise RuntimeError(
        "Missing sky coordinates."
    )


# ============================================================
# DECLINATION DECILES DEFINED FROM THE PARENT
# ============================================================

# Parent equal-count deciles. duplicates='drop' is defensive, though
# unique optical coordinates make ten bins expected.
dec_codes, dec_edges = pd.qcut(
    flow[
        "dec_deg"
    ],
    q=10,
    labels=False,
    retbins=True,
    duplicates="drop",
)

n_dec_bins = len(
    dec_edges
) - 1

if n_dec_bins < 8:
    raise RuntimeError(
        f"Unexpectedly few declination quantile bins: {n_dec_bins}"
    )

flow[
    "dec_bin"
] = dec_codes.astype(int)

selected[
    "dec_bin"
] = pd.cut(
    selected[
        "dec_deg"
    ],
    bins=dec_edges,
    labels=False,
    include_lowest=True,
).astype(int)

dec_rows = []

for b in range(
    n_dec_bins
):
    p = flow.loc[
        flow[
            "dec_bin"
        ].eq(b)
    ]

    s = selected.loc[
        selected[
            "dec_bin"
        ].eq(b)
    ]

    n_parent = len(p)
    n_ztf = int(
        p[
            "ZTF_ANY"
        ].sum()
    )
    n_final = int(
        p[
            "ANALYSIS_SELECTED"
        ].sum()
    )

    dec_rows.append({
        "dec_bin": b,
        "dec_low": float(
            dec_edges[b]
        ),
        "dec_high": float(
            dec_edges[b + 1]
        ),
        "N_parent": n_parent,
        "N_ZTF_ANY": n_ztf,
        "N_final": n_final,
        "retention_parent_to_ztf": (
            n_ztf / n_parent
        ),
        "retention_ztf_to_final": (
            n_final / n_ztf
            if n_ztf > 0
            else np.nan
        ),
        "retention_parent_to_final": (
            n_final / n_parent
        ),
        "mean_p_final_06D1": float(
            numeric(
                p[
                    "p_final_analysis_full"
                ]
            ).mean()
        ),
        "sum_SW_RAW_final": float(
            numeric(
                s[
                    "SW_RAW"
                ]
            ).sum()
        ),
    })

dec_table = pd.DataFrame(
    dec_rows
)

dec_table.to_csv(
    OUT_DEC,
    index=False
)


# ============================================================
# RA SUPPORT — 12 FIXED 30-DEGREE BINS
# ============================================================

ra_edges = np.linspace(
    0.0,
    360.0,
    13
)

flow[
    "ra_bin"
] = pd.cut(
    flow[
        "ra_deg"
    ],
    bins=ra_edges,
    labels=False,
    include_lowest=True,
    right=False,
)

# protect any source exactly at RA=360 after numeric representation
flow.loc[
    flow[
        "ra_deg"
    ].eq(360.0),
    "ra_bin"
] = 11

selected[
    "ra_bin"
] = pd.cut(
    selected[
        "ra_deg"
    ],
    bins=ra_edges,
    labels=False,
    include_lowest=True,
    right=False,
)

selected.loc[
    selected[
        "ra_deg"
    ].eq(360.0),
    "ra_bin"
] = 11

flow[
    "ra_bin"
] = flow[
    "ra_bin"
].astype(int)

selected[
    "ra_bin"
] = selected[
    "ra_bin"
].astype(int)

ra_rows = []

for b in range(
    12
):
    p = flow.loc[
        flow[
            "ra_bin"
        ].eq(b)
    ]

    n_parent = len(p)
    n_ztf = int(
        p[
            "ZTF_ANY"
        ].sum()
    )
    n_final = int(
        p[
            "ANALYSIS_SELECTED"
        ].sum()
    )

    ra_rows.append({
        "ra_bin": b,
        "ra_low": float(
            ra_edges[b]
        ),
        "ra_high": float(
            ra_edges[b + 1]
        ),
        "N_parent": n_parent,
        "N_ZTF_ANY": n_ztf,
        "N_final": n_final,
        "retention_parent_to_ztf": (
            n_ztf / n_parent
            if n_parent > 0
            else np.nan
        ),
        "retention_ztf_to_final": (
            n_final / n_ztf
            if n_ztf > 0
            else np.nan
        ),
        "retention_parent_to_final": (
            n_final / n_parent
            if n_parent > 0
            else np.nan
        ),
    })

ra_table = pd.DataFrame(
    ra_rows
)

ra_table.to_csv(
    OUT_RA,
    index=False
)


# ============================================================
# 2D SKY SUPPORT: 8 RA BINS x 8 PARENT DEC QUANTILE BINS
# ============================================================

dec8_codes, dec8_edges = pd.qcut(
    flow[
        "dec_deg"
    ],
    q=8,
    labels=False,
    retbins=True,
    duplicates="drop",
)

if len(
    dec8_edges
) - 1 != 8:
    raise RuntimeError(
        "Expected exactly 8 parent dec quantile bins."
    )

flow[
    "dec8_bin"
] = dec8_codes.astype(int)

selected[
    "dec8_bin"
] = pd.cut(
    selected[
        "dec_deg"
    ],
    bins=dec8_edges,
    labels=False,
    include_lowest=True,
).astype(int)

ra8_edges = np.linspace(
    0.0,
    360.0,
    9
)

flow[
    "ra8_bin"
] = pd.cut(
    flow[
        "ra_deg"
    ],
    bins=ra8_edges,
    labels=False,
    include_lowest=True,
    right=False,
)

flow.loc[
    flow[
        "ra_deg"
    ].eq(360.0),
    "ra8_bin"
] = 7

flow[
    "ra8_bin"
] = flow[
    "ra8_bin"
].astype(int)

cell_rows = []

for rb in range(
    8
):
    for db in range(
        8
    ):
        p = flow.loc[
            flow[
                "ra8_bin"
            ].eq(rb)
            &
            flow[
                "dec8_bin"
            ].eq(db)
        ]

        n_parent = len(p)

        if n_parent == 0:
            continue

        n_ztf = int(
            p[
                "ZTF_ANY"
            ].sum()
        )

        n_final = int(
            p[
                "ANALYSIS_SELECTED"
            ].sum()
        )

        cell_rows.append({
            "ra8_bin": rb,
            "dec8_bin": db,
            "N_parent": n_parent,
            "N_ZTF_ANY": n_ztf,
            "N_final": n_final,
            "retention_parent_to_ztf": (
                n_ztf / n_parent
            ),
            "retention_ztf_to_final": (
                n_final / n_ztf
                if n_ztf > 0
                else np.nan
            ),
            "retention_parent_to_final": (
                n_final / n_parent
            ),
            "zero_ZTF_support": bool(
                n_ztf == 0
            ),
            "zero_final_support": bool(
                n_final == 0
            ),
        })

cell_table = pd.DataFrame(
    cell_rows
)

cell_table.to_csv(
    OUT_CELL,
    index=False
)


# ============================================================
# GLOBAL SUPPORT / CDF DIAGNOSTICS
# ============================================================

parent_dec = flow[
    "dec_deg"
].to_numpy(
    dtype=float
)

sel_dec = selected[
    "dec_deg"
].to_numpy(
    dtype=float
)

ks_unweighted = weighted_cdf_ks(
    parent_dec,
    sel_dec,
    np.ones(
        len(selected),
        dtype=float
    )
)

ks_raw = weighted_cdf_ks(
    parent_dec,
    sel_dec,
    selected[
        "SW_RAW"
    ]
)

ks_t1 = weighted_cdf_ks(
    parent_dec,
    sel_dec,
    selected[
        "SW_TRIM_1_99"
    ]
)

ks_t25 = weighted_cdf_ks(
    parent_dec,
    sel_dec,
    selected[
        "SW_TRIM_2P5_97P5"
    ]
)

zero_ztf_cells = int(
    cell_table[
        "zero_ZTF_support"
    ].sum()
)

zero_final_cells = int(
    cell_table[
        "zero_final_support"
    ].sum()
)

parent_cells = len(
    cell_table
)

positive_cells = cell_table.loc[
    cell_table[
        "N_final"
    ] > 0
]

min_final_cell_ret = float(
    positive_cells[
        "retention_parent_to_final"
    ].min()
)

max_final_cell_ret = float(
    positive_cells[
        "retention_parent_to_final"
    ].max()
)

dec_min_ret_bin = dec_table.sort_values(
    "retention_parent_to_final"
).iloc[0]

dec_max_ret_bin = dec_table.sort_values(
    "retention_parent_to_final",
    ascending=False
).iloc[0]


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06D4A FINAL SUMMARY",
    "=" * 78,
    "",
    "DECLINATION SUPPORT:",
    (
        f"  parent Dec range   = "
        f"{flow['dec_deg'].min():.3f} to {flow['dec_deg'].max():.3f} deg"
    ),
    (
        f"  selected Dec range = "
        f"{selected['dec_deg'].min():.3f} to {selected['dec_deg'].max():.3f} deg"
    ),
    (
        "  lowest final-retention decile: "
        f"bin={int(dec_min_ret_bin['dec_bin'])}, "
        f"Dec=[{dec_min_ret_bin['dec_low']:.2f}, "
        f"{dec_min_ret_bin['dec_high']:.2f}], "
        f"retention={dec_min_ret_bin['retention_parent_to_final']:.3f}"
    ),
    (
        "  highest final-retention decile: "
        f"bin={int(dec_max_ret_bin['dec_bin'])}, "
        f"Dec=[{dec_max_ret_bin['dec_low']:.2f}, "
        f"{dec_max_ret_bin['dec_high']:.2f}], "
        f"retention={dec_max_ret_bin['retention_parent_to_final']:.3f}"
    ),
    "",
    "2D SKY SUPPORT (8 RA bins x 8 parent-dec quantile bins):",
    (
        f"  populated parent cells = {parent_cells}"
    ),
    (
        f"  zero-ZTF cells         = {zero_ztf_cells}"
    ),
    (
        f"  zero-final cells       = {zero_final_cells}"
    ),
    (
        "  positive-cell final retention range = "
        f"{min_final_cell_ret:.3f} to {max_final_cell_ret:.3f}"
    ),
    "",
    "DECLINATION CDF DISTANCE FROM PARENT:",
    (
        f"  UNWEIGHTED             KS={ks_unweighted:.3f}"
    ),
    (
        f"  STAGE06D1 RAW IPW      KS={ks_raw:.3f}"
    ),
    (
        f"  STAGE06D1 TRIM 1-99    KS={ks_t1:.3f}"
    ),
    (
        f"  STAGE06D1 TRIM 2.5-97.5 KS={ks_t25:.3f}"
    ),
    "",
    "INTERPRETATION GUIDE:",
    (
        "  If zero-final sky cells are absent or rare and retention is "
        "nonzero across declination deciles, residual imbalance is "
        "mainly a weighting/model-calibration problem."
    ),
    (
        "  If several parent sky cells have zero final support, exact "
        "generalization to the full parent is not identifiable there; "
        "a common-support target or explicit calibration restriction "
        "is then preferable to ever more flexible propensity models."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 06D4A")
print("SKY-SUPPORT / POSITIVITY AUDIT")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_DEC)
print(OUT_RA)
print(OUT_CELL)
print(OUT_SUMMARY)
print()
print("STAGE 06D4A COMPLETE")
