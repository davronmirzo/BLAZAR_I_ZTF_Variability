# ============================================================
# BLAZAR_I — STAGE 06A
# RMS–FLUX SEGMENTATION SENSITIVITY
#
# Purpose:
#   Test whether the STAGE 03B rms–flux result depends strongly on
#   the primary 20-point occupancy segmentation.
#
# Sensitivity schemes (pre-specified here, after primary freeze):
#
#   S10_OCCUPANCY
#       consecutive 10-night segments
#
#   S20_SPAN120
#       consecutive 20-night segments, but retain only segments
#       with temporal span <= 120 d
#
#   S30_OCCUPANCY
#       consecutive 30-night segments
#
#   S90D_FIXED
#       fixed 90-day bins, retain bins with >=10 nightly points
#
# For every scheme:
#   * at least 8 retained segments are required
#   * intrinsic rms:
#       sqrt(max(S^2 - mean(err^2), 0))
#   * Spearman rho, OLS slope
#   * deterministic paired bootstrap (1000 draws)
#   * BH-FDR applied WITHIN each sensitivity scheme across all
#     eligible source-filter tests
#
# Strict-positive gate mirrors STAGE 03B:
#   rho > 0
#   OLS slope > 0
#   bootstrap 95% lower slope > 0
#   BH q <= 0.05
#
# Primary STAGE 03B files are read-only and are NOT changed.
# ============================================================

from pathlib import Path
import math
import zlib

import numpy as np
import pandas as pd

from scipy.stats import spearmanr, linregress, fisher_exact


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

SAMPLE_FILE = (
    ROOT / "outputs" / "tables"
    / "stage02b3_GOLD_PLUS_SILVER.csv"
)

NIGHTLY_DIR = (
    ROOT / "data" / "processed"
    / "stage02b3_sources"
)

PRIMARY_FILE = (
    ROOT / "outputs" / "tables"
    / "stage03b_rmflux_master.csv"
)

POP_FILE = (
    ROOT / "outputs" / "tables"
    / "stage04_population_master.csv"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_MASTER = TABLE_DIR / "stage06a_rmflux_sensitivity_master.csv"
OUT_SOURCE = TABLE_DIR / "stage06a_rmflux_sensitivity_source.csv"
OUT_COMPARE = TABLE_DIR / "stage06a_rmflux_primary_comparison.csv"
OUT_ASSOC = TABLE_DIR / "stage06a_rmflux_colour_associations.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06a_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# CONFIG
# ============================================================

MIN_SEGMENTS = 8
BOOTSTRAP_N = 1000
FDR_ALPHA = 0.05
BASE_SEED = 20260917

SCHEMES = {
    "S10_OCCUPANCY": {
        "kind": "occupancy",
        "segment_n": 10,
        "max_span_days": None,
    },
    "S20_SPAN120": {
        "kind": "occupancy",
        "segment_n": 20,
        "max_span_days": 120.0,
    },
    "S30_OCCUPANCY": {
        "kind": "occupancy",
        "segment_n": 30,
        "max_span_days": None,
    },
    "S90D_FIXED": {
        "kind": "fixed",
        "width_days": 90.0,
        "min_points_bin": 10,
    },
}


# ============================================================
# HELPERS
# ============================================================

def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)

    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw = ranked * m / np.arange(1, m + 1)

    adj = np.minimum.accumulate(
        raw[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0
    )

    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[valid] = qv

    return q


def stable_seed(blazar_id, filt, scheme):
    token = (
        f"{BASE_SEED}|{blazar_id}|{filt}|{scheme}"
    ).encode("utf-8")

    return int(
        zlib.crc32(token)
        &
        0xFFFFFFFF
    )


def bootstrap_slope(x, y, seed):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)

    if n < 2:
        return {
            "boot_valid_N": 0,
            "slope_boot_p025": np.nan,
            "slope_boot_p975": np.nan,
            "slope_boot_median": np.nan,
        }

    rng = np.random.default_rng(seed)

    idx = rng.integers(
        0,
        n,
        size=(BOOTSTRAP_N, n),
    )

    xb = x[idx]
    yb = y[idx]

    xm = xb.mean(axis=1)
    ym = yb.mean(axis=1)

    dx = xb - xm[:, None]
    dy = yb - ym[:, None]

    denom = np.sum(dx ** 2, axis=1)
    numer = np.sum(dx * dy, axis=1)

    good = (
        np.isfinite(denom)
        &
        np.isfinite(numer)
        &
        (denom > 0)
    )

    slopes = (
        numer[good]
        /
        denom[good]
    )

    slopes = slopes[
        np.isfinite(slopes)
    ]

    if len(slopes) == 0:
        return {
            "boot_valid_N": 0,
            "slope_boot_p025": np.nan,
            "slope_boot_p975": np.nan,
            "slope_boot_median": np.nan,
        }

    return {
        "boot_valid_N": int(len(slopes)),
        "slope_boot_p025": float(
            np.percentile(slopes, 2.5)
        ),
        "slope_boot_p975": float(
            np.percentile(slopes, 97.5)
        ),
        "slope_boot_median": float(
            np.median(slopes)
        ),
    }


def segment_stats(seg):
    f = seg["flux_jy"].to_numpy(dtype=float)
    e = seg["fluxerr_jy"].to_numpy(dtype=float)
    t = seg["hmjd"].to_numpy(dtype=float)

    if len(f) < 2:
        return None

    mean_f = float(np.mean(f))
    s2 = float(np.var(f, ddof=1))
    mean_e2 = float(np.mean(e ** 2))

    xs = (
        s2
        -
        mean_e2
    )

    rms_xs = math.sqrt(
        max(
            xs,
            0.0
        )
    )

    return {
        "N_points": int(len(f)),
        "hmjd_start": float(np.min(t)),
        "hmjd_end": float(np.max(t)),
        "span_days": float(np.max(t) - np.min(t)),
        "mean_flux_jy": mean_f,
        "intrinsic_rms_jy": rms_xs,
        "noise_dominated": bool(xs <= 0),
    }


def build_segments(x, cfg):
    rows = []

    if cfg["kind"] == "occupancy":

        nseg = int(cfg["segment_n"])

        n_complete = len(x) // nseg

        for j in range(n_complete):

            a = j * nseg
            b = a + nseg

            seg = x.iloc[a:b]

            st = segment_stats(seg)

            if st is None:
                continue

            max_span = cfg.get("max_span_days")

            if (
                max_span is not None
                and
                st["span_days"] > max_span
            ):
                continue

            st["segment_index"] = j + 1
            rows.append(st)

    elif cfg["kind"] == "fixed":

        width = float(
            cfg["width_days"]
        )

        min_points = int(
            cfg["min_points_bin"]
        )

        if len(x) == 0:
            return pd.DataFrame()

        # Absolute deterministic 90-d grid.
        bin_id = np.floor(
            x["hmjd"].to_numpy(dtype=float)
            /
            width
        ).astype(int)

        tmp = x.copy()
        tmp["_bin_id"] = bin_id

        jj = 0

        for _, seg in tmp.groupby(
            "_bin_id",
            sort=True
        ):

            if len(seg) < min_points:
                continue

            st = segment_stats(seg)

            if st is None:
                continue

            jj += 1
            st["segment_index"] = jj
            rows.append(st)

    else:
        raise RuntimeError(
            f"Unknown scheme kind: {cfg['kind']}"
        )

    return pd.DataFrame(rows)


def analyze_one(
    blazar_id,
    filt,
    scheme,
    cfg,
    nightly,
    meta,
):
    x = nightly.loc[
        nightly["filter_name"].eq(filt),
        [
            "hmjd",
            "flux_jy",
            "fluxerr_jy",
        ],
    ].copy()

    for c in [
        "hmjd",
        "flux_jy",
        "fluxerr_jy",
    ]:
        x[c] = pd.to_numeric(
            x[c],
            errors="coerce"
        )

    x = x.loc[
        np.isfinite(x["hmjd"])
        &
        np.isfinite(x["flux_jy"])
        &
        np.isfinite(x["fluxerr_jy"])
        &
        (x["flux_jy"] > 0)
        &
        (x["fluxerr_jy"] >= 0)
    ].sort_values(
        "hmjd"
    ).reset_index(
        drop=True
    )

    seg = build_segments(
        x,
        cfg
    )

    row = {
        "blazar_id": blazar_id,
        "blazar_class": meta.get(
            "blazar_class",
            np.nan
        ),
        "sample_tier": meta.get(
            "sample_tier",
            np.nan
        ),
        "filter_name": filt,
        "scheme": scheme,
        "N_nightly": int(len(x)),
        "N_segments": int(len(seg)),
        "fit_status": "NOT_RUN",
    }

    if len(seg) > 0:
        row["segment_span_days_median"] = float(
            seg["span_days"].median()
        )

        row["segment_span_days_p90"] = float(
            seg["span_days"].quantile(0.90)
        )

        row["noise_dominated_fraction"] = float(
            seg["noise_dominated"].mean()
        )

    if len(seg) < MIN_SEGMENTS:
        row["fit_status"] = (
            f"TOO_FEW_SEGMENTS_LT_{MIN_SEGMENTS}"
        )

        return row

    xx = seg["mean_flux_jy"].to_numpy(dtype=float)
    yy = seg["intrinsic_rms_jy"].to_numpy(dtype=float)

    good = (
        np.isfinite(xx)
        &
        np.isfinite(yy)
        &
        (xx > 0)
        &
        (yy >= 0)
    )

    xx = xx[good]
    yy = yy[good]

    if len(xx) < MIN_SEGMENTS:
        row["fit_status"] = (
            f"TOO_FEW_FINITE_SEGMENTS_LT_{MIN_SEGMENTS}"
        )

        return row

    if (
        np.allclose(xx, xx[0])
        or
        np.allclose(yy, yy[0])
    ):
        row["fit_status"] = "DEGENERATE_RELATION"
        return row

    rho, p = spearmanr(
        xx,
        yy
    )

    lr = linregress(
        xx,
        yy
    )

    boot = bootstrap_slope(
        xx,
        yy,
        stable_seed(
            blazar_id,
            filt,
            scheme
        )
    )

    row.update({
        "N_segments_fit": int(len(xx)),
        "spearman_rho": float(rho),
        "spearman_p": float(p),
        "ols_slope": float(lr.slope),
        "ols_intercept_jy": float(lr.intercept),
        "ols_pvalue": float(lr.pvalue),
        **boot,
        "fit_status": "OK",
    })

    return row


def odds_ratio_2x2(a, b):
    a = np.asarray(a, dtype=bool)
    b = np.asarray(b, dtype=bool)

    # A positive/negative x B positive/negative
    n11 = int(np.sum(a & b))
    n10 = int(np.sum(a & ~b))
    n01 = int(np.sum(~a & b))
    n00 = int(np.sum(~a & ~b))

    table = np.array(
        [
            [n11, n10],
            [n01, n00],
        ],
        dtype=int,
    )

    orr, p = fisher_exact(
        table,
        alternative="two-sided"
    )

    return {
        "both_positive": n11,
        "A_only": n10,
        "B_only": n01,
        "neither": n00,
        "odds_ratio": float(orr),
        "fisher_p": float(p),
    }


# ============================================================
# LOAD
# ============================================================

for path in [
    SAMPLE_FILE,
    PRIMARY_FILE,
    POP_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

sample = pd.read_csv(SAMPLE_FILE)
primary = pd.read_csv(PRIMARY_FILE)
pop = pd.read_csv(POP_FILE)

sample["blazar_id"] = (
    sample["blazar_id"]
    .astype(str)
)

primary["blazar_id"] = (
    primary["blazar_id"]
    .astype(str)
)

pop["blazar_id"] = (
    pop["blazar_id"]
    .astype(str)
)

source_ids = (
    sample["blazar_id"]
    .drop_duplicates()
    .tolist()
)

lookup = (
    sample
    .drop_duplicates("blazar_id")
    .set_index("blazar_id")
)

N_SOURCE = len(source_ids)

if N_SOURCE != 1061:
    raise RuntimeError(
        f"Expected 1061 sources; got {N_SOURCE}"
    )


# ============================================================
# RUN ALL SENSITIVITIES
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 06A")
print("RMS–FLUX SEGMENTATION SENSITIVITY")
print("=" * 78)

rows = []

for i, blazar_id in enumerate(
    source_ids,
    start=1
):

    nightly_path = (
        NIGHTLY_DIR
        /
        f"{blazar_id}_NIGHTLY.parquet"
    )

    if not nightly_path.exists():
        raise FileNotFoundError(
            nightly_path
        )

    nightly = pd.read_parquet(
        nightly_path
    )

    meta = (
        lookup
        .loc[blazar_id]
        .to_dict()
    )

    for scheme, cfg in SCHEMES.items():

        for filt in [
            "g",
            "r",
        ]:

            rows.append(
                analyze_one(
                    blazar_id=blazar_id,
                    filt=filt,
                    scheme=scheme,
                    cfg=cfg,
                    nightly=nightly,
                    meta=meta,
                )
            )

    if (
        i % 100 == 0
        or
        i == N_SOURCE
    ):
        print(
            f"Processed {i}/{N_SOURCE}"
        )

master = pd.DataFrame(
    rows
)


# ============================================================
# FDR + STRICT FLAGS WITHIN EACH SCHEME
# ============================================================

master[
    "spearman_q_bh_scheme"
] = np.nan

master[
    "strict_positive_rmflux"
] = False

for scheme in SCHEMES:

    mask = (
        master["scheme"].eq(scheme)
        &
        master["fit_status"].eq("OK")
        &
        np.isfinite(
            pd.to_numeric(
                master["spearman_p"],
                errors="coerce"
            )
        )
    )

    idx = master.index[mask]

    master.loc[
        idx,
        "spearman_q_bh_scheme"
    ] = bh_qvalues(
        master.loc[
            idx,
            "spearman_p"
        ].to_numpy(dtype=float)
    )

    strict = (
        mask
        &
        (master["spearman_rho"] > 0)
        &
        (master["ols_slope"] > 0)
        &
        (master["slope_boot_p025"] > 0)
        &
        (
            master["spearman_q_bh_scheme"]
            <=
            FDR_ALPHA
        )
    )

    master.loc[
        strict,
        "strict_positive_rmflux"
    ] = True

master.to_csv(
    OUT_MASTER,
    index=False
)


# ============================================================
# SOURCE-LEVEL FLAGS BY SCHEME
# ============================================================

source_rows = []

for scheme in SCHEMES:

    x = master.loc[
        master["scheme"].eq(scheme)
    ]

    piv_strict = x.pivot(
        index="blazar_id",
        columns="filter_name",
        values="strict_positive_rmflux"
    )

    piv_ok = x.assign(
        eligible=x["fit_status"].eq("OK")
    ).pivot(
        index="blazar_id",
        columns="filter_name",
        values="eligible"
    )

    for bid in source_ids:

        sg = bool(
            piv_strict.loc[bid, "g"]
        )

        sr = bool(
            piv_strict.loc[bid, "r"]
        )

        eg = bool(
            piv_ok.loc[bid, "g"]
        )

        er = bool(
            piv_ok.loc[bid, "r"]
        )

        source_rows.append({
            "blazar_id": bid,
            "scheme": scheme,
            "eligible_g": eg,
            "eligible_r": er,
            "eligible_both": eg and er,
            "strict_g": sg,
            "strict_r": sr,
            "strict_any": sg or sr,
            "strict_both": sg and sr,
        })

source = pd.DataFrame(
    source_rows
)

source = source.merge(
    sample[
        [
            "blazar_id",
            "blazar_class",
            "sample_tier",
        ]
    ].drop_duplicates(
        "blazar_id"
    ),
    on="blazar_id",
    how="left",
    validate="many_to_one"
)

source.to_csv(
    OUT_SOURCE,
    index=False
)


# ============================================================
# PRIMARY COMPARISON
# ============================================================

p = primary.assign(
    eligible_primary=primary["fit_status"].eq("OK")
).pivot(
    index="blazar_id",
    columns="filter_name",
    values=[
        "eligible_primary",
        "strict_positive_rmflux",
    ],
)

compare_rows = []

for scheme in SCHEMES:

    xs = source.loc[
        source["scheme"].eq(scheme)
    ].set_index("blazar_id")

    for filt in [
        "g",
        "r",
    ]:

        pe = (
            p[
                (
                    "eligible_primary",
                    filt
                )
            ]
            .fillna(False)
            .astype(bool)
        )

        ps = (
            p[
                (
                    "strict_positive_rmflux",
                    filt
                )
            ]
            .fillna(False)
            .astype(bool)
        )

        se = xs[
            f"eligible_{filt}"
        ].astype(bool)

        ss = xs[
            f"strict_{filt}"
        ].astype(bool)

        common = pe & se

        n_common = int(
            common.sum()
        )

        agreement = (
            float(
                (ps[common] == ss[common]).mean()
            )
            if n_common
            else np.nan
        )

        inter = int(
            (ps[common] & ss[common]).sum()
        )

        union = int(
            (ps[common] | ss[common]).sum()
        )

        jaccard = (
            inter / union
            if union > 0
            else np.nan
        )

        compare_rows.append({
            "scheme": scheme,
            "filter_name": filt,
            "N_common_eligible": n_common,
            "primary_strict_in_common": int(
                ps[common].sum()
            ),
            "sensitivity_strict_in_common": int(
                ss[common].sum()
            ),
            "classification_agreement": agreement,
            "strict_positive_jaccard": jaccard,
        })

compare = pd.DataFrame(
    compare_rows
)

compare.to_csv(
    OUT_COMPARE,
    index=False
)


# ============================================================
# ASSOCIATION WITH ROBUST COLOUR BREAK
# ============================================================

pop2 = pop[
    [
        "blazar_id",
        "colour_robust_central_break",
        "blazar_class",
    ]
].copy()

pop2[
    "colour_robust_central_break"
] = (
    pop2[
        "colour_robust_central_break"
    ]
    .astype(str)
    .str.lower()
    .isin(
        ["true", "1", "yes"]
    )
)

assoc_rows = []

for scheme in SCHEMES:

    xs = source.loc[
        source["scheme"].eq(scheme)
    ].merge(
        pop2,
        on=[
            "blazar_id",
            "blazar_class",
        ],
        how="left",
        validate="one_to_one"
    )

    # Main comparison restricted to both-band eligible sources.
    xx = xs.loc[
        xs["eligible_both"]
    ]

    st = odds_ratio_2x2(
        xx["strict_both"],
        xx["colour_robust_central_break"],
    )

    assoc_rows.append({
        "scheme": scheme,
        "N_both_band_eligible": int(len(xx)),
        "strict_both_N": int(
            xx["strict_both"].sum()
        ),
        "robust_colour_break_N": int(
            xx["colour_robust_central_break"].sum()
        ),
        **st,
    })

assoc = pd.DataFrame(
    assoc_rows
)

assoc.to_csv(
    OUT_ASSOC,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06A RMS-FLUX SENSITIVITY SUMMARY",
    "=" * 72,
]

for scheme in SCHEMES:

    x = master.loc[
        master["scheme"].eq(scheme)
    ]

    s = source.loc[
        source["scheme"].eq(scheme)
    ]

    lines += [
        "",
        f"{scheme}:",
        (
            "  eligible source-filter rows = "
            f"{int((x['fit_status']=='OK').sum())}"
        ),
        (
            "  strict-positive source-filter rows = "
            f"{int(x['strict_positive_rmflux'].sum())}"
        ),
        (
            "  sources strict >=1 band = "
            f"{int(s['strict_any'].sum())}"
        ),
        (
            "  sources strict both bands = "
            f"{int(s['strict_both'].sum())}"
        ),
        (
            "  sources eligible both bands = "
            f"{int(s['eligible_both'].sum())}"
        ),
    ]

    aa = assoc.loc[
        assoc["scheme"].eq(scheme)
    ].iloc[0]

    lines.append(
        "  strict-both vs robust colour break: "
        f"OR={aa['odds_ratio']:.3f}, "
        f"p={aa['fisher_p']:.3g}"
    )

lines += [
    "",
    "PRIMARY-vs-SENSITIVITY AGREEMENT:",
]

for _, rr in compare.iterrows():

    lines.append(
        f"  {rr['scheme']} {rr['filter_name']}: "
        f"Ncommon={int(rr['N_common_eligible'])}, "
        f"agreement={rr['classification_agreement']:.3f}, "
        f"Jaccard={rr['strict_positive_jaccard']:.3f}"
    )

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)

print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_MASTER)
print(OUT_SOURCE)
print(OUT_COMPARE)
print(OUT_ASSOC)
print(OUT_SUMMARY)
print()
print("STAGE 06A COMPLETE")
