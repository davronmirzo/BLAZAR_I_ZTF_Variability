# ============================================================
# BLAZAR_I — STAGE 06D4B
# COMMON-SUPPORT TWO-STAGE SELECTION MODEL + BALANCE AUDIT
#
# Motivation:
#   STAGE 06D4A demonstrated a structural positivity violation:
#   the clean Fermi parent extends to Dec ~ -85.7 deg, whereas the
#   final ZTF analysis sample starts at Dec ~ -31.3 deg. The lowest
#   parent declination decile has zero final retention, and 8/64
#   coarse sky cells have zero final support.
#
# Therefore exact IPW generalization to the full 1901-source parent
# is not identifiable over the unsupported southern sky.
#
# Target population for this stage:
#   empirical sky-overlap/common-support parent
#   Dec >= min(Dec of final selected sample)
#   Dec <= max(Dec of final selected sample)
#
# Within this common-support target we refit the ORIGINAL, compact
# STAGE 06D1 parent-level propensity model:
#
#   FSRQ
#   RA_sin, RA_cos
#   Dec, Dec^2
#   SED_HSP, SED_ISP, SED_UNKNOWN  [LSP reference]
#   redshift_known
#   log10(Energy_Flux100_DR4)
#   log1p(Variability_Index_DR4)
#
# No downstream ZTF quality variables are used.
#
# Outputs:
#   common-support flow table
#   two-stage propensity model table
#   common-support weights
#   balance diagnostics + summary
#
# Endpoint inference is intentionally deferred until balance is
# inspected.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

FLOW_FILE = TABLE_DIR / "stage06d1_selection_flow_master.csv"

OUT_FLOW = TABLE_DIR / "stage06d4b_common_support_flow.csv"
OUT_MODELS = TABLE_DIR / "stage06d4b_common_support_models.csv"
OUT_WEIGHTS = TABLE_DIR / "stage06d4b_common_support_weights.csv"
OUT_BALANCE = TABLE_DIR / "stage06d4b_common_support_balance.csv"
OUT_BALANCE_SUMMARY = TABLE_DIR / "stage06d4b_common_support_balance_summary.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06d4b_summary.txt"


# ============================================================
# HELPERS
# ============================================================

def as_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def kish_ess(w):
    w = np.asarray(w, dtype=float)

    mask = (
        np.isfinite(w)
        &
        (w > 0)
    )

    w = w[mask]

    if len(w) == 0:
        return np.nan

    return float(
        (w.sum() ** 2)
        /
        np.sum(w ** 2)
    )


def weighted_mean(x, w):
    x = np.asarray(x, dtype=float)
    w = np.asarray(w, dtype=float)

    mask = (
        np.isfinite(x)
        &
        np.isfinite(w)
        &
        (w > 0)
    )

    if mask.sum() == 0:
        return np.nan

    return float(
        np.average(
            x[mask],
            weights=w[mask]
        )
    )


def weighted_cdf_ks(parent_x, selected_x, selected_w):
    p = np.asarray(parent_x, dtype=float)
    s = np.asarray(selected_x, dtype=float)
    w = np.asarray(selected_w, dtype=float)

    p = p[np.isfinite(p)]

    mask = (
        np.isfinite(s)
        &
        np.isfinite(w)
        &
        (w > 0)
    )

    s = s[mask]
    w = w[mask]

    if len(p) == 0 or len(s) == 0:
        return np.nan

    grid = np.unique(
        np.concatenate([p, s])
    )

    p_sorted = np.sort(p)

    order = np.argsort(s)
    s_sorted = s[order]
    w_sorted = w[order]

    cw = np.cumsum(w_sorted)
    total_w = cw[-1]

    p_cdf = (
        np.searchsorted(
            p_sorted,
            grid,
            side="right"
        )
        /
        len(p_sorted)
    )

    idx = (
        np.searchsorted(
            s_sorted,
            grid,
            side="right"
        )
        -
        1
    )

    s_cdf = np.zeros(
        len(grid),
        dtype=float
    )

    good = idx >= 0

    s_cdf[good] = (
        cw[idx[good]]
        /
        total_w
    )

    return float(
        np.max(
            np.abs(
                p_cdf - s_cdf
            )
        )
    )


# ============================================================
# LOAD + COMMON-SUPPORT DEFINITION
# ============================================================

if not FLOW_FILE.exists():
    raise FileNotFoundError(
        FLOW_FILE
    )

flow = pd.read_csv(
    FLOW_FILE
)

flow["blazar_id"] = (
    flow["blazar_id"]
    .astype(str)
)

flow["ZTF_ANY"] = as_bool_series(
    flow["ZTF_ANY"]
)

flow["ANALYSIS_SELECTED"] = as_bool_series(
    flow["ANALYSIS_SELECTED"]
)

if len(flow) != 1901:
    raise RuntimeError(
        f"Expected parent N=1901; got {len(flow)}"
    )

final_full = flow.loc[
    flow["ANALYSIS_SELECTED"]
].copy()

if len(final_full) != 1061:
    raise RuntimeError(
        f"Expected final N=1061; got {len(final_full)}"
    )

flow["dec_opt"] = numeric(
    flow["dec_opt"]
)

flow["ra_opt"] = numeric(
    flow["ra_opt"]
)

if flow[
    ["ra_opt", "dec_opt"]
].isna().any().any():
    raise RuntimeError(
        "Missing parent sky coordinates."
    )

dec_support_lo = float(
    final_full["dec_opt"].min()
)

dec_support_hi = float(
    final_full["dec_opt"].max()
)

common = flow.loc[
    flow["dec_opt"].between(
        dec_support_lo,
        dec_support_hi,
        inclusive="both"
    )
].copy()

if len(common) == 0:
    raise RuntimeError(
        "Common-support sample is empty."
    )

final = common.loc[
    common["ANALYSIS_SELECTED"]
].copy()

ztf = common.loc[
    common["ZTF_ANY"]
].copy()

# All selected sources should lie inside this empirical overlap target.
if len(final) != 1061:
    raise RuntimeError(
        f"Expected all 1061 selected sources inside common support; got {len(final)}"
    )


# ============================================================
# PARENT-LEVEL PREDICTORS
# ============================================================

common["FSRQ"] = (
    common["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

common["redshift_known"] = (
    numeric(
        common["redshift_clean"]
    )
    .notna()
    .astype(int)
)

sed = (
    common["SED_class_clean"]
    .fillna("UNKNOWN")
    .astype(str)
    .str.strip()
    .str.upper()
)

common["SED_HSP"] = sed.eq(
    "HSP"
).astype(int)

common["SED_ISP"] = sed.eq(
    "ISP"
).astype(int)

common["SED_UNKNOWN"] = sed.eq(
    "UNKNOWN"
).astype(int)

ra_rad = np.deg2rad(
    common["ra_opt"].to_numpy(
        dtype=float
    )
)

common["RA_sin"] = np.sin(
    ra_rad
)

common["RA_cos"] = np.cos(
    ra_rad
)

common["Dec_deg"] = (
    common["dec_opt"]
)

common["Dec2"] = (
    common["Dec_deg"] ** 2
)

energy = numeric(
    common["Energy_Flux100_DR4"]
)

varidx = numeric(
    common["Variability_Index_DR4"]
)

if (
    energy.isna().any()
    or
    (energy <= 0).any()
):
    raise RuntimeError(
        "Energy_Flux100_DR4 must be finite and >0 in common support."
    )

if (
    varidx.isna().any()
    or
    (varidx < 0).any()
):
    raise RuntimeError(
        "Variability_Index_DR4 must be finite and >=0 in common support."
    )

common["logEnergyFlux_DR4"] = np.log10(
    energy
)

common["log1pVarIndex_DR4"] = np.log1p(
    varidx
)

# refresh subsets after predictor construction
ztf = common.loc[
    common["ZTF_ANY"]
].copy()

final = common.loc[
    common["ANALYSIS_SELECTED"]
].copy()


# ============================================================
# MODEL FITTER
# ============================================================

PREDICTORS = [
    "FSRQ",
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "Dec2",
    "SED_HSP",
    "SED_ISP",
    "SED_UNKNOWN",
    "redshift_known",
    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",
]

CONTINUOUS = [
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "Dec2",
    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",
]


def fit_stage(
    train_df,
    apply_df,
    outcome,
    stage_name,
):
    train = train_df[
        [
            outcome,
            *PREDICTORS,
        ]
    ].copy()

    apply = apply_df[
        PREDICTORS
    ].copy()

    for c in [
        outcome,
        *PREDICTORS,
    ]:
        train[c] = numeric(
            train[c]
        )

    for c in PREDICTORS:
        apply[c] = numeric(
            apply[c]
        )

    train = train.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    if apply.replace(
        [np.inf, -np.inf],
        np.nan
    ).isna().any().any():
        raise RuntimeError(
            f"{stage_name}: apply set has missing predictors."
        )

    scaling = {}

    for c in CONTINUOUS:
        mu = float(
            train[c].mean()
        )

        sd = float(
            train[c].std(
                ddof=1
            )
        )

        if not (
            np.isfinite(sd)
            and
            sd > 0
        ):
            raise RuntimeError(
                f"{stage_name}: invalid SD for {c}"
            )

        train[c] = (
            train[c] - mu
        ) / sd

        apply[c] = (
            apply[c] - mu
        ) / sd

        scaling[c] = (
            mu,
            sd
        )

    y = train[
        outcome
    ].astype(float)

    X = sm.add_constant(
        train[
            PREDICTORS
        ].astype(float),
        has_constant="add"
    )

    fit = sm.GLM(
        y,
        X,
        family=sm.families.Binomial()
    ).fit(
        cov_type="HC3"
    )

    X_apply = sm.add_constant(
        apply[
            PREDICTORS
        ].astype(float),
        has_constant="add"
    )

    pred = np.asarray(
        fit.predict(
            X_apply
        ),
        dtype=float
    )

    ci = fit.conf_int()

    rows = []

    for term in fit.params.index:
        beta = float(
            fit.params[term]
        )

        lo = float(
            ci.loc[
                term,
                0
            ]
        )

        hi = float(
            ci.loc[
                term,
                1
            ]
        )

        rows.append({
            "stage": stage_name,
            "N_model": int(
                len(train)
            ),
            "N_positive": int(
                y.sum()
            ),
            "term": term,
            "beta": beta,
            "OR": (
                math.exp(beta)
                if term != "const"
                else np.nan
            ),
            "OR_ci95_low": (
                math.exp(lo)
                if term != "const"
                else np.nan
            ),
            "OR_ci95_high": (
                math.exp(hi)
                if term != "const"
                else np.nan
            ),
            "p_value": float(
                fit.pvalues[term]
            ),
            "AIC": float(
                fit.aic
            ),
            "deviance": float(
                fit.deviance
            ),
        })

    return pred, rows


# ============================================================
# FIT TWO-STAGE COMMON-SUPPORT PROPENSITY
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 06D4B")
print("COMMON-SUPPORT TWO-STAGE SELECTION MODEL + BALANCE")
print("=" * 78)

model_rows = []

p1, rows1 = fit_stage(
    train_df=common,
    apply_df=common,
    outcome="ZTF_ANY",
    stage_name="STAGE1_COMMON_PARENT_TO_ZTF_ANY",
)

model_rows.extend(
    rows1
)

common["p_stage1_common"] = p1

ztf = common.loc[
    common["ZTF_ANY"]
].copy()

p2, rows2 = fit_stage(
    train_df=ztf,
    apply_df=ztf,
    outcome="ANALYSIS_SELECTED",
    stage_name="STAGE2_COMMON_ZTF_TO_ANALYSIS",
)

model_rows.extend(
    rows2
)

p2_map = dict(
    zip(
        ztf["blazar_id"],
        p2,
    )
)

common["p_stage2_common"] = (
    common["blazar_id"]
    .map(
        p2_map
    )
)

common["p_final_common"] = (
    common["p_stage1_common"]
    *
    common["p_stage2_common"]
)

models = pd.DataFrame(
    model_rows
)

models.to_csv(
    OUT_MODELS,
    index=False
)


# ============================================================
# COMMON-SUPPORT STABILIZED WEIGHTS
# ============================================================

final = common.loc[
    common["ANALYSIS_SELECTED"]
].copy()

pf = numeric(
    final["p_final_common"]
)

if (
    pf.isna().any()
    or
    (pf <= 0).any()
    or
    (pf >= 1).any()
):
    raise RuntimeError(
        "Invalid common-support final probabilities."
    )

marginal_final = (
    len(final)
    /
    len(common)
)

final["SW_COMMON_RAW"] = (
    marginal_final
    /
    pf
)

q01 = float(
    final[
        "SW_COMMON_RAW"
    ].quantile(
        0.01
    )
)

q99 = float(
    final[
        "SW_COMMON_RAW"
    ].quantile(
        0.99
    )
)

q025 = float(
    final[
        "SW_COMMON_RAW"
    ].quantile(
        0.025
    )
)

q975 = float(
    final[
        "SW_COMMON_RAW"
    ].quantile(
        0.975
    )
)

final["SW_COMMON_TRIM_1_99"] = (
    final["SW_COMMON_RAW"]
    .clip(
        lower=q01,
        upper=q99
    )
)

final["SW_COMMON_TRIM_2P5_97P5"] = (
    final["SW_COMMON_RAW"]
    .clip(
        lower=q025,
        upper=q975
    )
)

weights = final[
    [
        "blazar_id",
        "p_stage1_common",
        "p_stage2_common",
        "p_final_common",
        "SW_COMMON_RAW",
        "SW_COMMON_TRIM_1_99",
        "SW_COMMON_TRIM_2P5_97P5",
    ]
].copy()

weights.to_csv(
    OUT_WEIGHTS,
    index=False
)


# ============================================================
# BALANCE
# ============================================================

BALANCE_VARS = [
    "FSRQ",
    "redshift_known",
    "SED_HSP",
    "SED_ISP",
    "SED_UNKNOWN",
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "Dec2",
    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",
]

WEIGHT_SCHEMES = [
    (
        "UNWEIGHTED",
        None
    ),
    (
        "COMMON_RAW",
        "SW_COMMON_RAW"
    ),
    (
        "COMMON_TRIM_1_99",
        "SW_COMMON_TRIM_1_99"
    ),
    (
        "COMMON_TRIM_2P5_97P5",
        "SW_COMMON_TRIM_2P5_97P5"
    ),
]

balance_rows = []

for var in BALANCE_VARS:
    px = numeric(
        common[var]
    )

    sx = numeric(
        final[var]
    )

    parent_mean = float(
        px.mean()
    )

    parent_sd = float(
        px.std(
            ddof=1
        )
    )

    if not (
        np.isfinite(parent_sd)
        and
        parent_sd > 0
    ):
        parent_sd = 1.0

    for label, wcol in WEIGHT_SCHEMES:
        if wcol is None:
            w = np.ones(
                len(final),
                dtype=float
            )
        else:
            w = numeric(
                final[wcol]
            ).to_numpy(
                dtype=float
            )

        sample_mean = weighted_mean(
            sx,
            w
        )

        balance_rows.append({
            "variable": var,
            "weight_scheme": label,
            "parent_mean": parent_mean,
            "selected_mean": sample_mean,
            "difference": (
                sample_mean
                -
                parent_mean
            ),
            "standardized_difference": (
                (
                    sample_mean
                    -
                    parent_mean
                )
                /
                parent_sd
            ),
        })

balance = pd.DataFrame(
    balance_rows
)

balance["abs_standardized_difference"] = np.abs(
    numeric(
        balance[
            "standardized_difference"
        ]
    )
)

balance.to_csv(
    OUT_BALANCE,
    index=False
)


# ============================================================
# BALANCE SUMMARY
# ============================================================

summary_rows = []

for label, wcol in WEIGHT_SCHEMES:
    x = balance.loc[
        balance[
            "weight_scheme"
        ].eq(label)
    ].copy()

    worst = x.sort_values(
        "abs_standardized_difference",
        ascending=False
    ).iloc[0]

    if wcol is None:
        w = np.ones(
            len(final),
            dtype=float
        )
    else:
        w = numeric(
            final[wcol]
        ).to_numpy(
            dtype=float
        )

    dec_ks = weighted_cdf_ks(
        parent_x=common["Dec_deg"],
        selected_x=final["Dec_deg"],
        selected_w=w,
    )

    summary_rows.append({
        "weight_scheme": label,
        "max_abs_smd": float(
            x[
                "abs_standardized_difference"
            ].max()
        ),
        "mean_abs_smd": float(
            x[
                "abs_standardized_difference"
            ].mean()
        ),
        "median_abs_smd": float(
            x[
                "abs_standardized_difference"
            ].median()
        ),
        "worst_variable": worst[
            "variable"
        ],
        "worst_abs_smd": float(
            worst[
                "abs_standardized_difference"
            ]
        ),
        "dec_weighted_KS": dec_ks,
        "weight_ESS": kish_ess(
            w
        ),
    })

balance_summary = pd.DataFrame(
    summary_rows
)

balance_summary.to_csv(
    OUT_BALANCE_SUMMARY,
    index=False
)

common.to_csv(
    OUT_FLOW,
    index=False
)


# ============================================================
# TEXT SUMMARY
# ============================================================

p1_final = numeric(
    final[
        "p_stage1_common"
    ]
)

p2_final = numeric(
    final[
        "p_stage2_common"
    ]
)

pf_final = numeric(
    final[
        "p_final_common"
    ]
)

wraw = numeric(
    final[
        "SW_COMMON_RAW"
    ]
)

lines = [
    "BLAZAR_I - STAGE 06D4B FINAL SUMMARY",
    "=" * 78,
    "",
    "COMMON-SUPPORT TARGET:",
    (
        f"  Dec overlap = "
        f"{dec_support_lo:.3f} to {dec_support_hi:.3f} deg"
    ),
    (
        f"  Parent target N = {len(common)} / 1901"
    ),
    (
        f"  ZTF_ANY N       = {int(common['ZTF_ANY'].sum())}"
    ),
    (
        f"  Final analysis N= {len(final)}"
    ),
    (
        f"  Parent target retained fraction = "
        f"{len(final)/len(common):.3f}"
    ),
    "",
    "COMMON-SUPPORT PROPENSITY / WEIGHTS:",
    (
        "  p_stage1_common: "
        f"min={p1_final.min():.4f}, "
        f"p01={p1_final.quantile(0.01):.4f}, "
        f"median={p1_final.median():.4f}"
    ),
    (
        "  p_stage2_common: "
        f"min={p2_final.min():.4f}, "
        f"p01={p2_final.quantile(0.01):.4f}, "
        f"median={p2_final.median():.4f}"
    ),
    (
        "  p_final_common:  "
        f"min={pf_final.min():.4f}, "
        f"p01={pf_final.quantile(0.01):.4f}, "
        f"median={pf_final.median():.4f}"
    ),
    (
        "  SW_COMMON_RAW:   "
        f"median={wraw.median():.3f}, "
        f"p95={wraw.quantile(0.95):.3f}, "
        f"p99={wraw.quantile(0.99):.3f}, "
        f"max={wraw.max():.3f}"
    ),
    "",
    "COMMON-SUPPORT BALANCE:",
]

for _, rr in balance_summary.iterrows():
    lines.append(
        f"  {rr['weight_scheme']}: "
        f"max|SMD|={rr['max_abs_smd']:.3f}, "
        f"mean|SMD|={rr['mean_abs_smd']:.3f}, "
        f"median|SMD|={rr['median_abs_smd']:.3f}, "
        f"worst={rr['worst_variable']} "
        f"({rr['worst_abs_smd']:.3f}), "
        f"Dec_KS={rr['dec_weighted_KS']:.3f}, "
        f"ESS={rr['weight_ESS']:.1f}"
    )

lines += [
    "",
    "INTERPRETATION:",
    (
        "  These weights target only the empirically observed ZTF/final "
        "sky-overlap population. They must not be described as "
        "generalizing to the unsupported southern part of the full "
        "1901-source Fermi parent."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_FLOW)
print(OUT_MODELS)
print(OUT_WEIGHTS)
print(OUT_BALANCE)
print(OUT_BALANCE_SUMMARY)
print(OUT_SUMMARY)
print()
print("STAGE 06D4B COMPLETE")
