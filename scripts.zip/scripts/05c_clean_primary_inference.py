# ============================================================
# BLAZAR_I — STAGE 05C
# CLEAN PRIMARY INFERENCE + SED-OVERLAP CONTROL
#
# Motivation from STAGE 05B:
#   * The FSRQ rms–flux OR jumps strongly only after adding
#     noise_dominated_fraction, a diagnostic-internal quantity.
#   * g/r segment-count and segment-span covariates show moderate
#     collinearity (VIF ~5–6).
#   * SED class is strongly imbalanced with optical class:
#       FSRQ: 305 LSP, 13 ISP, 1 HSP
#       BLL : 193 LSP, 205 ISP, 222 HSP
#
# Therefore this stage:
#   1) Defines "clean" class models using only pre-diagnostic
#      observation-coverage controls.
#   2) Keeps diagnostic-internal quantities OUT of the primary
#      rms–flux class model.
#   3) Tests rms–flux -> colour break with minimal and full
#      colour-detectability controls.
#   4) Restricts SED-class inference to BLLs, where LSP/ISP/HSP
#      have substantial overlap.
#
# No frozen upstream files are modified.
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

MASTER_FILE = TABLE_DIR / "stage04_population_master.csv"

OUT_CLASS = TABLE_DIR / "stage05c_clean_class_models.csv"
OUT_RMSCOLOR = TABLE_DIR / "stage05c_clean_rmflux_colour_models.csv"
OUT_BLL_SED = TABLE_DIR / "stage05c_bll_sed_models.csv"
OUT_AUDIT = TABLE_DIR / "stage05c_overlap_and_coverage_audit.csv"
OUT_SUMMARY = AUDIT_DIR / "stage05c_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )

def numeric(s):
    return pd.to_numeric(s, errors="coerce")

def safe_log1p(s):
    x = numeric(s)

    out = pd.Series(
        np.nan,
        index=x.index,
        dtype=float,
    )

    good = (
        np.isfinite(x)
        &
        (x >= 0)
    )

    out.loc[good] = np.log1p(
        x.loc[good]
    )

    return out

def zscore_inplace(df, cols):
    for c in cols:
        x = numeric(df[c])

        mu = x.mean()
        sd = x.std(ddof=1)

        if np.isfinite(sd) and sd > 0:
            df[c] = (x - mu) / sd
        else:
            df[c] = np.nan

def bh_qvalues(pvalues):
    p = np.asarray(
        pvalues,
        dtype=float
    )

    q = np.full(
        len(p),
        np.nan,
        dtype=float
    )

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]

    order = np.argsort(pv)
    ranked = pv[order]

    m = len(pv)

    raw = (
        ranked
        *
        m
        /
        np.arange(1, m + 1)
    )

    adj = np.minimum.accumulate(
        raw[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0
    )

    qv = np.empty(
        m,
        dtype=float
    )

    qv[order] = adj
    q[valid] = qv

    return q


def fit_logit(
    df,
    outcome,
    predictors,
    key_predictors,
    model_name,
    subset=None,
    standardize=None,
):
    if subset is None:
        subset = pd.Series(
            True,
            index=df.index
        )

    if standardize is None:
        standardize = []

    cols = (
        [outcome]
        +
        predictors
    )

    w = df.loc[
        subset,
        cols
    ].copy()

    w[outcome] = (
        as_bool(
            w[outcome]
        )
        .astype(int)
    )

    for c in predictors:
        w[c] = numeric(
            w[c]
        )

    w = (
        w.replace(
            [np.inf, -np.inf],
            np.nan
        )
        .dropna()
    )

    zscore_inplace(
        w,
        standardize
    )

    w = w.dropna()

    if len(w) < 30:
        raise RuntimeError(
            f"{model_name}: too few rows ({len(w)})"
        )

    y = w[outcome].astype(float)

    if y.nunique() < 2:
        raise RuntimeError(
            f"{model_name}: degenerate outcome"
        )

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add"
    )

    fit = sm.GLM(
        y,
        X,
        family=sm.families.Binomial(),
    ).fit(
        cov_type="HC3",
        maxiter=300,
    )

    ci = fit.conf_int()

    rows = []

    for key in key_predictors:
        beta = float(
            fit.params[key]
        )

        lo = float(
            ci.loc[key, 0]
        )

        hi = float(
            ci.loc[key, 1]
        )

        rows.append({
            "model_name": model_name,
            "outcome": outcome,
            "predictor": key,
            "N": int(len(w)),
            "N_event": int(y.sum()),
            "event_fraction": float(y.mean()),
            "coef_log_odds": beta,
            "odds_ratio": math.exp(beta),
            "or_ci95_low": math.exp(lo),
            "or_ci95_high": math.exp(hi),
            "p_value": float(
                fit.pvalues[key]
            ),
            "aic": float(
                fit.aic
            ),
            "status": "OK",
        })

    return pd.DataFrame(
        rows
    )


# ============================================================
# LOAD MASTER
# ============================================================

if not MASTER_FILE.exists():
    raise FileNotFoundError(
        MASTER_FILE
    )

d = pd.read_csv(
    MASTER_FILE
)

if len(d) != 1061:
    raise RuntimeError(
        f"Expected 1061 rows; got {len(d)}"
    )

required = [
    "blazar_class",
    "pdf_robust_double_both",
    "rmflux_strict_both",
    "colour_robust_central_break",
    "drw_interpretable_both",
    "rmf_rmflux_eligible_g",
    "rmf_rmflux_eligible_r",
    "N_nights_g",
    "N_nights_r",
    "baseline_g_yr",
    "baseline_r_yr",
    "drw_median_cadence_days_g",
    "drw_median_cadence_days_r",
    "col_N_colour_pairs",
    "col_r_mag_range",
    "col_pair_dt_hours_median",
    "SED_class_clean",
]

missing = [
    c
    for c in required
    if c not in d.columns
]

if missing:
    raise RuntimeError(
        "Missing columns: "
        + ", ".join(
            missing
        )
    )


# ============================================================
# CORE VARIABLES
# ============================================================

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

for c in [
    "pdf_robust_double_both",
    "rmflux_strict_both",
    "colour_robust_central_break",
    "drw_interpretable_both",
    "rmf_rmflux_eligible_g",
    "rmf_rmflux_eligible_r",
]:
    d[c] = as_bool(
        d[c]
    )

d["rmflux_eligible_both"] = (
    d["rmf_rmflux_eligible_g"]
    &
    d["rmf_rmflux_eligible_r"]
)


# ============================================================
# PRE-DIAGNOSTIC OBSERVATION-COVERAGE CONTROLS
# ============================================================

ng = numeric(
    d["N_nights_g"]
)

nr = numeric(
    d["N_nights_r"]
)

d["coverage_min_night"] = np.minimum(
    ng,
    nr
)

d["coverage_log_min_night"] = safe_log1p(
    d["coverage_min_night"]
)

d["coverage_band_balance"] = np.log(
    (ng + 1.0)
    /
    (nr + 1.0)
)

bg = numeric(
    d["baseline_g_yr"]
)

br = numeric(
    d["baseline_r_yr"]
)

d["coverage_mean_baseline_yr"] = (
    bg
    +
    br
) / 2.0

cg = numeric(
    d["drw_median_cadence_days_g"]
)

cr = numeric(
    d["drw_median_cadence_days_r"]
)

d["coverage_mean_cadence_days"] = (
    cg
    +
    cr
) / 2.0

d["colour_logN"] = safe_log1p(
    d["col_N_colour_pairs"]
)


coverage_predictors = [
    "coverage_log_min_night",
    "coverage_band_balance",
    "coverage_mean_baseline_yr",
    "coverage_mean_cadence_days",
]


# ============================================================
# 1) CLEAN CLASS MODELS
# ============================================================

class_frames = []

# PDF
class_frames.append(
    fit_logit(
        d,
        outcome="pdf_robust_double_both",
        predictors=[
            "FSRQ",
            *coverage_predictors,
        ],
        key_predictors=[
            "FSRQ"
        ],
        model_name="PDF_CLASS_PRE_DIAGNOSTIC_CONTROLS",
        standardize=coverage_predictors,
    )
)

# rms–flux: only both-band eligible sources.
class_frames.append(
    fit_logit(
        d,
        outcome="rmflux_strict_both",
        predictors=[
            "FSRQ",
            *coverage_predictors,
        ],
        key_predictors=[
            "FSRQ"
        ],
        model_name="RMFLUX_CLASS_ELIGIBLE_PRE_DIAGNOSTIC_CONTROLS",
        subset=d[
            "rmflux_eligible_both"
        ],
        standardize=coverage_predictors,
    )
)

# Colour break.
# Here Ncolour and pair timing are detectability controls.
# r_mag_range is intentionally NOT included in the primary class
# model because it is also an intrinsic variability property.
class_frames.append(
    fit_logit(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "FSRQ",
            "colour_logN",
            "col_pair_dt_hours_median",
        ],
        key_predictors=[
            "FSRQ"
        ],
        model_name="COLOUR_CLASS_MINIMAL_DETECTABILITY_CONTROLS",
        standardize=[
            "colour_logN",
            "col_pair_dt_hours_median",
        ],
    )
)

# Colour sensitivity: additionally control dynamic range.
class_frames.append(
    fit_logit(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "FSRQ",
            "colour_logN",
            "col_pair_dt_hours_median",
            "col_r_mag_range",
        ],
        key_predictors=[
            "FSRQ"
        ],
        model_name="COLOUR_CLASS_PLUS_DYNAMIC_RANGE_SENSITIVITY",
        standardize=[
            "colour_logN",
            "col_pair_dt_hours_median",
            "col_r_mag_range",
        ],
    )
)

# DRW interpretability.
class_frames.append(
    fit_logit(
        d,
        outcome="drw_interpretable_both",
        predictors=[
            "FSRQ",
            *coverage_predictors,
        ],
        key_predictors=[
            "FSRQ"
        ],
        model_name="DRW_CLASS_PRE_DIAGNOSTIC_CONTROLS",
        standardize=coverage_predictors,
    )
)

class_models = pd.concat(
    class_frames,
    ignore_index=True
)

class_models[
    "q_BH_FSRQ_effects"
] = bh_qvalues(
    class_models[
        "p_value"
    ].to_numpy(
        dtype=float
    )
)

class_models.to_csv(
    OUT_CLASS,
    index=False
)


# ============================================================
# 2) CLEAN RMS–FLUX -> COLOUR-BREAK MODELS
# ============================================================

rc_frames = []

# Minimal: class + colour sample size + simultaneity.
rc_frames.append(
    fit_logit(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
            "colour_logN",
            "col_pair_dt_hours_median",
        ],
        key_predictors=[
            "rmflux_strict_both",
            "FSRQ",
        ],
        model_name="RMS_TO_COLOUR_MINIMAL",
        subset=d[
            "rmflux_eligible_both"
        ],
        standardize=[
            "colour_logN",
            "col_pair_dt_hours_median",
        ],
    )
)

# Full colour-detectability sensitivity:
# dynamic range added explicitly.
rc_frames.append(
    fit_logit(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "rmflux_strict_both",
            "FSRQ",
            "colour_logN",
            "col_pair_dt_hours_median",
            "col_r_mag_range",
        ],
        key_predictors=[
            "rmflux_strict_both",
            "FSRQ",
        ],
        model_name="RMS_TO_COLOUR_PLUS_DYNAMIC_RANGE",
        subset=d[
            "rmflux_eligible_both"
        ],
        standardize=[
            "colour_logN",
            "col_pair_dt_hours_median",
            "col_r_mag_range",
        ],
    )
)

rmcolour = pd.concat(
    rc_frames,
    ignore_index=True
)

rmcolour.to_csv(
    OUT_RMSCOLOR,
    index=False
)


# ============================================================
# 3) BLL-ONLY SED MODELS
# ============================================================

sed = (
    d["SED_class_clean"]
    .astype(str)
    .str.strip()
    .str.upper()
)

d["SED_ISP"] = (
    sed
    ==
    "ISP"
).astype(int)

d["SED_HSP"] = (
    sed
    ==
    "HSP"
).astype(int)

sed_valid = (
    d["SED_class_clean"].notna()
    &
    sed.isin(
        [
            "LSP",
            "ISP",
            "HSP",
        ]
    )
)

bll = (
    d["blazar_class"]
    .astype(str)
    .eq("BLL")
    &
    sed_valid
)

bll_sed_frames = []

# PDF
bll_sed_frames.append(
    fit_logit(
        d,
        outcome="pdf_robust_double_both",
        predictors=[
            "SED_ISP",
            "SED_HSP",
            *coverage_predictors,
        ],
        key_predictors=[
            "SED_ISP",
            "SED_HSP",
        ],
        model_name="BLL_PDF_BY_SED",
        subset=bll,
        standardize=coverage_predictors,
    )
)

# rms–flux
bll_sed_frames.append(
    fit_logit(
        d,
        outcome="rmflux_strict_both",
        predictors=[
            "SED_ISP",
            "SED_HSP",
            *coverage_predictors,
        ],
        key_predictors=[
            "SED_ISP",
            "SED_HSP",
        ],
        model_name="BLL_RMFLUX_BY_SED",
        subset=(
            bll
            &
            d[
                "rmflux_eligible_both"
            ]
        ),
        standardize=coverage_predictors,
    )
)

# Colour
bll_sed_frames.append(
    fit_logit(
        d,
        outcome="colour_robust_central_break",
        predictors=[
            "SED_ISP",
            "SED_HSP",
            "colour_logN",
            "col_pair_dt_hours_median",
            "col_r_mag_range",
        ],
        key_predictors=[
            "SED_ISP",
            "SED_HSP",
        ],
        model_name="BLL_COLOUR_BY_SED",
        subset=bll,
        standardize=[
            "colour_logN",
            "col_pair_dt_hours_median",
            "col_r_mag_range",
        ],
    )
)

# DRW
bll_sed_frames.append(
    fit_logit(
        d,
        outcome="drw_interpretable_both",
        predictors=[
            "SED_ISP",
            "SED_HSP",
            *coverage_predictors,
        ],
        key_predictors=[
            "SED_ISP",
            "SED_HSP",
        ],
        model_name="BLL_DRW_BY_SED",
        subset=bll,
        standardize=coverage_predictors,
    )
)

bll_sed_models = pd.concat(
    bll_sed_frames,
    ignore_index=True
)

bll_sed_models[
    "q_BH_all_BLL_SED_coefficients"
] = bh_qvalues(
    bll_sed_models[
        "p_value"
    ].to_numpy(
        dtype=float
    )
)

bll_sed_models.to_csv(
    OUT_BLL_SED,
    index=False
)


# ============================================================
# 4) OVERLAP / COVERAGE AUDIT
# ============================================================

audit_rows = []

# Optical class x SED counts.
for cls in [
    "BLL",
    "FSRQ",
]:
    for sclass in [
        "LSP",
        "ISP",
        "HSP",
    ]:
        mask = (
            d["blazar_class"]
            .astype(str)
            .eq(cls)
            &
            sed.eq(sclass)
        )

        audit_rows.append({
            "audit_type": "class_x_SED",
            "group": cls,
            "metric": sclass,
            "value": int(
                mask.sum()
            ),
        })

# Coverage summaries by class.
for cls in [
    "BLL",
    "FSRQ",
]:
    xx = d.loc[
        d["blazar_class"]
        .astype(str)
        .eq(cls)
    ]

    for metric in [
        "coverage_min_night",
        "coverage_mean_baseline_yr",
        "coverage_mean_cadence_days",
        "col_N_colour_pairs",
        "col_r_mag_range",
    ]:
        x = numeric(
            xx[metric]
        )

        audit_rows.append({
            "audit_type": "coverage_median",
            "group": cls,
            "metric": metric,
            "value": float(
                x.median()
            ),
        })

audit = pd.DataFrame(
    audit_rows
)

audit.to_csv(
    OUT_AUDIT,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 05C FINAL SUMMARY",
    "=" * 72,
    "",
    "CLEAN CLASS EFFECTS:",
]

for _, rr in class_models.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['odds_ratio']:.3f}, "
        f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
        f"p={rr['p_value']:.3g}, "
        f"q={rr['q_BH_FSRQ_effects']:.3g}"
    )

lines += [
    "",
    "RMS-FLUX -> COLOUR BREAK:",
]

for model_name in rmcolour[
    "model_name"
].unique():

    xx = rmcolour.loc[
        rmcolour[
            "model_name"
        ].eq(
            model_name
        )
    ]

    rr = xx.loc[
        xx[
            "predictor"
        ].eq(
            "rmflux_strict_both"
        )
    ].iloc[0]

    rc = xx.loc[
        xx[
            "predictor"
        ].eq(
            "FSRQ"
        )
    ].iloc[0]

    lines.append(
        f"  {model_name}: "
        f"rms OR={rr['odds_ratio']:.3f} "
        f"({rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}), "
        f"p={rr['p_value']:.3g}; "
        f"FSRQ OR={rc['odds_ratio']:.3f}, "
        f"p={rc['p_value']:.3g}"
    )

lines += [
    "",
    "BLL-ONLY SED EFFECTS (LSP reference):",
]

for _, rr in bll_sed_models.iterrows():
    lines.append(
        f"  {rr['model_name']} / {rr['predictor']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['odds_ratio']:.3f}, "
        f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
        f"p={rr['p_value']:.3g}, "
        f"q={rr['q_BH_all_BLL_SED_coefficients']:.3g}"
    )

lines += [
    "",
    "SED OVERLAP:",
    (
        "  FSRQ HSP is too sparse for an independent "
        "full-sample HSP-vs-LSP interpretation."
    ),
]

for cls in [
    "BLL",
    "FSRQ",
]:
    vals = []

    for sclass in [
        "LSP",
        "ISP",
        "HSP",
    ]:
        n = int(
            (
                d["blazar_class"]
                .astype(str)
                .eq(cls)
                &
                sed.eq(sclass)
            ).sum()
        )

        vals.append(
            f"{sclass}={n}"
        )

    lines.append(
        f"  {cls}: "
        +
        ", ".join(vals)
    )

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 05C")
print("CLEAN PRIMARY INFERENCE + SED-OVERLAP CONTROL")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_CLASS)
print(OUT_RMSCOLOR)
print(OUT_BLL_SED)
print(OUT_AUDIT)
print(OUT_SUMMARY)
print()
print("STAGE 05C COMPLETE")
