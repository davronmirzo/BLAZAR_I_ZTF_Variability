# ============================================================
# BLAZAR_I — STAGE 06D2
# SELECTION-WEIGHTED ROBUSTNESS OF PRIMARY POPULATION RESULTS
#
# Inputs:
#   outputs/tables/stage06d1_selection_flow_master.csv
#   outputs/tables/stage04_population_master.csv
#
# Purpose:
#   Use the two-stage selection probabilities from STAGE 06D1
#   to test whether the principal population associations persist
#   after inverse-probability weighting (IPW).
#
# Final inclusion probability:
#   p_final = p(parent -> ZTF any) *
#             p(ZTF any -> GOLD+SILVER analysis)
#
# Stabilized final-sample weight:
#   SW = P(final analysis selection) / p_final
#      = (1061 / 1901) / p_final
#
# Weight schemes:
#   UNWEIGHTED
#   IPW_RAW
#   IPW_TRIM_1_99
#   IPW_TRIM_2P5_97P5
#
# Trimming limits are determined ONCE from the full 1061-source
# analysis sample and then reused for every endpoint.
#
# Binary endpoint models:
#   outcome ~ FSRQ
#
# Primary endpoints:
#   pdf_robust_double_both
#   rmflux_strict_both  [restricted to both-band RMF eligible]
#   colour_robust_central_break
#   drw_interpretable_both
#   core4_at_least3     [audit/synthesis only]
#
# Central cross-diagnostic model:
#   colour_robust_central_break ~ rmflux_strict_both + FSRQ
#   [restricted to both-band RMF eligible]
#
# Continuous class contrasts:
#   log10(Fvar_g) ~ FSRQ
#   log10(Fvar_r) ~ FSRQ
#   log10(tau_rest_g) ~ FSRQ
#   log10(tau_rest_r) ~ FSRQ
#
# Important:
#   This is a selection-bias sensitivity analysis, not a causal
#   estimator. Selection probabilities are estimated, and their
#   estimation uncertainty is not propagated into the endpoint
#   confidence intervals.
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore", category=RuntimeWarning)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

FLOW_FILE = TABLE_DIR / "stage06d1_selection_flow_master.csv"
POP_FILE = TABLE_DIR / "stage04_population_master.csv"

OUT_WEIGHTS = TABLE_DIR / "stage06d2_selection_weights.csv"
OUT_BALANCE = TABLE_DIR / "stage06d2_selection_balance.csv"
OUT_BINARY = TABLE_DIR / "stage06d2_ipw_binary_models.csv"
OUT_CROSS = TABLE_DIR / "stage06d2_ipw_rmflux_colour_models.csv"
OUT_CONT = TABLE_DIR / "stage06d2_ipw_continuous_models.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06d2_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def kish_ess(w):
    w = np.asarray(
        w,
        dtype=float
    )

    w = w[
        np.isfinite(w)
        &
        (w > 0)
    ]

    if len(w) == 0:
        return np.nan

    return float(
        (w.sum() ** 2)
        /
        np.sum(w ** 2)
    )


def normalize_weights(w):
    w = np.asarray(
        w,
        dtype=float
    )

    m = np.mean(w)

    if not (
        np.isfinite(m)
        and
        m > 0
    ):
        raise RuntimeError(
            "Invalid mean analysis weight."
        )

    return (
        w / m
    )


def fit_logit(
    df,
    outcome,
    predictors,
    weight_col,
    model_name,
    endpoint,
):
    cols = [
        outcome,
        *predictors,
    ]

    if weight_col is not None:
        cols.append(
            weight_col
        )

    w = df[
        cols
    ].copy()

    for c in [
        outcome,
        *predictors,
    ]:
        w[c] = numeric(
            w[c]
        )

    if weight_col is not None:
        w[weight_col] = numeric(
            w[weight_col]
        )

    w = w.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    if len(w) < 30:
        raise RuntimeError(
            f"{endpoint} {model_name}: too few rows ({len(w)})"
        )

    y = w[
        outcome
    ].astype(float)

    X = sm.add_constant(
        w[
            predictors
        ].astype(float),
        has_constant="add"
    )

    if weight_col is None:
        fit = sm.GLM(
            y,
            X,
            family=sm.families.Binomial()
        ).fit(
            cov_type="HC3"
        )

        weights_used = np.ones(
            len(w),
            dtype=float
        )

    else:
        weights_used = normalize_weights(
            w[
                weight_col
            ].to_numpy(
                dtype=float
            )
        )

        fit = sm.GLM(
            y,
            X,
            family=sm.families.Binomial(),
            freq_weights=weights_used,
        ).fit(
            cov_type="HC3"
        )

    ci = fit.conf_int()

    rows = []

    for term in predictors:
        beta = float(
            fit.params[term]
        )

        lo = float(
            ci.loc[
                term,
                0
            ]
        )

        hi = float(
            ci.loc[
                term,
                1
            ]
        )

        rows.append({
            "endpoint": endpoint,
            "model": model_name,
            "N": int(
                len(w)
            ),
            "N_positive": int(
                y.sum()
            ),
            "term": term,
            "beta": beta,
            "OR": math.exp(beta),
            "OR_ci95_low": math.exp(lo),
            "OR_ci95_high": math.exp(hi),
            "p_value": float(
                fit.pvalues[term]
            ),
            "weight_ESS": kish_ess(
                weights_used
            ),
        })

    return rows


def fit_continuous(
    df,
    outcome,
    weight_col,
    model_name,
    endpoint,
):
    cols = [
        outcome,
        "FSRQ",
    ]

    if weight_col is not None:
        cols.append(
            weight_col
        )

    w = df[
        cols
    ].copy()

    for c in [
        outcome,
        "FSRQ",
    ]:
        w[c] = numeric(
            w[c]
        )

    if weight_col is not None:
        w[weight_col] = numeric(
            w[weight_col]
        )

    w = w.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    w = w.loc[
        w[outcome] > 0
    ].copy()

    if len(w) < 30:
        raise RuntimeError(
            f"{endpoint} {model_name}: too few rows ({len(w)})"
        )

    y = np.log10(
        w[
            outcome
        ].astype(float)
    )

    X = sm.add_constant(
        w[
            [
                "FSRQ"
            ]
        ].astype(float),
        has_constant="add"
    )

    if weight_col is None:
        fit = sm.OLS(
            y,
            X
        ).fit(
            cov_type="HC3"
        )

        weights_used = np.ones(
            len(w),
            dtype=float
        )

    else:
        weights_used = normalize_weights(
            w[
                weight_col
            ].to_numpy(
                dtype=float
            )
        )

        fit = sm.WLS(
            y,
            X,
            weights=weights_used
        ).fit(
            cov_type="HC3"
        )

    ci = fit.conf_int()

    beta = float(
        fit.params[
            "FSRQ"
        ]
    )

    lo = float(
        ci.loc[
            "FSRQ",
            0
        ]
    )

    hi = float(
        ci.loc[
            "FSRQ",
            1
        ]
    )

    return {
        "endpoint": endpoint,
        "model": model_name,
        "N": int(
            len(w)
        ),
        "beta_log10_FSRQ": beta,
        "factor_FSRQ_vs_BLL": 10.0 ** beta,
        "factor_ci95_low": 10.0 ** lo,
        "factor_ci95_high": 10.0 ** hi,
        "p_value": float(
            fit.pvalues[
                "FSRQ"
            ]
        ),
        "weight_ESS": kish_ess(
            weights_used
        ),
    }


def weighted_mean(x, w):
    x = np.asarray(
        x,
        dtype=float
    )

    w = np.asarray(
        w,
        dtype=float
    )

    mask = (
        np.isfinite(x)
        &
        np.isfinite(w)
        &
        (w > 0)
    )

    if mask.sum() == 0:
        return np.nan

    return float(
        np.average(
            x[mask],
            weights=w[mask]
        )
    )


# ============================================================
# LOAD + VALIDATE
# ============================================================

for path in [
    FLOW_FILE,
    POP_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

flow = pd.read_csv(
    FLOW_FILE
)

pop = pd.read_csv(
    POP_FILE
)

flow[
    "blazar_id"
] = flow[
    "blazar_id"
].astype(str)

pop[
    "blazar_id"
] = pop[
    "blazar_id"
].astype(str)

flow[
    "ANALYSIS_SELECTED"
] = as_bool_series(
    flow[
        "ANALYSIS_SELECTED"
    ]
)

selected = flow.loc[
    flow[
        "ANALYSIS_SELECTED"
    ]
].copy()

if len(flow) != 1901:
    raise RuntimeError(
        f"Expected flow N=1901; got {len(flow)}"
    )

if len(selected) != 1061:
    raise RuntimeError(
        f"Expected selected N=1061; got {len(selected)}"
    )

if len(pop) != 1061:
    raise RuntimeError(
        f"Expected population N=1061; got {len(pop)}"
    )

if set(
    selected[
        "blazar_id"
    ]
) != set(
    pop[
        "blazar_id"
    ]
):
    raise RuntimeError(
        "Selected-flow IDs do not match stage04 population IDs."
    )


# ============================================================
# BUILD WEIGHTS
# ============================================================

p1 = numeric(
    selected[
        "p_stage1_ztf_any_full"
    ]
)

p2 = numeric(
    selected[
        "p_stage2_analysis_given_ztf_full"
    ]
)

pf = numeric(
    selected[
        "p_final_analysis_full"
    ]
)

if (
    p1.isna().any()
    or
    p2.isna().any()
    or
    pf.isna().any()
):
    raise RuntimeError(
        "Missing selection probabilities among final 1061 sources."
    )

if (
    (p1 <= 0).any()
    or
    (p1 >= 1).any()
    or
    (p2 <= 0).any()
    or
    (p2 >= 1).any()
    or
    (pf <= 0).any()
    or
    (pf >= 1).any()
):
    raise RuntimeError(
        "Selection probabilities must lie strictly inside (0,1)."
    )

marginal_final = (
    1061.0 / 1901.0
)

selected[
    "SW_RAW"
] = (
    marginal_final
    /
    pf
)

q01 = float(
    selected[
        "SW_RAW"
    ].quantile(
        0.01
    )
)

q99 = float(
    selected[
        "SW_RAW"
    ].quantile(
        0.99
    )
)

q025 = float(
    selected[
        "SW_RAW"
    ].quantile(
        0.025
    )
)

q975 = float(
    selected[
        "SW_RAW"
    ].quantile(
        0.975
    )
)

selected[
    "SW_TRIM_1_99"
] = selected[
    "SW_RAW"
].clip(
    lower=q01,
    upper=q99
)

selected[
    "SW_TRIM_2P5_97P5"
] = selected[
    "SW_RAW"
].clip(
    lower=q025,
    upper=q975
)

weights_keep = selected[
    [
        "blazar_id",
        "p_stage1_ztf_any_full",
        "p_stage2_analysis_given_ztf_full",
        "p_final_analysis_full",
        "SW_RAW",
        "SW_TRIM_1_99",
        "SW_TRIM_2P5_97P5",
    ]
].copy()

weights_keep.to_csv(
    OUT_WEIGHTS,
    index=False
)


# ============================================================
# MERGE WITH POPULATION ENDPOINTS
# ============================================================

keep_flow = selected[
    [
        "blazar_id",
        "FSRQ",
        "redshift_known",
        "SED_HSP",
        "SED_ISP",
        "SED_UNKNOWN",
        "RA_sin",
        "RA_cos",
        "Dec_deg",
        "Dec2",
        "logEnergyFlux_DR4",
        "log1pVarIndex_DR4",
        "SW_RAW",
        "SW_TRIM_1_99",
        "SW_TRIM_2P5_97P5",
    ]
].copy()

d = pop.merge(
    keep_flow,
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

if d[
    "SW_RAW"
].isna().any():
    raise RuntimeError(
        "Weight merge produced missing values."
    )

bool_cols = [
    "pdf_robust_double_both",
    "rmflux_strict_both",
    "colour_robust_central_break",
    "drw_interpretable_both",
    "core4_at_least3",
    "rmf_rmflux_eligible_g",
    "rmf_rmflux_eligible_r",
]

for c in bool_cols:
    if c not in d.columns:
        raise RuntimeError(
            f"Missing expected stage04 column: {c}"
        )

    d[c] = as_bool_series(
        d[c]
    )

d[
    "RMF_BOTH_ELIGIBLE"
] = (
    d[
        "rmf_rmflux_eligible_g"
    ]
    &
    d[
        "rmf_rmflux_eligible_r"
    ]
)


# ============================================================
# REPRESENTATIVENESS / BALANCE AUDIT
# ============================================================

balance_vars = [
    "FSRQ",
    "redshift_known",
    "SED_HSP",
    "SED_ISP",
    "SED_UNKNOWN",
    "RA_sin",
    "RA_cos",
    "Dec_deg",
    "logEnergyFlux_DR4",
    "log1pVarIndex_DR4",
]

balance_rows = []

for var in balance_vars:
    parent_x = numeric(
        flow[var]
    )

    sel_x = numeric(
        selected[var]
    )

    parent_mean = float(
        parent_x.mean()
    )

    parent_sd = float(
        parent_x.std(ddof=1)
    )

    if not (
        np.isfinite(parent_sd)
        and
        parent_sd > 0
    ):
        parent_sd = 1.0

    for label, wcol in [
        (
            "UNWEIGHTED",
            None
        ),
        (
            "IPW_RAW",
            "SW_RAW"
        ),
        (
            "IPW_TRIM_1_99",
            "SW_TRIM_1_99"
        ),
        (
            "IPW_TRIM_2P5_97P5",
            "SW_TRIM_2P5_97P5"
        ),
    ]:
        if wcol is None:
            sample_mean = float(
                sel_x.mean()
            )
        else:
            sample_mean = weighted_mean(
                sel_x,
                selected[
                    wcol
                ]
            )

        balance_rows.append({
            "variable": var,
            "weight_scheme": label,
            "parent_mean": parent_mean,
            "selected_mean": sample_mean,
            "difference": (
                sample_mean
                -
                parent_mean
            ),
            "standardized_difference": (
                (
                    sample_mean
                    -
                    parent_mean
                )
                /
                parent_sd
            ),
        })

balance = pd.DataFrame(
    balance_rows
)

balance.to_csv(
    OUT_BALANCE,
    index=False
)


# ============================================================
# PRIMARY BINARY ENDPOINTS
# ============================================================

weight_schemes = [
    (
        "UNWEIGHTED",
        None
    ),
    (
        "IPW_RAW",
        "SW_RAW"
    ),
    (
        "IPW_TRIM_1_99",
        "SW_TRIM_1_99"
    ),
    (
        "IPW_TRIM_2P5_97P5",
        "SW_TRIM_2P5_97P5"
    ),
]

binary_specs = [
    (
        "PDF_ROBUST_DOUBLE_BOTH",
        "pdf_robust_double_both",
        d
    ),
    (
        "RMFLUX_STRICT_BOTH_ELIGIBLE",
        "rmflux_strict_both",
        d.loc[
            d[
                "RMF_BOTH_ELIGIBLE"
            ]
        ].copy()
    ),
    (
        "COLOUR_ROBUST_CENTRAL_BREAK",
        "colour_robust_central_break",
        d
    ),
    (
        "DRW_INTERPRETABLE_BOTH",
        "drw_interpretable_both",
        d
    ),
    (
        "CORE4_AT_LEAST3_AUDIT",
        "core4_at_least3",
        d
    ),
]

binary_rows = []

for endpoint, outcome, sample in binary_specs:
    for label, wcol in weight_schemes:
        binary_rows.extend(
            fit_logit(
                df=sample,
                outcome=outcome,
                predictors=[
                    "FSRQ"
                ],
                weight_col=wcol,
                model_name=label,
                endpoint=endpoint,
            )
        )

binary_models = pd.DataFrame(
    binary_rows
)

binary_models.to_csv(
    OUT_BINARY,
    index=False
)


# ============================================================
# RMS -> COLOUR CENTRAL ASSOCIATION
# ============================================================

cross_sample = d.loc[
    d[
        "RMF_BOTH_ELIGIBLE"
    ]
].copy()

cross_rows = []

for label, wcol in weight_schemes:
    cross_rows.extend(
        fit_logit(
            df=cross_sample,
            outcome="colour_robust_central_break",
            predictors=[
                "rmflux_strict_both",
                "FSRQ",
            ],
            weight_col=wcol,
            model_name=label,
            endpoint="RMFLUX_TO_COLOUR_ROBUST",
        )
    )

cross_models = pd.DataFrame(
    cross_rows
)

cross_models.to_csv(
    OUT_CROSS,
    index=False
)


# ============================================================
# CONTINUOUS CLASS CONTRASTS
# ============================================================

continuous_specs = []

for endpoint, col in [
    (
        "FVAR_G",
        "pdf_Fvar_g"
    ),
    (
        "FVAR_R",
        "pdf_Fvar_r"
    ),
    (
        "TAU_REST_G",
        "drw_tau_rest_days_g"
    ),
    (
        "TAU_REST_R",
        "drw_tau_rest_days_r"
    ),
]:
    if col not in d.columns:
        raise RuntimeError(
            f"Missing expected stage04 column: {col}"
        )

    continuous_specs.append(
        (
            endpoint,
            col
        )
    )

cont_rows = []

for endpoint, col in continuous_specs:
    for label, wcol in weight_schemes:
        cont_rows.append(
            fit_continuous(
                df=d,
                outcome=col,
                weight_col=wcol,
                model_name=label,
                endpoint=endpoint,
            )
        )

continuous_models = pd.DataFrame(
    cont_rows
)

continuous_models.to_csv(
    OUT_CONT,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

weight_diag = {
    "p1_min": float(
        p1.min()
    ),
    "p1_p01": float(
        p1.quantile(0.01)
    ),
    "p1_med": float(
        p1.median()
    ),
    "p2_min": float(
        p2.min()
    ),
    "p2_p01": float(
        p2.quantile(0.01)
    ),
    "p2_med": float(
        p2.median()
    ),
    "pf_min": float(
        pf.min()
    ),
    "pf_p01": float(
        pf.quantile(0.01)
    ),
    "pf_med": float(
        pf.median()
    ),
    "w_med": float(
        selected[
            "SW_RAW"
        ].median()
    ),
    "w_p95": float(
        selected[
            "SW_RAW"
        ].quantile(
            0.95
        )
    ),
    "w_p99": float(
        selected[
            "SW_RAW"
        ].quantile(
            0.99
        )
    ),
    "w_max": float(
        selected[
            "SW_RAW"
        ].max()
    ),
    "ess_raw": kish_ess(
        selected[
            "SW_RAW"
        ]
    ),
    "ess_1_99": kish_ess(
        selected[
            "SW_TRIM_1_99"
        ]
    ),
    "ess_2p5_97p5": kish_ess(
        selected[
            "SW_TRIM_2P5_97P5"
        ]
    ),
}

lines = [
    "BLAZAR_I - STAGE 06D2 FINAL SUMMARY",
    "=" * 78,
    "",
    "SELECTION-PROBABILITY / WEIGHT DIAGNOSTICS:",
    (
        "  p_stage1: "
        f"min={weight_diag['p1_min']:.4f}, "
        f"p01={weight_diag['p1_p01']:.4f}, "
        f"median={weight_diag['p1_med']:.4f}"
    ),
    (
        "  p_stage2: "
        f"min={weight_diag['p2_min']:.4f}, "
        f"p01={weight_diag['p2_p01']:.4f}, "
        f"median={weight_diag['p2_med']:.4f}"
    ),
    (
        "  p_final:  "
        f"min={weight_diag['pf_min']:.4f}, "
        f"p01={weight_diag['pf_p01']:.4f}, "
        f"median={weight_diag['pf_med']:.4f}"
    ),
    (
        "  SW_RAW:   "
        f"median={weight_diag['w_med']:.3f}, "
        f"p95={weight_diag['w_p95']:.3f}, "
        f"p99={weight_diag['w_p99']:.3f}, "
        f"max={weight_diag['w_max']:.3f}"
    ),
    (
        "  Kish ESS: "
        f"raw={weight_diag['ess_raw']:.1f}, "
        f"trim1-99={weight_diag['ess_1_99']:.1f}, "
        f"trim2.5-97.5={weight_diag['ess_2p5_97p5']:.1f}"
    ),
    "",
    "PRIMARY BINARY FSRQ EFFECTS:",
]

for endpoint in [
    "PDF_ROBUST_DOUBLE_BOTH",
    "RMFLUX_STRICT_BOTH_ELIGIBLE",
    "COLOUR_ROBUST_CENTRAL_BREAK",
    "DRW_INTERPRETABLE_BOTH",
    "CORE4_AT_LEAST3_AUDIT",
]:
    lines.append(
        f"  {endpoint}:"
    )

    x = binary_models.loc[
        binary_models[
            "endpoint"
        ].eq(endpoint)
        &
        binary_models[
            "term"
        ].eq("FSRQ")
    ]

    for _, rr in x.iterrows():
        lines.append(
            f"    {rr['model']}: "
            f"N={int(rr['N'])}, "
            f"OR={rr['OR']:.3f} "
            f"({rr['OR_ci95_low']:.3f}-{rr['OR_ci95_high']:.3f}), "
            f"p={rr['p_value']:.3g}, "
            f"ESS={rr['weight_ESS']:.1f}"
        )

lines += [
    "",
    "RMS -> COLOUR ASSOCIATION (eligible sample):",
]

x = cross_models.loc[
    cross_models[
        "term"
    ].eq(
        "rmflux_strict_both"
    )
]

for _, rr in x.iterrows():
    lines.append(
        f"  {rr['model']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['OR']:.3f} "
        f"({rr['OR_ci95_low']:.3f}-{rr['OR_ci95_high']:.3f}), "
        f"p={rr['p_value']:.3g}, "
        f"ESS={rr['weight_ESS']:.1f}"
    )

lines += [
    "",
    "CONTINUOUS FSRQ/BLL FACTORS:",
]

for endpoint in [
    "FVAR_G",
    "FVAR_R",
    "TAU_REST_G",
    "TAU_REST_R",
]:
    lines.append(
        f"  {endpoint}:"
    )

    x = continuous_models.loc[
        continuous_models[
            "endpoint"
        ].eq(endpoint)
    ]

    for _, rr in x.iterrows():
        lines.append(
            f"    {rr['model']}: "
            f"N={int(rr['N'])}, "
            f"factor={rr['factor_FSRQ_vs_BLL']:.3f} "
            f"({rr['factor_ci95_low']:.3f}-{rr['factor_ci95_high']:.3f}), "
            f"p={rr['p_value']:.3g}, "
            f"ESS={rr['weight_ESS']:.1f}"
        )

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 06D2")
print("SELECTION-WEIGHTED ROBUSTNESS")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_WEIGHTS)
print(OUT_BALANCE)
print(OUT_BINARY)
print(OUT_CROSS)
print(OUT_CONT)
print(OUT_SUMMARY)
print()
print("STAGE 06D2 COMPLETE")
