# ============================================================
# BLAZAR_I — STAGE 06C2
# DRW CADENCE / WINDOW / BASELINE SENSITIVITY — RESUMABLE
#
# Targets:
#   Frozen STAGE 03D source-filter rows with
#   tau_interpretable_primary == True (N=1701 expected).
#
# Sensitivity schemes:
#
#   THIN_HALF
#     Deterministically retain every second nightly point.
#     The retained parity is source/filter-specific but fixed.
#
#   BASELINE_CENTRAL80
#     Retain observations within the central 80% of the original
#     temporal baseline (trim 10% of baseline from each edge).
#
#   SEASONAL_DENSE_QUARTER_DROP
#     Fold observing times on 365.25 d using a fixed MJD anchor,
#     identify the most populated of four annual phase quarters,
#     and remove that quarter in every year.  This is a deliberate
#     seasonal-window stress test based ONLY on sampling density.
#
# For every modified light curve:
#   * refit the white-noise null;
#   * refit the exact irregular OU/DRW model;
#   * recompute DeltaBIC and the primary interpretability gate.
#
# DRW gate:
#   optimizer success
#   DeltaBIC >= 10
#   tau >= 2 * median cadence
#   tau <= baseline / 10
#   tau not within 2% of either log-search boundary
#
# Search bounds are recomputed from the MODIFIED sampling:
#   tau_low  = max(0.5 d, 0.25 * median cadence)
#   tau_high = max(100 d, 10 * baseline)
#
# IMPORTANT:
#   This is a robustness analysis.  Frozen STAGE 03D products are
#   read-only and are never overwritten.
#
# Resumable checkpoint:
#   outputs/models/stage06c2_drw_sensitivity/
#       BZI_xxxxx_g_06C2.csv
#       BZI_xxxxx_g.done
#       BZI_xxxxx_r_06C2.csv
#       BZI_xxxxx_r.done
# ============================================================

from pathlib import Path
import argparse
import math
import zlib
import warnings

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import spearmanr

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"
DRW_FILE = ROOT / "outputs" / "tables" / "stage03d_drw_master.csv"

MODEL_DIR = (
    ROOT / "outputs" / "models"
    / "stage06c2_drw_sensitivity"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_MASTER = TABLE_DIR / "stage06c2_drw_sensitivity_master.csv"
OUT_SOURCE = TABLE_DIR / "stage06c2_drw_sensitivity_source.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06c2_summary.txt"

MODEL_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# CONFIG
# ============================================================

MIN_N = 50

SCHEMES = [
    "THIN_HALF",
    "BASELINE_CENTRAL80",
    "SEASONAL_DENSE_QUARTER_DROP",
]

MJD_PHASE_ANCHOR = 58000.0
YEAR_DAYS = 365.25

SIGMA_MIN = 1.0e-5
SIGMA_MAX_HARD = 5.0

BASE_SEED = 20260918


# ============================================================
# HELPERS
# ============================================================

def as_bool(v):
    if isinstance(v, (bool, np.bool_)):
        return bool(v)

    return str(v).strip().lower() in {
        "true", "1", "yes", "y"
    }


def stable_parity(blazar_id, filt):
    token = (
        f"{BASE_SEED}|{blazar_id}|{filt}|THIN_HALF"
    ).encode("utf-8")

    return int(
        zlib.crc32(token)
        &
        0xFFFFFFFF
    ) % 2


def white_loglike_pars(pars, y, err):
    mu, log_sigma = pars

    sigma = math.exp(log_sigma)

    var = (
        err ** 2
        +
        sigma ** 2
    )

    if (
        np.any(~np.isfinite(var))
        or
        np.any(var <= 0)
    ):
        return -np.inf

    resid = (
        y - mu
    )

    return -0.5 * float(
        np.sum(
            np.log(2.0 * np.pi * var)
            +
            resid ** 2 / var
        )
    )


def drw_loglike_pars(pars, t, y, err):
    mu, log_tau, log_sigma = pars

    tau = math.exp(log_tau)
    sigma = math.exp(log_sigma)

    if not (
        np.isfinite(mu)
        and
        np.isfinite(tau)
        and
        np.isfinite(sigma)
        and
        tau > 0
        and
        sigma > 0
    ):
        return -np.inf

    sigma2 = (
        sigma ** 2
    )

    m_pred = 0.0
    p_pred = sigma2

    ll = 0.0

    n = len(t)

    for i in range(n):
        obs_var = (
            p_pred
            +
            err[i] ** 2
        )

        if not (
            np.isfinite(obs_var)
            and
            obs_var > 0
        ):
            return -np.inf

        innov = (
            y[i]
            -
            mu
            -
            m_pred
        )

        ll += -0.5 * (
            math.log(
                2.0
                *
                math.pi
                *
                obs_var
            )
            +
            innov ** 2
            /
            obs_var
        )

        gain = (
            p_pred
            /
            obs_var
        )

        m_post = (
            m_pred
            +
            gain
            *
            innov
        )

        p_post = (
            p_pred
            *
            (
                1.0
                -
                gain
            )
        )

        if i == n - 1:
            break

        dt = (
            t[i + 1]
            -
            t[i]
        )

        if not (
            np.isfinite(dt)
            and
            dt >= 0
        ):
            return -np.inf

        a = math.exp(
            -dt / tau
        )

        q = (
            sigma2
            *
            (
                -math.expm1(
                    -2.0
                    *
                    dt
                    /
                    tau
                )
            )
        )

        m_pred = (
            a
            *
            m_post
        )

        p_pred = (
            a ** 2
            *
            p_post
            +
            q
        )

    return float(ll)


def fit_white(y, err, frozen_row):
    med = float(
        np.median(y)
    )

    sd = float(
        np.std(y, ddof=1)
    )

    if not np.isfinite(sd) or sd <= 0:
        sd = 0.05

    mu_pad = max(
        2.0,
        5.0 * sd
    )

    sigma_hi = min(
        SIGMA_MAX_HARD,
        max(
            1.0,
            10.0 * sd
        )
    )

    bounds = [
        (
            med - mu_pad,
            med + mu_pad
        ),
        (
            math.log(SIGMA_MIN),
            math.log(sigma_hi)
        ),
    ]

    starts = [
        [
            float(frozen_row["mu_white_mag"]),
            math.log(
                max(
                    SIGMA_MIN,
                    min(
                        sigma_hi,
                        float(
                            frozen_row[
                                "sigma_white_intrinsic_mag"
                            ]
                        )
                    )
                )
            ),
        ],
        [
            med,
            math.log(
                max(
                    SIGMA_MIN,
                    min(
                        sigma_hi,
                        sd
                    )
                )
            ),
        ],
    ]

    best = None

    for start in starts:
        start = np.asarray(
            [
                np.clip(
                    start[0],
                    bounds[0][0],
                    bounds[0][1]
                ),
                np.clip(
                    start[1],
                    bounds[1][0],
                    bounds[1][1]
                ),
            ],
            dtype=float
        )

        res = minimize(
            lambda p: -white_loglike_pars(
                p,
                y,
                err
            ),
            x0=start,
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 300,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(
            res.fun
        ):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    mu, log_sigma = best.x

    return {
        "success": bool(best.success),
        "message": str(best.message),
        "nit": int(getattr(best, "nit", -1)),
        "mu": float(mu),
        "sigma_intrinsic": float(
            math.exp(log_sigma)
        ),
        "loglike": float(
            -best.fun
        ),
    }


def fit_drw(
    t,
    y,
    err,
    tau_low,
    tau_high,
    cadence,
    baseline,
    frozen_row,
):
    med = float(
        np.median(y)
    )

    sd = float(
        np.std(y, ddof=1)
    )

    if not np.isfinite(sd) or sd <= 0:
        sd = 0.05

    mu_pad = max(
        2.0,
        5.0 * sd
    )

    sigma_hi = min(
        SIGMA_MAX_HARD,
        max(
            1.0,
            10.0 * sd
        )
    )

    bounds = [
        (
            med - mu_pad,
            med + mu_pad
        ),
        (
            math.log(tau_low),
            math.log(tau_high)
        ),
        (
            math.log(SIGMA_MIN),
            math.log(sigma_hi)
        ),
    ]

    tau_frozen = float(
        frozen_row["tau_obs_days"]
    )

    sigma_frozen = float(
        frozen_row[
            "sigma_drw_stationary_mag"
        ]
    )

    mu_frozen = float(
        frozen_row["mu_drw_mag"]
    )

    tau_candidates = [
        tau_frozen,
        max(
            tau_low,
            min(
                tau_high,
                10.0 * cadence
            )
        ),
        max(
            tau_low,
            min(
                tau_high,
                0.05 * baseline
            )
        ),
    ]

    starts = []

    for j, tau0 in enumerate(
        tau_candidates
    ):
        if j == 0:
            mu0 = mu_frozen
            sigma0 = sigma_frozen
        else:
            mu0 = med
            sigma0 = sd

        starts.append(
            [
                mu0,
                math.log(
                    max(
                        tau_low,
                        min(
                            tau_high,
                            tau0
                        )
                    )
                ),
                math.log(
                    max(
                        SIGMA_MIN,
                        min(
                            sigma_hi,
                            sigma0
                        )
                    )
                ),
            ]
        )

    best = None

    for start in starts:
        start = np.asarray(
            [
                np.clip(
                    start[0],
                    bounds[0][0],
                    bounds[0][1]
                ),
                np.clip(
                    start[1],
                    bounds[1][0],
                    bounds[1][1]
                ),
                np.clip(
                    start[2],
                    bounds[2][0],
                    bounds[2][1]
                ),
            ],
            dtype=float
        )

        res = minimize(
            lambda p: -drw_loglike_pars(
                p,
                t,
                y,
                err
            ),
            x0=start,
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 500,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(
            res.fun
        ):
            continue

        if (
            best is None
            or
            res.fun < best.fun
        ):
            best = res

    if best is None:
        return None

    mu, log_tau, log_sigma = (
        best.x
    )

    return {
        "success": bool(best.success),
        "message": str(best.message),
        "nit": int(getattr(best, "nit", -1)),
        "mu": float(mu),
        "tau": float(
            math.exp(log_tau)
        ),
        "sigma_stationary": float(
            math.exp(log_sigma)
        ),
        "loglike": float(
            -best.fun
        ),
    }


def near_log_bound(
    tau,
    lo,
    hi,
    frac=0.02,
):
    lt = math.log(tau)
    llo = math.log(lo)
    lhi = math.log(hi)

    pos = (
        (lt - llo)
        /
        (lhi - llo)
    )

    return (
        bool(pos <= frac),
        bool(pos >= 1.0 - frac),
        float(pos),
    )


def apply_scheme(
    x,
    scheme,
    blazar_id,
    filt,
):
    x = x.sort_values(
        "hmjd"
    ).reset_index(
        drop=True
    )

    meta = {
        "retained_fraction": np.nan,
        "seasonal_drop_quarter": np.nan,
    }

    if scheme == "THIN_HALF":
        parity = stable_parity(
            blazar_id,
            filt
        )

        keep = (
            np.arange(len(x))
            %
            2
        ) == parity

        y = x.loc[
            keep
        ].copy()

    elif scheme == "BASELINE_CENTRAL80":
        tmin = float(
            x["hmjd"].min()
        )

        tmax = float(
            x["hmjd"].max()
        )

        baseline = (
            tmax - tmin
        )

        lo = (
            tmin
            +
            0.10 * baseline
        )

        hi = (
            tmax
            -
            0.10 * baseline
        )

        y = x.loc[
            x["hmjd"].between(
                lo,
                hi,
                inclusive="both"
            )
        ].copy()

    elif scheme == "SEASONAL_DENSE_QUARTER_DROP":
        phase = (
            (
                x["hmjd"].to_numpy(dtype=float)
                -
                MJD_PHASE_ANCHOR
            )
            %
            YEAR_DAYS
        ) / YEAR_DAYS

        quarter = np.floor(
            4.0 * phase
        ).astype(int)

        quarter = np.clip(
            quarter,
            0,
            3
        )

        counts = np.bincount(
            quarter,
            minlength=4
        )

        qdrop = int(
            np.argmax(counts)
        )

        keep = (
            quarter
            !=
            qdrop
        )

        y = x.loc[
            keep
        ].copy()

        meta[
            "seasonal_drop_quarter"
        ] = qdrop

    else:
        raise RuntimeError(
            f"Unknown scheme: {scheme}"
        )

    meta[
        "retained_fraction"
    ] = (
        len(y)
        /
        len(x)
        if len(x) > 0
        else np.nan
    )

    return (
        y.reset_index(drop=True),
        meta,
    )


def analyze_modified(
    original,
    scheme,
    blazar_id,
    filt,
    frozen_row,
):
    x, smeta = apply_scheme(
        original,
        scheme,
        blazar_id,
        filt,
    )

    row = {
        "blazar_id": blazar_id,
        "blazar_class": frozen_row["blazar_class"],
        "sample_tier": frozen_row["sample_tier"],
        "filter_name": filt,
        "scheme": scheme,
        "N_original": int(len(original)),
        "N_modified": int(len(x)),
        "retained_fraction": smeta[
            "retained_fraction"
        ],
        "seasonal_drop_quarter": smeta[
            "seasonal_drop_quarter"
        ],
        "tau_obs_frozen_days": float(
            frozen_row["tau_obs_days"]
        ),
        "tau_rest_frozen_days": (
            float(
                frozen_row["tau_rest_days"]
            )
            if pd.notna(
                frozen_row["tau_rest_days"]
            )
            else np.nan
        ),
        "redshift_clean": (
            float(
                frozen_row["redshift_clean"]
            )
            if pd.notna(
                frozen_row["redshift_clean"]
            )
            else np.nan
        ),
        "fit_status": "NOT_RUN",
    }

    if len(x) < MIN_N:
        row["fit_status"] = (
            f"TOO_FEW_POINTS_LT_{MIN_N}"
        )
        return row

    t = x["hmjd"].to_numpy(
        dtype=float
    )

    y = x["mag"].to_numpy(
        dtype=float
    )

    err = x["magerr"].to_numpy(
        dtype=float
    )

    baseline = float(
        t[-1] - t[0]
    )

    cadence = float(
        np.median(
            np.diff(t)
        )
    )

    if not (
        np.isfinite(baseline)
        and
        baseline > 0
        and
        np.isfinite(cadence)
        and
        cadence > 0
    ):
        row["fit_status"] = (
            "INVALID_SAMPLING"
        )
        return row

    tau_low = max(
        0.5,
        0.25 * cadence
    )

    tau_high = max(
        100.0,
        10.0 * baseline
    )

    white = fit_white(
        y,
        err,
        frozen_row
    )

    if white is None:
        row["fit_status"] = (
            "WHITE_FIT_FAILED"
        )
        return row

    drw = fit_drw(
        t=t,
        y=y,
        err=err,
        tau_low=tau_low,
        tau_high=tau_high,
        cadence=cadence,
        baseline=baseline,
        frozen_row=frozen_row,
    )

    if drw is None:
        row["fit_status"] = (
            "DRW_FIT_FAILED"
        )
        return row

    n = len(x)

    bic_white = (
        2.0 * math.log(n)
        -
        2.0 * white["loglike"]
    )

    bic_drw = (
        3.0 * math.log(n)
        -
        2.0 * drw["loglike"]
    )

    delta_bic = (
        bic_white
        -
        bic_drw
    )

    tau = float(
        drw["tau"]
    )

    tau_over_cad = (
        tau / cadence
    )

    tau_over_base = (
        tau / baseline
    )

    near_lo, near_hi, logpos = near_log_bound(
        tau,
        tau_low,
        tau_high,
        frac=0.02,
    )

    interpretable = (
        bool(drw["success"])
        and
        delta_bic >= 10.0
        and
        tau >= 2.0 * cadence
        and
        tau <= baseline / 10.0
        and
        not near_lo
        and
        not near_hi
    )

    z = row[
        "redshift_clean"
    ]

    tau_rest = (
        tau / (1.0 + z)
        if np.isfinite(z)
        and
        z > -1
        else np.nan
    )

    tau_ratio = (
        tau
        /
        row["tau_obs_frozen_days"]
    )

    row.update({
        "baseline_days": baseline,
        "median_cadence_days": cadence,
        "tau_search_low_days": tau_low,
        "tau_search_high_days": tau_high,
        "optimizer_success_white": bool(
            white["success"]
        ),
        "optimizer_success_drw": bool(
            drw["success"]
        ),
        "optimizer_nit_drw": int(
            drw["nit"]
        ),
        "loglike_white": float(
            white["loglike"]
        ),
        "loglike_drw": float(
            drw["loglike"]
        ),
        "bic_white": bic_white,
        "bic_drw": bic_drw,
        "delta_bic_white_minus_drw": delta_bic,
        "tau_obs_days": tau,
        "tau_rest_days": tau_rest,
        "sigma_drw_stationary_mag": float(
            drw["sigma_stationary"]
        ),
        "tau_over_median_cadence": tau_over_cad,
        "tau_over_baseline": tau_over_base,
        "tau_near_lower_search_bound": near_lo,
        "tau_near_upper_search_bound": near_hi,
        "tau_log_search_position": logpos,
        "tau_interpretable_sensitivity": bool(
            interpretable
        ),
        "tau_ratio_to_frozen": tau_ratio,
        "abs_log10_tau_ratio": abs(
            math.log10(tau_ratio)
        ),
        "within_factor2_of_frozen": bool(
            0.5 <= tau_ratio <= 2.0
        ),
        "within_factor3_of_frozen": bool(
            (1.0 / 3.0)
            <=
            tau_ratio
            <=
            3.0
        ),
        "fit_status": "OK",
    })

    return row


# ============================================================
# MAIN
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="Process only first N not-yet-complete source-filter targets.",
)

args = parser.parse_args()

if not DRW_FILE.exists():
    raise FileNotFoundError(
        DRW_FILE
    )

master = pd.read_csv(
    DRW_FILE
)

master["blazar_id"] = (
    master["blazar_id"]
    .astype(str)
)

targets = master.loc[
    master[
        "tau_interpretable_primary"
    ].apply(as_bool)
].copy()

targets = targets.sort_values(
    [
        "blazar_id",
        "filter_name",
    ]
).reset_index(
    drop=True
)

if len(targets) != 1701:
    raise RuntimeError(
        f"Expected 1701 interpretable source-filter targets; got {len(targets)}"
    )

target_keys = [
    (
        str(r["blazar_id"]),
        str(r["filter_name"])
    )
    for _, r in targets.iterrows()
]

done_keys = set()

for p in MODEL_DIR.glob(
    "*.done"
):
    stem = p.stem

    if stem.endswith("_g"):
        done_keys.add(
            (
                stem[:-2],
                "g"
            )
        )
    elif stem.endswith("_r"):
        done_keys.add(
            (
                stem[:-2],
                "r"
            )
        )

todo = [
    key
    for key in target_keys
    if key not in done_keys
]

if args.limit is not None:
    todo = todo[
        :args.limit
    ]

print("=" * 78)
print("BLAZAR_I — STAGE 06C2")
print("DRW CADENCE / WINDOW / BASELINE SENSITIVITY")
print("=" * 78)
print(
    f"Frozen interpretable targets = {len(target_keys)}"
)
print(
    f"Already complete             = {len(done_keys)}"
)
print(
    f"This run                      = {len(todo)}"
)
print(
    f"Sensitivity schemes           = {len(SCHEMES)}"
)
print()

for i, (
    bid,
    filt
) in enumerate(
    todo,
    start=1
):
    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    nightly = pd.read_parquet(
        path
    )

    x = nightly.loc[
        nightly[
            "filter_name"
        ].astype(str).eq(filt),
        [
            "hmjd",
            "mag",
            "magerr",
        ],
    ].copy()

    for c in [
        "hmjd",
        "mag",
        "magerr",
    ]:
        x[c] = pd.to_numeric(
            x[c],
            errors="coerce"
        )

    x = x.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    x = x.loc[
        x["magerr"] > 0
    ].sort_values(
        "hmjd"
    ).reset_index(
        drop=True
    )

    frozen = targets.loc[
        targets["blazar_id"].eq(bid)
        &
        targets[
            "filter_name"
        ].astype(str).eq(filt)
    ]

    if len(frozen) != 1:
        raise RuntimeError(
            f"{bid} {filt}: frozen row count={len(frozen)}"
        )

    rr = frozen.iloc[0]

    if len(x) != int(
        rr["N_nightly"]
    ):
        raise RuntimeError(
            f"{bid} {filt}: N mismatch "
            f"{len(x)} vs {int(rr['N_nightly'])}"
        )

    result_rows = []

    for scheme in SCHEMES:
        result_rows.append(
            analyze_modified(
                original=x,
                scheme=scheme,
                blazar_id=bid,
                filt=filt,
                frozen_row=rr,
            )
        )

    out = pd.DataFrame(
        result_rows
    )

    out_path = (
        MODEL_DIR
        /
        f"{bid}_{filt}_06C2.csv"
    )

    out.to_csv(
        out_path,
        index=False
    )

    done_path = (
        MODEL_DIR
        /
        f"{bid}_{filt}.done"
    )

    done_path.write_text(
        "OK\n",
        encoding="utf-8"
    )

    if (
        i <= 5
        or
        i % 50 == 0
        or
        i == len(todo)
    ):
        bits = []

        for _, z in out.iterrows():
            if z["fit_status"] == "OK":
                bits.append(
                    f"{z['scheme']}:"
                    f"N={int(z['N_modified'])},"
                    f"tau={z['tau_obs_days']:.2f}d,"
                    f"ratio={z['tau_ratio_to_frozen']:.2f},"
                    f"interp={bool(z['tau_interpretable_sensitivity'])}"
                )
            else:
                bits.append(
                    f"{z['scheme']}:"
                    f"N={int(z['N_modified'])},"
                    f"status={z['fit_status']}"
                )

        print(
            f"{i}/{len(todo)} "
            f"{bid} {filt} | "
            +
            " | ".join(bits)
        )


# ============================================================
# STATUS
# ============================================================

n_done = len(
    list(
        MODEL_DIR.glob(
            "*.done"
        )
    )
)

remaining = (
    len(target_keys)
    -
    n_done
)

print()
print("=" * 78)
print("STAGE 06C2 CURRENT STATUS")
print("=" * 78)
print(
    f"Completed targets = {n_done} / {len(target_keys)}"
)
print(
    f"Remaining         = {remaining}"
)

if remaining > 0:
    print()
    print(
        "Partial run complete. Re-run the same command to resume."
    )
    raise SystemExit(0)


# ============================================================
# GLOBAL ASSEMBLY
# ============================================================

csv_files = sorted(
    MODEL_DIR.glob(
        "BZI_*_06C2.csv"
    )
)

all_rows = pd.concat(
    [
        pd.read_csv(f)
        for f in csv_files
    ],
    ignore_index=True
)

expected_rows = (
    len(target_keys)
    *
    len(SCHEMES)
)

if len(all_rows) != expected_rows:
    raise RuntimeError(
        f"Expected {expected_rows} global rows; got {len(all_rows)}"
    )

for c in [
    "optimizer_success_white",
    "optimizer_success_drw",
    "tau_near_lower_search_bound",
    "tau_near_upper_search_bound",
    "tau_interpretable_sensitivity",
    "within_factor2_of_frozen",
    "within_factor3_of_frozen",
]:
    if c in all_rows.columns:
        all_rows[c] = (
            all_rows[c]
            .astype(str)
            .str.lower()
            .isin(
                ["true", "1", "yes"]
            )
        )

all_rows.to_csv(
    OUT_MASTER,
    index=False
)


# ============================================================
# SOURCE-LEVEL WIDE TABLE
# ============================================================

wide_cols = [
    "tau_obs_days",
    "tau_rest_days",
    "tau_ratio_to_frozen",
    "tau_interpretable_sensitivity",
    "within_factor2_of_frozen",
    "within_factor3_of_frozen",
    "delta_bic_white_minus_drw",
    "N_modified",
    "retained_fraction",
]

wide = all_rows.pivot(
    index=[
        "blazar_id",
        "filter_name",
    ],
    columns="scheme",
    values=wide_cols
)

wide.columns = [
    f"{metric}_{scheme}"
    for metric, scheme in wide.columns
]

wide = wide.reset_index()

frozen_keep = targets[
    [
        "blazar_id",
        "filter_name",
        "blazar_class",
        "redshift_clean",
        "tau_obs_days",
        "tau_rest_days",
        "N_nightly",
        "baseline_days",
        "median_cadence_days",
    ]
].copy()

frozen_keep = frozen_keep.rename(
    columns={
        "tau_obs_days": "tau_obs_days_frozen",
        "tau_rest_days": "tau_rest_days_frozen",
        "N_nightly": "N_nightly_frozen",
        "baseline_days": "baseline_days_frozen",
        "median_cadence_days": "median_cadence_days_frozen",
    }
)

source = frozen_keep.merge(
    wide,
    on=[
        "blazar_id",
        "filter_name",
    ],
    how="left",
    validate="one_to_one"
)

source.to_csv(
    OUT_SOURCE,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06C2 FINAL SUMMARY",
    "=" * 72,
    "",
    f"Frozen interpretable source-filter targets: {len(target_keys)}",
]

for scheme in SCHEMES:
    x = all_rows.loc[
        all_rows["scheme"].eq(
            scheme
        )
    ].copy()

    ok = x.loc[
        x["fit_status"].eq("OK")
    ]

    interp = ok.loc[
        ok[
            "tau_interpretable_sensitivity"
        ]
    ]

    ratio = pd.to_numeric(
        ok["tau_ratio_to_frozen"],
        errors="coerce"
    )

    ratio_i = pd.to_numeric(
        interp["tau_ratio_to_frozen"],
        errors="coerce"
    )

    lines += [
        "",
        f"{scheme}:",
        (
            f"  fit OK = {len(ok)}/{len(x)}"
        ),
        (
            "  modified interpretable = "
            f"{len(interp)}/{len(x)} "
            f"({len(interp)/len(x):.3f})"
        ),
        (
            "  median retained fraction = "
            f"{ok['retained_fraction'].median():.3f}"
        ),
        (
            "  median tau/frozen (all fit OK) = "
            f"{ratio.median():.3f}"
        ),
        (
            "  median tau/frozen (modified interpretable) = "
            f"{ratio_i.median():.3f}"
        ),
        (
            "  within factor 2 of frozen (all fit OK) = "
            f"{int(ok['within_factor2_of_frozen'].sum())}/{len(ok)}"
        ),
        (
            "  within factor 3 of frozen (all fit OK) = "
            f"{int(ok['within_factor3_of_frozen'].sum())}/{len(ok)}"
        ),
    ]

    for cls in [
        "BLL",
        "FSRQ",
    ]:
        z = interp.loc[
            interp[
                "blazar_class"
            ].eq(cls)
        ]

        if len(z) == 0:
            continue

        lines.append(
            f"  {cls}: Ninterp={len(z)}, "
            f"median tau={z['tau_obs_days'].median():.2f} d, "
            f"median tau/frozen={z['tau_ratio_to_frozen'].median():.3f}"
        )

    # Cross-band log-tau correlation for sources interpretable
    # in both bands under this scheme.
    z = interp[
        [
            "blazar_id",
            "filter_name",
            "tau_obs_days",
        ]
    ].copy()

    piv = z.pivot(
        index="blazar_id",
        columns="filter_name",
        values="tau_obs_days"
    )

    if (
        "g" in piv.columns
        and
        "r" in piv.columns
    ):
        both = piv.dropna(
            subset=[
                "g",
                "r",
            ]
        )

        if len(both) >= 3:
            rho, p = spearmanr(
                np.log10(
                    both["g"]
                ),
                np.log10(
                    both["r"]
                ),
            )

            lines.append(
                "  cross-band logtau: "
                f"N={len(both)}, "
                f"rho={rho:.3f}, "
                f"p={p:.3g}"
            )

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print()
print(summary)
print()
print("=" * 78)
print("GLOBAL FILES SAVED")
print("=" * 78)
print(OUT_MASTER)
print(OUT_SOURCE)
print(OUT_SUMMARY)
print()
print("STAGE 06C2 COMPLETE")
