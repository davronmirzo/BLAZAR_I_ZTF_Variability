# ============================================================
# BLAZAR_I — STAGE 09D1B
# TEMPORAL EARLY/LATE DRW REPLICATION
#
# Purpose:
#   Refit the exact irregular OU/DRW model on EARLY and LATE temporal
#   blocks and test whether the full-sample FSRQ/BLL rest-frame timescale
#   contrast is reproduced in both halves.
#
# Analysis support:
#   Stage09D0 sources with:
#       >=50 nightly points in BOTH g/r in BOTH halves
#       known redshift
#
# Temporal split:
#   Uses the frozen source-level t_split saved by Stage09D0.
#
# DRW fitter:
#   Same white-noise and exact irregular OU likelihood machinery used in
#   Stage09C1 calibration.
#
# Interpretability gate:
#   optimizer success
#   DeltaBIC >= 10
#   tau >= 2 * median cadence
#   tau <= baseline / 10
#   tau not within 2% of log-search boundaries
#
# Inference for each half:
#   D0: log(tau_rest) ~ FSRQ
#   D1: + z(redshift) + log10(gamma energy flux) when available
#   D2: + filter-specific half median magnitude + PS1 host proxy
#
#   Row-level OLS uses cluster-robust covariance by blazar_id because
#   g/r rows from the same source are correlated.
#
#   Also fitted:
#       one-row-per-source geometric-mean tau_rest model
#       single-band g and r D2 models
#
# LSP-only sensitivity:
#   If a recognizable SED column is available, D2 is also fitted in the
#   LSP-only overlap subset.
#
# IMPORTANT:
#   - EARLY and LATE are repeated temporal blocks of the same sources.
#   - Their p-values are NOT independent.
#   - This is temporal replication, not a causal model.
#
# Outputs:
#   outputs/models/stage09d1b_drw_temporal/*.csv
#   outputs/tables/stage09d1b_drw_half_master.csv
#   outputs/tables/stage09d1b_clustered_models.csv
#   outputs/tables/stage09d1b_source_level_models.csv
#   outputs/tables/stage09d1b_single_band_models.csv
#   outputs/tables/stage09d1b_lsp_only_models.csv
#   outputs/audit/stage09d1b_summary.txt
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
from scipy.optimize import minimize
import statsmodels.api as sm

warnings.filterwarnings("ignore", category=RuntimeWarning)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"
MODEL_DIR = ROOT / "outputs" / "models" / "stage09d1b_drw_temporal"

ELIG_FILE = TABLE_DIR / "stage09d0_temporal_source_eligibility.csv"
COUNT_FILE = TABLE_DIR / "stage09d0_temporal_split_counts.csv"
CONF_FILE = TABLE_DIR / "stage09a2_q1_confounder_master_ps1.csv"

OUT_MASTER = TABLE_DIR / "stage09d1b_drw_half_master.csv"
OUT_CLUSTER = TABLE_DIR / "stage09d1b_clustered_models.csv"
OUT_SOURCE = TABLE_DIR / "stage09d1b_source_level_models.csv"
OUT_BAND = TABLE_DIR / "stage09d1b_single_band_models.csv"
OUT_LSP = TABLE_DIR / "stage09d1b_lsp_only_models.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09d1b_summary.txt"

for p in [TABLE_DIR, AUDIT_DIR, MODEL_DIR]:
    p.mkdir(parents=True, exist_ok=True)

MIN_N_HALF = 50
SIGMA_MIN = 1.0e-5
SIGMA_MAX_HARD = 5.0


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def parse_bool_series(s):
    num = pd.to_numeric(s, errors="coerce")
    out = pd.Series(False, index=s.index, dtype=bool)
    good = num.notna()
    out.loc[good] = num.loc[good] != 0
    rem = ~good
    if rem.any():
        txt = (
            s.loc[rem]
            .astype(str)
            .str.strip()
            .str.lower()
        )
        out.loc[rem] = txt.isin(["true", "t", "yes", "y"])
    return out


def robust_scale(y):
    y = np.asarray(y, dtype=float)
    med = np.nanmedian(y)
    mad = np.nanmedian(np.abs(y - med))
    nmad = 1.4826 * mad
    sd = np.nanstd(y, ddof=1)

    for v in [nmad, sd, 0.05]:
        if np.isfinite(v) and v > 0:
            return float(v)

    return 0.05


def near_log_bound(tau, lo, hi, frac=0.02):
    lt = math.log(tau)
    llo = math.log(lo)
    lhi = math.log(hi)
    pos = (lt - llo) / (lhi - llo)
    return (
        bool(pos <= frac),
        bool(pos >= 1.0 - frac),
        float(pos),
    )


# ============================================================
# LIKELIHOODS
# ============================================================

def white_loglike_pars(pars, y, err):
    mu, log_sigma = pars
    sigma = math.exp(log_sigma)

    var = err ** 2 + sigma ** 2

    if np.any(~np.isfinite(var)) or np.any(var <= 0):
        return -np.inf

    resid = y - mu

    return -0.5 * float(
        np.sum(
            np.log(2.0 * np.pi * var)
            +
            resid ** 2 / var
        )
    )


def drw_loglike_pars(pars, t, y, err):
    mu, log_tau, log_sigma = pars

    tau = math.exp(log_tau)
    sigma = math.exp(log_sigma)

    if not (
        np.isfinite(mu)
        and np.isfinite(tau)
        and np.isfinite(sigma)
        and tau > 0
        and sigma > 0
    ):
        return -np.inf

    sigma2 = sigma ** 2

    m_pred = 0.0
    p_pred = sigma2
    ll = 0.0

    for i in range(len(t)):
        obs_var = p_pred + err[i] ** 2

        if not np.isfinite(obs_var) or obs_var <= 0:
            return -np.inf

        innov = y[i] - mu - m_pred

        ll += -0.5 * (
            math.log(2.0 * math.pi * obs_var)
            +
            innov ** 2 / obs_var
        )

        gain = p_pred / obs_var
        m_post = m_pred + gain * innov
        p_post = p_pred * (1.0 - gain)

        if i == len(t) - 1:
            break

        dt = t[i + 1] - t[i]

        if not np.isfinite(dt) or dt < 0:
            return -np.inf

        a = math.exp(-dt / tau)

        q = sigma2 * (
            -math.expm1(
                -2.0 * dt / tau
            )
        )

        m_pred = a * m_post
        p_pred = a ** 2 * p_post + q

    return float(ll)


# ============================================================
# FITTERS
# ============================================================

def fit_white(y, err):
    med = float(np.median(y))
    sd = robust_scale(y)

    mu_pad = max(2.0, 5.0 * sd)

    sigma_hi = min(
        SIGMA_MAX_HARD,
        max(1.0, 10.0 * sd),
    )

    bounds = [
        (med - mu_pad, med + mu_pad),
        (math.log(SIGMA_MIN), math.log(sigma_hi)),
    ]

    starts = [
        [
            med,
            math.log(
                max(
                    SIGMA_MIN,
                    min(sigma_hi, sd),
                )
            ),
        ],
        [
            float(np.mean(y)),
            math.log(
                max(
                    SIGMA_MIN,
                    min(sigma_hi, 0.5 * sd),
                )
            ),
        ],
    ]

    best = None

    for start in starts:
        start = np.asarray(
            [
                np.clip(start[0], *bounds[0]),
                np.clip(start[1], *bounds[1]),
            ],
            dtype=float,
        )

        res = minimize(
            lambda p: -white_loglike_pars(
                p,
                y,
                err,
            ),
            x0=start,
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 250,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(res.fun):
            continue

        if best is None or res.fun < best.fun:
            best = res

    if best is None:
        return None

    return {
        "success": bool(best.success),
        "mu": float(best.x[0]),
        "sigma_intrinsic": float(
            math.exp(best.x[1])
        ),
        "loglike": float(-best.fun),
    }


def fit_drw(t, y, err, cadence, baseline):
    med = float(np.median(y))
    sd = robust_scale(y)

    tau_low = max(
        0.5,
        0.25 * cadence,
    )

    tau_high = max(
        100.0,
        10.0 * baseline,
    )

    mu_pad = max(2.0, 5.0 * sd)

    sigma_hi = min(
        SIGMA_MAX_HARD,
        max(1.0, 10.0 * sd),
    )

    bounds = [
        (med - mu_pad, med + mu_pad),
        (math.log(tau_low), math.log(tau_high)),
        (math.log(SIGMA_MIN), math.log(sigma_hi)),
    ]

    tau_candidates = [
        max(
            tau_low,
            min(tau_high, 3.0 * cadence),
        ),
        max(
            tau_low,
            min(
                tau_high,
                math.sqrt(
                    max(3.0 * cadence, tau_low)
                    *
                    max(0.05 * baseline, tau_low)
                ),
            ),
        ),
        max(
            tau_low,
            min(tau_high, 0.05 * baseline),
        ),
    ]

    best = None

    for tau0 in tau_candidates:
        start = np.asarray(
            [
                med,
                math.log(tau0),
                math.log(
                    max(
                        SIGMA_MIN,
                        min(sigma_hi, sd),
                    )
                ),
            ],
            dtype=float,
        )

        for j in range(3):
            start[j] = np.clip(
                start[j],
                bounds[j][0],
                bounds[j][1],
            )

        res = minimize(
            lambda p: -drw_loglike_pars(
                p,
                t,
                y,
                err,
            ),
            x0=start,
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": 400,
                "ftol": 1.0e-10,
            },
        )

        if not np.isfinite(res.fun):
            continue

        if best is None or res.fun < best.fun:
            best = res

    if best is None:
        return None

    mu, log_tau, log_sigma = best.x

    tau = float(math.exp(log_tau))

    near_lo, near_hi, logpos = near_log_bound(
        tau,
        tau_low,
        tau_high,
        frac=0.02,
    )

    return {
        "success": bool(best.success),
        "mu": float(mu),
        "tau": tau,
        "sigma_stationary": float(
            math.exp(log_sigma)
        ),
        "loglike": float(-best.fun),
        "tau_low": float(tau_low),
        "tau_high": float(tau_high),
        "near_lo": near_lo,
        "near_hi": near_hi,
        "logpos": logpos,
    }


def fit_half_one(bid, cls, z, filt, half, d):
    x = (
        d.loc[
            d["filter_name"].eq(filt)
        ]
        .copy()
        .sort_values("hmjd")
        .reset_index(drop=True)
    )

    t = numeric(x["hmjd"]).to_numpy(dtype=float)
    mag = numeric(x["mag"]).to_numpy(dtype=float)
    err = numeric(x["magerr"]).to_numpy(dtype=float)

    good = (
        np.isfinite(t)
        &
        np.isfinite(mag)
        &
        np.isfinite(err)
        &
        (err > 0)
    )

    t = t[good]
    mag = mag[good]
    err = err[good]

    row = {
        "blazar_id": bid,
        "blazar_class": cls,
        "redshift": z,
        "filter_name": filt,
        "half": half,
        "N_nightly": int(len(t)),
        "fit_status": "NOT_RUN",
    }

    if len(t) < MIN_N_HALF:
        row["fit_status"] = f"TOO_FEW_LT_{MIN_N_HALF}"
        return row

    baseline = float(t[-1] - t[0])
    cadence = float(np.median(np.diff(t)))

    if (
        not np.isfinite(baseline)
        or baseline <= 0
        or
        not np.isfinite(cadence)
        or cadence <= 0
    ):
        row["fit_status"] = "INVALID_TIME_GRID"
        return row

    white = fit_white(mag, err)
    drw = fit_drw(
        t,
        mag,
        err,
        cadence,
        baseline,
    )

    if white is None:
        row["fit_status"] = "WHITE_FAILED"
        return row

    if drw is None:
        row["fit_status"] = "DRW_FAILED"
        return row

    n = len(t)

    bic_white = (
        2.0 * math.log(n)
        -
        2.0 * white["loglike"]
    )

    bic_drw = (
        3.0 * math.log(n)
        -
        2.0 * drw["loglike"]
    )

    dbic = bic_white - bic_drw

    tau = drw["tau"]

    interpretable = bool(
        drw["success"]
        and
        dbic >= 10.0
        and
        tau >= 2.0 * cadence
        and
        tau <= baseline / 10.0
        and
        not drw["near_lo"]
        and
        not drw["near_hi"]
    )

    tau_rest = (
        tau / (1.0 + z)
        if np.isfinite(z) and z >= 0
        else np.nan
    )

    row.update({
        "baseline_days": baseline,
        "median_cadence_days": cadence,
        "median_mag": float(np.median(mag)),
        "median_magerr": float(np.median(err)),
        "optimizer_success_white": bool(
            white["success"]
        ),
        "optimizer_success_drw": bool(
            drw["success"]
        ),
        "delta_bic_white_minus_drw": float(dbic),
        "tau_obs_days": float(tau),
        "tau_rest_days": float(tau_rest),
        "sigma_drw_stationary_mag": float(
            drw["sigma_stationary"]
        ),
        "tau_over_cadence": float(
            tau / cadence
        ),
        "tau_over_baseline": float(
            tau / baseline
        ),
        "tau_near_lower_bound": bool(
            drw["near_lo"]
        ),
        "tau_near_upper_bound": bool(
            drw["near_hi"]
        ),
        "tau_interpretable": interpretable,
        "fit_status": "OK",
    })

    return row


# ============================================================
# COVARIATE DISCOVERY
# ============================================================

def first_existing(df, candidates):
    lower_map = {
        c.lower(): c
        for c in df.columns
    }

    for c in candidates:
        if c in df.columns:
            return c

        hit = lower_map.get(
            c.lower()
        )

        if hit is not None:
            return hit

    return None


def standardize(s):
    x = numeric(s)
    mu = x.mean()
    sd = x.std(ddof=0)

    if not np.isfinite(sd) or sd <= 0:
        return pd.Series(
            np.nan,
            index=s.index,
            dtype=float,
        )

    return (x - mu) / sd


# ============================================================
# REGRESSION HELPERS
# ============================================================

def cluster_ols(df, predictors, focal="FSRQ"):
    cols = [
        "log_tau_rest",
        "blazar_id",
        *predictors,
    ]

    x = df[cols].copy()

    for c in [
        "log_tau_rest",
        *predictors,
    ]:
        x[c] = numeric(x[c])

    x = x.dropna()

    if len(x) < 30:
        return {
            "N_rows": len(x),
            "N_sources": x["blazar_id"].nunique(),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": "TOO_FEW_COMPLETE_CASES",
        }

    X = sm.add_constant(
        x[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            x["log_tau_rest"].astype(float),
            X,
        ).fit(
            cov_type="cluster",
            cov_kwds={
                "groups": x["blazar_id"],
            },
        )

        beta = float(
            fit.params[focal]
        )

        se = float(
            fit.bse[focal]
        )

        return {
            "N_rows": len(x),
            "N_sources": x["blazar_id"].nunique(),
            "factor": math.exp(beta),
            "ci95_low": math.exp(
                beta
                -
                1.959963984540054 * se
            ),
            "ci95_high": math.exp(
                beta
                +
                1.959963984540054 * se
            ),
            "p": float(
                fit.pvalues[focal]
            ),
            "status": "OK",
        }

    except Exception as exc:
        return {
            "N_rows": len(x),
            "N_sources": x["blazar_id"].nunique(),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": f"FAILED:{type(exc).__name__}",
        }


def ordinary_ols(df, predictors, focal="FSRQ"):
    cols = [
        "log_tau_rest",
        *predictors,
    ]

    x = df[cols].copy()

    for c in cols:
        x[c] = numeric(x[c])

    x = x.dropna()

    if len(x) < 30:
        return {
            "N_sources": len(x),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": "TOO_FEW_COMPLETE_CASES",
        }

    X = sm.add_constant(
        x[predictors].astype(float),
        has_constant="add",
    )

    try:
        fit = sm.OLS(
            x["log_tau_rest"].astype(float),
            X,
        ).fit(
            cov_type="HC3",
        )

        beta = float(
            fit.params[focal]
        )

        se = float(
            fit.bse[focal]
        )

        return {
            "N_sources": len(x),
            "factor": math.exp(beta),
            "ci95_low": math.exp(
                beta
                -
                1.959963984540054 * se
            ),
            "ci95_high": math.exp(
                beta
                +
                1.959963984540054 * se
            ),
            "p": float(
                fit.pvalues[focal]
            ),
            "status": "OK",
        }

    except Exception as exc:
        return {
            "N_sources": len(x),
            "factor": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan,
            "p": np.nan,
            "status": f"FAILED:{type(exc).__name__}",
        }


# ============================================================
# LOAD SUPPORT + METADATA
# ============================================================

for path in [
    ELIG_FILE,
    COUNT_FILE,
    CONF_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

elig = pd.read_csv(
    ELIG_FILE,
    low_memory=False,
)

elig["blazar_id"] = (
    elig["blazar_id"]
    .astype(str)
)

elig["drw_rest_N50_both_halves"] = (
    parse_bool_series(
        elig["drw_rest_N50_both_halves"]
    )
)

elig = elig.loc[
    elig["drw_rest_N50_both_halves"]
].copy()

if len(elig) == 0:
    raise RuntimeError(
        "No DRW temporal support sources."
    )

counts = pd.read_csv(
    COUNT_FILE,
    low_memory=False,
)

counts["blazar_id"] = (
    counts["blazar_id"]
    .astype(str)
)

split_lookup = (
    counts[
        [
            "blazar_id",
            "t_split",
        ]
    ]
    .drop_duplicates(
        "blazar_id"
    )
    .set_index(
        "blazar_id"
    )
)

conf = pd.read_csv(
    CONF_FILE,
    low_memory=False,
)

conf["blazar_id"] = (
    conf["blazar_id"]
    .astype(str)
)

conf = conf.drop_duplicates(
    "blazar_id"
)

# Discover static confounders without hard-coding one exact historical schema.
z_col = first_existing(
    conf,
    [
        "redshift",
        "redshift_clean",
        "z",
    ],
)

sed_col = first_existing(
    conf,
    [
        "sed_class",
        "SED_class_clean",
        "sed_class_clean",
        "SED_class",
    ],
)

gamma_col = first_existing(
    conf,
    [
        "log10_Energy_Flux100_DR4",
        "logEnergyFlux_DR4",
        "fermi_log10_energy_flux",
        "log_gamma_energy_flux",
    ],
)

host_col = first_existing(
    conf,
    [
        "ps1_host_proxy_ri",
        "ps1_host_proxy",
        "host_proxy",
        "ps1_extension_proxy",
    ],
)

if z_col is None:
    # Eligibility file itself contains redshift from Stage09D0.
    z_col_elig = first_existing(
        elig,
        [
            "redshift",
            "redshift_clean",
            "z",
        ],
    )
else:
    z_col_elig = None

meta_cols = [
    "blazar_id",
    "blazar_class",
]

if z_col is not None:
    meta_cols.append(z_col)

if sed_col is not None:
    meta_cols.append(sed_col)

if gamma_col is not None:
    meta_cols.append(gamma_col)

if host_col is not None:
    meta_cols.append(host_col)

meta = conf[
    list(dict.fromkeys(meta_cols))
].copy()

meta = elig[
    [
        "blazar_id",
        "blazar_class",
    ]
    +
    (
        [z_col_elig]
        if z_col_elig is not None
        else
        []
    )
].merge(
    meta,
    on=[
        c
        for c in [
            "blazar_id",
            "blazar_class",
        ]
        if c in meta.columns
    ],
    how="left",
    suffixes=("_elig", ""),
)

# Normalize redshift.
if z_col is not None and z_col in meta.columns:
    meta["redshift_work"] = numeric(
        meta[z_col]
    )
elif z_col_elig is not None and z_col_elig in meta.columns:
    meta["redshift_work"] = numeric(
        meta[z_col_elig]
    )
else:
    raise RuntimeError(
        "Could not resolve redshift column."
    )

meta = meta.drop_duplicates(
    "blazar_id"
).set_index(
    "blazar_id"
)

source_ids = elig[
    "blazar_id"
].tolist()

print("=" * 80)
print("BLAZAR_I — STAGE 09D1B TEMPORAL DRW REPLICATION")
print("=" * 80)
print("Support sources =", len(source_ids))
print("Resolved columns:")
print("  redshift =", z_col if z_col is not None else z_col_elig)
print("  SED      =", sed_col)
print("  gamma    =", gamma_col)
print("  host     =", host_col)


# ============================================================
# REFIT, RESUMABLE BY SOURCE
# ============================================================

frames = []

for i, bid in enumerate(
    source_ids,
    start=1,
):
    out_file = MODEL_DIR / f"{bid}_09D1B.csv"

    if out_file.exists():
        res = pd.read_csv(
            out_file,
            low_memory=False,
        )

        if len(res) == 4:
            frames.append(res)

            if (
                i % 50 == 0
                or
                i == len(source_ids)
            ):
                print(
                    f"Completed {i}/{len(source_ids)} sources"
                )

            continue

    if bid not in split_lookup.index:
        raise RuntimeError(
            f"Missing split for {bid}"
        )

    tsplit = float(
        split_lookup.loc[
            bid,
            "t_split",
        ]
    )

    m = meta.loc[bid]

    cls = str(
        m.get(
            "blazar_class",
            ""
        )
    )

    z = float(
        m["redshift_work"]
    )

    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(path)

    d = pd.read_parquet(path)

    d["filter_name"] = (
        d["filter_name"]
        .astype(str)
        .str.lower()
        .str.strip()
    )

    for c in [
        "hmjd",
        "mag",
        "magerr",
    ]:
        d[c] = numeric(d[c])

    d = d.loc[
        d["filter_name"].isin(["g", "r"])
        &
        np.isfinite(d["hmjd"])
        &
        np.isfinite(d["mag"])
        &
        np.isfinite(d["magerr"])
        &
        (d["magerr"] > 0)
    ].copy()

    rows = []

    for half in [
        "EARLY",
        "LATE",
    ]:
        if half == "EARLY":
            dh = d.loc[
                d["hmjd"]
                <=
                tsplit
            ].copy()
        else:
            dh = d.loc[
                d["hmjd"]
                >
                tsplit
            ].copy()

        for filt in [
            "g",
            "r",
        ]:
            rows.append(
                fit_half_one(
                    bid,
                    cls,
                    z,
                    filt,
                    half,
                    dh,
                )
            )

    res = pd.DataFrame(rows)
    res.to_csv(
        out_file,
        index=False,
    )

    frames.append(res)

    if (
        i % 50 == 0
        or
        i == len(source_ids)
    ):
        print(
            f"Completed {i}/{len(source_ids)} sources"
        )


master = pd.concat(
    frames,
    ignore_index=True,
)

master["tau_interpretable"] = (
    parse_bool_series(
        master["tau_interpretable"]
    )
)

master.to_csv(
    OUT_MASTER,
    index=False,
)


# ============================================================
# ATTACH COVARIATES
# ============================================================

cov = conf.copy()

keep = [
    "blazar_id",
]

for c in [
    sed_col,
    gamma_col,
    host_col,
]:
    if c is not None and c in cov.columns:
        keep.append(c)

cov = cov[
    list(dict.fromkeys(keep))
].copy()

analysis = master.merge(
    cov,
    on="blazar_id",
    how="left",
    validate="many_to_one",
)

analysis["FSRQ"] = (
    analysis["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

analysis["redshift_work"] = numeric(
    analysis["redshift"]
)

analysis["log_tau_rest"] = np.log(
    numeric(
        analysis["tau_rest_days"]
    )
)

analysis["mag_half"] = numeric(
    analysis["median_mag"]
)

if gamma_col is not None:
    analysis["gamma_work"] = numeric(
        analysis[gamma_col]
    )
else:
    analysis["gamma_work"] = np.nan

if host_col is not None:
    analysis["host_work"] = numeric(
        analysis[host_col]
    )
else:
    analysis["host_work"] = np.nan

if sed_col is not None:
    analysis["sed_work"] = (
        analysis[sed_col]
        .astype(str)
        .str.upper()
        .str.strip()
    )
else:
    analysis["sed_work"] = ""


# ============================================================
# HALF-SPECIFIC STANDARDIZATION + MODELS
# ============================================================

cluster_rows = []
source_rows = []
band_rows = []
lsp_rows = []

for half in [
    "EARLY",
    "LATE",
]:
    x = analysis.loc[
        analysis["half"].eq(half)
        &
        analysis["tau_interpretable"]
        &
        np.isfinite(
            numeric(
                analysis["tau_rest_days"]
            )
        )
        &
        (
            numeric(
                analysis["tau_rest_days"]
            )
            >
            0
        )
    ].copy()

    x["z_z"] = standardize(
        x["redshift_work"]
    )

    x["gamma_z"] = standardize(
        x["gamma_work"]
    )

    # Filter-specific brightness standardization.
    x["mag_z"] = np.nan

    for filt in [
        "g",
        "r",
    ]:
        idx = x.index[
            x["filter_name"].eq(filt)
        ]

        x.loc[
            idx,
            "mag_z",
        ] = standardize(
            x.loc[
                idx,
                "mag_half",
            ]
        ).to_numpy()

    x["host_z"] = standardize(
        x["host_work"]
    )

    # D0.
    r = cluster_ols(
        x,
        predictors=[
            "FSRQ",
        ],
    )

    cluster_rows.append({
        "half": half,
        "model": "D0_CLASS_ONLY",
        **r,
    })

    # D1 only if gamma resolved.
    d1_predictors = [
        "FSRQ",
        "z_z",
    ]

    if gamma_col is not None:
        d1_predictors.append(
            "gamma_z"
        )

    r = cluster_ols(
        x,
        predictors=d1_predictors,
    )

    cluster_rows.append({
        "half": half,
        "model": "D1_Z_GAMMA",
        **r,
    })

    # D2 includes half-specific filter brightness and host if available.
    d2_predictors = list(
        d1_predictors
    )

    d2_predictors.append(
        "mag_z"
    )

    if host_col is not None:
        d2_predictors.append(
            "host_z"
        )

    r = cluster_ols(
        x,
        predictors=d2_predictors,
    )

    cluster_rows.append({
        "half": half,
        "model": "D2_FULL",
        **r,
    })

    # Single-band D2.
    for filt in [
        "g",
        "r",
    ]:
        xb = x.loc[
            x["filter_name"].eq(filt)
        ].copy()

        r = ordinary_ols(
            xb,
            predictors=d2_predictors,
        )

        band_rows.append({
            "half": half,
            "filter_name": filt,
            "model": "D2_FULL",
            **r,
        })

    # Source-level both-band geometric mean among sources with both bands.
    piv = x.pivot_table(
        index="blazar_id",
        columns="filter_name",
        values="tau_rest_days",
        aggfunc="first",
    )

    common = piv.dropna(
        subset=[
            "g",
            "r",
        ]
    ).copy()

    common["tau_geom"] = np.sqrt(
        common["g"]
        *
        common["r"]
    )

    src = (
        x.sort_values(
            "filter_name"
        )
        .drop_duplicates(
            "blazar_id"
        )
        .set_index(
            "blazar_id"
        )
    )

    s = src.loc[
        common.index
    ].copy()

    s["log_tau_rest"] = np.log(
        common["tau_geom"]
    )

    # Source-level magnitude = mean of standardized g/r brightness where possible.
    mz = x.pivot_table(
        index="blazar_id",
        columns="filter_name",
        values="mag_z",
        aggfunc="first",
    )

    if (
        "g" in mz.columns
        and
        "r" in mz.columns
    ):
        s["mag_z"] = mz.loc[
            s.index
        ][
            [
                "g",
                "r",
            ]
        ].mean(
            axis=1
        )

    r = ordinary_ols(
        s.reset_index(),
        predictors=d2_predictors,
    )

    source_rows.append({
        "half": half,
        "model": "D2_SOURCE_GEOMEAN",
        **r,
    })

    # LSP-only D2.
    if sed_col is not None:
        xlsp = x.loc[
            x["sed_work"].eq("LSP")
        ].copy()

        r = cluster_ols(
            xlsp,
            predictors=d2_predictors,
        )

        lsp_rows.append({
            "half": half,
            "model": "D2_LSP_ONLY",
            **r,
        })


cluster = pd.DataFrame(
    cluster_rows
)

source_models = pd.DataFrame(
    source_rows
)

band_models = pd.DataFrame(
    band_rows
)

lsp_models = pd.DataFrame(
    lsp_rows
)

cluster.to_csv(
    OUT_CLUSTER,
    index=False,
)

source_models.to_csv(
    OUT_SOURCE,
    index=False,
)

band_models.to_csv(
    OUT_BAND,
    index=False,
)

lsp_models.to_csv(
    OUT_LSP,
    index=False,
)


# ============================================================
# FINAL SUMMARY
# ============================================================

def get_model(df, half, model, filt=None):
    mask = (
        df["half"].eq(half)
        &
        df["model"].eq(model)
    )

    if filt is not None:
        mask = (
            mask
            &
            df["filter_name"].eq(filt)
        )

    hit = df.loc[
        mask
    ]

    if len(hit) != 1:
        return None

    return hit.iloc[0]


lines = [
    "BLAZAR_I - STAGE 09D1B FINAL SUMMARY",
    "=" * 80,
    "",
    "TEMPORAL EARLY/LATE DRW REPLICATION",
    "",
    f"Pre-outcome temporal support sources : {len(source_ids)}",
    f"Resolved gamma covariate             : {gamma_col}",
    f"Resolved host covariate              : {host_col}",
    f"Resolved SED covariate               : {sed_col}",
    "",
]

for half in [
    "EARLY",
    "LATE",
]:
    x = master.loc[
        master["half"].eq(half)
    ]

    interp = x.loc[
        x["tau_interpretable"]
    ]

    lines += [
        f"{half}:",
        f"  source-filter fits                : {len(x)}",
        f"  interpretable source-filter rows  : {len(interp)}",
        f"  interpretable unique sources      : {interp['blazar_id'].nunique()}",
    ]

    for model in [
        "D0_CLASS_ONLY",
        "D1_Z_GAMMA",
        "D2_FULL",
    ]:
        r = get_model(
            cluster,
            half,
            model,
        )

        if r is not None:
            lines.append(
                f"  clustered {model:14s}: "
                f"factor={r['factor']:.3f}, "
                f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
                f"p={r['p']:.3g}, "
                f"rows={int(r['N_rows'])}, "
                f"sources={int(r['N_sources'])}"
            )

    r = get_model(
        source_models,
        half,
        "D2_SOURCE_GEOMEAN",
    )

    if r is not None:
        lines.append(
            f"  source-level D2 geomean : "
            f"factor={r['factor']:.3f}, "
            f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
            f"p={r['p']:.3g}, Nsrc={int(r['N_sources'])}"
        )

    for filt in [
        "g",
        "r",
    ]:
        r = get_model(
            band_models,
            half,
            "D2_FULL",
            filt=filt,
        )

        if r is not None:
            lines.append(
                f"  single-band {filt} D2       : "
                f"factor={r['factor']:.3f}, "
                f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
                f"p={r['p']:.3g}, N={int(r['N_sources'])}"
            )

    if len(lsp_models):
        r = get_model(
            lsp_models,
            half,
            "D2_LSP_ONLY",
        )

        if r is not None:
            lines.append(
                f"  LSP-only clustered D2       : "
                f"factor={r['factor']:.3f}, "
                f"95%CI=[{r['ci95_low']:.3f},{r['ci95_high']:.3f}], "
                f"p={r['p']:.3g}, "
                f"rows={int(r['N_rows'])}, "
                f"sources={int(r['N_sources'])}"
            )

    lines.append("")

lines += [
    "Interpretation locks:",
    "  - A factor <1 means shorter rest-frame tau in FSRQs relative to BLLs.",
    "  - EARLY and LATE are repeated temporal blocks, not independent samples.",
    "  - Consistent D2 direction across halves is the key temporal robustness test.",
    "  - LSP-only attenuation, if present again, remains evidence that population/SED",
    "    composition contributes to the global class contrast.",
    "  - Long-timescale recovery limitations from Stage09C1 remain applicable.",
    "",
    "Files saved:",
    f"  {OUT_MASTER}",
    f"  {OUT_CLUSTER}",
    f"  {OUT_SOURCE}",
    f"  {OUT_BAND}",
    f"  {OUT_LSP}",
    "",
    "STAGE 09D1B COMPLETE",
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
