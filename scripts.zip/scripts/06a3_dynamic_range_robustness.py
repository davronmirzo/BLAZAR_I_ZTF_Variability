# ============================================================
# BLAZAR_I — STAGE 06A3
# DYNAMIC-RANGE ROBUSTNESS OF RMS–FLUX -> COLOUR-BREAK LINK
#
# Motivation:
#   STAGE 06A2 showed that the rms–flux -> robust colour-break
#   association is significant under all segmentation schemes in
#   minimal models, but often attenuates after adding r-band
#   magnitude range.
#
# This stage asks whether that attenuation reflects:
#   (a) simple linear adjustment,
#   (b) nonlinear dependence on dynamic range,
#   (c) effect heterogeneity with dynamic range, or
#   (d) imbalance across dynamic-range strata.
#
# Schemes:
#   PRIMARY20  = frozen STAGE 03B strict-both definition
#   S10_OCCUPANCY
#   S20_SPAN120
#   S30_OCCUPANCY
#   S90D_FIXED
#
# For each scheme, restricted to BOTH-band eligible sources:
#   M0 minimal:
#      colour_break ~ rms_strict + FSRQ + logNcolour + pair_dt
#
#   M1 linear range:
#      M0 + r_mag_range
#
#   M2 nonlinear range:
#      M0 + cubic spline(r_mag_range, df=4)
#
#   M3 interaction:
#      M1 + rms_strict * standardized(r_mag_range)
#
# Also:
#   Cochran–Mantel–Haenszel pooled OR across
#   optical-class x r-range-quartile strata.
#
# Upstream frozen products are read-only.
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm

from patsy import dmatrix
from statsmodels.stats.contingency_tables import StratifiedTable

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

PRIMARY_FILE = TABLE_DIR / "stage03b_rmflux_master.csv"
SENS_FILE = TABLE_DIR / "stage06a_rmflux_sensitivity_source.csv"
POP_FILE = TABLE_DIR / "stage04_population_master.csv"

OUT_MODELS = TABLE_DIR / "stage06a3_dynamic_range_models.csv"
OUT_CMH = TABLE_DIR / "stage06a3_dynamic_range_cmh.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06a3_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def safe_log1p(s):
    x = numeric(s)
    out = pd.Series(np.nan, index=x.index, dtype=float)

    good = np.isfinite(x) & (x >= 0)

    out.loc[good] = np.log1p(
        x.loc[good]
    )

    return out


def zscore(s):
    x = numeric(s)
    mu = x.mean()
    sd = x.std(ddof=1)

    if not np.isfinite(sd) or sd <= 0:
        return pd.Series(np.nan, index=x.index)

    return (x - mu) / sd


def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(pv)
    ranked = pv[order]

    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[valid] = qv

    return q


def fit_glm_matrix(
    y,
    X,
    key_name,
    model_name,
    scheme,
):
    data = pd.concat(
        [
            pd.Series(y, name="__y__"),
            X,
        ],
        axis=1
    ).replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    y2 = data.pop("__y__").astype(float)
    X2 = data.astype(float)

    X2 = sm.add_constant(
        X2,
        has_constant="add"
    )

    fit = sm.GLM(
        y2,
        X2,
        family=sm.families.Binomial(),
    ).fit(
        cov_type="HC3",
        maxiter=300,
    )

    ci = fit.conf_int()

    beta = float(fit.params[key_name])
    lo = float(ci.loc[key_name, 0])
    hi = float(ci.loc[key_name, 1])

    return {
        "scheme": scheme,
        "model_name": model_name,
        "key_predictor": key_name,
        "N": int(len(y2)),
        "N_event": int(y2.sum()),
        "odds_ratio": math.exp(beta),
        "or_ci95_low": math.exp(lo),
        "or_ci95_high": math.exp(hi),
        "p_value": float(fit.pvalues[key_name]),
        "aic": float(fit.aic),
    }


def build_scheme_table():
    primary = pd.read_csv(PRIMARY_FILE)
    sens = pd.read_csv(SENS_FILE)
    pop = pd.read_csv(POP_FILE)

    for df in [primary, sens, pop]:
        df["blazar_id"] = df["blazar_id"].astype(str)

    # ----------------------------
    # PRIMARY20 source flags
    # ----------------------------
    primary["eligible"] = (
        primary["fit_status"]
        .astype(str)
        .eq("OK")
    )

    primary["strict"] = as_bool(
        primary["strict_positive_rmflux"]
    )

    pe = primary.pivot(
        index="blazar_id",
        columns="filter_name",
        values="eligible"
    )

    ps = primary.pivot(
        index="blazar_id",
        columns="filter_name",
        values="strict"
    )

    primary_src = pd.DataFrame({
        "blazar_id": pe.index,
        "scheme": "PRIMARY20",
        "eligible_both": (
            pe["g"].fillna(False).astype(bool)
            &
            pe["r"].fillna(False).astype(bool)
        ).values,
        "strict_both": (
            ps["g"].fillna(False).astype(bool)
            &
            ps["r"].fillna(False).astype(bool)
        ).values,
    })

    # ----------------------------
    # Sensitivity flags
    # ----------------------------
    sens2 = sens[
        [
            "blazar_id",
            "scheme",
            "eligible_both",
            "strict_both",
        ]
    ].copy()

    sens2["eligible_both"] = as_bool(
        sens2["eligible_both"]
    )

    sens2["strict_both"] = as_bool(
        sens2["strict_both"]
    )

    all_src = pd.concat(
        [
            primary_src,
            sens2,
        ],
        ignore_index=True
    )

    # ----------------------------
    # Merge population covariates
    # ----------------------------
    keep = [
        "blazar_id",
        "blazar_class",
        "colour_robust_central_break",
        "col_N_colour_pairs",
        "col_pair_dt_hours_median",
        "col_r_mag_range",
    ]

    pop2 = pop[keep].copy()

    pop2["colour_robust_central_break"] = as_bool(
        pop2["colour_robust_central_break"]
    )

    out = all_src.merge(
        pop2,
        on="blazar_id",
        how="left",
        validate="many_to_one"
    )

    out["FSRQ"] = (
        out["blazar_class"]
        .astype(str)
        .eq("FSRQ")
        .astype(int)
    )

    out["colour_logN"] = safe_log1p(
        out["col_N_colour_pairs"]
    )

    return out


# ============================================================
# LOAD
# ============================================================

for path in [
    PRIMARY_FILE,
    SENS_FILE,
    POP_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(path)

d = build_scheme_table()

schemes = [
    "PRIMARY20",
    "S10_OCCUPANCY",
    "S20_SPAN120",
    "S30_OCCUPANCY",
    "S90D_FIXED",
]


# ============================================================
# GLM MODELS
# ============================================================

model_rows = []

for scheme in schemes:

    x = d.loc[
        d["scheme"].eq(scheme)
        &
        d["eligible_both"]
    ].copy()

    x["strict_both"] = as_bool(
        x["strict_both"]
    ).astype(int)

    x["colour_break"] = as_bool(
        x["colour_robust_central_break"]
    ).astype(int)

    x["FSRQ"] = numeric(x["FSRQ"])
    x["colour_logN_z"] = zscore(
        x["colour_logN"]
    )
    x["pair_dt_z"] = zscore(
        x["col_pair_dt_hours_median"]
    )
    x["range_z"] = zscore(
        x["col_r_mag_range"]
    )

    # Common finite base.
    base_cols = [
        "colour_break",
        "strict_both",
        "FSRQ",
        "colour_logN_z",
        "pair_dt_z",
        "range_z",
        "col_r_mag_range",
    ]

    x = x[
        base_cols
    ].replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    y = x["colour_break"]

    # M0 minimal.
    X0 = x[
        [
            "strict_both",
            "FSRQ",
            "colour_logN_z",
            "pair_dt_z",
        ]
    ].copy()

    model_rows.append(
        fit_glm_matrix(
            y,
            X0,
            key_name="strict_both",
            model_name="M0_MINIMAL",
            scheme=scheme,
        )
    )

    # M1 linear dynamic range.
    X1 = x[
        [
            "strict_both",
            "FSRQ",
            "colour_logN_z",
            "pair_dt_z",
            "range_z",
        ]
    ].copy()

    model_rows.append(
        fit_glm_matrix(
            y,
            X1,
            key_name="strict_both",
            model_name="M1_LINEAR_RANGE",
            scheme=scheme,
        )
    )

    # M2 nonlinear range spline.
    spline = dmatrix(
        "bs(rng, df=4, degree=3, include_intercept=False)",
        {
            "rng": x["col_r_mag_range"].to_numpy(dtype=float)
        },
        return_type="dataframe",
    )

    spline = spline.reset_index(drop=True)

    X2 = x[
        [
            "strict_both",
            "FSRQ",
            "colour_logN_z",
            "pair_dt_z",
        ]
    ].reset_index(drop=True)

    spline_cols = []

    # Patsy may include an Intercept column depending on formula;
    # drop it because statsmodels adds a constant below.
    for j, c in enumerate(spline.columns):
        if str(c).lower() == "intercept":
            continue

        newc = f"range_spline_{j}"
        X2[newc] = spline[c].to_numpy(dtype=float)
        spline_cols.append(newc)

    y2 = y.reset_index(drop=True)

    model_rows.append(
        fit_glm_matrix(
            y2,
            X2,
            key_name="strict_both",
            model_name="M2_SPLINE_RANGE_DF4",
            scheme=scheme,
        )
    )

    # M3 interaction with linear standardized range.
    X3 = X1.copy()
    X3["strict_x_range"] = (
        X3["strict_both"]
        *
        X3["range_z"]
    )

    # Store strict-both main effect.
    row_main = fit_glm_matrix(
        y,
        X3,
        key_name="strict_both",
        model_name="M3_LINEAR_RANGE_INTERACTION_MAIN",
        scheme=scheme,
    )

    model_rows.append(
        row_main
    )

    # Store interaction term.
    row_int = fit_glm_matrix(
        y,
        X3,
        key_name="strict_x_range",
        model_name="M3_LINEAR_RANGE_INTERACTION_TERM",
        scheme=scheme,
    )

    model_rows.append(
        row_int
    )

models = pd.DataFrame(
    model_rows
)

mask_main = (
    models["key_predictor"]
    .eq("strict_both")
)

models.loc[
    mask_main,
    "q_BH_strict_effects"
] = bh_qvalues(
    models.loc[
        mask_main,
        "p_value"
    ].to_numpy(dtype=float)
)

mask_int = (
    models["key_predictor"]
    .eq("strict_x_range")
)

models.loc[
    mask_int,
    "q_BH_interactions"
] = bh_qvalues(
    models.loc[
        mask_int,
        "p_value"
    ].to_numpy(dtype=float)
)

models.to_csv(
    OUT_MODELS,
    index=False
)


# ============================================================
# CMH STRATIFICATION
# optical class x r-range quartile
# ============================================================

cmh_rows = []

for scheme in schemes:

    x = d.loc[
        d["scheme"].eq(scheme)
        &
        d["eligible_both"]
    ].copy()

    x["strict_both"] = as_bool(
        x["strict_both"]
    )

    x["colour_break"] = as_bool(
        x["colour_robust_central_break"]
    )

    x["r_range"] = numeric(
        x["col_r_mag_range"]
    )

    x = x.dropna(
        subset=[
            "r_range",
            "blazar_class",
        ]
    )

    # Global quartiles within each scheme's eligible sample.
    x["range_quartile"] = pd.qcut(
        x["r_range"],
        q=4,
        labels=False,
        duplicates="drop"
    )

    tables = []
    n_strata = 0

    for (cls, q), z in x.groupby(
        [
            "blazar_class",
            "range_quartile",
        ],
        dropna=True
    ):

        n11 = int(
            (
                z["strict_both"]
                &
                z["colour_break"]
            ).sum()
        )

        n10 = int(
            (
                z["strict_both"]
                &
                ~z["colour_break"]
            ).sum()
        )

        n01 = int(
            (
                ~z["strict_both"]
                &
                z["colour_break"]
            ).sum()
        )

        n00 = int(
            (
                ~z["strict_both"]
                &
                ~z["colour_break"]
            ).sum()
        )

        table = np.array(
            [
                [n11, n10],
                [n01, n00],
            ],
            dtype=float
        )

        # Need non-empty margins.
        if (
            table.sum() == 0
            or
            table[0].sum() == 0
            or
            table[1].sum() == 0
            or
            table[:, 0].sum() == 0
            or
            table[:, 1].sum() == 0
        ):
            continue

        tables.append(table)
        n_strata += 1

    if len(tables) >= 2:

        st = StratifiedTable(
            tables
        )

        ci_lo, ci_hi = (
            st.oddsratio_pooled_confint(
                alpha=0.05
            )
        )

        test = st.test_null_odds(
            correction=False
        )

        cmh_rows.append({
            "scheme": scheme,
            "N_eligible_both": int(len(x)),
            "N_strata_used": int(n_strata),
            "cmh_pooled_or": float(
                st.oddsratio_pooled
            ),
            "cmh_ci95_low": float(ci_lo),
            "cmh_ci95_high": float(ci_hi),
            "cmh_test_p": float(
                test.pvalue
            ),
        })

    else:

        cmh_rows.append({
            "scheme": scheme,
            "N_eligible_both": int(len(x)),
            "N_strata_used": int(n_strata),
            "cmh_pooled_or": np.nan,
            "cmh_ci95_low": np.nan,
            "cmh_ci95_high": np.nan,
            "cmh_test_p": np.nan,
        })

cmh = pd.DataFrame(
    cmh_rows
)

cmh["cmh_q_BH"] = bh_qvalues(
    cmh["cmh_test_p"]
    .to_numpy(dtype=float)
)

cmh.to_csv(
    OUT_CMH,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06A3 DYNAMIC-RANGE ROBUSTNESS SUMMARY",
    "=" * 72,
    "",
    "STRICT RMS-FLUX EFFECT ON ROBUST COLOUR BREAK:",
]

for scheme in schemes:

    lines.append(
        f"\n{scheme}:"
    )

    xx = models.loc[
        models["scheme"].eq(scheme)
    ]

    for model_name in [
        "M0_MINIMAL",
        "M1_LINEAR_RANGE",
        "M2_SPLINE_RANGE_DF4",
    ]:

        rr = xx.loc[
            xx["model_name"].eq(model_name)
            &
            xx["key_predictor"].eq("strict_both")
        ].iloc[0]

        lines.append(
            f"  {model_name}: "
            f"OR={rr['odds_ratio']:.3f}, "
            f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
            f"p={rr['p_value']:.3g}, "
            f"q={rr['q_BH_strict_effects']:.3g}"
        )

    ri = xx.loc[
        xx["model_name"].eq(
            "M3_LINEAR_RANGE_INTERACTION_TERM"
        )
    ].iloc[0]

    lines.append(
        "  interaction strict×range: "
        f"OR_per_SD={ri['odds_ratio']:.3f}, "
        f"p={ri['p_value']:.3g}, "
        f"q={ri['q_BH_interactions']:.3g}"
    )

    rc = cmh.loc[
        cmh["scheme"].eq(scheme)
    ].iloc[0]

    lines.append(
        "  CMH class×range-quartile pooled: "
        f"OR={rc['cmh_pooled_or']:.3f}, "
        f"95%CI={rc['cmh_ci95_low']:.3f}-{rc['cmh_ci95_high']:.3f}, "
        f"p={rc['cmh_test_p']:.3g}, "
        f"q={rc['cmh_q_BH']:.3g}"
    )

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 06A3")
print("DYNAMIC-RANGE ROBUSTNESS")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_MODELS)
print(OUT_CMH)
print(OUT_SUMMARY)
print()
print("STAGE 06A3 COMPLETE")
