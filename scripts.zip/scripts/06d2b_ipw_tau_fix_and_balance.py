# ============================================================
# BLAZAR_I — STAGE 06D2B
# DRW-TAU IPW SAMPLE FIX + SELECTION-BALANCE AUDIT
#
# Why this stage exists:
#   STAGE 06D2 correctly handled the selection weights and the
#   binary / Fvar endpoints, but its continuous DRW-tau models
#   used all redshift-known rows (N=808 per band).
#
#   The primary DRW continuous inference must instead be restricted
#   to the SAME filter-specific interpretable subsets used upstream:
#       g: drw_tau_interpretable_primary_g == True
#       r: drw_tau_interpretable_primary_r == True
#
#   Expected known-z interpretable sizes from frozen upstream work:
#       g ~ 633
#       r ~ 644
#
# This stage:
#   1) recomputes the IPW rest-frame tau class contrasts on the
#      correct filter-specific interpretable subsets;
#   2) summarizes covariate balance for UNWEIGHTED and each IPW
#      scheme using stage06d2_selection_balance.csv;
#   3) leaves every upstream product untouched.
#
# Weight schemes:
#   UNWEIGHTED
#   IPW_RAW
#   IPW_TRIM_1_99
#   IPW_TRIM_2P5_97P5
#
# Outcome:
#   log10(tau_rest_days)
#
# Predictor:
#   FSRQ (BLL reference)
#
# Effect factor:
#   10**beta_FSRQ
#   (<1 => shorter rest-frame tau in FSRQs)
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

POP_FILE = TABLE_DIR / "stage04_population_master.csv"
WEIGHT_FILE = TABLE_DIR / "stage06d2_selection_weights.csv"
BALANCE_FILE = TABLE_DIR / "stage06d2_selection_balance.csv"

OUT_TAU = TABLE_DIR / "stage06d2b_ipw_tau_interpretable_models.csv"
OUT_BALANCE = TABLE_DIR / "stage06d2b_selection_balance_summary.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06d2b_summary.txt"


def as_bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def kish_ess(w):
    w = np.asarray(
        w,
        dtype=float
    )

    w = w[
        np.isfinite(w)
        &
        (w > 0)
    ]

    if len(w) == 0:
        return np.nan

    return float(
        (w.sum() ** 2)
        /
        np.sum(w ** 2)
    )


def normalize_weights(w):
    w = np.asarray(
        w,
        dtype=float
    )

    m = np.mean(w)

    if not (
        np.isfinite(m)
        and
        m > 0
    ):
        raise RuntimeError(
            "Invalid mean analysis weight."
        )

    return w / m


def fit_tau(
    df,
    tau_col,
    weight_col,
    model_name,
    band,
):
    cols = [
        tau_col,
        "FSRQ",
    ]

    if weight_col is not None:
        cols.append(
            weight_col
        )

    x = df[
        cols
    ].copy()

    x[tau_col] = numeric(
        x[tau_col]
    )

    x["FSRQ"] = numeric(
        x["FSRQ"]
    )

    if weight_col is not None:
        x[weight_col] = numeric(
            x[weight_col]
        )

    x = x.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    x = x.loc[
        x[tau_col] > 0
    ].copy()

    if len(x) < 30:
        raise RuntimeError(
            f"{band} {model_name}: too few rows ({len(x)})"
        )

    y = np.log10(
        x[tau_col].astype(float)
    )

    X = sm.add_constant(
        x[
            ["FSRQ"]
        ].astype(float),
        has_constant="add"
    )

    if weight_col is None:
        fit = sm.OLS(
            y,
            X
        ).fit(
            cov_type="HC3"
        )

        w_used = np.ones(
            len(x),
            dtype=float
        )

    else:
        w_used = normalize_weights(
            x[
                weight_col
            ].to_numpy(
                dtype=float
            )
        )

        fit = sm.WLS(
            y,
            X,
            weights=w_used
        ).fit(
            cov_type="HC3"
        )

    ci = fit.conf_int()

    beta = float(
        fit.params["FSRQ"]
    )

    lo = float(
        ci.loc["FSRQ", 0]
    )

    hi = float(
        ci.loc["FSRQ", 1]
    )

    return {
        "band": band,
        "model": model_name,
        "N": int(len(x)),
        "N_FSRQ": int(
            x["FSRQ"].sum()
        ),
        "N_BLL": int(
            len(x) - x["FSRQ"].sum()
        ),
        "beta_log10_tau_FSRQ": beta,
        "factor_FSRQ_vs_BLL": 10.0 ** beta,
        "factor_ci95_low": 10.0 ** lo,
        "factor_ci95_high": 10.0 ** hi,
        "p_value": float(
            fit.pvalues["FSRQ"]
        ),
        "weight_ESS": kish_ess(
            w_used
        ),
    }


for path in [
    POP_FILE,
    WEIGHT_FILE,
    BALANCE_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

pop = pd.read_csv(
    POP_FILE
)

weights = pd.read_csv(
    WEIGHT_FILE
)

balance = pd.read_csv(
    BALANCE_FILE
)

for df in [
    pop,
    weights,
]:
    df["blazar_id"] = (
        df["blazar_id"]
        .astype(str)
    )

if len(pop) != 1061:
    raise RuntimeError(
        f"Expected stage04 N=1061; got {len(pop)}"
    )

if len(weights) != 1061:
    raise RuntimeError(
        f"Expected weight N=1061; got {len(weights)}"
    )

d = pop.merge(
    weights,
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

if d[
    [
        "SW_RAW",
        "SW_TRIM_1_99",
        "SW_TRIM_2P5_97P5",
    ]
].isna().any().any():
    raise RuntimeError(
        "Weight merge produced missing values."
    )

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

for c in [
    "drw_tau_interpretable_primary_g",
    "drw_tau_interpretable_primary_r",
]:
    if c not in d.columns:
        raise RuntimeError(
            f"Missing expected stage04 column: {c}"
        )

    d[c] = as_bool_series(
        d[c]
    )

weight_schemes = [
    (
        "UNWEIGHTED",
        None
    ),
    (
        "IPW_RAW",
        "SW_RAW"
    ),
    (
        "IPW_TRIM_1_99",
        "SW_TRIM_1_99"
    ),
    (
        "IPW_TRIM_2P5_97P5",
        "SW_TRIM_2P5_97P5"
    ),
]

specs = [
    (
        "g",
        "drw_tau_rest_days_g",
        "drw_tau_interpretable_primary_g"
    ),
    (
        "r",
        "drw_tau_rest_days_r",
        "drw_tau_interpretable_primary_r"
    ),
]

tau_rows = []

for band, tau_col, gate_col in specs:
    x = d.loc[
        d[
            gate_col
        ]
    ].copy()

    for model_name, wcol in weight_schemes:
        tau_rows.append(
            fit_tau(
                df=x,
                tau_col=tau_col,
                weight_col=wcol,
                model_name=model_name,
                band=band,
            )
        )

tau_models = pd.DataFrame(
    tau_rows
)

tau_models.to_csv(
    OUT_TAU,
    index=False
)


# ============================================================
# BALANCE SUMMARY
# ============================================================

balance[
    "abs_standardized_difference"
] = np.abs(
    numeric(
        balance[
            "standardized_difference"
        ]
    )
)

balance_summary = (
    balance.groupby(
        "weight_scheme",
        as_index=False
    )
    .agg(
        max_abs_std_diff=(
            "abs_standardized_difference",
            "max"
        ),
        mean_abs_std_diff=(
            "abs_standardized_difference",
            "mean"
        ),
        median_abs_std_diff=(
            "abs_standardized_difference",
            "median"
        ),
    )
)

# Add the worst-balanced variable under each scheme.
worst_rows = []

for scheme, x in balance.groupby(
    "weight_scheme"
):
    z = x.sort_values(
        "abs_standardized_difference",
        ascending=False
    ).iloc[0]

    worst_rows.append({
        "weight_scheme": scheme,
        "worst_variable": z["variable"],
        "worst_abs_std_diff": float(
            z[
                "abs_standardized_difference"
            ]
        ),
    })

worst = pd.DataFrame(
    worst_rows
)

balance_summary = (
    balance_summary.merge(
        worst,
        on="weight_scheme",
        how="left",
        validate="one_to_one"
    )
)

balance_summary.to_csv(
    OUT_BALANCE,
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

lines = [
    "BLAZAR_I - STAGE 06D2B FINAL SUMMARY",
    "=" * 78,
    "",
    "CORRECTED REST-FRAME DRW TAU MODELS",
    "(filter-specific primary interpretable subsets only):",
]

for band in [
    "g",
    "r",
]:
    lines.append(
        f"  BAND {band}:"
    )

    x = tau_models.loc[
        tau_models[
            "band"
        ].eq(band)
    ]

    for _, rr in x.iterrows():
        lines.append(
            f"    {rr['model']}: "
            f"N={int(rr['N'])} "
            f"(FSRQ={int(rr['N_FSRQ'])}, BLL={int(rr['N_BLL'])}), "
            f"factor={rr['factor_FSRQ_vs_BLL']:.3f} "
            f"({rr['factor_ci95_low']:.3f}-{rr['factor_ci95_high']:.3f}), "
            f"p={rr['p_value']:.3g}, "
            f"ESS={rr['weight_ESS']:.1f}"
        )

lines += [
    "",
    "SELECTION-COVARIATE BALANCE:",
]

order = [
    "UNWEIGHTED",
    "IPW_RAW",
    "IPW_TRIM_1_99",
    "IPW_TRIM_2P5_97P5",
]

for scheme in order:
    x = balance_summary.loc[
        balance_summary[
            "weight_scheme"
        ].eq(scheme)
    ]

    if len(x) == 0:
        continue

    rr = x.iloc[0]

    lines.append(
        f"  {scheme}: "
        f"max|SMD|={rr['max_abs_std_diff']:.3f}, "
        f"mean|SMD|={rr['mean_abs_std_diff']:.3f}, "
        f"median|SMD|={rr['median_abs_std_diff']:.3f}, "
        f"worst={rr['worst_variable']} "
        f"({rr['worst_abs_std_diff']:.3f})"
    )

lines += [
    "",
    "NOTE:",
    (
        "  The STAGE 06D2 binary endpoints, rms->colour association, "
        "and Fvar models are unaffected by this correction."
    ),
    (
        "  Only the STAGE 06D2 continuous TAU_REST_G / TAU_REST_R "
        "rows should be superseded by these 06D2B tau results."
    ),
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 06D2B")
print("DRW-TAU IPW SAMPLE FIX + SELECTION-BALANCE AUDIT")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_TAU)
print(OUT_BALANCE)
print(OUT_SUMMARY)
print()
print("STAGE 06D2B COMPLETE")
