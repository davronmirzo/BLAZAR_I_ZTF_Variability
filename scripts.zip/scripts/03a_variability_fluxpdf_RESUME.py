# ============================================================
# BLAZAR_I — STAGE 03A
# BASIC VARIABILITY + FLUX-PDF MODEL COMPARISON
#
# Input:
#   outputs/tables/stage02b3_GOLD_PLUS_SILVER.csv
#   data/processed/stage02b3_sources/BZI_xxxxx_NIGHTLY.parquet
#
# Per source and per filter (g, r):
#   - basic cadence / baseline
#   - robust magnitude amplitude
#   - flux moments
#   - excess variance and Fvar
#   - Gaussian flux PDF
#   - Lognormal flux PDF
#   - Double-lognormal flux PDF (2-component mixture in ln F)
#   - AIC / BIC comparison
#
# IMPORTANT:
#   * Uses NIGHTLY data only.
#   * No sigma clipping is applied here; variability is the signal.
#   * Distribution fitting is empirical and does not deconvolve
#     heteroscedastic measurement errors.
#   * Double-lognormal fit is deterministic via fixed random_state.
#
# Checkpoint unit:
#   1 blazar -> one CSV + one .done
# ============================================================

from pathlib import Path
import argparse
import math
import sys
import time
import traceback

import numpy as np
import pandas as pd

from scipy.stats import skew, kurtosis
from sklearn.mixture import GaussianMixture


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()
parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="Process at most this many unfinished blazars."
)
args = parser.parse_args()


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

SAMPLE_FILE = (
    ROOT / "outputs" / "tables"
    / "stage02b3_GOLD_PLUS_SILVER.csv"
)

NIGHTLY_DIR = (
    ROOT / "data" / "processed"
    / "stage02b3_sources"
)

OUT_DIR = (
    ROOT / "outputs" / "models"
    / "stage03a_fluxpdf"
)

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

OUT_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# FROZEN CONFIG
# ============================================================

MIN_N_FIT = 50
DAYS_PER_YEAR = 365.25

GMM_N_INIT = 10
GMM_MAX_ITER = 500
GMM_REG_COVAR = 1.0e-4
GMM_RANDOM_STATE = 20260917


# ============================================================
# OUTPUT HELPERS
# ============================================================

def result_file(blazar_id):
    return OUT_DIR / f"{blazar_id}_03A.csv"

def done_file(blazar_id):
    return OUT_DIR / f"{blazar_id}.done"

def temp_path(path):
    return path.with_name(path.name + ".tmp")

def remove_if_exists(path):
    if path.exists():
        path.unlink()

def atomic_csv(df, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    df.to_csv(tmp, index=False)
    remove_if_exists(path)
    tmp.replace(path)

def atomic_text(text, path):
    tmp = temp_path(path)
    remove_if_exists(tmp)
    tmp.write_text(text, encoding="utf-8")
    remove_if_exists(path)
    tmp.replace(path)


# ============================================================
# BASIC STATISTICS
# ============================================================

def safe_percentile(x, q):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return np.nan
    return float(np.percentile(x, q))

def sample_baseline_days(t):
    t = np.asarray(t, dtype=float)
    t = t[np.isfinite(t)]
    if len(t) < 2:
        return 0.0
    return float(np.max(t) - np.min(t))

def excess_variance_and_fvar(flux, fluxerr):
    f = np.asarray(flux, dtype=float)
    e = np.asarray(fluxerr, dtype=float)

    good = (
        np.isfinite(f)
        & np.isfinite(e)
        & (f > 0)
        & (e >= 0)
    )

    f = f[good]
    e = e[good]

    n = len(f)

    if n < 2:
        return np.nan, np.nan, np.nan, np.nan

    mean_f = float(np.mean(f))
    s2 = float(np.var(f, ddof=1))
    mean_err2 = float(np.mean(e ** 2))

    excess_var = s2 - mean_err2

    if not np.isfinite(mean_f) or mean_f <= 0:
        return excess_var, np.nan, np.nan, np.nan

    nxs = excess_var / (mean_f ** 2)

    if excess_var > 0:
        fvar = math.sqrt(excess_var) / mean_f
    else:
        fvar = 0.0

    # Vaughan et al.-style approximate uncertainty on normalized
    # excess variance, then propagated to Fvar.
    term1 = math.sqrt(2.0 / n) * mean_err2 / (mean_f ** 2)

    if fvar > 0:
        term2 = (
            math.sqrt(mean_err2 / n)
            * (2.0 * fvar / mean_f)
        )
    else:
        term2 = 0.0

    nxs_err = math.sqrt(term1 ** 2 + term2 ** 2)

    if fvar > 0 and nxs_err >= 0:
        fvar_err = nxs_err / (2.0 * fvar)
    else:
        fvar_err = np.nan

    return excess_var, nxs, fvar, fvar_err


# ============================================================
# PDF FITS
# ============================================================

def gaussian_flux_fit(f):
    f = np.asarray(f, dtype=float)
    f = f[np.isfinite(f) & (f > 0)]

    n = len(f)

    if n < 2:
        return None

    mu = float(np.mean(f))
    sigma = float(np.std(f, ddof=0))

    if not np.isfinite(sigma) or sigma <= 0:
        return None

    z = (f - mu) / sigma

    loglike = float(
        np.sum(
            -0.5 * z ** 2
            - math.log(sigma)
            - 0.5 * math.log(2.0 * math.pi)
        )
    )

    k = 2
    aic = 2 * k - 2 * loglike
    bic = k * math.log(n) - 2 * loglike

    return {
        "gauss_mu_flux": mu,
        "gauss_sigma_flux": sigma,
        "gauss_loglike": loglike,
        "gauss_aic": aic,
        "gauss_bic": bic,
    }

def lognormal_flux_fit(f):
    f = np.asarray(f, dtype=float)
    f = f[np.isfinite(f) & (f > 0)]

    n = len(f)

    if n < 2:
        return None

    y = np.log(f)

    mu = float(np.mean(y))
    sigma = float(np.std(y, ddof=0))

    if not np.isfinite(sigma) or sigma <= 0:
        return None

    z = (y - mu) / sigma

    # Density in flux space:
    # log p(F) = log Normal(log F | mu,sigma) - log F
    loglike = float(
        np.sum(
            -0.5 * z ** 2
            - math.log(sigma)
            - 0.5 * math.log(2.0 * math.pi)
            - y
        )
    )

    k = 2
    aic = 2 * k - 2 * loglike
    bic = k * math.log(n) - 2 * loglike

    return {
        "lnorm_mu_lnflux": mu,
        "lnorm_sigma_lnflux": sigma,
        "lnorm_loglike": loglike,
        "lnorm_aic": aic,
        "lnorm_bic": bic,
    }

def double_lognormal_flux_fit(f):
    f = np.asarray(f, dtype=float)
    f = f[np.isfinite(f) & (f > 0)]

    n = len(f)

    if n < MIN_N_FIT:
        return None

    y = np.log(f).reshape(-1, 1)

    model = GaussianMixture(
        n_components=2,
        covariance_type="full",
        reg_covar=GMM_REG_COVAR,
        n_init=GMM_N_INIT,
        max_iter=GMM_MAX_ITER,
        random_state=GMM_RANDOM_STATE,
    )

    model.fit(y)

    logpdf_y = model.score_samples(y)

    # Convert density in ln F to density in F.
    loglike = float(
        np.sum(
            logpdf_y - y[:, 0]
        )
    )

    weights = model.weights_.astype(float)
    means = model.means_[:, 0].astype(float)
    sigmas = np.sqrt(
        model.covariances_[:, 0, 0]
    ).astype(float)

    # Sort components by mean ln flux.
    order = np.argsort(means)

    weights = weights[order]
    means = means[order]
    sigmas = sigmas[order]

    # Free parameters:
    # 2 means + 2 sigmas + 1 independent weight = 5
    k = 5

    aic = 2 * k - 2 * loglike
    bic = k * math.log(n) - 2 * loglike

    pooled = math.sqrt(
        0.5 * (
            sigmas[0] ** 2
            + sigmas[1] ** 2
        )
    )

    if pooled > 0:
        separation = (
            means[1] - means[0]
        ) / pooled
    else:
        separation = np.nan

    return {
        "dlnorm_weight_low": float(weights[0]),
        "dlnorm_weight_high": float(weights[1]),
        "dlnorm_mu_low_lnflux": float(means[0]),
        "dlnorm_mu_high_lnflux": float(means[1]),
        "dlnorm_sigma_low_lnflux": float(sigmas[0]),
        "dlnorm_sigma_high_lnflux": float(sigmas[1]),
        "dlnorm_component_separation": float(separation),
        "dlnorm_loglike": loglike,
        "dlnorm_aic": aic,
        "dlnorm_bic": bic,
        "dlnorm_converged": bool(model.converged_),
        "dlnorm_n_iter": int(model.n_iter_),
    }


# ============================================================
# ONE FILTER
# ============================================================

def analyze_filter(blazar_id, filt, df, meta):
    x = df.loc[
        df["filter_name"].eq(filt)
    ].copy()

    x = x.loc[
        np.isfinite(x["hmjd"])
        & np.isfinite(x["mag"])
        & np.isfinite(x["magerr"])
        & np.isfinite(x["flux_jy"])
        & np.isfinite(x["fluxerr_jy"])
        & (x["flux_jy"] > 0)
        & (x["fluxerr_jy"] >= 0)
    ].copy()

    n = len(x)

    row = {
        "blazar_id": blazar_id,
        "Source_Name": meta.get("Source_Name", np.nan),
        "ASSOC1": meta.get("ASSOC1", np.nan),
        "blazar_class": meta.get("blazar_class", np.nan),
        "sample_tier": meta.get("sample_tier", np.nan),
        "redshift_clean": meta.get("redshift_clean", np.nan),
        "SED_class_clean": meta.get("SED_class_clean", np.nan),
        "filter_name": filt,
        "N_nightly": int(n),
        "fit_status": "NOT_RUN",
    }

    if n == 0:
        row["fit_status"] = "NO_DATA"
        return row

    t = x["hmjd"].to_numpy(dtype=float)
    m = x["mag"].to_numpy(dtype=float)
    me = x["magerr"].to_numpy(dtype=float)
    f = x["flux_jy"].to_numpy(dtype=float)
    fe = x["fluxerr_jy"].to_numpy(dtype=float)

    baseline_days = sample_baseline_days(t)

    row.update({
        "baseline_days": baseline_days,
        "baseline_yr": baseline_days / DAYS_PER_YEAR,
        "median_mag": float(np.median(m)),
        "mean_mag": float(np.mean(m)),
        "std_mag": float(np.std(m, ddof=1)) if n >= 2 else np.nan,
        "median_magerr": float(np.median(me)),
        "p05_mag": safe_percentile(m, 5),
        "p95_mag": safe_percentile(m, 95),
        "robust_amp_mag_p95_p05": (
            safe_percentile(m, 95)
            - safe_percentile(m, 5)
        ),
        "full_amp_mag_max_min": (
            float(np.max(m) - np.min(m))
            if n >= 1 else np.nan
        ),
        "mean_flux_jy": float(np.mean(f)),
        "median_flux_jy": float(np.median(f)),
        "std_flux_jy": float(np.std(f, ddof=1)) if n >= 2 else np.nan,
        "median_fluxerr_jy": float(np.median(fe)),
        "flux_skewness": float(skew(f, bias=False)) if n >= 3 else np.nan,
        "flux_excess_kurtosis": float(kurtosis(f, fisher=True, bias=False)) if n >= 4 else np.nan,
        "lnflux_skewness": float(skew(np.log(f), bias=False)) if n >= 3 else np.nan,
        "lnflux_excess_kurtosis": float(kurtosis(np.log(f), fisher=True, bias=False)) if n >= 4 else np.nan,
    })

    excess_var, nxs, fvar, fvar_err = excess_variance_and_fvar(f, fe)

    row.update({
        "excess_variance_flux": excess_var,
        "normalized_excess_variance": nxs,
        "Fvar": fvar,
        "Fvar_err_approx": fvar_err,
    })

    if n < MIN_N_FIT:
        row["fit_status"] = f"TOO_FEW_POINTS_LT_{MIN_N_FIT}"
        return row

    try:
        gfit = gaussian_flux_fit(f)
        lfit = lognormal_flux_fit(f)
        dfit = double_lognormal_flux_fit(f)

        if gfit is None or lfit is None or dfit is None:
            row["fit_status"] = "FIT_INVALID"
            return row

        row.update(gfit)
        row.update(lfit)
        row.update(dfit)

        bic_values = {
            "GAUSSIAN": row["gauss_bic"],
            "LOGNORMAL": row["lnorm_bic"],
            "DOUBLE_LOGNORMAL": row["dlnorm_bic"],
        }

        aic_values = {
            "GAUSSIAN": row["gauss_aic"],
            "LOGNORMAL": row["lnorm_aic"],
            "DOUBLE_LOGNORMAL": row["dlnorm_aic"],
        }

        bic_sorted = sorted(
            bic_values.items(),
            key=lambda kv: kv[1]
        )

        aic_sorted = sorted(
            aic_values.items(),
            key=lambda kv: kv[1]
        )

        row["preferred_bic_model"] = bic_sorted[0][0]
        row["delta_bic_second_minus_best"] = float(
            bic_sorted[1][1] - bic_sorted[0][1]
        )
        row["preferred_aic_model"] = aic_sorted[0][0]
        row["delta_aic_second_minus_best"] = float(
            aic_sorted[1][1] - aic_sorted[0][1]
        )

        row["delta_bic_gauss_minus_lognorm"] = float(
            row["gauss_bic"] - row["lnorm_bic"]
        )

        row["delta_bic_lognorm_minus_double"] = float(
            row["lnorm_bic"] - row["dlnorm_bic"]
        )

        row["fit_status"] = "OK"

    except Exception as exc:
        row["fit_status"] = f"FIT_FAILED:{type(exc).__name__}"

    return row


# ============================================================
# LOAD SAMPLE
# ============================================================

sample = pd.read_csv(SAMPLE_FILE)

required_sample_cols = [
    "blazar_id",
    "sample_tier",
    "blazar_class",
]

missing_cols = [
    c for c in required_sample_cols
    if c not in sample.columns
]

if missing_cols:
    raise RuntimeError(
        "Missing sample columns: "
        + ", ".join(missing_cols)
    )

sample["blazar_id"] = sample["blazar_id"].astype(str)

source_ids = sample["blazar_id"].drop_duplicates().tolist()

sample_lookup = (
    sample
    .drop_duplicates("blazar_id")
    .set_index("blazar_id")
)

N_SOURCE = len(source_ids)


# ============================================================
# HEADER
# ============================================================

print("=" * 78)
print("BLAZAR_I — STAGE 03A")
print("BASIC VARIABILITY + FLUX-PDF MODEL COMPARISON")
print("=" * 78)
print("Analysis sample =", N_SOURCE)
print("Minimum N/filter for PDF fits =", MIN_N_FIT)
print("GMM random_state =", GMM_RANDOM_STATE)


# ============================================================
# CHECKPOINT STATUS
# ============================================================

def source_complete(blazar_id):
    return (
        result_file(blazar_id).exists()
        and done_file(blazar_id).exists()
    )

complete_before = [
    bid for bid in source_ids
    if source_complete(bid)
]

print()
print(
    "Completed 03A sources on disk =",
    len(complete_before),
    "/",
    N_SOURCE
)
print(
    "Remaining 03A sources         =",
    N_SOURCE - len(complete_before)
)


# ============================================================
# PER-SOURCE LOOP
# ============================================================

processed_this_run = 0
session_start = time.time()

for source_number, blazar_id in enumerate(source_ids, start=1):

    if source_complete(blazar_id):
        continue

    if (
        args.limit is not None
        and processed_this_run >= args.limit
    ):
        print()
        print("Pilot limit reached:", args.limit)
        break

    nightly_path = NIGHTLY_DIR / f"{blazar_id}_NIGHTLY.parquet"

    if not nightly_path.exists():
        raise FileNotFoundError(nightly_path)

    # Clean incomplete outputs from a prior interruption.
    if not done_file(blazar_id).exists():
        remove_if_exists(result_file(blazar_id))
        remove_if_exists(temp_path(result_file(blazar_id)))
        remove_if_exists(temp_path(done_file(blazar_id)))

    print()
    print("=" * 78)
    print(f"SOURCE {source_number}/{N_SOURCE}")
    print("blazar_id =", blazar_id)

    t0 = time.time()

    try:
        nightly = pd.read_parquet(nightly_path)

        meta = sample_lookup.loc[blazar_id].to_dict()

        rows = []

        for filt in ["g", "r"]:
            rows.append(
                analyze_filter(
                    blazar_id=blazar_id,
                    filt=filt,
                    df=nightly,
                    meta=meta,
                )
            )

        result = pd.DataFrame(rows)

        atomic_csv(
            result,
            result_file(blazar_id)
        )

        elapsed = time.time() - t0

        atomic_text(
            (
                "COMPLETE\n"
                f"blazar_id={blazar_id}\n"
                f"elapsed_seconds={elapsed:.6f}\n"
            ),
            done_file(blazar_id)
        )

        ok_rows = int(
            result["fit_status"].eq("OK").sum()
        )

        print(
            "Nightly g/r =",
            int(
                result.loc[
                    result["filter_name"].eq("g"),
                    "N_nightly"
                ].iloc[0]
            ),
            "/",
            int(
                result.loc[
                    result["filter_name"].eq("r"),
                    "N_nightly"
                ].iloc[0]
            )
        )

        print("PDF fits OK =", ok_rows, "/ 2")

        for _, rr in result.iterrows():
            print(
                f"{rr['filter_name']}: "
                f"N={int(rr['N_nightly'])}, "
                f"Fvar={rr.get('Fvar', np.nan):.4f}, "
                f"BIC={rr.get('preferred_bic_model', 'NA')}, "
                f"status={rr['fit_status']}"
            )

        print(
            "CHECKPOINT =",
            done_file(blazar_id).name
        )

        processed_this_run += 1

    except Exception:
        print()
        print("FAILED SOURCE:", blazar_id)
        traceback.print_exc()

        fail_path = AUDIT_DIR / "stage03a_last_failure.txt"

        fail_path.write_text(
            (
                "BLAZAR_I STAGE 03A FAILURE\n"
                f"blazar_id={blazar_id}\n"
                f"source_number={source_number}/{N_SOURCE}\n"
            ),
            encoding="utf-8"
        )

        sys.exit(30)


# ============================================================
# CURRENT STATUS
# ============================================================

complete_now = [
    bid for bid in source_ids
    if source_complete(bid)
]

session_elapsed = time.time() - session_start

print()
print("=" * 78)
print("STAGE 03A CURRENT STATUS")
print("=" * 78)
print("Completed sources =", len(complete_now), "/", N_SOURCE)
print("Remaining         =", N_SOURCE - len(complete_now))
print(f"Session elapsed   = {session_elapsed/60:.2f} min")


# ============================================================
# GLOBAL PRODUCTS
# ============================================================

if len(complete_now) == N_SOURCE:

    print()
    print("All STAGE 03A sources complete.")

    frames = []

    for bid in source_ids:
        frames.append(
            pd.read_csv(
                result_file(bid)
            )
        )

    master = pd.concat(
        frames,
        ignore_index=True
    )

    MASTER_OUT = (
        TABLE_DIR
        / "stage03a_fluxpdf_master.csv"
    )

    master.to_csv(
        MASTER_OUT,
        index=False
    )

    ok = master.loc[
        master["fit_status"].eq("OK")
    ].copy()

    MODEL_COUNTS_OUT = (
        TABLE_DIR
        / "stage03a_bic_model_counts.csv"
    )

    model_counts = (
        ok.groupby(
            [
                "filter_name",
                "blazar_class",
                "sample_tier",
                "preferred_bic_model",
            ],
            dropna=False
        )
        .size()
        .rename("N")
        .reset_index()
    )

    model_counts.to_csv(
        MODEL_COUNTS_OUT,
        index=False
    )

    # Compact source-level wide table for later joins.
    keep = [
        "blazar_id",
        "filter_name",
        "N_nightly",
        "baseline_yr",
        "robust_amp_mag_p95_p05",
        "full_amp_mag_max_min",
        "Fvar",
        "Fvar_err_approx",
        "flux_skewness",
        "lnflux_skewness",
        "preferred_bic_model",
        "delta_bic_second_minus_best",
        "delta_bic_gauss_minus_lognorm",
        "delta_bic_lognorm_minus_double",
        "dlnorm_component_separation",
        "fit_status",
    ]

    wide = master[
        [c for c in keep if c in master.columns]
    ].pivot(
        index="blazar_id",
        columns="filter_name"
    )

    wide.columns = [
        f"{metric}_{filt}"
        for metric, filt in wide.columns
    ]

    wide = (
        wide
        .reset_index()
    )

    meta_cols = [
        "blazar_id",
        "Source_Name",
        "ASSOC1",
        "blazar_class",
        "sample_tier",
        "redshift_clean",
        "SED_class_clean",
    ]

    meta = (
        master[
            [c for c in meta_cols if c in master.columns]
        ]
        .drop_duplicates("blazar_id")
    )

    source_master = meta.merge(
        wide,
        on="blazar_id",
        how="left",
        validate="one_to_one"
    )

    SOURCE_OUT = (
        TABLE_DIR
        / "stage03a_source_master.csv"
    )

    source_master.to_csv(
        SOURCE_OUT,
        index=False
    )

    # Final summary.
    summary_lines = [
        "BLAZAR_I - STAGE 03A FINAL SUMMARY",
        "=" * 72,
        "",
        f"Analysis blazars             : {N_SOURCE}",
        f"Source-filter rows           : {len(master)}",
        f"Successful PDF fits          : {len(ok)}",
        f"Failed/non-fit rows          : {len(master)-len(ok)}",
        "",
        "BIC preferred models:",
    ]

    counts = (
        ok["preferred_bic_model"]
        .value_counts()
    )

    for model, n in counts.items():
        pct = 100.0 * n / len(ok) if len(ok) else np.nan
        summary_lines.append(
            f"  {model:<20s}: {n:5d} ({pct:6.2f}%)"
        )

    summary_lines += [
        "",
        "Per filter:",
    ]

    for filt in ["g", "r"]:
        xx = ok.loc[
            ok["filter_name"].eq(filt)
        ]

        summary_lines.append(
            f"  {filt}: N={len(xx)}"
        )

        cc = (
            xx["preferred_bic_model"]
            .value_counts()
        )

        for model, n in cc.items():
            pct = 100.0 * n / len(xx) if len(xx) else np.nan
            summary_lines.append(
                f"      {model:<20s}: {n:5d} ({pct:6.2f}%)"
            )

    SUMMARY_OUT = (
        AUDIT_DIR
        / "stage03a_summary.txt"
    )

    final_summary = "\n".join(summary_lines)

    SUMMARY_OUT.write_text(
        final_summary,
        encoding="utf-8"
    )

    print()
    print(final_summary)

    print()
    print("=" * 78)
    print("GLOBAL FILES SAVED")
    print("=" * 78)
    print(MASTER_OUT)
    print(SOURCE_OUT)
    print(MODEL_COUNTS_OUT)
    print(SUMMARY_OUT)

    print()
    print("STAGE 03A COMPLETE")
