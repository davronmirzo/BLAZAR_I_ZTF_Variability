# ============================================================
# BLAZAR_I — STAGE 09A1
# Q1 CONFOUNDER MASTER + HOST-AUGMENTATION DECISION
#
# Purpose:
#   Build one exact 1061-row source-level master for the Q1-reviewer
#   confounder rebuild, using only frozen upstream products.
#
# Adds / harmonizes:
#   - primary diagnostic endpoints
#   - redshift + known-z
#   - SED class
#   - DR4 gamma-ray energy flux + variability index
#   - optical counterpart sky coordinates
#   - nightly g/r coverage, cadence, median error, median magnitude
#   - optical dynamic-range diagnostics already frozen upstream
#
# Important:
#   "col_colour_break_morphology" is a COLOUR-TRACK morphology label,
#   not a host-galaxy morphology measurement. It is explicitly rejected
#   as a host proxy.
#
# No endpoint model is fit here.
# No external catalogue is queried here.
#
# Outputs:
#   outputs/tables/stage09a1_q1_confounder_master.csv
#   outputs/audit/stage09a1_covariate_coverage.csv
#   outputs/audit/stage09a1_model_eligibility.csv
#   outputs/audit/stage09a1_host_proxy_decision.txt
#   outputs/audit/stage09a1_summary.txt
# ============================================================

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
INTERIM_DIR = ROOT / "data" / "interim"
PROCESSED_DIR = ROOT / "data" / "processed"

MASTER04 = TABLE_DIR / "stage04_population_master.csv"
PARENT01 = INTERIM_DIR / "stage01_parent_clean_fsrq_bll.csv"
NIGHTLY_DIR = PROCESSED_DIR / "stage02b3_sources"

OUT_MASTER = TABLE_DIR / "stage09a1_q1_confounder_master.csv"
OUT_COVER = AUDIT_DIR / "stage09a1_covariate_coverage.csv"
OUT_ELIG = AUDIT_DIR / "stage09a1_model_eligibility.csv"
OUT_HOST = AUDIT_DIR / "stage09a1_host_proxy_decision.txt"
OUT_SUMMARY = AUDIT_DIR / "stage09a1_summary.txt"

AUDIT_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)


def require(path):
    if not path.exists():
        raise FileNotFoundError(path)


def first_existing(df, candidates, required=False):
    for c in candidates:
        if c in df.columns:
            return c

    if required:
        raise RuntimeError(
            "None of the required candidate columns exist:\n  "
            + "\n  ".join(candidates)
        )

    return None


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce",
    )


def boolish(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def clean_sed(s):
    x = (
        s.astype(str)
        .str.strip()
        .str.upper()
        .replace(
            {
                "NAN": "UNKNOWN",
                "NONE": "UNKNOWN",
                "": "UNKNOWN",
            }
        )
    )

    # Standardize common variants.
    out = np.select(
        [
            x.str.contains("LSP", regex=False),
            x.str.contains("ISP", regex=False),
            x.str.contains("HSP", regex=False),
        ],
        [
            "LSP",
            "ISP",
            "HSP",
        ],
        default="UNKNOWN",
    )

    return pd.Series(
        out,
        index=s.index,
        dtype="object",
    )


for path in [MASTER04, PARENT01]:
    require(path)

if not NIGHTLY_DIR.exists():
    raise FileNotFoundError(NIGHTLY_DIR)

m = pd.read_csv(
    MASTER04,
    low_memory=False,
)

p = pd.read_csv(
    PARENT01,
    low_memory=False,
)

for df in [m, p]:
    if "blazar_id" not in df.columns:
        raise RuntimeError(
            "Required key blazar_id not found."
        )

    df["blazar_id"] = (
        df["blazar_id"]
        .astype(str)
    )

if len(m) != 1061:
    raise RuntimeError(
        f"Expected stage04 population master N=1061, got {len(m)}"
    )

if m["blazar_id"].duplicated().any():
    raise RuntimeError(
        "stage04_population_master has duplicate blazar_id rows."
    )

p = (
    p.drop_duplicates(
        "blazar_id"
    )
    .copy()
)

# ============================================================
# BASE SCIENCE MASTER
# ============================================================

out = pd.DataFrame({
    "blazar_id": m["blazar_id"].astype(str),
})

class_col = first_existing(
    m,
    [
        "blazar_class",
        "fermi_blazar_class",
        "CLASS1",
        "fermi_CLASS1",
    ],
    required=True,
)

out["blazar_class"] = (
    m[class_col]
    .astype(str)
    .str.strip()
    .str.upper()
)

if not set(
    out["blazar_class"].dropna().unique()
).issubset({"BLL", "FSRQ"}):
    raise RuntimeError(
        "Unexpected optical classes in stage04 master: "
        + repr(
            sorted(
                out["blazar_class"]
                .dropna()
                .unique()
                .tolist()
            )
        )
    )

out["FSRQ"] = (
    out["blazar_class"]
    .eq("FSRQ")
    .astype(int)
)

# ============================================================
# ENDPOINTS — EXACT FROZEN SOURCE-LEVEL FLAGS
# ============================================================

endpoint_candidates = {
    "endpoint_pdf_robust_double_both": [
        "pdf_robust_double_both",
    ],
    "endpoint_rmflux_strict_both": [
        "rmflux_strict_both",
    ],
    "endpoint_colour_robust_central": [
        "colour_robust_central_break",
        "col_colour_robust_central_break",
    ],
    "endpoint_drw_interpretable_both": [
        "drw_interpretable_both",
    ],
}

for out_col, candidates in endpoint_candidates.items():
    c = first_existing(
        m,
        candidates,
        required=True,
    )

    out[out_col] = boolish(
        m[c]
    )

# Stage 04 does not create a combined rmflux_eligible_both column.
# Reconstruct it exactly from the two frozen source/filter eligibility flags
# generated by the Stage 03B pivot:
#   rmf_rmflux_eligible_g
#   rmf_rmflux_eligible_r
elig_g = first_existing(
    m,
    [
        "rmf_rmflux_eligible_g",
        "rmflux_eligible_g",
    ],
    required=True,
)

elig_r = first_existing(
    m,
    [
        "rmf_rmflux_eligible_r",
        "rmflux_eligible_r",
    ],
    required=True,
)

out["endpoint_rmflux_eligible_both"] = (
    boolish(m[elig_g])
    &
    boolish(m[elig_r])
)

# Continuous endpoints / sensitivity quantities.
numeric_fields = {
    "fvar_g": [
        "pdf_Fvar_g",
        "Fvar_g",
    ],
    "fvar_r": [
        "pdf_Fvar_r",
        "Fvar_r",
    ],
    "tau_rest_g": [
        "drw_tau_rest_days_g",
        "tau_rest_days_g",
    ],
    "tau_rest_r": [
        "drw_tau_rest_days_r",
        "tau_rest_days_r",
    ],
    "colour_r_mag_range": [
        "col_r_mag_range",
        "r_mag_range",
    ],
    "colour_pair_dt_hours_median": [
        "col_pair_dt_hours_median",
        "pair_dt_hours_median",
    ],
    "pdf_amp_g": [
        "pdf_robust_amp_mag_p95_p05_g",
    ],
    "pdf_amp_r": [
        "pdf_robust_amp_mag_p95_p05_r",
    ],
}

for out_col, candidates in numeric_fields.items():
    c = first_existing(
        m,
        candidates,
        required=False,
    )

    out[out_col] = (
        numeric(m[c])
        if c is not None
        else np.nan
    )

# ============================================================
# PARENT COVARIATES
# ============================================================

# Prefer direct Stage01 parent columns; Stage04-prefixed copies are only
# a fallback. This keeps provenance clean.
red_col = first_existing(
    p,
    [
        "redshift_clean",
        "Redshift",
        "redshift",
    ],
    required=True,
)

sed_col = first_existing(
    p,
    [
        "SED_class_clean",
        "SED_class",
    ],
    required=True,
)

energy_col = first_existing(
    p,
    [
        "Energy_Flux100_DR4",
        "EnergyFlux_DR4",
        "Energy_Flux_DR4",
        "Energy_Flux100",
        "EnergyFlux",
    ],
    required=True,
)

var_col = first_existing(
    p,
    [
        "Variability_Index_DR4",
        "VariabilityIndex_DR4",
        "Variability_Index",
        "VariabilityIndex",
    ],
    required=True,
)

ra_col = first_existing(
    p,
    [
        "RA_Counterpart_DR4",
        "RA_Counterpart",
        "RA_COUNTERPART",
        "RA",
    ],
    required=True,
)

dec_col = first_existing(
    p,
    [
        "DEC_Counterpart_DR4",
        "DEC_Counterpart",
        "DEC_COUNTERPART",
        "DEC",
    ],
    required=True,
)

parent_keep = p[
    [
        "blazar_id",
        red_col,
        sed_col,
        energy_col,
        var_col,
        ra_col,
        dec_col,
    ]
].copy()

parent_keep = parent_keep.rename(
    columns={
        red_col: "redshift",
        sed_col: "sed_raw",
        energy_col: "gamma_energy_flux",
        var_col: "gamma_variability_index",
        ra_col: "ra_counterpart_deg",
        dec_col: "dec_counterpart_deg",
    }
)

for c in [
    "redshift",
    "gamma_energy_flux",
    "gamma_variability_index",
    "ra_counterpart_deg",
    "dec_counterpart_deg",
]:
    parent_keep[c] = numeric(
        parent_keep[c]
    )

parent_keep["sed_class"] = clean_sed(
    parent_keep["sed_raw"]
)

parent_keep["redshift_known"] = (
    parent_keep["redshift"]
    .notna()
    &
    (
        parent_keep["redshift"]
        >
        0
    )
)

out = out.merge(
    parent_keep[
        [
            "blazar_id",
            "redshift",
            "redshift_known",
            "sed_class",
            "gamma_energy_flux",
            "gamma_variability_index",
            "ra_counterpart_deg",
            "dec_counterpart_deg",
        ]
    ],
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

out["log10_gamma_energy_flux"] = np.where(
    out["gamma_energy_flux"] > 0,
    np.log10(
        out["gamma_energy_flux"]
    ),
    np.nan,
)

out["log1p_gamma_variability_index"] = np.where(
    out["gamma_variability_index"] >= 0,
    np.log1p(
        out["gamma_variability_index"]
    ),
    np.nan,
)

# SED indicators; LSP is the eventual reference category.
out["SED_ISP"] = (
    out["sed_class"]
    .eq("ISP")
    .astype(int)
)
out["SED_HSP"] = (
    out["sed_class"]
    .eq("HSP")
    .astype(int)
)
out["SED_UNKNOWN"] = (
    out["sed_class"]
    .eq("UNKNOWN")
    .astype(int)
)

# ============================================================
# NIGHTLY COVERAGE / BRIGHTNESS / ERROR MASTER
# ============================================================

nightly_rows = []

for i, bid in enumerate(
    out["blazar_id"].tolist(),
    start=1,
):
    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        nightly_rows.append({
            "blazar_id": bid,
            "nightly_file_status": "MISSING",
        })
        continue

    d = pd.read_parquet(
        path
    )

    row = {
        "blazar_id": bid,
        "nightly_file_status": "OK",
    }

    for filt in [
        "g",
        "r",
    ]:
        x = d.loc[
            d["filter_name"]
            .astype(str)
            .str.lower()
            .eq(filt)
        ].copy()

        row[
            f"N_nightly_{filt}"
        ] = len(x)

        if len(x) == 0:
            for name in [
                "baseline_days",
                "median_cadence_days",
                "median_mag",
                "median_magerr",
                "p05_mag",
                "p95_mag",
                "mag_range_p95_p05",
            ]:
                row[
                    f"{name}_{filt}"
                ] = np.nan

            continue

        t = np.sort(
            numeric(
                x["hmjd"]
            )
            .dropna()
            .to_numpy(
                dtype=float
            )
        )

        mag = numeric(
            x["mag"]
        )
        magerr = numeric(
            x["magerr"]
        )

        row[
            f"baseline_days_{filt}"
        ] = (
            float(
                np.nanmax(t)
                -
                np.nanmin(t)
            )
            if len(t) >= 2
            else np.nan
        )

        row[
            f"median_cadence_days_{filt}"
        ] = (
            float(
                np.nanmedian(
                    np.diff(t)
                )
            )
            if len(t) >= 2
            else np.nan
        )

        row[
            f"median_mag_{filt}"
        ] = float(
            np.nanmedian(
                mag
            )
        )

        row[
            f"median_magerr_{filt}"
        ] = float(
            np.nanmedian(
                magerr
            )
        )

        row[
            f"p05_mag_{filt}"
        ] = float(
            np.nanquantile(
                mag,
                0.05,
            )
        )

        row[
            f"p95_mag_{filt}"
        ] = float(
            np.nanquantile(
                mag,
                0.95,
            )
        )

        row[
            f"mag_range_p95_p05_{filt}"
        ] = (
            row[
                f"p95_mag_{filt}"
            ]
            -
            row[
                f"p05_mag_{filt}"
            ]
        )

    nightly_rows.append(
        row
    )

    if (
        i % 100 == 0
        or
        i == len(out)
    ):
        print(
            f"Nightly summaries: {i}/{len(out)}"
        )

nightly = pd.DataFrame(
    nightly_rows
)

out = out.merge(
    nightly,
    on="blazar_id",
    how="left",
    validate="one_to_one",
)

# Compact symmetric coverage controls.
for base in [
    "N_nightly",
    "baseline_days",
    "median_cadence_days",
    "median_magerr",
    "median_mag",
    "mag_range_p95_p05",
]:
    g = f"{base}_g"
    r = f"{base}_r"

    if (
        g in out.columns
        and
        r in out.columns
    ):
        out[
            f"{base}_mean_gr"
        ] = (
            numeric(out[g])
            +
            numeric(out[r])
        ) / 2.0

# Log transforms used in nested models.
out["log1p_N_nightly_mean_gr"] = np.log1p(
    out["N_nightly_mean_gr"]
)

out["log10_baseline_mean_gr"] = np.where(
    out["baseline_days_mean_gr"] > 0,
    np.log10(
        out["baseline_days_mean_gr"]
    ),
    np.nan,
)

out["log10_cadence_mean_gr"] = np.where(
    out["median_cadence_days_mean_gr"] > 0,
    np.log10(
        out["median_cadence_days_mean_gr"]
    ),
    np.nan,
)

# ============================================================
# HOST-PROXY DECISION
# ============================================================

# The only "morphology" hit in Stage 09A0 was colour-track morphology:
#   col_colour_break_morphology
# That encodes BWB/RWB slope configuration and must NOT be used as a
# galaxy morphology / host-contamination proxy.

valid_internal_host_proxy = False

out["host_proxy_internal_available"] = False
out["host_proxy_external_required"] = True

# ============================================================
# MODEL ELIGIBILITY — NO FITS YET
# ============================================================

coverage_cols = [
    "log1p_N_nightly_mean_gr",
    "log10_baseline_mean_gr",
    "log10_cadence_mean_gr",
    "median_magerr_mean_gr",
]

astro_cols = [
    "redshift",
    "SED_ISP",
    "SED_HSP",
    "log10_gamma_energy_flux",
    "log1p_gamma_variability_index",
]

brightness_cols = [
    "median_mag_g",
    "median_mag_r",
]

model_sets = {
    "M0_COVERAGE": (
        coverage_cols
    ),
    "M1_Z_SED_GAMMA": (
        coverage_cols
        +
        astro_cols
    ),
    "M2_PLUS_OPTICAL_BRIGHTNESS": (
        coverage_cols
        +
        astro_cols
        +
        brightness_cols
    ),
    "M3_PLUS_HOST_PROXY": (
        coverage_cols
        +
        astro_cols
        +
        brightness_cols
        +
        ["HOST_PROXY_EXTERNAL_PENDING"]
    ),
}

endpoint_cols = [
    "endpoint_pdf_robust_double_both",
    "endpoint_rmflux_strict_both",
    "endpoint_colour_robust_central",
    "endpoint_drw_interpretable_both",
]

elig_rows = []

for endpoint in endpoint_cols:
    for model_name, cols in model_sets.items():
        if "HOST_PROXY_EXTERNAL_PENDING" in cols:
            elig_rows.append({
                "endpoint": endpoint,
                "model": model_name,
                "N": np.nan,
                "N_BLL": np.nan,
                "N_FSRQ": np.nan,
                "status": "PENDING_EXTERNAL_HOST_PROXY",
            })
            continue

        required_cols = [
            endpoint,
            "blazar_class",
            *cols,
        ]

        w = out[
            required_cols
        ].copy()

        mask = w[endpoint].notna()

        for c in cols:
            mask &= w[c].notna()

        ww = w.loc[
            mask
        ]

        elig_rows.append({
            "endpoint": endpoint,
            "model": model_name,
            "N": len(ww),
            "N_BLL": int(
                ww["blazar_class"]
                .eq("BLL")
                .sum()
            ),
            "N_FSRQ": int(
                ww["blazar_class"]
                .eq("FSRQ")
                .sum()
            ),
            "status": "READY",
        })

elig = pd.DataFrame(
    elig_rows
)

elig.to_csv(
    OUT_ELIG,
    index=False,
)

# ============================================================
# COVARIATE COVERAGE
# ============================================================

covariates = [
    "redshift",
    "redshift_known",
    "sed_class",
    "gamma_energy_flux",
    "gamma_variability_index",
    "ra_counterpart_deg",
    "dec_counterpart_deg",
    "N_nightly_g",
    "N_nightly_r",
    "baseline_days_g",
    "baseline_days_r",
    "median_cadence_days_g",
    "median_cadence_days_r",
    "median_mag_g",
    "median_mag_r",
    "median_magerr_g",
    "median_magerr_r",
    "mag_range_p95_p05_g",
    "mag_range_p95_p05_r",
    "colour_r_mag_range",
]

cover_rows = []

for c in covariates:
    if c not in out.columns:
        continue

    for cls in [
        "ALL",
        "BLL",
        "FSRQ",
    ]:
        w = (
            out
            if cls == "ALL"
            else out.loc[
                out["blazar_class"]
                .eq(cls)
            ]
        )

        nonmissing = int(
            w[c]
            .notna()
            .sum()
        )

        cover_rows.append({
            "covariate": c,
            "class": cls,
            "N_total": len(w),
            "N_nonmissing": nonmissing,
            "fraction_nonmissing": (
                nonmissing / len(w)
                if len(w)
                else np.nan
            ),
        })

coverage = pd.DataFrame(
    cover_rows
)

coverage.to_csv(
    OUT_COVER,
    index=False,
)

# ============================================================
# FINAL VALIDATION / SAVE
# ============================================================

if len(out) != 1061:
    raise RuntimeError(
        f"Final confounder master should have 1061 rows; got {len(out)}"
    )

if out["blazar_id"].duplicated().any():
    raise RuntimeError(
        "Duplicate blazar_id after Stage 09A1 merges."
    )

if int(
    out["blazar_class"]
    .eq("BLL")
    .sum()
) != 727:
    raise RuntimeError(
        "BLL count changed."
    )

if int(
    out["blazar_class"]
    .eq("FSRQ")
    .sum()
) != 334:
    raise RuntimeError(
        "FSRQ count changed."
    )

out.to_csv(
    OUT_MASTER,
    index=False,
)

host_text = f"""BLAZAR_I — STAGE 09A1 HOST-PROXY DECISION
================================================================================

Internal host-galaxy / morphology proxy available:
  {valid_internal_host_proxy}

Rejected false-positive morphology field:
  stage04_population_master.csv :: col_colour_break_morphology

Reason:
  This column describes the signs of the two fitted colour--magnitude
  slopes (BWB->BWB, RWB->RWB, BWB->RWB, RWB->BWB). It is an endpoint-
  related colour-track descriptor and is NOT a galaxy morphology or
  host-contamination measurement.

Decision:
  EXTERNAL HOST PROXY REQUIRED.

Recommended next augmentation:
  Pan-STARRS1 DR2 mean-stack morphology/photometry at the Fermi optical
  counterpart coordinates, using PSF-versus-Kron magnitude differences
  in r/i as an empirical extension/host-contamination sensitivity proxy.

Scientific role:
  Host proxy will be used as a SENSITIVITY covariate, especially for
  BL Lac colour curvature and fractional-variability results. It will
  not replace the primary pre-diagnostic coverage model and will not
  be presented as a perfect host decomposition.

STAGE 09A1 HOST DECISION COMPLETE
"""

OUT_HOST.write_text(
    host_text,
    encoding="utf-8",
)

def class_cov(c):
    result = {}

    for cls in [
        "BLL",
        "FSRQ",
    ]:
        w = out.loc[
            out["blazar_class"]
            .eq(cls)
        ]

        result[cls] = (
            int(w[c].notna().sum()),
            len(w),
        )

    return result

z_cov = class_cov(
    "redshift"
)
sed_cov = class_cov(
    "sed_class"
)
gamma_cov = class_cov(
    "gamma_energy_flux"
)
mag_cov = class_cov(
    "median_mag_r"
)

summary = f"""BLAZAR_I - STAGE 09A1 FINAL SUMMARY
================================================================================

Q1 confounder master:
  rows                         : {len(out)}
  BLL                          : {int(out['blazar_class'].eq('BLL').sum())}
  FSRQ                         : {int(out['blazar_class'].eq('FSRQ').sum())}

Key covariate coverage:
  redshift BLL                 : {z_cov['BLL'][0]}/{z_cov['BLL'][1]}
  redshift FSRQ                : {z_cov['FSRQ'][0]}/{z_cov['FSRQ'][1]}
  SED class BLL                : {sed_cov['BLL'][0]}/{sed_cov['BLL'][1]}
  SED class FSRQ               : {sed_cov['FSRQ'][0]}/{sed_cov['FSRQ'][1]}
  gamma energy flux BLL        : {gamma_cov['BLL'][0]}/{gamma_cov['BLL'][1]}
  gamma energy flux FSRQ       : {gamma_cov['FSRQ'][0]}/{gamma_cov['FSRQ'][1]}
  nightly median r mag BLL     : {mag_cov['BLL'][0]}/{mag_cov['BLL'][1]}
  nightly median r mag FSRQ    : {mag_cov['FSRQ'][0]}/{mag_cov['FSRQ'][1]}

Nested model definitions frozen for next inference stage:
  M0_COVERAGE
    log N, baseline, cadence, median photometric error

  M1_Z_SED_GAMMA
    M0 + redshift + SED + DR4 gamma energy flux + variability index

  M2_PLUS_OPTICAL_BRIGHTNESS
    M1 + median g/r magnitude

  M3_PLUS_HOST_PROXY
    pending external host augmentation

Host-proxy decision:
  INTERNAL HOST PROXY          : NO
  EXTERNAL AUGMENTATION        : REQUIRED
  recommended source           : Pan-STARRS1 DR2
  intended use                 : sensitivity analysis, not exact decomposition

Files saved:
  {OUT_MASTER}
  {OUT_COVER}
  {OUT_ELIG}
  {OUT_HOST}

Next:
  STAGE 09A2 — external Pan-STARRS1 host/morphology augmentation with
  resumable queries and an explicit match/quality audit.

No endpoint model was fit in STAGE 09A1.

STAGE 09A1 COMPLETE
"""

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(summary)
