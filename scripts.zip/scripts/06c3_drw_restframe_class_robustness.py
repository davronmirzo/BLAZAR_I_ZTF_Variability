# ============================================================
# BLAZAR_I — STAGE 06C3
# CONTROLLED REST-FRAME DRW CLASS EFFECT ACROSS SAMPLING SENSITIVITIES
#
# Inputs:
#   outputs/tables/stage06c2_drw_sensitivity_master.csv
#   outputs/tables/stage03d_drw_master.csv
#
# Goals:
#   1) Test whether the shorter FSRQ rest-frame DRW timescale
#      persists after each sampling perturbation.
#   2) Use only modified fits that pass the same interpretability
#      gate used in STAGE 03D.
#   3) Control for pre-diagnostic sampling/measurement coverage:
#        log1p(N_modified)
#        log10(baseline_days)
#        log10(median_cadence_days)
#        median_magerr (from frozen source-filter row)
#   4) Repeat on a common source-filter set interpretable under
#      ALL three sensitivity schemes, so sample-composition changes
#      cannot drive the class contrast.
#
# Outcome:
#   log10(tau_rest_days)
#
# Key coefficient:
#   FSRQ (BLL reference)
#
# Reported effect factor:
#   10**beta_FSRQ
#   (<1 means shorter tau_rest in FSRQs)
#
# HC3 robust standard errors.
#
# Read-only relative to upstream frozen products.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

SENS_FILE = TABLE_DIR / "stage06c2_drw_sensitivity_master.csv"
FROZEN_FILE = TABLE_DIR / "stage03d_drw_master.csv"

OUT_MODELS = TABLE_DIR / "stage06c3_drw_restframe_class_models.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06c3_summary.txt"

SCHEMES = [
    "THIN_HALF",
    "BASELINE_CENTRAL80",
    "SEASONAL_DENSE_QUARTER_DROP",
]


def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)

    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce"
    )


def zscore_inplace(df, cols):
    for c in cols:
        x = numeric(df[c])
        mu = x.mean()
        sd = x.std(ddof=1)

        if np.isfinite(sd) and sd > 0:
            df[c] = (
                x - mu
            ) / sd
        else:
            df[c] = np.nan


def bh_qvalues(pvalues):
    p = np.asarray(
        pvalues,
        dtype=float
    )

    q = np.full(
        len(p),
        np.nan,
        dtype=float
    )

    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)

    order = np.argsort(
        pv
    )

    ranked = pv[
        order
    ]

    raw = (
        ranked
        *
        m
        /
        np.arange(
            1,
            m + 1
        )
    )

    adj = np.minimum.accumulate(
        raw[::-1]
    )[::-1]

    adj = np.minimum(
        adj,
        1.0
    )

    qv = np.empty(
        m,
        dtype=float
    )

    qv[order] = adj

    q[valid] = qv

    return q


def fit_ols(
    df,
    model_name,
    sample_definition,
):
    cols = [
        "tau_rest_days",
        "FSRQ",
        "logN",
        "logBaseline",
        "logCadence",
        "median_magerr",
    ]

    w = df[
        cols
    ].copy()

    for c in cols:
        w[c] = numeric(
            w[c]
        )

    w = w.replace(
        [np.inf, -np.inf],
        np.nan
    ).dropna()

    if len(w) < 30:
        raise RuntimeError(
            f"{model_name}: too few rows ({len(w)})"
        )

    w = w.loc[
        w["tau_rest_days"] > 0
    ].copy()

    w["logTauRest"] = np.log10(
        w["tau_rest_days"]
    )

    controls = [
        "logN",
        "logBaseline",
        "logCadence",
        "median_magerr",
    ]

    zscore_inplace(
        w,
        controls
    )

    w = w.dropna()

    y = w[
        "logTauRest"
    ].astype(float)

    X = sm.add_constant(
        w[
            [
                "FSRQ",
                *controls,
            ]
        ].astype(float),
        has_constant="add"
    )

    fit = sm.OLS(
        y,
        X
    ).fit(
        cov_type="HC3"
    )

    ci = fit.conf_int()

    beta = float(
        fit.params["FSRQ"]
    )

    lo = float(
        ci.loc[
            "FSRQ",
            0
        ]
    )

    hi = float(
        ci.loc[
            "FSRQ",
            1
        ]
    )

    return {
        "model_name": model_name,
        "sample_definition": sample_definition,
        "N": int(
            len(w)
        ),
        "N_FSRQ": int(
            w["FSRQ"].sum()
        ),
        "N_BLL": int(
            len(w)
            -
            w["FSRQ"].sum()
        ),
        "beta_log10_tau_FSRQ": beta,
        "beta_ci95_low": lo,
        "beta_ci95_high": hi,
        "factor_FSRQ_vs_BLL": 10.0 ** beta,
        "factor_ci95_low": 10.0 ** lo,
        "factor_ci95_high": 10.0 ** hi,
        "p_value": float(
            fit.pvalues["FSRQ"]
        ),
        "r2": float(
            fit.rsquared
        ),
    }


for path in [
    SENS_FILE,
    FROZEN_FILE,
]:
    if not path.exists():
        raise FileNotFoundError(
            path
        )

sens = pd.read_csv(
    SENS_FILE
)

frozen = pd.read_csv(
    FROZEN_FILE
)

sens["blazar_id"] = (
    sens["blazar_id"]
    .astype(str)
)

frozen["blazar_id"] = (
    frozen["blazar_id"]
    .astype(str)
)

sens[
    "tau_interpretable_sensitivity"
] = as_bool(
    sens[
        "tau_interpretable_sensitivity"
    ]
)

frozen[
    "tau_interpretable_primary"
] = as_bool(
    frozen[
        "tau_interpretable_primary"
    ]
)

frozen_key = frozen[
    [
        "blazar_id",
        "filter_name",
        "median_magerr",
        "tau_interpretable_primary",
    ]
].copy()

d = sens.merge(
    frozen_key,
    on=[
        "blazar_id",
        "filter_name",
    ],
    how="left",
    validate="many_to_one",
)

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

d["logN"] = np.log1p(
    numeric(
        d["N_modified"]
    )
)

d["logBaseline"] = np.log10(
    numeric(
        d["baseline_days"]
    )
)

d["logCadence"] = np.log10(
    numeric(
        d["median_cadence_days"]
    )
)

# ------------------------------------------------------------
# Common-set definition:
# source-filter rows that are interpretable in all three schemes.
# ------------------------------------------------------------

interp_wide = (
    d.pivot(
        index=[
            "blazar_id",
            "filter_name",
        ],
        columns="scheme",
        values="tau_interpretable_sensitivity"
    )
)

for scheme in SCHEMES:
    if scheme not in interp_wide.columns:
        raise RuntimeError(
            f"Missing scheme in sensitivity table: {scheme}"
        )

common_index = interp_wide.index[
    interp_wide[
        SCHEMES
    ].all(
        axis=1
    )
]

common_keys = set(
    common_index.tolist()
)

# ------------------------------------------------------------
# Fit models.
# ------------------------------------------------------------

rows = []

for scheme in SCHEMES:
    x = d.loc[
        d["scheme"].eq(
            scheme
        )
        &
        d[
            "tau_interpretable_sensitivity"
        ]
        &
        d[
            "tau_interpretable_primary"
        ]
        &
        numeric(
            d["tau_rest_days"]
        ).notna()
    ].copy()

    rows.append(
        fit_ols(
            x,
            model_name=f"{scheme}_CUTSPEC",
            sample_definition="scheme_specific_interpretable",
        )
    )

    mask_common = [
        (
            bid,
            filt
        )
        in common_keys
        for bid, filt
        in zip(
            x["blazar_id"],
            x["filter_name"],
        )
    ]

    xc = x.loc[
        mask_common
    ].copy()

    rows.append(
        fit_ols(
            xc,
            model_name=f"{scheme}_COMMON",
            sample_definition="interpretable_all_three_schemes",
        )
    )

models = pd.DataFrame(
    rows
)

models[
    "q_BH_all_models"
] = bh_qvalues(
    models[
        "p_value"
    ].to_numpy(
        dtype=float
    )
)

for sample_def in models[
    "sample_definition"
].unique():
    mask = models[
        "sample_definition"
    ].eq(
        sample_def
    )

    models.loc[
        mask,
        "q_BH_within_family"
    ] = bh_qvalues(
        models.loc[
            mask,
            "p_value"
        ].to_numpy(
            dtype=float
        )
    )

models.to_csv(
    OUT_MODELS,
    index=False
)

# ------------------------------------------------------------
# Summary.
# ------------------------------------------------------------

lines = [
    "BLAZAR_I - STAGE 06C3 FINAL SUMMARY",
    "=" * 72,
    "",
    (
        "Common source-filter rows interpretable "
        f"in all three schemes: {len(common_keys)}"
    ),
    "",
    "CONTROLLED FSRQ EFFECT ON log10(tau_rest):",
]

for _, rr in models.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"N={int(rr['N'])} "
        f"(FSRQ={int(rr['N_FSRQ'])}, BLL={int(rr['N_BLL'])}), "
        f"beta={rr['beta_log10_tau_FSRQ']:.4f}, "
        f"factor={rr['factor_FSRQ_vs_BLL']:.3f} "
        f"({rr['factor_ci95_low']:.3f}-{rr['factor_ci95_high']:.3f}), "
        f"p={rr['p_value']:.3g}, "
        f"q_family={rr['q_BH_within_family']:.3g}"
    )

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8"
)

print("=" * 78)
print("BLAZAR_I — STAGE 06C3")
print("CONTROLLED REST-FRAME DRW CLASS EFFECT")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_MODELS)
print(OUT_SUMMARY)
print()
print("STAGE 06C3 COMPLETE")
