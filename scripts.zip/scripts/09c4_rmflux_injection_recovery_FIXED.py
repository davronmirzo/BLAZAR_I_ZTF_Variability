# ============================================================
# BLAZAR_I — STAGE 09C4
# RMS–FLUX ADDITIVE-NULL / MULTIPLICATIVE-INJECTION CALIBRATION
#
# Purpose:
#   Calibrate the frozen Stage03B 20-night occupancy rms–flux diagnostic
#   under ACTUAL ZTF cadence/error patterns.
#
# Exact Stage03B analysis reproduced:
#   - consecutive 20-night segments
#   - final incomplete remainder discarded
#   - >=8 complete segments required
#   - intrinsic rms = sqrt(max(S^2 - mean(err^2), 0))
#   - Spearman rho between segment mean flux and intrinsic rms
#   - OLS slope
#   - paired-segment bootstrap, 2000 draws
#
# Strict-positive ingredients:
#   rho > 0
#   OLS slope > 0
#   bootstrap 95% lower slope > 0
#
# Significance is reported three ways:
#   RAW_P05:
#       Spearman p <= 0.05
#
#   FROZEN_GLOBAL_P:
#       Spearman p <= the empirical p cutoff corresponding to q_global<=0.05
#       in the frozen Stage03B analysis. This preserves the original
#       multiplicity threshold as a practical calibration reference.
#
#   BANK_BH:
#       BH q<=0.05 within each simulated scenario/replicate across the
#       48 template tests. This is a template-bank FDR sensitivity, not
#       a literal replacement for the original 1888-test global FDR.
#
# Scenarios:
#   ADDITIVE_OU_NULL
#       Linear-flux OU variability with constant absolute intrinsic scale.
#
#   MULTIPLICATIVE_FROZEN
#       Lognormal OU flux process with source-specific observed Fvar.
#
#   MULTIPLICATIVE_STRONG
#       Same, with target Fvar increased by 50% (capped).
#
# Default workload:
#   48 templates x 3 scenarios x 30 reps = 4320 simulations.
# ============================================================

from pathlib import Path
import argparse
import math
import time
import zlib
import warnings

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, linregress

warnings.filterwarnings("ignore", category=RuntimeWarning)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

MODEL_DIR = ROOT / "outputs" / "models" / "stage09c4_rmflux_calibration"

TEMPLATE_FILE = TABLE_DIR / "stage09c0_source_filter_template_bank.csv"
PRIMARY_FILE = TABLE_DIR / "stage03b_rmflux_master.csv"

OUT_MASTER = TABLE_DIR / "stage09c4_rmflux_simulation_master.csv"
OUT_SCEN = TABLE_DIR / "stage09c4_rmflux_scenario_summary.csv"
OUT_TEMPLATE = TABLE_DIR / "stage09c4_rmflux_template_summary.csv"
OUT_SUMMARY = AUDIT_DIR / "stage09c4_summary.txt"

for p in [TABLE_DIR, AUDIT_DIR, MODEL_DIR]:
    p.mkdir(parents=True, exist_ok=True)

SEGMENT_N = 20
MIN_SEGMENTS = 8
BOOTSTRAP_N = 2000
FDR_ALPHA = 0.05
BASE_SEED = 20260918

SCENARIOS = [
    "ADDITIVE_OU_NULL",
    "MULTIPLICATIVE_FROZEN",
    "MULTIPLICATIVE_STRONG",
]

parser = argparse.ArgumentParser()
parser.add_argument("--reps", type=int, default=30)
parser.add_argument("--limit-templates", type=int, default=None)
args = parser.parse_args()

if args.reps < 1:
    raise RuntimeError("--reps must be >=1")


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def stable_seed(template_id, scenario, rep, token):
    payload = f"{BASE_SEED}|{template_id}|{scenario}|{rep}|{token}".encode("utf-8")
    return int(zlib.crc32(payload) & 0xFFFFFFFF)


def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)
    valid = np.isfinite(p)
    if valid.sum() == 0:
        return q
    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    m = len(ranked)
    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)
    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[valid] = qv
    return q


def wilson_interval(k, n, z=1.959963984540054):
    if n <= 0:
        return np.nan, np.nan
    p = k / n
    denom = 1.0 + z * z / n
    centre = (p + z * z / (2.0 * n)) / denom
    half = z * math.sqrt(
        p * (1.0 - p) / n + z * z / (4.0 * n * n)
    ) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def build_segments(t, flux, fluxerr):
    order = np.argsort(t)
    t = np.asarray(t, dtype=float)[order]
    flux = np.asarray(flux, dtype=float)[order]
    fluxerr = np.asarray(fluxerr, dtype=float)[order]

    n_complete = len(flux) // SEGMENT_N
    rows = []

    for j in range(n_complete):
        a = j * SEGMENT_N
        b = a + SEGMENT_N
        tt = t[a:b]
        ff = flux[a:b]
        ee = fluxerr[a:b]

        mean_f = float(np.mean(ff))
        s2 = float(np.var(ff, ddof=1))
        mean_e2 = float(np.mean(ee ** 2))
        xs = s2 - mean_e2
        rms_xs = math.sqrt(max(xs, 0.0))

        rows.append({
            "segment_index": j + 1,
            "mean_flux_jy": mean_f,
            "intrinsic_rms_jy": rms_xs,
            "span_days": float(np.max(tt) - np.min(tt)),
            "noise_dominated": bool(xs <= 0),
        })

    return pd.DataFrame(rows)


def bootstrap_slope(x, y, seed):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(x)

    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(BOOTSTRAP_N, n), endpoint=False)

    xb = x[idx]
    yb = y[idx]

    xm = xb.mean(axis=1)
    ym = yb.mean(axis=1)
    dx = xb - xm[:, None]
    dy = yb - ym[:, None]

    denom = np.sum(dx ** 2, axis=1)
    numer = np.sum(dx * dy, axis=1)

    good = np.isfinite(denom) & np.isfinite(numer) & (denom > 0)

    slopes = numer[good] / denom[good]
    slopes = slopes[np.isfinite(slopes)]

    if len(slopes) == 0:
        return {
            "boot_valid_N": 0,
            "slope_boot_p025": np.nan,
            "slope_boot_p975": np.nan,
            "slope_boot_median": np.nan,
        }

    return {
        "boot_valid_N": int(len(slopes)),
        "slope_boot_p025": float(np.percentile(slopes, 2.5)),
        "slope_boot_p975": float(np.percentile(slopes, 97.5)),
        "slope_boot_median": float(np.median(slopes)),
    }


def analyze_simulated(template_id, scenario, rep, t, flux, fluxerr):
    seg = build_segments(t, flux, fluxerr)

    row = {
        "N_nightly": int(len(flux)),
        "N_segments": int(len(seg)),
        "fit_status": "NOT_RUN",
    }

    if len(seg) < MIN_SEGMENTS:
        row["fit_status"] = f"TOO_FEW_SEGMENTS_LT_{MIN_SEGMENTS}"
        return row

    xx = numeric(seg["mean_flux_jy"]).to_numpy(dtype=float)
    yy = numeric(seg["intrinsic_rms_jy"]).to_numpy(dtype=float)

    good = np.isfinite(xx) & np.isfinite(yy) & (xx > 0) & (yy >= 0)
    xx = xx[good]
    yy = yy[good]

    row["N_segments_fit"] = int(len(xx))

    if len(xx) < MIN_SEGMENTS:
        row["fit_status"] = f"TOO_FEW_FINITE_SEGMENTS_LT_{MIN_SEGMENTS}"
        return row

    if np.allclose(xx, xx[0]) or np.allclose(yy, yy[0]):
        row["fit_status"] = "DEGENERATE_RELATION"
        return row

    rho, p = spearmanr(xx, yy)
    lr = linregress(xx, yy)

    boot = bootstrap_slope(
        xx,
        yy,
        stable_seed(template_id, scenario, rep, "BOOTSTRAP"),
    )

    candidate = bool(
        np.isfinite(rho)
        and rho > 0
        and np.isfinite(lr.slope)
        and lr.slope > 0
        and np.isfinite(boot["slope_boot_p025"])
        and boot["slope_boot_p025"] > 0
    )

    row.update({
        "spearman_rho": float(rho),
        "spearman_p": float(p),
        "ols_slope": float(lr.slope),
        "ols_intercept_jy": float(lr.intercept),
        **boot,
        "candidate_positive_before_p": candidate,
        "raw_p05_positive": bool(candidate and p <= 0.05),
        "noise_dominated_fraction": float(seg["noise_dominated"].mean()),
        "segment_span_days_median": float(seg["span_days"].median()),
        "fit_status": "OK",
    })

    return row


def simulate_ou_standard(rng, t, tau):
    n = len(t)
    z = np.empty(n, dtype=float)
    z[0] = rng.normal()

    for i in range(1, n):
        dt = t[i] - t[i - 1]
        a = math.exp(-dt / tau)
        q = max(0.0, 1.0 - a ** 2)
        z[i] = a * z[i - 1] + rng.normal(0.0, math.sqrt(q))

    return z


def build_design(template_row):
    bid = str(template_row["blazar_id"])
    filt = str(template_row["filter_name"]).lower()

    path = NIGHTLY_DIR / f"{bid}_NIGHTLY.parquet"
    if not path.exists():
        raise FileNotFoundError(path)

    d = pd.read_parquet(path)

    x = (
        d.loc[
            d["filter_name"].astype(str).str.lower().eq(filt)
        ]
        .copy()
        .sort_values("hmjd")
        .reset_index(drop=True)
    )

    t = numeric(x["hmjd"]).to_numpy(dtype=float)
    flux = numeric(x["flux_jy"]).to_numpy(dtype=float)
    fluxerr = numeric(x["fluxerr_jy"]).to_numpy(dtype=float)

    good = (
        np.isfinite(t)
        & np.isfinite(flux)
        & np.isfinite(fluxerr)
        & (flux > 0)
        & (fluxerr >= 0)
    )

    t = t[good]
    flux = flux[good]
    fluxerr = fluxerr[good]

    if len(t) < SEGMENT_N * MIN_SEGMENTS:
        raise RuntimeError(
            f"{bid} {filt}: template reports Stage03B eligibility but actual "
            f"nightly file has only N={len(t)} valid points (<160)."
        )

    mean_flux = float(np.mean(flux))
    median_flux = float(np.median(flux))

    fracerr = np.clip(fluxerr / flux, 1.0e-5, 0.20)

    fvar = numeric(pd.Series([template_row["Fvar"]])).iloc[0]

    if not np.isfinite(fvar) or fvar <= 0:
        var_obs = float(np.var(flux, ddof=1))
        mean_e2 = float(np.mean(fluxerr ** 2))
        excess = max(0.0, var_obs - mean_e2)
        fvar = math.sqrt(excess) / mean_flux if mean_flux > 0 else 0.10

    fvar_frozen = float(np.clip(fvar, 0.03, 1.25))
    fvar_strong = float(np.clip(1.5 * fvar_frozen, 0.05, 1.50))

    baseline = float(t[-1] - t[0])
    cadence = float(np.median(np.diff(t)))

    tau_obs = numeric(pd.Series([template_row["tau_obs_days"]])).iloc[0]

    tau_lo = max(3.0 * cadence, 1.0)
    tau_hi = max(tau_lo, 0.08 * baseline)

    if not np.isfinite(tau_obs) or tau_obs <= 0:
        tau_obs = math.sqrt(tau_lo * tau_hi)

    tau_corr = float(np.clip(tau_obs, tau_lo, tau_hi))

    return {
        "t": t,
        "mean_flux": mean_flux,
        "median_flux": median_flux,
        "fracerr": fracerr,
        "fvar_frozen": fvar_frozen,
        "fvar_strong": fvar_strong,
        "baseline": baseline,
        "cadence": cadence,
        "tau_corr": tau_corr,
    }


def simulate_flux(rng, design, scenario):
    t = design["t"]
    z = simulate_ou_standard(rng, t, design["tau_corr"])

    if scenario == "ADDITIVE_OU_NULL":
        sigma_abs = design["fvar_frozen"] * design["mean_flux"]
        true_flux = design["mean_flux"] + sigma_abs * z

        shift = 0.0
        min_flux = float(np.min(true_flux))
        positive_floor = 0.05 * design["mean_flux"]

        if min_flux <= positive_floor:
            shift = positive_floor - min_flux
            true_flux = true_flux + shift

        target_fvar = design["fvar_frozen"]

    elif scenario in {"MULTIPLICATIVE_FROZEN", "MULTIPLICATIVE_STRONG"}:
        target_fvar = (
            design["fvar_frozen"]
            if scenario == "MULTIPLICATIVE_FROZEN"
            else design["fvar_strong"]
        )

        sigma_ln = math.sqrt(math.log(1.0 + target_fvar ** 2))

        true_flux = (
            design["mean_flux"]
            * np.exp(
                sigma_ln * z
                - 0.5 * sigma_ln ** 2
            )
        )

        shift = 0.0

    else:
        raise RuntimeError(f"Unknown scenario: {scenario}")

    err_sim = np.maximum(design["fracerr"] * true_flux, 1.0e-12)

    obs_flux = true_flux + rng.normal(0.0, err_sim)

    floor = max(1.0e-12, 1.0e-6 * design["mean_flux"])
    obs_flux = np.maximum(obs_flux, floor)

    return {
        "obs_flux": obs_flux,
        "err_sim": err_sim,
        "target_fvar": float(target_fvar),
        "additive_positive_shift": float(shift),
    }


if not PRIMARY_FILE.exists():
    raise FileNotFoundError(PRIMARY_FILE)

primary = pd.read_csv(PRIMARY_FILE, low_memory=False)

required_primary = [
    "fit_status",
    "spearman_p",
    "spearman_q_bh_global",
]

missing_primary = [
    c for c in required_primary
    if c not in primary.columns
]

if missing_primary:
    raise RuntimeError(
        "Stage03B master missing: " + repr(missing_primary)
    )

eligible_primary = primary["fit_status"].astype(str).eq("OK")

sig_primary = (
    eligible_primary
    &
    (
        numeric(primary["spearman_q_bh_global"])
        <=
        FDR_ALPHA
    )
)

if not sig_primary.any():
    raise RuntimeError("No frozen q_global<=0.05 rows found.")

FROZEN_GLOBAL_P_CUTOFF = float(
    numeric(primary.loc[sig_primary, "spearman_p"]).max()
)

PRIMARY_ELIGIBLE_N = int(eligible_primary.sum())
PRIMARY_FDR_SIG_N = int(sig_primary.sum())


if not TEMPLATE_FILE.exists():
    raise FileNotFoundError(TEMPLATE_FILE)

templates = pd.read_csv(TEMPLATE_FILE, low_memory=False)

templates["blazar_id"] = templates["blazar_id"].astype(str)
templates["filter_name"] = templates["filter_name"].astype(str).str.lower()

if args.limit_templates is not None:
    templates = templates.head(args.limit_templates).copy()

# Stage03B primary rms-flux analysis requires >=8 complete 20-point
# segments, i.e. at least 160 nightly points.  Stage09C0 was intentionally
# shared across DRW/PDF/rms-flux and only required >=100 points, so some
# source-filter templates are valid for DRW/PDF but ineligible for the
# PRIMARY rms-flux gate.  Exclude those templates here rather than aborting.
templates["N_nightly"] = numeric(
    templates["N_nightly"]
)

templates_before_rmflux_gate = len(templates)

templates = templates.loc[
    templates["N_nightly"]
    >=
    (
        SEGMENT_N
        *
        MIN_SEGMENTS
    )
].copy()

templates_excluded_rmflux_gate = (
    templates_before_rmflux_gate
    -
    len(templates)
)

if len(templates) == 0:
    raise RuntimeError(
        "No Stage09C0 templates satisfy the primary Stage03B "
        "eligibility requirement N_nightly>=160."
    )

print("=" * 80)
print("BLAZAR_I — STAGE 09C4 RMS-FLUX CALIBRATION")
print("=" * 80)
print("Stage09C0 templates before RMF eligibility =", templates_before_rmflux_gate)
print("Excluded because N_nightly < 160 =", templates_excluded_rmflux_gate)
print("RMF-eligible templates =", len(templates))
print("Scenarios =", len(SCENARIOS))
print("Replicates/template/scenario =", args.reps)
print("Target simulations =", len(templates) * len(SCENARIOS) * args.reps)
print("Frozen Stage03B eligible tests =", PRIMARY_ELIGIBLE_N)
print("Frozen Stage03B q_global<=0.05 tests =", PRIMARY_FDR_SIG_N)
print("Frozen empirical global p cutoff =", f"{FROZEN_GLOBAL_P_CUTOFF:.8g}")


all_frames = []
cell_index = 0
n_cells = len(templates) * len(SCENARIOS)
t0 = time.time()

for _, template_row in templates.iterrows():
    template_id = str(template_row["template_id"])
    design = build_design(template_row)

    for scenario in SCENARIOS:
        cell_index += 1

        cell_file = MODEL_DIR / f"{template_id}_{scenario}.csv"

        if cell_file.exists():
            prev = pd.read_csv(cell_file, low_memory=False)
        else:
            prev = pd.DataFrame()

        done_reps = set()

        if len(prev) and "replicate" in prev.columns:
            done_reps = set(
                numeric(prev["replicate"])
                .dropna()
                .astype(int)
                .tolist()
            )

        rows = []

        for rep in range(1, args.reps + 1):
            if rep in done_reps:
                continue

            rng = np.random.default_rng(
                stable_seed(
                    template_id,
                    scenario,
                    rep,
                    "SIMULATION",
                )
            )

            try:
                sim = simulate_flux(
                    rng,
                    design,
                    scenario,
                )

                result = analyze_simulated(
                    template_id,
                    scenario,
                    rep,
                    design["t"],
                    sim["obs_flux"],
                    sim["err_sim"],
                )

                row = {
                    "template_id": template_id,
                    "blazar_id": str(template_row["blazar_id"]),
                    "blazar_class": template_row["blazar_class"],
                    "filter_name": template_row["filter_name"],
                    "scenario": scenario,
                    "replicate": int(rep),
                    "target_fvar": sim["target_fvar"],
                    "tau_corr_days": design["tau_corr"],
                    "additive_positive_shift": sim["additive_positive_shift"],
                    **result,
                }

            except Exception as exc:
                row = {
                    "template_id": template_id,
                    "blazar_id": str(template_row["blazar_id"]),
                    "blazar_class": template_row["blazar_class"],
                    "filter_name": template_row["filter_name"],
                    "scenario": scenario,
                    "replicate": int(rep),
                    "fit_status": (
                        f"EXCEPTION:{type(exc).__name__}:{exc}"
                    ),
                }

            rows.append(row)

            current = pd.concat(
                [prev, pd.DataFrame(rows)],
                ignore_index=True,
            )

            current = (
                current
                .sort_values("replicate")
                .drop_duplicates("replicate", keep="last")
            )

            current.to_csv(cell_file, index=False)

        final_cell = pd.read_csv(cell_file, low_memory=False)

        final_cell = final_cell.loc[
            numeric(final_cell["replicate"]) <= args.reps
        ].copy()

        all_frames.append(final_cell)

        elapsed = time.time() - t0

        print(
            f"Cell {cell_index}/{n_cells} "
            f"{template_id} {scenario}: "
            f"saved_reps={len(final_cell)} "
            f"elapsed={elapsed/60.0:.1f} min"
        )


master = pd.concat(all_frames, ignore_index=True)

master["fit_ok"] = master["fit_status"].astype(str).eq("OK")

master["candidate_positive_bool"] = (
    master["candidate_positive_before_p"]
    .astype(str)
    .str.strip()
    .str.lower()
    .isin(["true", "1", "1.0", "yes", "y"])
)

master["raw_p05_bool"] = (
    master["candidate_positive_bool"]
    &
    (numeric(master["spearman_p"]) <= 0.05)
)

master["frozen_global_p_bool"] = (
    master["candidate_positive_bool"]
    &
    (
        numeric(master["spearman_p"])
        <=
        FROZEN_GLOBAL_P_CUTOFF
    )
)

master["bank_q_bh"] = np.nan
master["bank_bh_bool"] = False

for (scenario, rep), g in master.groupby(
    ["scenario", "replicate"]
):
    idx = g.index[
        g["fit_ok"]
        &
        numeric(g["spearman_p"]).notna()
    ]

    if len(idx) == 0:
        continue

    q = bh_qvalues(
        numeric(
            master.loc[idx, "spearman_p"]
        ).to_numpy(dtype=float)
    )

    master.loc[idx, "bank_q_bh"] = q

    master.loc[idx, "bank_bh_bool"] = (
        master.loc[idx, "candidate_positive_bool"].astype(bool)
        &
        (q <= FDR_ALPHA)
    )

master.to_csv(OUT_MASTER, index=False)


scenario_rows = []

for scenario, g in master.groupby("scenario"):
    ok = g.loc[g["fit_ok"]].copy()
    n = len(ok)

    k_raw = int(ok["raw_p05_bool"].sum())
    k_frozen = int(ok["frozen_global_p_bool"].sum())
    k_bank = int(ok["bank_bh_bool"].sum())

    raw_lo, raw_hi = wilson_interval(k_raw, n)
    frozen_lo, frozen_hi = wilson_interval(k_frozen, n)
    bank_lo, bank_hi = wilson_interval(k_bank, n)

    scenario_rows.append({
        "scenario": scenario,
        "N_simulations": len(g),
        "N_fit_ok": n,
        "fit_ok_fraction": n / len(g) if len(g) else np.nan,
        "raw_p05_positive_N": k_raw,
        "raw_p05_positive_fraction": k_raw / n if n else np.nan,
        "raw_p05_ci95_low": raw_lo,
        "raw_p05_ci95_high": raw_hi,
        "frozen_global_positive_N": k_frozen,
        "frozen_global_positive_fraction": k_frozen / n if n else np.nan,
        "frozen_global_ci95_low": frozen_lo,
        "frozen_global_ci95_high": frozen_hi,
        "bank_bh_positive_N": k_bank,
        "bank_bh_positive_fraction": k_bank / n if n else np.nan,
        "bank_bh_ci95_low": bank_lo,
        "bank_bh_ci95_high": bank_hi,
        "median_spearman_rho": (
            numeric(ok["spearman_rho"]).median()
            if n else np.nan
        ),
        "median_ols_slope": (
            numeric(ok["ols_slope"]).median()
            if n else np.nan
        ),
        "median_noise_dominated_fraction": (
            numeric(ok["noise_dominated_fraction"]).median()
            if n else np.nan
        ),
    })

scenario_summary = pd.DataFrame(scenario_rows)
scenario_summary.to_csv(OUT_SCEN, index=False)


template_rows = []

for (template_id, scenario), g in master.groupby(
    ["template_id", "scenario"]
):
    ok = g.loc[g["fit_ok"]].copy()

    template_rows.append({
        "template_id": template_id,
        "scenario": scenario,
        "N_simulations": len(g),
        "N_fit_ok": len(ok),
        "raw_p05_positive_fraction": (
            float(ok["raw_p05_bool"].mean())
            if len(ok) else np.nan
        ),
        "frozen_global_positive_fraction": (
            float(ok["frozen_global_p_bool"].mean())
            if len(ok) else np.nan
        ),
        "bank_bh_positive_fraction": (
            float(ok["bank_bh_bool"].mean())
            if len(ok) else np.nan
        ),
        "median_spearman_rho": (
            numeric(ok["spearman_rho"]).median()
            if len(ok) else np.nan
        ),
        "median_ols_slope": (
            numeric(ok["ols_slope"]).median()
            if len(ok) else np.nan
        ),
    })

template_summary = pd.DataFrame(template_rows)
template_summary.to_csv(OUT_TEMPLATE, index=False)


def get_scenario(name):
    hit = scenario_summary.loc[
        scenario_summary["scenario"].eq(name)
    ]
    if len(hit) != 1:
        return None
    return hit.iloc[0]


lines = [
    "BLAZAR_I - STAGE 09C4 FINAL SUMMARY",
    "=" * 80,
    "",
    "rms-flux additive-null / multiplicative-injection calibration",
    "",
    f"Stage09C0 templates before gate    : {templates_before_rmflux_gate}",
    f"Excluded N_nightly < 160           : {templates_excluded_rmflux_gate}",
    f"RMF-eligible templates             : {len(templates)}",
    f"Replicates/template/scenario       : {args.reps}",
    f"Total simulations                 : {len(master)}",
    "",
    "Frozen Stage03B multiplicity reference:",
    f"  eligible source-filter tests    : {PRIMARY_ELIGIBLE_N}",
    f"  q_global <= 0.05 tests          : {PRIMARY_FDR_SIG_N}",
    f"  empirical Spearman p cutoff     : {FROZEN_GLOBAL_P_CUTOFF:.8g}",
    "",
]

for name in SCENARIOS:
    r = get_scenario(name)
    if r is None:
        continue

    label = (
        "false-positive"
        if name == "ADDITIVE_OU_NULL"
        else "recovery"
    )

    lines += [
        f"{name}:",
        f"  fit success fraction            : {r['fit_ok_fraction']:.4f}",
        f"  RAW_P05 {label:14s}          : {r['raw_p05_positive_fraction']:.4f} [{r['raw_p05_ci95_low']:.4f}, {r['raw_p05_ci95_high']:.4f}]",
        f"  FROZEN_GLOBAL_P {label:14s}  : {r['frozen_global_positive_fraction']:.4f} [{r['frozen_global_ci95_low']:.4f}, {r['frozen_global_ci95_high']:.4f}]",
        f"  BANK_BH {label:14s}           : {r['bank_bh_positive_fraction']:.4f} [{r['bank_bh_ci95_low']:.4f}, {r['bank_bh_ci95_high']:.4f}]",
        f"  median Spearman rho             : {r['median_spearman_rho']:.3f}",
        f"  median noise-dominated fraction : {r['median_noise_dominated_fraction']:.3f}",
        "",
    ]

lines += [
    "Interpretation locks:",
    "  - Only templates satisfying the frozen PRIMARY Stage03B eligibility",
    "    requirement (>=8 x 20-night segments; N_nightly>=160) are calibrated.",
    "  - ADDITIVE_OU_NULL tests whether correlated additive variability plus",
    "    actual photometric noise can spuriously satisfy the rms-flux gate.",
    "  - MULTIPLICATIVE scenarios test detection efficiency for lognormal",
    "    OU variability at source-specific observed/stronger fractional RMS.",
    "  - BANK_BH uses only the 48-template calibration bank and therefore",
    "    is a sensitivity analysis, not the literal original 1888-test BH.",
    "  - FROZEN_GLOBAL_P is the practical reference closest to the frozen",
    "    Stage03B global multiplicity decision threshold.",
    "  - Calibration does not imply that real blazar variability is exactly",
    "    additive OU or lognormal OU.",
    "",
    "Files saved:",
    f"  {OUT_MASTER}",
    f"  {OUT_SCEN}",
    f"  {OUT_TEMPLATE}",
    "",
    "Checkpoint directory:",
    f"  {MODEL_DIR}",
    "",
    "Next:",
    "  STAGE 09C5 — integrate DRW, colour, PDF, and rms-flux calibration",
    "  into one reviewer-facing calibration ledger.",
    "",
    "STAGE 09C4 COMPLETE",
]

summary = "\n".join(lines)

OUT_SUMMARY.write_text(summary, encoding="utf-8")
print(summary)
