# ============================================================
# BLAZAR_I — STAGE 06A2
# CONTROLLED INFERENCE ACROSS RMS–FLUX SEGMENTATION SENSITIVITIES
#
# Inputs:
#   outputs/tables/stage06a_rmflux_sensitivity_source.csv
#   outputs/tables/stage04_population_master.csv
#
# For each sensitivity scheme:
#   1) FSRQ class effect on strict-both rms–flux among sources
#      eligible in both bands, using the same clean pre-diagnostic
#      coverage controls as STAGE 05C.
#
#   2) strict-both rms–flux -> robust central colour-break
#      association, with:
#        (a) minimal colour detectability controls
#        (b) dynamic-range sensitivity control
#
# No upstream files are modified.
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import statsmodels.api as sm


ROOT = Path(__file__).resolve().parents[1]
TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"

SOURCE_FILE = TABLE_DIR / "stage06a_rmflux_sensitivity_source.csv"
POP_FILE = TABLE_DIR / "stage04_population_master.csv"

OUT_CLASS = TABLE_DIR / "stage06a2_class_effects_by_segmentation.csv"
OUT_COLOUR = TABLE_DIR / "stage06a2_rmflux_colour_by_segmentation.csv"
OUT_SUMMARY = AUDIT_DIR / "stage06a2_summary.txt"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


def as_bool(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).astype(bool)
    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y"])
    )


def numeric(s):
    return pd.to_numeric(s, errors="coerce")


def safe_log1p(s):
    x = numeric(s)
    out = pd.Series(np.nan, index=x.index, dtype=float)
    good = np.isfinite(x) & (x >= 0)
    out.loc[good] = np.log1p(x.loc[good])
    return out


def zscore_inplace(df, cols):
    for c in cols:
        x = numeric(df[c])
        mu = x.mean()
        sd = x.std(ddof=1)
        if np.isfinite(sd) and sd > 0:
            df[c] = (x - mu) / sd
        else:
            df[c] = np.nan


def bh_qvalues(pvalues):
    p = np.asarray(pvalues, dtype=float)
    q = np.full(len(p), np.nan, dtype=float)
    valid = np.isfinite(p)

    if valid.sum() == 0:
        return q

    pv = p[valid]
    m = len(pv)
    order = np.argsort(pv)
    ranked = pv[order]

    raw = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(raw[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    qv = np.empty(m, dtype=float)
    qv[order] = adj
    q[valid] = qv
    return q


def fit_logit(
    df,
    outcome,
    predictors,
    key_predictors,
    model_name,
    standardize=None,
):
    if standardize is None:
        standardize = []

    w = df[[outcome] + predictors].copy()
    w[outcome] = as_bool(w[outcome]).astype(int)

    for c in predictors:
        w[c] = numeric(w[c])

    w = w.replace([np.inf, -np.inf], np.nan).dropna()

    zscore_inplace(w, standardize)
    w = w.dropna()

    if len(w) < 30:
        raise RuntimeError(f"{model_name}: too few rows ({len(w)})")

    y = w[outcome].astype(float)

    if y.nunique() < 2:
        raise RuntimeError(f"{model_name}: degenerate outcome")

    X = sm.add_constant(
        w[predictors].astype(float),
        has_constant="add"
    )

    fit = sm.GLM(
        y,
        X,
        family=sm.families.Binomial(),
    ).fit(
        cov_type="HC3",
        maxiter=300,
    )

    ci = fit.conf_int()
    rows = []

    for key in key_predictors:
        beta = float(fit.params[key])
        lo = float(ci.loc[key, 0])
        hi = float(ci.loc[key, 1])

        rows.append({
            "model_name": model_name,
            "outcome": outcome,
            "predictor": key,
            "N": int(len(w)),
            "N_event": int(y.sum()),
            "event_fraction": float(y.mean()),
            "coef_log_odds": beta,
            "odds_ratio": math.exp(beta),
            "or_ci95_low": math.exp(lo),
            "or_ci95_high": math.exp(hi),
            "p_value": float(fit.pvalues[key]),
            "aic": float(fit.aic),
        })

    return pd.DataFrame(rows)


for path in [SOURCE_FILE, POP_FILE]:
    if not path.exists():
        raise FileNotFoundError(path)

src = pd.read_csv(SOURCE_FILE)
pop = pd.read_csv(POP_FILE)

src["blazar_id"] = src["blazar_id"].astype(str)
pop["blazar_id"] = pop["blazar_id"].astype(str)

if pop["blazar_id"].duplicated().any():
    raise RuntimeError("Population master has duplicate blazar_id values.")

# Merge only once.
d = src.merge(
    pop,
    on="blazar_id",
    how="left",
    suffixes=("_sens", ""),
    validate="many_to_one",
)

# Resolve class from population master.
if "blazar_class" not in d.columns:
    if "blazar_class_sens" in d.columns:
        d["blazar_class"] = d["blazar_class_sens"]
    else:
        raise RuntimeError("blazar_class missing after merge.")

d["FSRQ"] = (
    d["blazar_class"]
    .astype(str)
    .eq("FSRQ")
    .astype(int)
)

for c in [
    "eligible_both",
    "strict_both",
    "colour_robust_central_break",
]:
    d[c] = as_bool(d[c])

# Clean pre-diagnostic coverage controls (same principle as 05C).
ng = numeric(d["N_nights_g"])
nr = numeric(d["N_nights_r"])

d["coverage_log_min_night"] = safe_log1p(
    np.minimum(ng, nr)
)

d["coverage_band_balance"] = np.log(
    (ng + 1.0) / (nr + 1.0)
)

d["coverage_mean_baseline_yr"] = (
    numeric(d["baseline_g_yr"])
    +
    numeric(d["baseline_r_yr"])
) / 2.0

d["coverage_mean_cadence_days"] = (
    numeric(d["drw_median_cadence_days_g"])
    +
    numeric(d["drw_median_cadence_days_r"])
) / 2.0

d["colour_logN"] = safe_log1p(
    d["col_N_colour_pairs"]
)

coverage = [
    "coverage_log_min_night",
    "coverage_band_balance",
    "coverage_mean_baseline_yr",
    "coverage_mean_cadence_days",
]

schemes = sorted(d["scheme"].dropna().unique().tolist())

class_frames = []
colour_frames = []

for scheme in schemes:
    x = d.loc[
        d["scheme"].eq(scheme)
        &
        d["eligible_both"]
    ].copy()

    # Clean class effect.
    class_frames.append(
        fit_logit(
            x,
            outcome="strict_both",
            predictors=[
                "FSRQ",
                *coverage,
            ],
            key_predictors=["FSRQ"],
            model_name=f"{scheme}_CLASS_CLEAN",
            standardize=coverage,
        )
    )

    # Minimal colour detectability model.
    colour_frames.append(
        fit_logit(
            x,
            outcome="colour_robust_central_break",
            predictors=[
                "strict_both",
                "FSRQ",
                "colour_logN",
                "col_pair_dt_hours_median",
            ],
            key_predictors=[
                "strict_both",
                "FSRQ",
            ],
            model_name=f"{scheme}_RMS_TO_COLOUR_MINIMAL",
            standardize=[
                "colour_logN",
                "col_pair_dt_hours_median",
            ],
        )
    )

    # Dynamic-range sensitivity.
    colour_frames.append(
        fit_logit(
            x,
            outcome="colour_robust_central_break",
            predictors=[
                "strict_both",
                "FSRQ",
                "colour_logN",
                "col_pair_dt_hours_median",
                "col_r_mag_range",
            ],
            key_predictors=[
                "strict_both",
                "FSRQ",
            ],
            model_name=f"{scheme}_RMS_TO_COLOUR_PLUS_RANGE",
            standardize=[
                "colour_logN",
                "col_pair_dt_hours_median",
                "col_r_mag_range",
            ],
        )
    )

class_models = pd.concat(class_frames, ignore_index=True)
colour_models = pd.concat(colour_frames, ignore_index=True)

class_models["q_BH_FSRQ_across_schemes"] = bh_qvalues(
    class_models["p_value"].to_numpy(dtype=float)
)

mask_rms = colour_models["predictor"].eq("strict_both")
colour_models.loc[
    mask_rms,
    "q_BH_rms_across_models"
] = bh_qvalues(
    colour_models.loc[
        mask_rms,
        "p_value"
    ].to_numpy(dtype=float)
)

mask_cls = colour_models["predictor"].eq("FSRQ")
colour_models.loc[
    mask_cls,
    "q_BH_FSRQ_across_models"
] = bh_qvalues(
    colour_models.loc[
        mask_cls,
        "p_value"
    ].to_numpy(dtype=float)
)

class_models.to_csv(OUT_CLASS, index=False)
colour_models.to_csv(OUT_COLOUR, index=False)

lines = [
    "BLAZAR_I - STAGE 06A2 CONTROLLED SENSITIVITY SUMMARY",
    "=" * 72,
    "",
    "CLEAN FSRQ CLASS EFFECT BY SEGMENTATION:",
]

for _, rr in class_models.iterrows():
    lines.append(
        f"  {rr['model_name']}: "
        f"N={int(rr['N'])}, "
        f"OR={rr['odds_ratio']:.3f}, "
        f"95%CI={rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}, "
        f"p={rr['p_value']:.3g}, "
        f"q={rr['q_BH_FSRQ_across_schemes']:.3g}"
    )

lines += [
    "",
    "RMS-FLUX -> ROBUST COLOUR BREAK:",
]

for model_name in colour_models["model_name"].dropna().unique():
    xx = colour_models.loc[
        colour_models["model_name"].eq(model_name)
    ]

    rr = xx.loc[
        xx["predictor"].eq("strict_both")
    ].iloc[0]

    rc = xx.loc[
        xx["predictor"].eq("FSRQ")
    ].iloc[0]

    lines.append(
        f"  {model_name}: "
        f"rms OR={rr['odds_ratio']:.3f} "
        f"({rr['or_ci95_low']:.3f}-{rr['or_ci95_high']:.3f}), "
        f"p={rr['p_value']:.3g}, "
        f"q={rr['q_BH_rms_across_models']:.3g}; "
        f"FSRQ OR={rc['odds_ratio']:.3f}, "
        f"p={rc['p_value']:.3g}"
    )

summary = "\n".join(lines)
OUT_SUMMARY.write_text(summary, encoding="utf-8")

print("=" * 78)
print("BLAZAR_I — STAGE 06A2")
print("CONTROLLED RMS–FLUX SEGMENTATION SENSITIVITY")
print("=" * 78)
print()
print(summary)
print()
print("=" * 78)
print("FILES SAVED")
print("=" * 78)
print(OUT_CLASS)
print(OUT_COLOUR)
print(OUT_SUMMARY)
print()
print("STAGE 06A2 COMPLETE")
