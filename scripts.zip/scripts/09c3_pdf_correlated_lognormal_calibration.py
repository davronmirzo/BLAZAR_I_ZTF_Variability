# ============================================================
# BLAZAR_I — STAGE 09C3
# FLUX-PDF CORRELATED-LOGNORMAL NULL / MIXTURE INJECTION CALIBRATION
#
# Purpose:
#   Calibrate the frozen Stage03A robust-double-lognormal gate under
#   observation-conditioned serial correlation and under controlled
#   two-component injections.
#
# Exact Stage03A fitting machinery:
#   Gaussian in flux, k=2
#   Lognormal in flux space, k=2
#   Double-lognormal = 2-component GaussianMixture in ln(F), k=5
#
#   GaussianMixture:
#       n_components=2
#       covariance_type="full"
#       n_init=10
#       max_iter=500
#       reg_covar=1e-4
#       random_state=20260917
#
# Robust-double gate:
#   preferred BIC model == DOUBLE_LOGNORMAL
#   DeltaBIC(second-best - best) >= 10
#   smaller component weight >= 0.10
#   Ashman D >= 2
#
# Scenarios:
#
#   CORRELATED_LOGNORMAL_NULL
#       Single Gaussian OU process in ln(F), sampled at the ACTUAL ZTF times.
#       This is the reviewer-critical null for testing whether serial
#       correlation alone can make a single lognormal look like a mixture.
#
#   MIXTURE_D2P5
#       Continuous-time two-state process with stationary minority weight
#       0.35 and true Ashman D=2.5. Within-state fluctuations are OU.
#
#   MIXTURE_D3P5
#       Same, with true Ashman D=3.5.
#
# Source-specific design:
#   - actual ZTF times
#   - actual fractional photometric-error pattern
#   - observed mean ln(F)
#   - intrinsic ln(F) variance estimated after subtracting mean
#     measurement variance
#   - correlation timescale anchored to frozen Stage03D tau_obs, clipped
#     to an interpretable observational range
#
# The injected mixture preserves approximately the source-specific total
# intrinsic ln(F) variance:
#       sigma_total^2 = sigma_component^2 + w(1-w) Delta_mu^2
#   with Delta_mu / sigma_component = target Ashman D.
#
# Important:
#   - No observed endpoint is overwritten.
#   - The frozen Stage03A GMM random_state is retained exactly.
#   - Simulations are deterministic and resumable per replicate.
#
# Default workload:
#   48 templates x 3 scenarios x 30 reps = 4320 simulated PDF fits.
#
# Outputs:
#   outputs/models/stage09c3_pdf_calibration/*.csv
#   outputs/tables/stage09c3_pdf_simulation_master.csv
#   outputs/tables/stage09c3_pdf_scenario_summary.csv
#   outputs/tables/stage09c3_pdf_template_summary.csv
#   outputs/audit/stage09c3_summary.txt
# ============================================================

from pathlib import Path
import argparse
import math
import time
import zlib
import warnings

import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.exceptions import ConvergenceWarning
from sklearn.mixture import GaussianMixture

warnings.filterwarnings(
    "ignore",
    category=ConvergenceWarning,
)
warnings.filterwarnings(
    "ignore",
    category=RuntimeWarning,
)

ROOT = Path(__file__).resolve().parents[1]

TABLE_DIR = ROOT / "outputs" / "tables"
AUDIT_DIR = ROOT / "outputs" / "audit"
NIGHTLY_DIR = ROOT / "data" / "processed" / "stage02b3_sources"

MODEL_DIR = (
    ROOT
    /
    "outputs"
    /
    "models"
    /
    "stage09c3_pdf_calibration"
)

TEMPLATE_FILE = (
    TABLE_DIR
    /
    "stage09c0_source_filter_template_bank.csv"
)

OUT_MASTER = (
    TABLE_DIR
    /
    "stage09c3_pdf_simulation_master.csv"
)

OUT_SCEN = (
    TABLE_DIR
    /
    "stage09c3_pdf_scenario_summary.csv"
)

OUT_TEMPLATE = (
    TABLE_DIR
    /
    "stage09c3_pdf_template_summary.csv"
)

OUT_SUMMARY = (
    AUDIT_DIR
    /
    "stage09c3_summary.txt"
)

for p in [
    TABLE_DIR,
    AUDIT_DIR,
    MODEL_DIR,
]:
    p.mkdir(
        parents=True,
        exist_ok=True,
    )


# ============================================================
# FROZEN STAGE03A CONFIG
# ============================================================

GMM_RANDOM_STATE = 20260917
GMM_N_INIT = 10
GMM_MAX_ITER = 500
GMM_REG_COVAR = 1.0e-4

ROBUST_DELTA_BIC = 10.0
ROBUST_MIN_WEIGHT = 0.10
ROBUST_MIN_D = 2.0

BASE_SEED = 20260918

SCENARIOS = [
    "CORRELATED_LOGNORMAL_NULL",
    "MIXTURE_D2P5",
    "MIXTURE_D3P5",
]

TRUE_D = {
    "CORRELATED_LOGNORMAL_NULL": np.nan,
    "MIXTURE_D2P5": 2.5,
    "MIXTURE_D3P5": 3.5,
}

MINORITY_WEIGHT = 0.35


# ============================================================
# CLI
# ============================================================

parser = argparse.ArgumentParser()

parser.add_argument(
    "--reps",
    type=int,
    default=30,
    help="Replicates per template/scenario. Default=30.",
)

parser.add_argument(
    "--limit-templates",
    type=int,
    default=None,
    help="Optional pilot limit.",
)

args = parser.parse_args()

if args.reps < 1:
    raise RuntimeError(
        "--reps must be >=1"
    )


# ============================================================
# HELPERS
# ============================================================

def numeric(s):
    return pd.to_numeric(
        s,
        errors="coerce",
    )


def stable_seed(
    template_id,
    scenario,
    rep,
):
    token = (
        f"{BASE_SEED}|"
        f"{template_id}|"
        f"{scenario}|"
        f"{rep}"
    ).encode(
        "utf-8"
    )

    return int(
        zlib.crc32(
            token
        )
        &
        0xFFFFFFFF
    )


def wilson_interval(
    k,
    n,
    z=1.959963984540054,
):
    if n <= 0:
        return (
            np.nan,
            np.nan,
        )

    p = (
        k
        /
        n
    )

    denom = (
        1.0
        +
        z * z / n
    )

    centre = (
        p
        +
        z * z
        /
        (
            2.0 * n
        )
    ) / denom

    half = (
        z
        *
        math.sqrt(
            p
            *
            (
                1.0 - p
            )
            /
            n
            +
            z * z
            /
            (
                4.0
                *
                n
                *
                n
            )
        )
        /
        denom
    )

    return (
        max(
            0.0,
            centre - half,
        ),
        min(
            1.0,
            centre + half,
        ),
    )


def robust_bool(s):
    num = pd.to_numeric(
        s,
        errors="coerce",
    )

    out = pd.Series(
        False,
        index=s.index,
        dtype=bool,
    )

    good = num.notna()

    out.loc[
        good
    ] = (
        num.loc[
            good
        ]
        !=
        0
    )

    rem = (
        ~good
    )

    if rem.any():
        txt = (
            s.loc[
                rem
            ]
            .astype(
                str
            )
            .str.strip()
            .str.lower()
        )

        out.loc[
            rem
        ] = txt.isin(
            [
                "true",
                "t",
                "yes",
                "y",
            ]
        )

    return out


# ============================================================
# EXACT STAGE03A PDF FIT
# ============================================================

def normal_logpdf(
    x,
    mu,
    sigma,
):
    return (
        -0.5
        *
        np.log(
            2.0
            *
            np.pi
        )
        -
        np.log(
            sigma
        )
        -
        0.5
        *
        (
            (
                x - mu
            )
            /
            sigma
        ) ** 2
    )


def choose_model(
    bic_g,
    bic_l,
    bic_d,
):
    vals = {
        "GAUSSIAN": float(
            bic_g
        ),
        "LOGNORMAL": float(
            bic_l
        ),
        "DOUBLE_LOGNORMAL": float(
            bic_d
        ),
    }

    ordered = sorted(
        vals.items(),
        key=lambda kv: kv[1],
    )

    return (
        ordered[0][0],
        float(
            ordered[1][1]
            -
            ordered[0][1]
        ),
    )


def fit_one(
    flux,
):
    f = np.asarray(
        flux,
        dtype=float,
    )

    f = f[
        np.isfinite(
            f
        )
        &
        (
            f > 0
        )
    ]

    n = len(
        f
    )

    if n < 50:
        raise RuntimeError(
            f"Too few positive flux points: N={n}"
        )

    lnf = np.log(
        f
    )

    # Gaussian flux MLE.
    g_mu = float(
        np.mean(
            f
        )
    )

    g_sig = float(
        np.std(
            f,
            ddof=0,
        )
    )

    if (
        not np.isfinite(
            g_sig
        )
        or
        g_sig <= 0
    ):
        raise RuntimeError(
            "Invalid Gaussian sigma."
        )

    ll_g = float(
        normal_logpdf(
            f,
            g_mu,
            g_sig,
        ).sum()
    )

    bic_g = (
        2.0
        *
        math.log(
            n
        )
        -
        2.0
        *
        ll_g
    )

    # Single lognormal MLE in flux space.
    l_mu = float(
        np.mean(
            lnf
        )
    )

    l_sig = float(
        np.std(
            lnf,
            ddof=0,
        )
    )

    if (
        not np.isfinite(
            l_sig
        )
        or
        l_sig <= 0
    ):
        raise RuntimeError(
            "Invalid lognormal sigma."
        )

    ll_l = float(
        (
            normal_logpdf(
                lnf,
                l_mu,
                l_sig,
            )
            -
            lnf
        ).sum()
    )

    bic_l = (
        2.0
        *
        math.log(
            n
        )
        -
        2.0
        *
        ll_l
    )

    # Double lognormal GMM in ln F.
    gm = GaussianMixture(
        n_components=2,
        covariance_type="full",
        n_init=GMM_N_INIT,
        max_iter=GMM_MAX_ITER,
        reg_covar=GMM_REG_COVAR,
        random_state=GMM_RANDOM_STATE,
    )

    gm.fit(
        lnf.reshape(
            -1,
            1,
        )
    )

    means = (
        gm.means_[
            :,
            0
        ]
        .astype(
            float
        )
    )

    order = np.argsort(
        means
    )

    means = means[
        order
    ]

    weights = (
        gm.weights_[
            order
        ]
        .astype(
            float
        )
    )

    variances = (
        gm.covariances_[
            order,
            0,
            0,
        ]
        .astype(
            float
        )
    )

    sigmas = np.sqrt(
        variances
    )

    comp = np.vstack(
        [
            math.log(
                weights[0]
            )
            +
            normal_logpdf(
                lnf,
                means[0],
                sigmas[0],
            ),
            math.log(
                weights[1]
            )
            +
            normal_logpdf(
                lnf,
                means[1],
                sigmas[1],
            ),
        ]
    )

    ll_d = float(
        (
            logsumexp(
                comp,
                axis=0,
            )
            -
            lnf
        ).sum()
    )

    bic_d = (
        5.0
        *
        math.log(
            n
        )
        -
        2.0
        *
        ll_d
    )

    sep = (
        math.sqrt(
            2.0
        )
        *
        abs(
            means[1]
            -
            means[0]
        )
        /
        math.sqrt(
            sigmas[0] ** 2
            +
            sigmas[1] ** 2
        )
    )

    smaller_weight = float(
        min(
            weights[0],
            weights[1],
        )
    )

    pref, delta = choose_model(
        bic_g,
        bic_l,
        bic_d,
    )

    robust = bool(
        pref
        ==
        "DOUBLE_LOGNORMAL"
        and
        delta
        >=
        ROBUST_DELTA_BIC
        and
        smaller_weight
        >=
        ROBUST_MIN_WEIGHT
        and
        sep
        >=
        ROBUST_MIN_D
    )

    return {
        "N_fit": int(
            n
        ),
        "gauss_bic": float(
            bic_g
        ),
        "lnorm_bic": float(
            bic_l
        ),
        "dlnorm_bic": float(
            bic_d
        ),
        "preferred": pref,
        "delta_second": float(
            delta
        ),
        "weight_low": float(
            weights[0]
        ),
        "weight_high": float(
            weights[1]
        ),
        "smaller_weight": smaller_weight,
        "mu_low": float(
            means[0]
        ),
        "mu_high": float(
            means[1]
        ),
        "sigma_low": float(
            sigmas[0]
        ),
        "sigma_high": float(
            sigmas[1]
        ),
        "separation": float(
            sep
        ),
        "robust_double": robust,
        "gmm_converged": bool(
            gm.converged_
        ),
        "gmm_n_iter": int(
            gm.n_iter_
        ),
    }


# ============================================================
# OBSERVATION-CONDITIONED DESIGN
# ============================================================

def build_design(
    template_row,
):
    bid = str(
        template_row[
            "blazar_id"
        ]
    )

    filt = str(
        template_row[
            "filter_name"
        ]
    ).lower()

    path = (
        NIGHTLY_DIR
        /
        f"{bid}_NIGHTLY.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            path
        )

    d = pd.read_parquet(
        path
    )

    x = (
        d.loc[
            d[
                "filter_name"
            ]
            .astype(
                str
            )
            .str.lower()
            .eq(
                filt
            )
        ]
        .copy()
        .sort_values(
            "hmjd"
        )
        .reset_index(
            drop=True
        )
    )

    t = numeric(
        x[
            "hmjd"
        ]
    ).to_numpy(
        dtype=float
    )

    flux = numeric(
        x[
            "flux_jy"
        ]
    ).to_numpy(
        dtype=float
    )

    fluxerr = numeric(
        x[
            "fluxerr_jy"
        ]
    ).to_numpy(
        dtype=float
    )

    good = (
        np.isfinite(
            t
        )
        &
        np.isfinite(
            flux
        )
        &
        np.isfinite(
            fluxerr
        )
        &
        (
            flux > 0
        )
        &
        (
            fluxerr >= 0
        )
    )

    t = t[
        good
    ]

    flux = flux[
        good
    ]

    fluxerr = fluxerr[
        good
    ]

    if len(
        t
    ) < 100:
        raise RuntimeError(
            f"{bid} {filt}: expected >=100 nightly points."
        )

    lnf = np.log(
        flux
    )

    mu_ln = float(
        np.mean(
            lnf
        )
    )

    var_obs = float(
        np.var(
            lnf,
            ddof=1,
        )
    )

    fracerr = (
        fluxerr
        /
        flux
    )

    fracerr = np.clip(
        fracerr,
        1.0e-5,
        0.30,
    )

    mean_meas_var_ln = float(
        np.mean(
            fracerr ** 2
        )
    )

    var_intrinsic = max(
        var_obs
        -
        mean_meas_var_ln,
        0.03 ** 2,
    )

    sigma_total = math.sqrt(
        var_intrinsic
    )

    sigma_total_raw = sigma_total

    sigma_total = float(
        np.clip(
            sigma_total,
            0.03,
            1.25,
        )
    )

    baseline = float(
        t[-1]
        -
        t[0]
    )

    cadence = float(
        np.median(
            np.diff(
                t
            )
        )
    )

    tau_frozen = numeric(
        pd.Series(
            [
                template_row[
                    "tau_obs_days"
                ]
            ]
        )
    ).iloc[
        0
    ]

    tau_lo = max(
        3.0
        *
        cadence,
        1.0,
    )

    tau_hi = max(
        tau_lo,
        0.08
        *
        baseline,
    )

    if (
        not np.isfinite(
            tau_frozen
        )
        or
        tau_frozen <= 0
    ):
        tau_frozen = math.sqrt(
            tau_lo
            *
            tau_hi
        )

    tau_corr = float(
        np.clip(
            tau_frozen,
            tau_lo,
            tau_hi,
        )
    )

    tau_state = float(
        np.clip(
            2.0
            *
            tau_corr,
            max(
                10.0
                *
                cadence,
                3.0,
            ),
            max(
                10.0
                *
                cadence,
                0.10
                *
                baseline,
            ),
        )
    )

    return {
        "t": t,
        "mu_ln": mu_ln,
        "sigma_total": sigma_total,
        "sigma_total_raw": sigma_total_raw,
        "sigma_total_clipped": bool(
            not np.isclose(
                sigma_total,
                sigma_total_raw,
            )
        ),
        "fracerr": fracerr,
        "baseline": baseline,
        "cadence": cadence,
        "tau_corr": tau_corr,
        "tau_frozen": float(
            tau_frozen
        ),
        "tau_state": tau_state,
    }


# ============================================================
# SIMULATION HELPERS
# ============================================================

def simulate_ou_standard(
    rng,
    t,
    tau,
):
    n = len(
        t
    )

    z = np.empty(
        n,
        dtype=float,
    )

    z[0] = rng.normal()

    for i in range(
        1,
        n,
    ):
        dt = (
            t[i]
            -
            t[i - 1]
        )

        a = math.exp(
            -dt
            /
            tau
        )

        q = max(
            0.0,
            1.0
            -
            a ** 2,
        )

        z[i] = (
            a
            *
            z[i - 1]
            +
            rng.normal(
                0.0,
                math.sqrt(
                    q
                ),
            )
        )

    return z


def simulate_ctmc_states(
    rng,
    t,
    pi_low,
    tau_state,
):
    n = len(
        t
    )

    state = np.empty(
        n,
        dtype=int,
    )

    state[0] = (
        0
        if
        rng.random()
        <
        pi_low
        else
        1
    )

    pi_high = (
        1.0
        -
        pi_low
    )

    for i in range(
        1,
        n,
    ):
        dt = (
            t[i]
            -
            t[i - 1]
        )

        e = math.exp(
            -dt
            /
            tau_state
        )

        if state[
            i - 1
        ] == 0:
            p_low = (
                pi_low
                +
                pi_high
                *
                e
            )

        else:
            p_low = (
                pi_low
                *
                (
                    1.0
                    -
                    e
                )
            )

        state[i] = (
            0
            if
            rng.random()
            <
            p_low
            else
            1
        )

    return state


def simulate_flux(
    rng,
    design,
    scenario,
):
    t = design[
        "t"
    ]

    mu_ln = design[
        "mu_ln"
    ]

    sigma_total = design[
        "sigma_total"
    ]

    fracerr = design[
        "fracerr"
    ]

    z = simulate_ou_standard(
        rng,
        t,
        design[
            "tau_corr"
        ],
    )

    if scenario == "CORRELATED_LOGNORMAL_NULL":
        ln_true = (
            mu_ln
            +
            sigma_total
            *
            z
        )

        realized_low_fraction = np.nan
        sigma_component = sigma_total
        delta_mu_true = 0.0

    else:
        d_target = TRUE_D[
            scenario
        ]

        w = MINORITY_WEIGHT

        sigma_component = (
            sigma_total
            /
            math.sqrt(
                1.0
                +
                w
                *
                (
                    1.0 - w
                )
                *
                d_target ** 2
            )
        )

        delta_mu_true = (
            d_target
            *
            sigma_component
        )

        mu_low = (
            mu_ln
            -
            (
                1.0 - w
            )
            *
            delta_mu_true
        )

        mu_high = (
            mu_ln
            +
            w
            *
            delta_mu_true
        )

        states = simulate_ctmc_states(
            rng,
            t,
            pi_low=w,
            tau_state=design[
                "tau_state"
            ],
        )

        state_mu = np.where(
            states == 0,
            mu_low,
            mu_high,
        )

        ln_true = (
            state_mu
            +
            sigma_component
            *
            z
        )

        realized_low_fraction = float(
            np.mean(
                states
                ==
                0
            )
        )

    flux_true = np.exp(
        ln_true
    )

    # Positive multiplicative measurement perturbation approximating
    # source-specific fractional flux uncertainties.
    eps_ln = rng.normal(
        0.0,
        fracerr,
    )

    flux_obs = (
        flux_true
        *
        np.exp(
            eps_ln
            -
            0.5
            *
            fracerr ** 2
        )
    )

    return {
        "flux_obs": flux_obs,
        "realized_low_fraction": realized_low_fraction,
        "sigma_component_true": float(
            sigma_component
        ),
        "delta_mu_true": float(
            delta_mu_true
        ),
    }


# ============================================================
# ONE REPLICATE
# ============================================================

def run_one(
    template_row,
    design,
    scenario,
    rep,
):
    template_id = str(
        template_row[
            "template_id"
        ]
    )

    rng = np.random.default_rng(
        stable_seed(
            template_id,
            scenario,
            rep,
        )
    )

    sim = simulate_flux(
        rng,
        design,
        scenario,
    )

    fit = fit_one(
        sim[
            "flux_obs"
        ]
    )

    row = {
        "template_id": template_id,
        "blazar_id": str(
            template_row[
                "blazar_id"
            ]
        ),
        "blazar_class": template_row[
            "blazar_class"
        ],
        "filter_name": str(
            template_row[
                "filter_name"
            ]
        ),
        "scenario": scenario,
        "replicate": int(
            rep
        ),
        "N_nightly": int(
            len(
                design[
                    "t"
                ]
            )
        ),
        "baseline_days": float(
            design[
                "baseline"
            ]
        ),
        "median_cadence_days": float(
            design[
                "cadence"
            ]
        ),
        "tau_corr_days": float(
            design[
                "tau_corr"
            ]
        ),
        "tau_state_days": float(
            design[
                "tau_state"
            ]
        ),
        "sigma_ln_total_true": float(
            design[
                "sigma_total"
            ]
        ),
        "sigma_ln_component_true": float(
            sim[
                "sigma_component_true"
            ]
        ),
        "true_ashman_D": (
            float(
                TRUE_D[
                    scenario
                ]
            )
            if
            np.isfinite(
                TRUE_D[
                    scenario
                ]
            )
            else
            np.nan
        ),
        "true_delta_mu_lnflux": float(
            sim[
                "delta_mu_true"
            ]
        ),
        "realized_low_state_fraction": sim[
            "realized_low_fraction"
        ],
        "preferred_bic_model": fit[
            "preferred"
        ],
        "delta_bic_second_minus_best": fit[
            "delta_second"
        ],
        "fitted_smaller_weight": fit[
            "smaller_weight"
        ],
        "fitted_ashman_D": fit[
            "separation"
        ],
        "robust_double": fit[
            "robust_double"
        ],
        "gmm_converged": fit[
            "gmm_converged"
        ],
        "gmm_n_iter": fit[
            "gmm_n_iter"
        ],
        "fit_status": "OK",
    }

    return row


# ============================================================
# LOAD TEMPLATE BANK
# ============================================================

if not TEMPLATE_FILE.exists():
    raise FileNotFoundError(
        TEMPLATE_FILE
    )

templates = pd.read_csv(
    TEMPLATE_FILE,
    low_memory=False,
)

templates[
    "blazar_id"
] = (
    templates[
        "blazar_id"
    ]
    .astype(
        str
    )
)

templates[
    "filter_name"
] = (
    templates[
        "filter_name"
    ]
    .astype(
        str
    )
    .str.lower()
)

if args.limit_templates is not None:
    templates = templates.head(
        args.limit_templates
    ).copy()

if len(
    templates
) == 0:
    raise RuntimeError(
        "No templates selected."
    )

print(
    "=" * 80
)

print(
    "BLAZAR_I — STAGE 09C3 FLUX-PDF CALIBRATION"
)

print(
    "=" * 80
)

print(
    "Templates =",
    len(
        templates
    ),
)

print(
    "Scenarios =",
    len(
        SCENARIOS
    ),
)

print(
    "Replicates/template/scenario =",
    args.reps,
)

print(
    "Target simulations =",
    len(
        templates
    )
    *
    len(
        SCENARIOS
    )
    *
    args.reps,
)


# ============================================================
# RESUMABLE LOOP
# ============================================================

all_frames = []

cell_index = 0

n_cells = (
    len(
        templates
    )
    *
    len(
        SCENARIOS
    )
)

t0 = time.time()

for _, template_row in templates.iterrows():
    template_id = str(
        template_row[
            "template_id"
        ]
    )

    design = build_design(
        template_row
    )

    for scenario in SCENARIOS:
        cell_index += 1

        cell_file = (
            MODEL_DIR
            /
            f"{template_id}_{scenario}.csv"
        )

        if cell_file.exists():
            prev = pd.read_csv(
                cell_file,
                low_memory=False,
            )
        else:
            prev = pd.DataFrame()

        done_reps = set()

        if (
            len(
                prev
            )
            and
            "replicate"
            in prev.columns
        ):
            done_reps = set(
                numeric(
                    prev[
                        "replicate"
                    ]
                )
                .dropna()
                .astype(
                    int
                )
                .tolist()
            )

        rows = []

        for rep in range(
            1,
            args.reps + 1,
        ):
            if rep in done_reps:
                continue

            try:
                row = run_one(
                    template_row,
                    design,
                    scenario,
                    rep,
                )

            except Exception as exc:
                row = {
                    "template_id": template_id,
                    "blazar_id": template_row[
                        "blazar_id"
                    ],
                    "blazar_class": template_row[
                        "blazar_class"
                    ],
                    "filter_name": template_row[
                        "filter_name"
                    ],
                    "scenario": scenario,
                    "replicate": int(
                        rep
                    ),
                    "fit_status": (
                        f"EXCEPTION:"
                        f"{type(exc).__name__}:"
                        f"{exc}"
                    ),
                }

            rows.append(
                row
            )

            current = pd.concat(
                [
                    prev,
                    pd.DataFrame(
                        rows
                    ),
                ],
                ignore_index=True,
            )

            current = (
                current
                .sort_values(
                    "replicate"
                )
                .drop_duplicates(
                    "replicate",
                    keep="last",
                )
            )

            current.to_csv(
                cell_file,
                index=False,
            )

        final_cell = pd.read_csv(
            cell_file,
            low_memory=False,
        )

        final_cell = final_cell.loc[
            numeric(
                final_cell[
                    "replicate"
                ]
            )
            <=
            args.reps
        ].copy()

        all_frames.append(
            final_cell
        )

        elapsed = (
            time.time()
            -
            t0
        )

        print(
            f"Cell {cell_index}/{n_cells} "
            f"{template_id} {scenario}: "
            f"saved_reps={len(final_cell)} "
            f"elapsed={elapsed/60.0:.1f} min"
        )


# ============================================================
# AGGREGATE
# ============================================================

master = pd.concat(
    all_frames,
    ignore_index=True,
)

master.to_csv(
    OUT_MASTER,
    index=False,
)

master[
    "fit_ok"
] = (
    master[
        "fit_status"
    ]
    .astype(
        str
    )
    .eq(
        "OK"
    )
)

master[
    "robust_bool"
] = robust_bool(
    master[
        "robust_double"
    ]
)

master[
    "double_preferred_bool"
] = (
    master[
        "preferred_bic_model"
    ]
    .astype(
        str
    )
    .eq(
        "DOUBLE_LOGNORMAL"
    )
)


# ============================================================
# SCENARIO SUMMARY
# ============================================================

scenario_rows = []

for scenario, g in master.groupby(
    "scenario"
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    n = len(
        ok
    )

    k_double = int(
        ok[
            "double_preferred_bool"
        ].sum()
    )

    k_robust = int(
        ok[
            "robust_bool"
        ].sum()
    )

    double_lo, double_hi = wilson_interval(
        k_double,
        n,
    )

    robust_lo, robust_hi = wilson_interval(
        k_robust,
        n,
    )

    row = {
        "scenario": scenario,
        "N_simulations": len(
            g
        ),
        "N_fit_ok": n,
        "fit_ok_fraction": (
            n
            /
            len(
                g
            )
            if len(
                g
            )
            else np.nan
        ),
        "double_preferred_N": k_double,
        "double_preferred_fraction": (
            k_double
            /
            n
            if n
            else np.nan
        ),
        "double_preferred_ci95_low": double_lo,
        "double_preferred_ci95_high": double_hi,
        "robust_double_N": k_robust,
        "robust_double_fraction": (
            k_robust
            /
            n
            if n
            else np.nan
        ),
        "robust_double_ci95_low": robust_lo,
        "robust_double_ci95_high": robust_hi,
        "median_delta_bic_second": (
            numeric(
                ok[
                    "delta_bic_second_minus_best"
                ]
            ).median()
            if n
            else np.nan
        ),
        "median_fitted_D": (
            numeric(
                ok[
                    "fitted_ashman_D"
                ]
            ).median()
            if n
            else np.nan
        ),
        "median_fitted_smaller_weight": (
            numeric(
                ok[
                    "fitted_smaller_weight"
                ]
            ).median()
            if n
            else np.nan
        ),
    }

    if scenario != "CORRELATED_LOGNORMAL_NULL":
        realized = numeric(
            ok[
                "realized_low_state_fraction"
            ]
        ).dropna()

        true_d = float(
            TRUE_D[
                scenario
            ]
        )

        fitted_d = numeric(
            ok[
                "fitted_ashman_D"
            ]
        ).dropna()

        row.update({
            "target_D": true_d,
            "median_realized_low_state_fraction": (
                realized.median()
                if len(
                    realized
                )
                else np.nan
            ),
            "median_fitted_D_over_true": (
                (
                    fitted_d
                    /
                    true_d
                ).median()
                if len(
                    fitted_d
                )
                else np.nan
            ),
        })

    scenario_rows.append(
        row
    )

scenario_summary = pd.DataFrame(
    scenario_rows
)

scenario_summary.to_csv(
    OUT_SCEN,
    index=False,
)


# ============================================================
# TEMPLATE SUMMARY
# ============================================================

template_rows = []

for (
    template_id,
    scenario,
), g in master.groupby(
    [
        "template_id",
        "scenario",
    ]
):
    ok = g.loc[
        g[
            "fit_ok"
        ]
    ].copy()

    template_rows.append({
        "template_id": template_id,
        "scenario": scenario,
        "N_simulations": len(
            g
        ),
        "N_fit_ok": len(
            ok
        ),
        "double_preferred_fraction": (
            float(
                ok[
                    "double_preferred_bool"
                ].mean()
            )
            if len(
                ok
            )
            else np.nan
        ),
        "robust_double_fraction": (
            float(
                ok[
                    "robust_bool"
                ].mean()
            )
            if len(
                ok
            )
            else np.nan
        ),
        "median_delta_bic_second": (
            numeric(
                ok[
                    "delta_bic_second_minus_best"
                ]
            ).median()
            if len(
                ok
            )
            else np.nan
        ),
        "median_fitted_D": (
            numeric(
                ok[
                    "fitted_ashman_D"
                ]
            ).median()
            if len(
                ok
            )
            else np.nan
        ),
        "median_fitted_smaller_weight": (
            numeric(
                ok[
                    "fitted_smaller_weight"
                ]
            ).median()
            if len(
                ok
            )
            else np.nan
        ),
    })

template_summary = pd.DataFrame(
    template_rows
)

template_summary.to_csv(
    OUT_TEMPLATE,
    index=False,
)


# ============================================================
# FINAL SUMMARY
# ============================================================

def get_scenario(
    name,
):
    hit = scenario_summary.loc[
        scenario_summary[
            "scenario"
        ].eq(
            name
        )
    ]

    if len(
        hit
    ) != 1:
        return None

    return hit.iloc[
        0
    ]


lines = [
    "BLAZAR_I - STAGE 09C3 FINAL SUMMARY",
    "=" * 80,
    "",
    "Flux-PDF correlated-lognormal null / mixture injection calibration",
    "",
    f"Templates                       : {len(templates)}",
    f"Replicates/template/scenario    : {args.reps}",
    f"Total simulations               : {len(master)}",
    "",
]

null = get_scenario(
    "CORRELATED_LOGNORMAL_NULL"
)

if null is not None:
    lines += [
        "CORRELATED_LOGNORMAL_NULL:",
        f"  fit success fraction          : {null['fit_ok_fraction']:.4f}",
        f"  double preferred false pos.   : {null['double_preferred_fraction']:.4f} [{null['double_preferred_ci95_low']:.4f}, {null['double_preferred_ci95_high']:.4f}]",
        f"  ROBUST-double false positive  : {null['robust_double_fraction']:.4f} [{null['robust_double_ci95_low']:.4f}, {null['robust_double_ci95_high']:.4f}]",
        f"  median DeltaBIC(second-best)  : {null['median_delta_bic_second']:.3f}",
        f"  median fitted Ashman D        : {null['median_fitted_D']:.3f}",
        "",
    ]

for name in [
    "MIXTURE_D2P5",
    "MIXTURE_D3P5",
]:
    r = get_scenario(
        name
    )

    if r is None:
        continue

    lines += [
        f"{name}:",
        f"  double preferred recovery     : {r['double_preferred_fraction']:.4f} [{r['double_preferred_ci95_low']:.4f}, {r['double_preferred_ci95_high']:.4f}]",
        f"  ROBUST-double recovery        : {r['robust_double_fraction']:.4f} [{r['robust_double_ci95_low']:.4f}, {r['robust_double_ci95_high']:.4f}]",
        f"  target Ashman D               : {r['target_D']:.2f}",
        f"  median fitted D               : {r['median_fitted_D']:.3f}",
        f"  median fitted D / true D      : {r['median_fitted_D_over_true']:.3f}",
        f"  median fitted smaller weight  : {r['median_fitted_smaller_weight']:.3f}",
        f"  median realized low fraction  : {r['median_realized_low_state_fraction']:.3f}",
        "",
    ]

lines += [
    "Interpretation locks:",
    "  - The correlated-lognormal null directly tests the concern that",
    "    serially correlated nightly points can inflate ordinary BIC support",
    "    for a double-lognormal model.",
    "  - Mixture injections preserve approximately each template's total",
    "    intrinsic ln(F) variance while imposing known component separation.",
    "  - Recovery is a detectability calibration, not evidence that observed",
    "    double-lognormal labels correspond to literal two-state physics.",
    "  - Final manuscript incidence claims must remain explicitly",
    "    sampling- and correlation-sensitive.",
    "",
    "Files saved:",
    f"  {OUT_MASTER}",
    f"  {OUT_SCEN}",
    f"  {OUT_TEMPLATE}",
    "",
    "Checkpoint directory:",
    f"  {MODEL_DIR}",
    "",
    "Next:",
    "  STAGE 09C4 — rms-flux additive-null / multiplicative injection.",
    "",
    "STAGE 09C3 COMPLETE",
]

summary = "\n".join(
    lines
)

OUT_SUMMARY.write_text(
    summary,
    encoding="utf-8",
)

print(
    summary
)
