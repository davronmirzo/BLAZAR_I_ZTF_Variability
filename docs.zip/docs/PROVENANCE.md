# Provenance and interpretation locks

This archive is a curated supporting research object for the BLAZAR_I analysis.

Final interpretation rules:

- The principal result is a population-level rest-frame DRW-timescale association.
- It must not be described as a causal or intrinsic effect of the optical class label.
- LSP-only attenuation demonstrates that SED/population composition contributes materially.
- Raw rms-flux / colour-curvature co-occurrence is not retained after optical dynamic-range
  adjustment in either temporal half.
- Double-lognormal flux-PDF classifications are descriptive mixture-like structure, not a
  physical two-state fraction.
- Early and late temporal blocks reuse the same sources and are therefore not statistically
  independent replication samples.
- Injection–recovery calibration defines the interpretation limits of binary diagnostic
  incidences.

The machine-readable CSV files in `tables/` are the compact numerical reference for the final
reported results.
