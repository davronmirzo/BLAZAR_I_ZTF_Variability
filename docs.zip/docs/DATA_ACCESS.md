# External data access and local layout

This Zenodo archive does not redistribute raw bulk survey/catalog products.

The analysis uses public external inputs, including:

- 4LAC-DR3 high-latitude AGN catalogue;
- 4FGL-DR4 source catalogue (`gll_psc_v35.fit`);
- ZTF DR24 optical light curves;
- Pan-STARRS1 photometric products used for the host-extension proxy.

Expected local project structure:

```text
project_root/
├── data/
│   ├── raw/
│   │   ├── fermi/
│   │   └── ztf/
│   ├── interim/
│   └── processed/
├── outputs/
│   ├── audit/
│   ├── tables/
│   ├── figures/
│   └── models/
└── scripts/
```

The scripts preserve the project-relative paths used in the original analysis.
Users should obtain the external data from the original public providers and retain
the associated catalogue/version provenance.
