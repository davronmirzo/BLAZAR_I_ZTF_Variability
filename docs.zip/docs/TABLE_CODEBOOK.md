# Table codebook

## `table1_sample_overview.csv`
Final analysis sample and principal diagnostic incidences.

## `table2_drw_temporal.csv`
FSRQ-to-BL-Lac factors for rest-frame DRW timescale analyses.
A factor below 1 means the fitted FSRQ timescale is shorter.

## `table3_crossdiag_temporal.csv`
Early/late odds ratios for the rms-flux / colour-curvature association,
including optical dynamic-range adjustment.

## `table4_calibration.csv`
Observation-conditioned null false-positive rates and representative injection-recovery rates.

## `final_claim_hierarchy.csv`
The final hierarchy used to govern article-level interpretation.
