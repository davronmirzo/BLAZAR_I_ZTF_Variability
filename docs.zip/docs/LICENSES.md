# Licensing

This archive uses mixed licensing.

- `scripts/` — MIT License
- `tables/`, `figures/`, `metadata/`, and `docs/` — CC BY 4.0

See the root license files for the full declarations.
