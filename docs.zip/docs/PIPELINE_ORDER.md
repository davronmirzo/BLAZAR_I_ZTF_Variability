# Analysis pipeline order

The stage numbers are retained so that the analysis history is explicit.

## 1. ZTF acquisition and cleaning
- `02b2_download_ztf_lightcurves_PER_SOURCE.py`
- `02b3_clean_homogenize_select_RESUME.py`

## 2. Core diagnostics
- `03a_variability_fluxpdf_RESUME.py`
- `03b_rmflux_RESUME.py`
- `03c_colour_break_RESUME.py`
- `03d_drw_timescale_RESUME.py`
- `04_population_synthesis.py`
- `05_controlled_population_inference.py`
- `05c_clean_primary_inference.py`

## 3. Robustness analyses
### rms-flux
- `06a_rmflux_segmentation_sensitivity.py`
- `06a2_controlled_rmflux_sensitivity.py`
- `06a3_dynamic_range_robustness.py`

### colour curvature
- `06b0_colour_pair_schema_audit.py`
- `06b1_colour_timing_erroraware_RESUME.py`
- `06b2_colour_class_controlled.py`
- `06b3_colour_break_bootstrap_RESUME.py`

### DRW
- `06c0_drw_schema_audit_FIXED.py`
- `06c0b_nightly_drw_input_audit.py`
- `06c1_drw_likelihood_equivalence.py`
- `06c2_drw_sampling_sensitivity_RESUME.py`
- `06c3_drw_restframe_class_robustness.py`

### selection/common support
- `06d1_selection_function.py`
- `06d4a_sky_support_audit.py`
- `06d4b_common_support_propensity_balance.py`
- `06d5_common_support_endpoint_robustness.py`

### PDF sampling sensitivity
- `06e1_pdf_likelihood_equivalence.py`
- `06e1b_pdf_optimizer_equivalence.py`
- `06e2_pdf_sampling_sensitivity_RESUME.py`
- `06e3_equaln50_montecarlo_RESUME.py`

## 4. Confounder and source-clustered inference
- `09a0_q1_confounder_schema_audit.py`
- `09a1_build_q1_confounder_master_FIXED.py`
- `09a2_ps1_host_proxy_augmentation.py`
- `09a3_q1_nested_confounder_models.py`
- `09a4_overlap_aware_confounder_decomposition.py`
- `09b_drw_clustered_rebuild.py`

## 5. Observation-conditioned calibration
- `09c0_build_injection_template_bank_FIXED.py`
- `09c1_drw_injection_recovery.py`
- `09c1b_repair_drw_recovery_summary.py`
- `09c2_colour_break_injection_recovery.py`
- `09c3_pdf_correlated_lognormal_calibration.py`
- `09c4_rmflux_injection_recovery_FIXED.py`
- `09c5_integrated_calibration_ledger.py`

## 6. Temporal validation
- `09d0_temporal_split_eligibility_audit.py`
- `09d1a_flagship_temporal_replication.py`
- `09d1b_drw_temporal_replication.py`
- `09d1c_repair_temporal_drw_gamma_FIXED.py`
- `09d2_integrated_temporal_validation.py`

## 7. Figure generation
- `07b_generate_main_figures.py`
- `regenerate_figures.py` (where available)

Manuscript-building and journal-formatting scripts are intentionally excluded.
